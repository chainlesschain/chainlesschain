/**
 * Skill Marketplace commands (Phase 65)
 * chainlesschain marketplace status-types|invocation-statuses|publish|list|
 *                             show|status|record|invocations|stats
 */

import chalk from "chalk";
import { logger } from "../lib/logger.js";
import { bootstrap, shutdown } from "../runtime/bootstrap.js";
import {
  ensureMarketplaceTables,
  listServiceStatus,
  listInvocationStatus,
  publishService,
  getService,
  listServices,
  updateServiceStatus,
  recordInvocation,
  listInvocations,
  getInvocationStats,
  // V2 (Phase 65)
  SERVICE_STATUS_V2,
  INVOCATION_STATUS_V2,
  PRICING_MODEL_V2,
  MARKETPLACE_DEFAULT_MAX_CONCURRENT_INVOCATIONS,
  setMaxConcurrentInvocations,
  getMaxConcurrentInvocations,
  getActiveInvocationCount,
  beginInvocationV2,
  startInvocation,
  completeInvocationV2,
  failInvocationV2,
  timeoutInvocationV2,
  setInvocationStatus,
  getMarketplaceStatsV2,
} from "../lib/skill-marketplace.js";
import {
  openMultisigManager,
  defaultMultisigDbPath,
  defaultMultisigLogPath,
  readSecretKey,
} from "../lib/multisig-runtime.js";

// v1.2 m-of-n Phase 2 — marketplace.purchase 大额触发阈值。设计文档 §1 写的
// "商品 price ≥ ¥1000"。fen = ¥ × 100。可由命令行 --threshold-fen 覆盖（测试用）。
export const LARGE_PURCHASE_THRESHOLD_FEN = 100_000;
const MULTISIG_DOMAIN = "marketplace.purchase";

function _dbFromCtx(ctx) {
  if (!ctx.db) {
    logger.error("Database not available");
    process.exit(1);
  }
  const db = ctx.db.getDatabase();
  ensureMarketplaceTables(db);
  return db;
}

function _printService(s) {
  logger.log(
    `  ${chalk.bold("ID:")}           ${chalk.cyan(s.id.slice(0, 8))}`,
  );
  logger.log(`  ${chalk.bold("Name:")}         ${s.name} @ ${s.version}`);
  logger.log(`  ${chalk.bold("Status:")}       ${s.status}`);
  if (s.description) {
    logger.log(`  ${chalk.bold("Description:")}  ${s.description}`);
  }
  if (s.endpoint) {
    logger.log(`  ${chalk.bold("Endpoint:")}     ${s.endpoint}`);
  }
  if (s.owner) {
    logger.log(`  ${chalk.bold("Owner:")}        ${s.owner}`);
  }
  logger.log(`  ${chalk.bold("Invocations:")}  ${s.invocationCount}`);
}

export function registerMarketplaceCommand(program) {
  const mp = program
    .command("marketplace")
    .description(
      "Skill marketplace — publish skill services, record invocations, view stats",
    );

  mp.command("status-types")
    .description("List known service statuses")
    .option("--json", "Output as JSON")
    .action((options) => {
      const statuses = listServiceStatus();
      if (options.json) {
        console.log(JSON.stringify(statuses, null, 2));
      } else {
        for (const s of statuses) logger.log(`  ${chalk.cyan(s)}`);
      }
    });

  mp.command("invocation-statuses")
    .description("List known invocation statuses")
    .option("--json", "Output as JSON")
    .action((options) => {
      const statuses = listInvocationStatus();
      if (options.json) {
        console.log(JSON.stringify(statuses, null, 2));
      } else {
        for (const s of statuses) logger.log(`  ${chalk.cyan(s)}`);
      }
    });

  mp.command("publish <name>")
    .description("Publish a skill service")
    .option("-v, --version <v>", "Version", "1.0.0")
    .option("-d, --description <text>", "Description", "")
    .option("-e, --endpoint <url>", "Invocation endpoint")
    .option("-o, --owner <did>", "Service owner (DID)")
    .option("-p, --pricing <json>", "Pricing info (JSON)")
    .option(
      "-s, --status <s>",
      "Initial status (draft|published|deprecated|suspended)",
      "published",
    )
    .option("--json", "Output as JSON")
    .action(async (name, options) => {
      try {
        const ctx = await bootstrap({ verbose: program.opts().verbose });
        const db = _dbFromCtx(ctx);
        const pricing = options.pricing ? JSON.parse(options.pricing) : null;
        const service = publishService(db, {
          name,
          version: options.version,
          description: options.description,
          endpoint: options.endpoint,
          owner: options.owner,
          pricing,
          status: options.status,
        });
        if (options.json) {
          console.log(JSON.stringify(service, null, 2));
        } else {
          logger.success("Service published");
          _printService(service);
        }
        await shutdown();
      } catch (err) {
        logger.error(`Failed: ${err.message}`);
        process.exit(1);
      }
    });

  mp.command("list")
    .description("List skill services")
    .option(
      "-s, --status <s>",
      "Filter by status (draft|published|deprecated|suspended)",
    )
    .option("-o, --owner <did>", "Filter by owner DID")
    .option("-n, --name <substring>", "Name substring filter")
    .option("--limit <n>", "Maximum entries", parseInt, 50)
    .option("--json", "Output as JSON")
    .action(async (options) => {
      try {
        const ctx = await bootstrap({ verbose: program.opts().verbose });
        _dbFromCtx(ctx);
        const rows = listServices({
          status: options.status,
          owner: options.owner,
          name: options.name,
          limit: options.limit,
        });
        if (options.json) {
          console.log(JSON.stringify(rows, null, 2));
        } else if (rows.length === 0) {
          logger.info("No services.");
        } else {
          for (const s of rows) {
            logger.log(
              `  ${chalk.cyan(s.id.slice(0, 8))} [${s.status.padEnd(10)}] ${chalk.bold(s.name.padEnd(22))} v${s.version.padEnd(8)} invocations=${s.invocationCount}`,
            );
          }
        }
        await shutdown();
      } catch (err) {
        logger.error(`Failed: ${err.message}`);
        process.exit(1);
      }
    });

  mp.command("show <service-id>")
    .description("Show full details of a skill service")
    .option("--json", "Output as JSON")
    .action(async (serviceId, options) => {
      try {
        const ctx = await bootstrap({ verbose: program.opts().verbose });
        _dbFromCtx(ctx);
        const service = getService(serviceId);
        if (!service) {
          logger.error(`Service not found: ${serviceId}`);
          process.exit(1);
        }
        if (options.json) {
          console.log(JSON.stringify(service, null, 2));
        } else {
          _printService(service);
        }
        await shutdown();
      } catch (err) {
        logger.error(`Failed: ${err.message}`);
        process.exit(1);
      }
    });

  mp.command("status <service-id> <new-status>")
    .description(
      "Transition service status (draft|published|deprecated|suspended)",
    )
    .option("--json", "Output as JSON")
    .action(async (serviceId, newStatus, options) => {
      try {
        const ctx = await bootstrap({ verbose: program.opts().verbose });
        const db = _dbFromCtx(ctx);
        const service = updateServiceStatus(db, serviceId, newStatus);
        if (options.json) {
          console.log(JSON.stringify(service, null, 2));
        } else {
          logger.success(`Status updated → ${service.status}`);
        }
        await shutdown();
      } catch (err) {
        logger.error(`Failed: ${err.message}`);
        process.exit(1);
      }
    });

  mp.command("record <service-id>")
    .description("Record a skill invocation against a published service")
    .option("-c, --caller <did>", "Caller DID")
    .option("-i, --input <json>", "Invocation input (JSON)")
    .option("-o, --output <json>", "Invocation output (JSON)")
    .option(
      "-s, --status <s>",
      "Status (pending|running|success|failed|timeout)",
      "success",
    )
    .option("-d, --duration-ms <n>", "Duration in ms", parseInt)
    .option("-e, --error <text>", "Error message when failed")
    .option("--json", "Output as JSON")
    .action(async (serviceId, options) => {
      try {
        const ctx = await bootstrap({ verbose: program.opts().verbose });
        const db = _dbFromCtx(ctx);
        const input = options.input ? JSON.parse(options.input) : null;
        const output = options.output ? JSON.parse(options.output) : null;
        const inv = recordInvocation(db, {
          serviceId,
          callerId: options.caller,
          input,
          output,
          status: options.status,
          durationMs: options.durationMs,
          error: options.error,
        });
        if (options.json) {
          console.log(JSON.stringify(inv, null, 2));
        } else {
          logger.success("Invocation recorded");
          logger.log(
            `  ${chalk.bold("ID:")}        ${chalk.cyan(inv.id.slice(0, 8))}`,
          );
          logger.log(
            `  ${chalk.bold("Service:")}   ${inv.serviceId.slice(0, 8)}`,
          );
          logger.log(`  ${chalk.bold("Status:")}    ${inv.status}`);
          if (inv.durationMs != null) {
            logger.log(`  ${chalk.bold("Duration:")}  ${inv.durationMs}ms`);
          }
        }
        await shutdown();
      } catch (err) {
        logger.error(`Failed: ${err.message}`);
        process.exit(1);
      }
    });

  mp.command("invocations")
    .description("List skill invocations")
    .option("-s, --service <id>", "Filter by service")
    .option("-c, --caller <did>", "Filter by caller")
    .option("-S, --status <s>", "Filter by status")
    .option("--limit <n>", "Maximum entries", parseInt, 50)
    .option("--json", "Output as JSON")
    .action(async (options) => {
      try {
        const ctx = await bootstrap({ verbose: program.opts().verbose });
        _dbFromCtx(ctx);
        const rows = listInvocations({
          serviceId: options.service,
          callerId: options.caller,
          status: options.status,
          limit: options.limit,
        });
        if (options.json) {
          console.log(JSON.stringify(rows, null, 2));
        } else if (rows.length === 0) {
          logger.info("No invocations.");
        } else {
          for (const i of rows) {
            const duration = i.durationMs != null ? `${i.durationMs}ms` : "-";
            logger.log(
              `  ${chalk.cyan(i.id.slice(0, 8))} svc=${i.serviceId.slice(0, 8)} [${i.status.padEnd(8)}] ${duration.padStart(7)} caller=${i.callerId || "anon"}`,
            );
          }
        }
        await shutdown();
      } catch (err) {
        logger.error(`Failed: ${err.message}`);
        process.exit(1);
      }
    });

  mp.command("stats")
    .description("Aggregate invocation stats (optionally scoped to a service)")
    .option("-s, --service <id>", "Scope to a single service")
    .option("--json", "Output as JSON")
    .action(async (options) => {
      try {
        const ctx = await bootstrap({ verbose: program.opts().verbose });
        _dbFromCtx(ctx);
        const stats = getInvocationStats({ serviceId: options.service });
        if (options.json) {
          console.log(JSON.stringify(stats, null, 2));
        } else {
          logger.log(`  ${chalk.bold("Total:")}         ${stats.total}`);
          logger.log(
            `  ${chalk.bold("Success rate:")}  ${(stats.successRate * 100).toFixed(1)}%`,
          );
          logger.log(
            `  ${chalk.bold("Avg duration:")}  ${stats.avgDurationMs}ms (success-only)`,
          );
          logger.log(
            `  ${chalk.bold("Counts:")}        success=${stats.counts.success} failed=${stats.counts.failed} timeout=${stats.counts.timeout} pending=${stats.counts.pending} running=${stats.counts.running}`,
          );
          if (stats.scopedToService) {
            logger.log(
              `  ${chalk.bold("Scope:")}         service ${stats.scopedToService.slice(0, 8)}`,
            );
          }
        }
        await shutdown();
      } catch (err) {
        logger.error(`Failed: ${err.message}`);
        process.exit(1);
      }
    });

  /* ── V2 (Phase 65) ───────────────────────────────────────── */

  mp.command("service-statuses-v2")
    .description("List V2 service statuses (frozen enum)")
    .option("--json", "Output as JSON")
    .action((options) => {
      const values = Object.values(SERVICE_STATUS_V2);
      if (options.json) console.log(JSON.stringify(values, null, 2));
      else for (const v of values) logger.log(`  ${chalk.cyan(v)}`);
    });

  mp.command("invocation-statuses-v2")
    .description("List V2 invocation statuses (frozen enum)")
    .option("--json", "Output as JSON")
    .action((options) => {
      const values = Object.values(INVOCATION_STATUS_V2);
      if (options.json) console.log(JSON.stringify(values, null, 2));
      else for (const v of values) logger.log(`  ${chalk.cyan(v)}`);
    });

  mp.command("pricing-models")
    .description("List V2 pricing models (frozen enum)")
    .option("--json", "Output as JSON")
    .action((options) => {
      const values = Object.values(PRICING_MODEL_V2);
      if (options.json) console.log(JSON.stringify(values, null, 2));
      else for (const v of values) logger.log(`  ${chalk.cyan(v)}`);
    });

  mp.command("default-max-concurrent")
    .description("Show default per-service concurrency cap")
    .action(() => {
      logger.log(`  ${MARKETPLACE_DEFAULT_MAX_CONCURRENT_INVOCATIONS}`);
    });

  mp.command("max-concurrent")
    .description("Show current per-service concurrency cap")
    .action(() => {
      logger.log(`  ${getMaxConcurrentInvocations()}`);
    });

  mp.command("active-invocation-count [service-id]")
    .description(
      "Show count of PENDING + RUNNING invocations (all services by default)",
    )
    .action((serviceId) => {
      logger.log(`  ${getActiveInvocationCount(serviceId)}`);
    });

  mp.command("set-max-concurrent <n>")
    .description("Set the per-service concurrency cap")
    .action((n) => {
      try {
        const v = setMaxConcurrentInvocations(Number(n));
        logger.success(`Max concurrent invocations = ${v}`);
      } catch (err) {
        logger.error(`Failed: ${err.message}`);
        process.exit(1);
      }
    });

  mp.command("begin-v2 <service-id>")
    .description("Begin a V2 invocation (creates PENDING, enforces cap)")
    .option("-c, --caller <id>", "Caller ID")
    .option("-i, --input <json>", "JSON-encoded input")
    .option("--json", "Output as JSON")
    .action(async (serviceId, options) => {
      try {
        const ctx = await bootstrap({ verbose: program.opts().verbose });
        const db = _dbFromCtx(ctx);
        let input = null;
        if (options.input) {
          try {
            input = JSON.parse(options.input);
          } catch {
            input = options.input;
          }
        }
        const inv = beginInvocationV2(db, {
          serviceId,
          callerId: options.caller,
          input,
        });
        if (options.json) console.log(JSON.stringify(inv, null, 2));
        else {
          logger.success(`Invocation queued [${inv.status}]`);
          logger.log(`  ${chalk.bold("ID:")} ${chalk.cyan(inv.id)}`);
        }
        await shutdown();
      } catch (err) {
        logger.error(`Failed: ${err.message}`);
        process.exit(1);
      }
    });

  mp.command("start-invocation <invocation-id>")
    .description("Start a V2 invocation (PENDING → RUNNING)")
    .option("--json", "Output as JSON")
    .action(async (invocationId, options) => {
      try {
        const ctx = await bootstrap({ verbose: program.opts().verbose });
        const db = _dbFromCtx(ctx);
        const result = startInvocation(db, invocationId);
        if (options.json) console.log(JSON.stringify(result, null, 2));
        else logger.success(`Status = ${result.status}`);
        await shutdown();
      } catch (err) {
        logger.error(`Failed: ${err.message}`);
        process.exit(1);
      }
    });

  mp.command("complete-invocation <invocation-id>")
    .description("Complete a V2 invocation (RUNNING → SUCCESS)")
    .option("-o, --output <json>", "JSON-encoded output")
    .option("-d, --duration-ms <n>", "Duration in milliseconds", parseInt)
    .option("--json", "Output as JSON")
    .action(async (invocationId, options) => {
      try {
        const ctx = await bootstrap({ verbose: program.opts().verbose });
        const db = _dbFromCtx(ctx);
        let output = null;
        if (options.output) {
          try {
            output = JSON.parse(options.output);
          } catch {
            output = options.output;
          }
        }
        const result = completeInvocationV2(db, invocationId, {
          output,
          durationMs: options.durationMs,
        });
        if (options.json) console.log(JSON.stringify(result, null, 2));
        else logger.success(`Status = ${result.status}`);
        await shutdown();
      } catch (err) {
        logger.error(`Failed: ${err.message}`);
        process.exit(1);
      }
    });

  mp.command("fail-invocation <invocation-id>")
    .description("Fail a V2 invocation")
    .option("-m, --message <msg>", "Error message")
    .option("-d, --duration-ms <n>", "Duration in milliseconds", parseInt)
    .action(async (invocationId, options) => {
      try {
        const ctx = await bootstrap({ verbose: program.opts().verbose });
        const db = _dbFromCtx(ctx);
        const result = failInvocationV2(db, invocationId, options.message, {
          durationMs: options.durationMs,
        });
        logger.success(`Status = ${result.status}`);
        if (result.error) logger.log(`  Error: ${result.error}`);
        await shutdown();
      } catch (err) {
        logger.error(`Failed: ${err.message}`);
        process.exit(1);
      }
    });

  mp.command("timeout-invocation <invocation-id>")
    .description("Timeout a V2 invocation")
    .option("-d, --duration-ms <n>", "Duration in milliseconds", parseInt)
    .action(async (invocationId, options) => {
      try {
        const ctx = await bootstrap({ verbose: program.opts().verbose });
        const db = _dbFromCtx(ctx);
        const result = timeoutInvocationV2(db, invocationId, {
          durationMs: options.durationMs,
        });
        logger.success(`Status = ${result.status}`);
        await shutdown();
      } catch (err) {
        logger.error(`Failed: ${err.message}`);
        process.exit(1);
      }
    });

  mp.command("set-invocation-status <invocation-id> <status>")
    .description("Set V2 invocation status via the state machine")
    .option("-m, --message <msg>", "Error message (FAILED/TIMEOUT)")
    .option("--json", "Output as JSON")
    .action(async (invocationId, status, options) => {
      try {
        const ctx = await bootstrap({ verbose: program.opts().verbose });
        const db = _dbFromCtx(ctx);
        const patch = options.message ? { error: options.message } : {};
        const result = setInvocationStatus(db, invocationId, status, patch);
        if (options.json) console.log(JSON.stringify(result, null, 2));
        else logger.success(`Status = ${result.status}`);
        await shutdown();
      } catch (err) {
        logger.error(`Failed: ${err.message}`);
        process.exit(1);
      }
    });

  mp.command("stats-v2")
    .description("V2 aggregated stats")
    .option("--json", "Output as JSON")
    .action(async (options) => {
      try {
        const ctx = await bootstrap({ verbose: program.opts().verbose });
        _dbFromCtx(ctx);
        const stats = getMarketplaceStatsV2();
        if (options.json) console.log(JSON.stringify(stats, null, 2));
        else {
          logger.log(
            `  ${chalk.bold("Services:")}       ${stats.totalServices}`,
          );
          logger.log(
            `  ${chalk.bold("Invocations:")}    ${stats.totalInvocations} (active: ${stats.activeInvocations})`,
          );
          logger.log(
            `  ${chalk.bold("Max concurrent:")} ${stats.maxConcurrentInvocations}`,
          );
          logger.log(`  ${chalk.bold("Services by status:")}`);
          for (const [k, v] of Object.entries(stats.servicesByStatus))
            logger.log(`    ${k.padEnd(12)} ${v}`);
          logger.log(`  ${chalk.bold("Services by pricing:")}`);
          for (const [k, v] of Object.entries(stats.servicesByPricing))
            logger.log(`    ${k.padEnd(14)} ${v}`);
          logger.log(`  ${chalk.bold("Invocations by status:")}`);
          for (const [k, v] of Object.entries(stats.invocationsByStatus))
            logger.log(`    ${k.padEnd(10)} ${v}`);
          logger.log(
            `  ${chalk.bold("Success rate:")}   ${(stats.successRate * 100).toFixed(1)}%`,
          );
          logger.log(
            `  ${chalk.bold("Avg duration:")}   ${stats.avgDurationMs}ms`,
          );
        }
        await shutdown();
      } catch (err) {
        logger.error(`Failed: ${err.message}`);
        process.exit(1);
      }
    });

  /* ── v1.2 m-of-n Phase 2: marketplace.purchase mediator ─────── */

  mp.command("purchase <itemId>")
    .description(
      "Initiate a purchase. Large orders (≥ threshold) route through M-of-N multisig.",
    )
    .requiredOption("--amount-fen <n>", "Order amount in fen (¥ × 100)", (v) =>
      parseInt(v, 10),
    )
    .requiredOption("--buyer <did>", "Buyer DID (multisig initiator)")
    .option("--alg <alg>", "Initiator signing alg", "Ed25519")
    .option("--key <hex|path>", "Initiator secret key hex / file")
    .option(
      "--threshold-fen <n>",
      `Override large-order threshold (default ${LARGE_PURCHASE_THRESHOLD_FEN})`,
      (v) => parseInt(v, 10),
    )
    .option("--item-name <name>", "Optional item display name")
    .option("--db <path>", "Multisig DB path", defaultMultisigDbPath())
    .option("--log <path>", "Governance log path", defaultMultisigLogPath())
    .option("--json", "Output JSON")
    .action(async (itemId, options) => {
      try {
        const threshold = options.thresholdFen ?? LARGE_PURCHASE_THRESHOLD_FEN;
        const amountFen = options.amountFen;
        if (!Number.isFinite(amountFen) || amountFen <= 0) {
          logger.error("--amount-fen must be positive integer");
          process.exit(2);
        }
        const requiresMultisig = amountFen >= threshold;

        if (!requiresMultisig) {
          // Below threshold: direct path. No real payment processor in CLI scope
          // — emit a "purchased" record. Phase 2 doesn't aim to wire a real
          // payment gateway; it aims to gate large orders through multisig.
          if (options.json) {
            console.log(
              JSON.stringify(
                {
                  status: "purchased",
                  itemId,
                  amountFen,
                  buyer: options.buyer,
                  path: "direct",
                },
                null,
                2,
              ),
            );
          } else {
            logger.log(
              chalk.green(
                `✓ Purchase executed (direct, below ¥${(threshold / 100).toFixed(2)} threshold)`,
              ),
            );
            logger.log(`  itemId: ${itemId}`);
            logger.log(`  amount: ¥${(amountFen / 100).toFixed(2)}`);
          }
          return;
        }

        // Above threshold: route through multisig.
        const { store, mgr, close } = await openMultisigManager(
          options.db,
          options.log,
        );
        try {
          const policy = store.getPolicy(MULTISIG_DOMAIN);
          if (!policy) {
            const msg = `No multisig policy for domain "${MULTISIG_DOMAIN}" — cannot route ¥${(amountFen / 100).toFixed(2)} (≥ threshold). Run: cc multisig policy set ${MULTISIG_DOMAIN} --m <M> --members <json>`;
            if (options.json) {
              console.log(
                JSON.stringify(
                  {
                    status: "blocked",
                    reason: "no_policy",
                    itemId,
                    amountFen,
                    path: "multisig",
                  },
                  null,
                  2,
                ),
              );
            } else {
              logger.error(chalk.red(`✗ ${msg}`));
            }
            process.exit(2);
          }
          const secretKey = readSecretKey(options.key);
          const result = mgr.propose({
            domain: MULTISIG_DOMAIN,
            payload: {
              itemId,
              amountFen,
              buyer: options.buyer,
              itemName: options.itemName || null,
            },
            policy,
            initiator: {
              did: options.buyer,
              alg: options.alg,
              secretKey,
            },
          });
          if (options.json) {
            console.log(
              JSON.stringify(
                {
                  status: "needs_co_sign",
                  path: "multisig",
                  proposalId: result.proposal.id,
                  reachedThreshold: result.reachedThreshold,
                  requiredSigs: policy.m,
                  itemId,
                  amountFen,
                },
                null,
                2,
              ),
            );
          } else {
            logger.log(
              chalk.cyan(
                `↪ Routed through multisig (¥${(amountFen / 100).toFixed(2)} ≥ ¥${(threshold / 100).toFixed(2)} threshold)`,
              ),
            );
            logger.log(`  proposalId: ${result.proposal.id}`);
            logger.log(
              `  needs ${policy.m} of ${policy.members.length} signatures`,
            );
            if (result.reachedThreshold) {
              logger.log(
                chalk.green(
                  "  ✓ threshold reached on first signature — run: cc marketplace consume",
                ),
              );
            } else {
              logger.log(
                `  next: co-signers run: cc multisig sign ${result.proposal.id}`,
              );
            }
          }
        } finally {
          close();
        }
      } catch (err) {
        logger.error(`Purchase failed: ${err.message}`);
        process.exit(1);
      }
    });

  mp.command("consume <proposalId>")
    .description(
      "Execute a multisig-gated purchase after threshold reached (marks proposal consumed)",
    )
    .option("--db <path>", "Multisig DB path", defaultMultisigDbPath())
    .option("--log <path>", "Governance log path", defaultMultisigLogPath())
    .option("--json", "Output JSON")
    .action(async (proposalId, options) => {
      try {
        const { mgr, close } = await openMultisigManager(
          options.db,
          options.log,
        );
        try {
          const got = mgr.get(proposalId);
          if (!got) {
            if (options.json) {
              console.log(
                JSON.stringify(
                  { status: "error", reason: "proposal_not_found" },
                  null,
                  2,
                ),
              );
            } else {
              logger.error(chalk.red(`No proposal: ${proposalId}`));
            }
            process.exit(2);
          }
          if (got.proposal.domain !== MULTISIG_DOMAIN) {
            if (options.json) {
              console.log(
                JSON.stringify(
                  {
                    status: "error",
                    reason: "wrong_domain",
                    expected: MULTISIG_DOMAIN,
                    actual: got.proposal.domain,
                  },
                  null,
                  2,
                ),
              );
            } else {
              logger.error(
                chalk.red(
                  `Proposal domain "${got.proposal.domain}" is not "${MULTISIG_DOMAIN}" — use cc multisig finalize instead.`,
                ),
              );
            }
            process.exit(2);
          }
          if (got.proposal.state !== "reached") {
            if (options.json) {
              console.log(
                JSON.stringify(
                  {
                    status: "error",
                    reason: `proposal_state_${got.proposal.state}`,
                  },
                  null,
                  2,
                ),
              );
            } else {
              logger.error(
                chalk.red(
                  `Proposal state is "${got.proposal.state}", need "reached" — sign more before consume.`,
                ),
              );
            }
            process.exit(2);
          }

          // Execute purchase from proposal payload (CLI stub — Phase 2 doesn't
          // ship a real payment processor). Just print the order, then finalize.
          const order = JSON.parse(got.proposal.payloadJcs);
          const finalizeRes = mgr.finalize(proposalId);
          if (!finalizeRes.ok) {
            if (options.json) {
              console.log(
                JSON.stringify(
                  { status: "error", reason: finalizeRes.reason },
                  null,
                  2,
                ),
              );
            } else {
              logger.error(chalk.red(`Finalize failed: ${finalizeRes.reason}`));
            }
            process.exit(1);
          }
          if (options.json) {
            console.log(
              JSON.stringify(
                {
                  status: "consumed",
                  proposalId,
                  order,
                },
                null,
                2,
              ),
            );
          } else {
            logger.log(
              chalk.green(
                `✓ Purchase consumed — order ${order.itemId} for ¥${(order.amountFen / 100).toFixed(2)}`,
              ),
            );
            logger.log(`  buyer: ${order.buyer}`);
            if (order.itemName) logger.log(`  item: ${order.itemName}`);
            logger.log(`  proposalId: ${proposalId}`);
          }
        } finally {
          close();
        }
      } catch (err) {
        logger.error(`Consume failed: ${err.message}`);
        process.exit(1);
      }
    });
}

// === Iter16 V2 governance overlay ===
export function registerMktgovV2Commands(program) {
  const parent = program.commands.find((c) => c.name() === "marketplace");
  if (!parent) return;
  const L = async () => await import("../lib/skill-marketplace.js");
  parent
    .command("mktgov-enums-v2")
    .description("Show V2 enums (mktgov maturity + order lifecycle)")
    .action(async () => {
      const m = await L();
      console.log(
        JSON.stringify(
          {
            profileMaturity: m.MKTGOV_PROFILE_MATURITY_V2,
            orderLifecycle: m.MKTGOV_ORDER_LIFECYCLE_V2,
          },
          null,
          2,
        ),
      );
    });
  parent
    .command("mktgov-config-v2")
    .description("Show V2 config thresholds")
    .action(async () => {
      const m = await L();
      console.log(
        JSON.stringify(
          {
            maxActive: m.getMaxActiveMktgovProfilesPerOwnerV2(),
            maxPending: m.getMaxPendingMktgovOrdersPerProfileV2(),
            idleMs: m.getMktgovProfileIdleMsV2(),
            stuckMs: m.getMktgovOrderStuckMsV2(),
          },
          null,
          2,
        ),
      );
    });
  parent
    .command("mktgov-set-max-active-v2 <n>")
    .description("Set max active profiles per owner")
    .action(async (n) => {
      const m = await L();
      m.setMaxActiveMktgovProfilesPerOwnerV2(Number(n));
      console.log("ok");
    });
  parent
    .command("mktgov-set-max-pending-v2 <n>")
    .description("Set max pending orders per profile")
    .action(async (n) => {
      const m = await L();
      m.setMaxPendingMktgovOrdersPerProfileV2(Number(n));
      console.log("ok");
    });
  parent
    .command("mktgov-set-idle-ms-v2 <n>")
    .description("Set profile idle threshold (ms)")
    .action(async (n) => {
      const m = await L();
      m.setMktgovProfileIdleMsV2(Number(n));
      console.log("ok");
    });
  parent
    .command("mktgov-set-stuck-ms-v2 <n>")
    .description("Set order stuck threshold (ms)")
    .action(async (n) => {
      const m = await L();
      m.setMktgovOrderStuckMsV2(Number(n));
      console.log("ok");
    });
  parent
    .command("mktgov-register-v2 <id> <owner>")
    .description("Register V2 mktgov profile")
    .option("--category <v>", "category")
    .action(async (id, owner, o) => {
      const m = await L();
      console.log(
        JSON.stringify(
          m.registerMktgovProfileV2({ id, owner, category: o.category }),
          null,
          2,
        ),
      );
    });
  parent
    .command("mktgov-activate-v2 <id>")
    .description("Activate profile")
    .action(async (id) => {
      const m = await L();
      console.log(JSON.stringify(m.activateMktgovProfileV2(id), null, 2));
    });
  parent
    .command("mktgov-suspend-v2 <id>")
    .description("Suspend profile")
    .action(async (id) => {
      const m = await L();
      console.log(JSON.stringify(m.suspendMktgovProfileV2(id), null, 2));
    });
  parent
    .command("mktgov-archive-v2 <id>")
    .description("Archive profile (terminal)")
    .action(async (id) => {
      const m = await L();
      console.log(JSON.stringify(m.archiveMktgovProfileV2(id), null, 2));
    });
  parent
    .command("mktgov-touch-v2 <id>")
    .description("Touch profile")
    .action(async (id) => {
      const m = await L();
      console.log(JSON.stringify(m.touchMktgovProfileV2(id), null, 2));
    });
  parent
    .command("mktgov-get-v2 <id>")
    .description("Get profile")
    .action(async (id) => {
      const m = await L();
      console.log(JSON.stringify(m.getMktgovProfileV2(id), null, 2));
    });
  parent
    .command("mktgov-list-v2")
    .description("List profiles")
    .action(async () => {
      const m = await L();
      console.log(JSON.stringify(m.listMktgovProfilesV2(), null, 2));
    });
  parent
    .command("mktgov-create-order-v2 <id> <profileId>")
    .description("Create order (queued)")
    .option("--listingId <v>", "listingId")
    .action(async (id, profileId, o) => {
      const m = await L();
      console.log(
        JSON.stringify(
          m.createMktgovOrderV2({ id, profileId, listingId: o.listingId }),
          null,
          2,
        ),
      );
    });
  parent
    .command("mktgov-processing-order-v2 <id>")
    .description("Mark order as processing")
    .action(async (id) => {
      const m = await L();
      console.log(JSON.stringify(m.processingMktgovOrderV2(id), null, 2));
    });
  parent
    .command("mktgov-complete-order-v2 <id>")
    .description("Complete order")
    .action(async (id) => {
      const m = await L();
      console.log(JSON.stringify(m.completeOrderMktgovV2(id), null, 2));
    });
  parent
    .command("mktgov-fail-order-v2 <id> [reason]")
    .description("Fail order")
    .action(async (id, reason) => {
      const m = await L();
      console.log(JSON.stringify(m.failMktgovOrderV2(id, reason), null, 2));
    });
  parent
    .command("mktgov-cancel-order-v2 <id> [reason]")
    .description("Cancel order")
    .action(async (id, reason) => {
      const m = await L();
      console.log(JSON.stringify(m.cancelMktgovOrderV2(id, reason), null, 2));
    });
  parent
    .command("mktgov-get-order-v2 <id>")
    .description("Get order")
    .action(async (id) => {
      const m = await L();
      console.log(JSON.stringify(m.getMktgovOrderV2(id), null, 2));
    });
  parent
    .command("mktgov-list-orders-v2")
    .description("List orders")
    .action(async () => {
      const m = await L();
      console.log(JSON.stringify(m.listMktgovOrdersV2(), null, 2));
    });
  parent
    .command("mktgov-auto-suspend-idle-v2")
    .description("Auto-suspend idle profiles")
    .action(async () => {
      const m = await L();
      console.log(JSON.stringify(m.autoSuspendIdleMktgovProfilesV2(), null, 2));
    });
  parent
    .command("mktgov-auto-fail-stuck-v2")
    .description("Auto-fail stuck orders")
    .action(async () => {
      const m = await L();
      console.log(JSON.stringify(m.autoFailStuckMktgovOrdersV2(), null, 2));
    });
  parent
    .command("mktgov-gov-stats-v2")
    .description("V2 gov aggregate stats")
    .action(async () => {
      const m = await L();
      console.log(JSON.stringify(m.getSkillMarketplaceGovStatsV2(), null, 2));
    });
}
