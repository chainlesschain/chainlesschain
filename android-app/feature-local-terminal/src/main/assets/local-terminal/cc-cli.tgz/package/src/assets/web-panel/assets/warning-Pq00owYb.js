let t={};function e(a,n){}function c(a,n,i){!n&&!t[i]&&(t[i]=!0)}function o(a,n){c(e,a,n)}export{e as a,o as w};
