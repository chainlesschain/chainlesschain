import{d as o}from"./styleChecker-CPYAtz6z.js";import{o as t,s}from"./vendor-M5lGV-wr.js";const r=(()=>{const e=s(!1);return t(()=>{e.value=o()}),e});export{r as u};
