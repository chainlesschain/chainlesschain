import{j as s,m as t}from"./_getTag-BVc6NQ_K.js";var b="[object Symbol]";function e(o){return typeof o=="symbol"||s(o)&&t(o)==b}export{e as i};
