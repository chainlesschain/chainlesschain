import{a7 as t,r as o}from"./vendor-M5lGV-wr.js";const f=()=>{const e=o(new Map),s=a=>r=>{e.value.set(a,r)};return t(()=>{e.value=new Map}),[s,e]};export{f as u};
