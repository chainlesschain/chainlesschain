import{h as s}from"./index-U0SCkuWf.js";function a(n,t){const e=s({},n);for(let o=0;o<t.length;o+=1){const r=t[o];delete e[r]}return e}export{a as o};
