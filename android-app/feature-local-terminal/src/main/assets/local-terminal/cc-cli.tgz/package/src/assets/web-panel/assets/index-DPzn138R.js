import{C as o}from"./Col-R6o5-ElS.js";import{S as t}from"./index-U0SCkuWf.js";import"./index-3gjSikZH.js";import"./vendor-M5lGV-wr.js";import"./icons-wfnF-zdj.js";const s=t(o);export{s as default};
