import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import {nativeEnvironment} from "../../packages/cli/scripts/verify01-native-task-campaign.mjs";
import {runCaptured} from "../../packages/cli/scripts/verify01-first-run-cli-diagnostic.mjs";
const repository=process.cwd();
const output=path.join(repository,".work/verify01-remaining-20261027/windows-public-startup-r4");
assert.ok(!fs.existsSync(output));fs.mkdirSync(output);
const root=fs.mkdtempSync(path.join(os.tmpdir(),"cc-verify01-preflight-"));
const workspace=path.join(root,"workspace");fs.mkdirSync(workspace);
const env=nativeEnvironment(root,path.join(root,"home"),path.join(root,"profile"),[]);
const install=path.join(repository,".work/verify01-remaining-20261027/windows-public-preflight-r2/install");
const installed=JSON.parse(fs.readFileSync(path.join(install,"node_modules/chainlesschain/package.json")));
assert.equal(installed.version,"0.166.127");
const installReceipt=JSON.parse(fs.readFileSync(path.join(repository,".work/verify01-remaining-20261027/windows-public-preflight-r2/install.process.json")));
assert.equal(installReceipt.ok,true);
const cli=path.join(install,"node_modules/chainlesschain/bin/chainlesschain.js");
let status="FAILED";const stages=[];
async function run(stage,args){const r=await runCaptured(process.execPath,[cli,...args],{cwd:workspace,env,deadline:Date.now()+120000,outputPrefix:path.join(output,stage)});stages.push({stage,passed:r.ok,startedAt:r.startedAt,finishedAt:r.finishedAt,exitCode:r.exitCode,timedOut:r.timedOut});console.log(JSON.stringify(stages.at(-1)));assert.ok(r.ok,stage);return r;}
try{
 assert.equal((await run("version",["--version"])).stdout.trim(),"0.166.127");
 assert.ok(JSON.parse((await run("capabilities",["agent","--capabilities"])).stdout));
 for(const [field,value] of Object.entries({provider:"volcengine",model:"deepseek-v4-flash-ga-260731",baseUrl:"http://127.0.0.1:9/api/v3"}))await run(`config-${field}`,["config","set",`llm.${field}`,value]);
 const llm=JSON.parse((await run("config-readback",["config","get","llm","--json"])).stdout).value;
 assert.equal(llm.provider,"volcengine");assert.equal(llm.model,"deepseek-v4-flash-ga-260731");assert.equal(llm.baseUrl,"http://127.0.0.1:9/api/v3");
 status="PASSED_PUBLIC_WINDOWS_STARTUP_AND_CONFIGURATION_ONLY";
}finally{const result={schema:"chainlesschain.remaining-native-windows-preflight/v1",status,platform:process.platform,arch:process.arch,node:process.version,version:installed.version,profileOutsideGitWorktree:true,install:{passed:true,lifecycleScriptsEnabled:true,startedAt:installReceipt.startedAt,finishedAt:installReceipt.finishedAt},stages,newModelCalls:0,newAcceptedSamples:0,limitations:["Public Windows install, static capabilities and isolated configuration only; no IDE or model task.","Not an independent first-run sample or native/formal admission."]};fs.writeFileSync(path.join(output,"result.json"),JSON.stringify(result,null,2)+"\n",{flag:"wx"});console.log(JSON.stringify({status,newModelCalls:0}));}
