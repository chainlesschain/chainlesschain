import assert from "node:assert/strict";
export function transform(source) {
  const start = source.indexOf("  const fields = [\"category\", \"scope\", \"state\", \"tag\", \"sink\"];");
  const end = source.indexOf("  return { rows: value.rows, postings };", start);
  assert.ok(start >= 0 && end > start);
  return source.slice(0, start) + `  // Experimental private compilation strategy, not production source.
  // Preserve the current decoder's failure for non-iterable tag/sink fields
  // before returning any query result, including unused fields.
  for (const row of value.rows) {
    for (const tag of row.tags) void tag;
    for (const sink of row.allowedSinks) void sink;
  }
  const postings = {};
  for (const field of ["category", "scope", "state", "tag", "sink"]) {
    let compiled;
    Object.defineProperty(postings, field, {
      enumerable: true,
      get() {
        if (compiled) return compiled;
        const map = new Map();
        const add = (key, index) => {
          let values = map.get(key);
          if (!values) map.set(key, values = []);
          values.push(index);
        };
        value.rows.forEach((row, index) => {
          if (field === "scope") add(scopeKey(row.scope, row.scopeId), index);
          else if (field === "tag") for (const tag of row.tags) add(tag, index);
          else if (field === "sink") for (const sink of row.allowedSinks) add(sink, index);
          else add(row[field], index);
        });
        compiled = map;
        return map;
      },
    });
  }
` + source.slice(end);
}
