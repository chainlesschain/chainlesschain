import fs from "node:fs";
import path from "node:path";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import { gzipSync } from "node:zlib";
const directory = "docs/research/cli/evidence/memory-slo131-2026-10-29";
const review = JSON.parse(fs.readFileSync(`${directory}/review.json`));
const sha = bytes => createHash("sha256").update(bytes).digest("hex");
const source = review.frozenCandidateSource;
const stop = JSON.parse(fs.readFileSync(".work/memory-query-bundle/candidate131-stop100.json"));
const hot = JSON.parse(fs.readFileSync(".work/memory-query-bundle/candidate131-hot100.json"));
const additions = [];
function bind(file, expected) {
  const digest = sha(fs.readFileSync(file));
  assert.equal(digest, expected.replace(/^sha256:/, ""), file);
  const blob = execFileSync("git", ["rev-parse", `${source}:${file}`], { encoding: "utf8", windowsHide: true }).trim();
  assert.equal(execFileSync("git", ["hash-object", `--path=${file}`, file], { encoding: "utf8", windowsHide: true }).trim(), blob, file);
  review.sourceBinding[file] = { sha256: digest, frozenGitBlob: blob };
  additions.push(file);
}
bind("packages/cli/src/lib/secure-file-identity.js", hot.implementationSha256["secure-file-identity.js"]);
for (const [relative, digest] of Object.entries(stop.sourceDigests)) {
  const absolute = path.resolve("packages/cli/scripts", relative);
  assert.ok(absolute.startsWith(process.cwd() + path.sep));
  bind(path.relative(process.cwd(), absolute).replaceAll("\\", "/"), digest);
}
const scopes = ["packages/cli/src", "packages/context-memory-kernel/lib", "packages/cli/scripts/memory-query-index-benchmark.mjs", "packages/cli/scripts/memory-query-responsiveness-benchmark.mjs", "packages/cli/scripts/persistent-capacity-benchmark.mjs", "packages/cli/scripts/memory-mixed-concurrency-benchmark.mjs"];
execFileSync("git", ["diff", "--quiet", source, "--", ...scopes], { windowsHide: true });
review.additionalSourceBinding = { observedAt: new Date().toISOString(), filesVerified: additions, scopedGitDiffExitCode: 0, scopes, nodeOptionsPresent: Boolean(process.env.NODE_OPTIONS) };
const bytes = fs.readFileSync(".work/memory-query-bundle/complete-slo44-bindings-20261029.mjs"), compressed = gzipSync(bytes);
const file = `${directory}/raw/complete-slo44-bindings-20261029.mjs.gz`;
fs.writeFileSync(file, compressed, { flag: "wx" });
review.artifacts.push({ path: file, source: ".work/memory-query-bundle/complete-slo44-bindings-20261029.mjs", encoding: "gzip", bytes: compressed.length, sha256: sha(compressed), contentBytes: bytes.length, contentSha256: sha(bytes) });
fs.writeFileSync(`${directory}/review.json`, JSON.stringify(review, null, 2) + "\n");
console.log(JSON.stringify({ frozenCandidate: source, boundSourceFiles: Object.keys(review.sourceBinding).length, scopedGitDiffExitCode: 0 }));
