import fs from "node:fs";
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
const source = "7a5d38d151d437f94f8c223dec1fbca52a44da5b";
const operations = [];
function gh(args) {
  const result = spawnSync("gh", args, { encoding: "utf8", windowsHide: true, timeout: 60_000, maxBuffer: 16 * 1024 * 1024 });
  operations.push({ args, exitCode: result.status, stdout: result.stdout || "", stderr: result.stderr || "" });
  assert.equal(result.status, 0, result.stdout + result.stderr);
  return result.stdout;
}
const active = JSON.parse(gh(["api", "repos/chainlesschain/chainlesschain/actions/runs/40826012460"]));
assert.equal(active.head_sha, source);
assert.equal(active.head_branch, "ci-cli131-7a5d38d151d4");
assert.equal(active.event, "workflow_dispatch");
assert.ok(active.status !== "completed" || active.conclusion === "success");
const cancellations = [];
const file = ".work/memory-query-bundle/superseded-ide-cleanup-20261029.json";
const save = () => fs.writeFileSync(file, JSON.stringify({ observedAt: new Date().toISOString(), frozenCandidateSource: source, preservedFrozenRun: active.id, cancellations, operations, scope: "Only old main-push IDE build/test matrices superseded by the frozen .131 source. No native/provider or publishing workflow is touched." }, null, 2) + "\n");
for (const [id, expectedSource] of [[40819683763, "ebc2aef24fa00c4f55cb9d872369694e8e2cc095"], [40816026027, "0d67a7d43bca2a41baf4fe5fd662bc5d97954954"]]) {
  const current = JSON.parse(gh(["api", `repos/chainlesschain/chainlesschain/actions/runs/${id}`]));
  assert.equal(current.name, "IDE Extensions");
  assert.equal(current.event, "push");
  assert.equal(current.head_branch, "main");
  assert.equal(current.head_sha, expectedSource);
  const ancestor = spawnSync("git", ["merge-base", "--is-ancestor", expectedSource, source], { encoding: "utf8", windowsHide: true });
  assert.equal(ancestor.status, 0);
  if (current.status === "completed") { cancellations.push({ id, source: expectedSource, state: "already_terminal", status: current.status, conclusion: current.conclusion }); save(); continue; }
  const item = { id, source: expectedSource, state: "intent_recorded", observedStatus: current.status };
  cancellations.push(item);
  save();
  gh(["run", "cancel", String(id), "--repo", "chainlesschain/chainlesschain"]);
  item.state = "cancellation_accepted";
  save();
  const after = JSON.parse(gh(["api", `repos/chainlesschain/chainlesschain/actions/runs/${id}`]));
  item.after = { status: after.status, conclusion: after.conclusion };
  save();
}
console.log(JSON.stringify({ preservedFrozenRun: active.id, cancellations }));
