import fs from "node:fs";
import path from "node:path";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";
import { gzipSync, gunzipSync } from "node:zlib";
const work = ".work/memory-query-bundle";
const target = "docs/research/cli/evidence/memory-slo131-2026-10-29";
const frozen = ".work/release131-immutable-validation/ci-cli131-7a5d38d151d4";
const releaseSource = "7a5d38d151d437f94f8c223dec1fbca52a44da5b";
const read = file => JSON.parse(fs.readFileSync(file));
const sha = bytes => createHash("sha256").update(bytes).digest("hex");
const hot = read(`${work}/candidate131-hot100.json`);
const cold = read(`${work}/candidate131-cold100.json`);
const stop = read(`${work}/candidate131-stop100.json`);
assert.ok(hot.complete && cold.complete && stop.targetMet);
assert.equal(hot.samples, 100);
assert.equal(cold.samples, 100);
assert.equal(stop.samplesPerCase, 100);
assert.equal(hot.cacheMode, "validate-disk");
assert.equal(cold.cacheMode, "validate-disk");
assert.deepEqual(hot.implementationSha256, cold.implementationSha256);
let listSamples = 0, stopSamples = 0;
const tiers = hot.tiers.map((tier, index) => {
  const other = cold.tiers[index];
  assert.equal(tier.count, other.count);
  assert.equal(tier.expectedDigest, other.expectedDigest);
  const hotRows = tier.groups.hot.samples, coldRows = other.groups.cold.samples;
  assert.equal(hotRows.length, 100);
  assert.equal(coldRows.length, 100);
  for (const value of [...hotRows, ...coldRows]) assert.equal(value.rowsDigest, tier.expectedDigest);
  listSamples += hotRows.length + coldRows.length;
  return { count: tier.count, hot: tier.groups.hot.latency, cold: other.groups.cold.latency, hotTargetMet: tier.groups.hot.latency.p95Ms < 200, coldTargetMet: other.groups.cold.latency.p95Ms < 1000, hotIndexOpens: [...new Set(hotRows.map(row => row.indexReadOpens))], authorityBytesPerQuery: tier.groups.hot.authorityBytes, hotPeakRssBytes: tier.groups.hot.peakRssBytes, coldPeakRssBytes: other.groups.cold.peakRssBytes, hotMaxEventLoopDelayMs: Math.max(...hotRows.map(row => row.eventLoopDelayMaxMs)), coldMaxEventLoopDelayMs: Math.max(...coldRows.map(row => row.eventLoopDelayMaxMs)) };
});
for (const tier of stop.tiers) for (const mode of Object.values(tier.modes)) {
  assert.ok(mode.targetMet && mode.authorityUnchanged);
  assert.equal(mode.acknowledged, 100);
  assert.equal(mode.lateSuccessfulCompletion, 0);
  assert.ok(mode.samples.every(sample => sample.lockReleased));
  stopSamples += mode.samples.length;
}
assert.equal(listSamples, 600);
assert.equal(stopSamples, 600);
const sourceBinding = {};
for (const label of ["candidate131-hot100", "candidate131-cold100", "candidate131-stop100", "candidate131-cold-cpu"]) {
  const receipt = read(`${work}/${label}-process.json`);
  assert.ok(receipt.exitCode === 0 && receipt.sourcesStable);
  for (const [file, digest] of Object.entries(receipt.sourceAfter)) {
    assert.equal(sha(fs.readFileSync(file)), digest, file);
    const blob = execFileSync("git", ["rev-parse", `${releaseSource}:${file}`], { encoding: "utf8", windowsHide: true }).trim();
    const workingBlob = execFileSync("git", ["hash-object", `--path=${file}`, file], { encoding: "utf8", windowsHide: true }).trim();
    assert.equal(workingBlob, blob, file);
    sourceBinding[file] = { sha256: digest, frozenGitBlob: blob };
  }
}
const failed = read(`${work}/lazy-index-rejection-20261029.json`);
assert.equal(failed.rejectionParityPreserved, false);
assert.equal(failed.prototypeAdmittedForProduction, false);
const observed = read(`${frozen}/observation-memory-report.json`);
for (const workflow of ["CLI Strict Sandbox", "Context Memory Kernel CI"]) {
  const result = observed.observations.find(result => result.status === "fulfilled" && result.value.workflow === workflow).value;
  assert.equal(result.source, releaseSource);
  assert.equal(result.conclusion, "success");
  assert.ok(result.jobs.every(job => job.status === "completed" && job.conclusion === "success"));
}
const gateMeta = [];
for (const id of [40825996255, 40826001600, 40826006659, 40826012460]) {
  const result = JSON.parse(execFileSync("gh", ["api", `repos/chainlesschain/chainlesschain/actions/runs/${id}`], { encoding: "utf8", windowsHide: true, timeout: 30_000, maxBuffer: 4 * 1024 * 1024 }));
  assert.equal(result.head_sha, releaseSource);
  gateMeta.push({ id, workflow: result.name, source: result.head_sha, ref: result.head_branch, status: result.status, conclusion: result.conclusion, url: result.html_url });
}
const cleanup = [];
for (const id of [40819683763, 40816026027]) {
  const result = JSON.parse(execFileSync("gh", ["api", `repos/chainlesschain/chainlesschain/actions/runs/${id}`], { encoding: "utf8", windowsHide: true, timeout: 30_000, maxBuffer: 4 * 1024 * 1024 }));
  assert.equal(result.event, "push");
  assert.equal(result.name, "IDE Extensions");
  assert.equal(result.status, "completed");
  assert.equal(result.conclusion, "cancelled");
  cleanup.push({ id, source: result.head_sha, status: result.status, conclusion: result.conclusion });
}
fs.writeFileSync(`${work}/slo44-cloud-status.json`, JSON.stringify({ observedAt: new Date().toISOString(), gateMeta, cleanup }, null, 2) + "\n", { flag: "wx" });
const artifacts = [];
fs.mkdirSync(`${target}/raw`, { recursive: true });
function archive(source, name) {
  const bytes = fs.readFileSync(source), compressed = gzipSync(bytes);
  const file = `${target}/raw/${name}.gz`;
  fs.writeFileSync(file, compressed, { flag: "wx" });
  assert.equal(sha(gunzipSync(fs.readFileSync(file))), sha(bytes));
  artifacts.push({ path: file, source, encoding: "gzip", bytes: compressed.length, sha256: sha(compressed), contentBytes: bytes.length, contentSha256: sha(bytes) });
}
for (const label of ["candidate131-hot100", "candidate131-cold100", "candidate131-stop100"]) for (const suffix of [".json", "-process.json", ".log"]) archive(`${work}/${label}${suffix}`, `${label}${suffix}`);
for (const suffix of ["-process.json", ".log"]) archive(`${work}/candidate131-cold-cpu${suffix}`, `candidate131-cold-cpu${suffix}`);
for (const file of fs.readdirSync(`${work}/cold-cpu-PtgIEH`)) archive(`${work}/cold-cpu-PtgIEH/${file}`, `cold-cpu-${file}`);
for (const file of ["canonical-shape-experiment-20261029.mjs", "canonical-shape-experiment-20261029.json", "canonical-shape-prototype-20261029.cjs", "lazy-index-transform-20261029.mjs", "lazy-index-loader-20261029.mjs", "lazy-index-preload-20261029.mjs", "lazy-index-parity-20261029.mjs", "lazy-index-parity-20261029.json", "lazy-index-rejection-20261029.mjs", "lazy-index-rejection-20261029.json", "astra-cold-review-20261029.md", "cancel-superseded-ide-20261029.mjs", "superseded-ide-cleanup-20261029.json", "slo44-cloud-status.json", "archive-slo44-20261029.mjs"]) archive(`${work}/${file}`, file);
for (const file of ["poll.mjs", "observation-memory-baseline.json", "observation-memory-final.json", "observation-memory-report.json"]) archive(`${frozen}/${file}`, `gates-${file}`);
const journalPath = `${frozen}/release-target.json`;
const journal = read(journalPath);
assert.equal(journal.source, releaseSource);
journal.lastGateObservation = { observedAt: new Date().toISOString(), gates: gateMeta };
journal.state = "GATES_PENDING";
journal.allRequiredWorkflowsCompletedSuccessfully = gateMeta.every(gate => gate.status === "completed" && gate.conclusion === "success");
fs.writeFileSync(journalPath, JSON.stringify(journal, null, 2) + "\n");
archive(journalPath, "release-target-current.json");
const review = { schema: "chainlesschain.memory-slo131/v1", observedAt: new Date().toISOString(), sourceHead: hot.sourceHead, frozenCandidateSource: releaseSource, sourceBinding, productionSourceChanged: false, listQueries: { query: hot.query, samplesPerCase: 100, totalSamples: listSamples, cacheMode: hot.cacheMode, indexLayout: hot.indexLayout, tiers, boundary: "Windows / Node 22.22.2 category-filtered list limit 20. Cold is a fresh Node process, OS caches are not flushed; startup/import/fixture setup excluded. Not all recall workloads or full cross-platform SLO admission." }, stop: { samplesPerCase: 100, totalSamples: stopSamples, succeeded: 600, tiers: stop.tiers.map(tier => ({ count: tier.count, modes: Object.fromEntries(Object.entries(tier.modes).map(([name, mode]) => [name, { acknowledged: mode.acknowledged, targetMet: mode.targetMet, delivery: mode.stopDeliveryDelay, acknowledgement: mode.stopAcknowledgement, authorityManifestBytesUnchangedAcrossGroup: mode.authorityUnchanged }])) })), boundary: "Each sample checks released authority lock; authority manifest bytes are compared before/after each cache-mode group, not a proof that every physical shard byte was unchanged at every instant. Real IDE Stop remains separate." }, coldProfile: read(`${work}/cold-cpu-PtgIEH/worker-result.json`), prototypeDecision: { productionAdmitted: false, canonicalShapeMicro: read(`${work}/canonical-shape-experiment-20261029.json`), lazyParityMicro: read(`${work}/lazy-index-parity-20261029.json`), lazyRejection: failed, loaderAndPreloadExecuted: false, astraReadOnlyReview: "raw/astra-cold-review-20261029.md.gz", reason: "Partial micro gains do not establish cold SLO and lazy prototype failed an existing rejection condition. Full authority validation remains active; new smaller-shard layout or internal serialization needs design/migration and separate exact-source validation." }, gateMeta, supersededIdeCleanup: cleanup, publication: { executed: false, releaseTagCreated: false, requiredWorkflow: "npm-publish.yml", blockedBy: "CLI CI exact-source full matrix is incomplete; the dedicated OIDC workflow gates protected Kernel publication together with CLI prerequisites. Do not route through workspace-npm-publish or local tokens.", requiredOrder: "verified child -> CLI -> IDE -> clients" }, limitations: ["Shared workstation and background activity; do not attribute differences from older short runs solely to code changes", "Hot peak RSS includes fixture construction; cold peak RSS includes worker imports and query", "Rebuild/corruption/mixed processes at 100 samples on this source, all crash windows, real IDE, semantics and global latency SLO remain incomplete"], acceptance: { accepted: 34, total: 45, original129Dispatch: "REQUEST_UNRESOLVED", paidReady: false, nativeAdmission: "NOT_ADMITTED", automaticPromotion: "HOLD", microsoft: "deferred" }, artifacts };
fs.writeFileSync(`${target}/review.json`, JSON.stringify(review, null, 2) + "\n", { flag: "wx" });
console.log(JSON.stringify({ listSamples, stopSamples, hotTarget: tiers.every(tier => tier.hotTargetMet), coldTarget: tiers.every(tier => tier.coldTargetMet), productionSourceChanged: false, artifacts: artifacts.length, gates: gateMeta.map(({ workflow, status, conclusion }) => ({ workflow, status, conclusion })) }));
