import fs from "node:fs";
import path from "node:path";
import assert from "node:assert/strict";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { fileURLToPath } from "node:url";
const exec = promisify(execFile);
const directory = path.dirname(fileURLToPath(import.meta.url));
const [label] = process.argv.slice(2);
assert.match(label, /^[a-z0-9-]+$/);
const journal = JSON.parse(fs.readFileSync(path.join(directory, "release-target.json")));
const handles = [40825996255, 40826001600, 40826006659, 40826012460];
async function api(endpoint) {
  const { stdout } = await exec("gh", ["api", `repos/chainlesschain/chainlesschain/${endpoint}`], { encoding: "utf8", windowsHide: true, timeout: 30_000, maxBuffer: 16 * 1024 * 1024 });
  return JSON.parse(stdout);
}
const observations = await Promise.allSettled(handles.map(async id => {
  const meta = await api(`actions/runs/${id}`);
  assert.equal(meta.head_sha, journal.source);
  assert.equal(meta.head_branch, journal.validationTag);
  const jobs = [];
  for (let page = 1;; page++) {
    const result = await api(`actions/runs/${id}/jobs?filter=latest&per_page=20&page=${page}`);
    jobs.push(...result.jobs);
    if (jobs.length >= result.total_count) break;
  }
  return { id, workflow: meta.name, source: meta.head_sha, ref: meta.head_branch, status: meta.status, conclusion: meta.conclusion, attempt: meta.run_attempt, url: meta.html_url, jobs };
}));
const receipt = { observedAt: new Date().toISOString(), source: journal.source, validationTag: journal.validationTag, observations: observations.map((result, index) => result.status === "fulfilled" ? { status: result.status, value: result.value } : { status: result.status, id: handles[index], error: result.reason.message }), boundary: "Read-only status observation of existing handles; a transient observation failure never restarts a workflow." };
fs.writeFileSync(path.join(directory, `${label}.json`), JSON.stringify(receipt, null, 2) + "\n", { flag: "wx" });
console.log(JSON.stringify(receipt.observations.map(result => result.status === "rejected" ? result : { id: result.value.id, workflow: result.value.workflow, status: result.value.status, conclusion: result.value.conclusion, jobs: result.value.jobs.reduce((counts, job) => { const key = job.conclusion || job.status; counts[key] = (counts[key] || 0) + 1; return counts; }, {}), failures: result.value.jobs.filter(job => job.status === "completed" && ["failure", "timed_out", "startup_failure"].includes(job.conclusion)).map(job => ({ id: job.id, name: job.name, conclusion: job.conclusion, steps: job.steps.filter(step => step.conclusion === "failure") })) })));
