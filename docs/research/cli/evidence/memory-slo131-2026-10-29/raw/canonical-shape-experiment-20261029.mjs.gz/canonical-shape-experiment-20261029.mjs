import fs from "node:fs";
import path from "node:path";
import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { performance } from "node:perf_hooks";
import { createHash } from "node:crypto";
import { createDurableMemoryFixture } from "../../packages/cli/scripts/persistent-capacity-benchmark.mjs";
const sourceFile = path.resolve("packages/context-memory-kernel/lib/canonical.js");
const source = fs.readFileSync(sourceFile, "utf8");
const require = createRequire(sourceFile);
const sha = bytes => createHash("sha256").update(bytes).digest("hex");
const load = text => {
  const module = { exports: {} };
  new Function("module", "exports", "require", text)(module, module.exports, require);
  return module.exports;
};
const helper = `
const nativeSort = Object.getOwnPropertyDescriptor(Array.prototype, "sort").value;
const nativeCompare = Object.getOwnPropertyDescriptor(String.prototype, "localeCompare").value;
const isNative = (fn) => typeof fn === "function" && !require("node:util").types.isProxy(fn) && /\\{\\s*\\[native code\\]\\s*\\}/.test(Function.prototype.toString.call(fn));
const cacheAllowed = isNative(nativeSort) && isNative(nativeCompare);
const keyOrders = new Map();
function orderedKeys(value) {
  const keys = Object.keys(value).filter(key => value[key] !== undefined);
  if (keys.length < 2 || keys.length > 64 || !cacheAllowed || Object.getOwnPropertyDescriptor(Array.prototype, "sort")?.value !== nativeSort || Object.getOwnPropertyDescriptor(String.prototype, "localeCompare")?.value !== nativeCompare)
    return keys.sort((left, right) => left.localeCompare(right, "en"));
  let shape = "";
  for (let index = 0; index < keys.length; index++) {
    const key = keys[index];
    if (key.length > 128) return keys.sort((left, right) => left.localeCompare(right, "en"));
    shape += key.length + ":" + key;
  }
  const cached = keyOrders.get(shape);
  if (cached) return cached;
  const sorted = keys.sort((left, right) => left.localeCompare(right, "en"));
  if (keyOrders.size >= 64) keyOrders.delete(keyOrders.keys().next().value);
  keyOrders.set(shape, sorted);
  return sorted;
}
`;
const needle = `  const keys = Object.keys(value)\n    .filter((key) => value[key] !== undefined)\n    .sort((left, right) => left.localeCompare(right, "en"));`;
assert.equal(source.split(needle).length, 2);
const prototypeSource = source.replace("function canonicalTree(value, path = \"$\") {", helper + "\nfunction canonicalTree(value, path = \"$\") {").replace(needle, "  const keys = orderedKeys(value);");
const original = load(source), prototype = load(prototypeSource);
const state = createDurableMemoryFixture(3000);
const corpus = [...Object.values(state.records), ...state.events, state];
const checks = [];
const check = (name, value) => {
  assert.equal(prototype.canonicalJson(value), original.canonicalJson(value), name);
  assert.equal(prototype.canonicalDigest(value, "shape-test/v1"), original.canonicalDigest(value, "shape-test/v1"), name);
  checks.push(name);
};
for (let index = 0; index < corpus.length; index++) check(`fixture-${index}`, corpus[index]);
check("unicode", { "\u0000:1": 2, "Á": 3, A: 4, a: 5, "ä": 6, "2": 7 });
check("length-collision-left", { "a": 1, "bc": 2 });
check("length-collision-right", { "ab": 1, "c": 2 });
for (let index = 0; index < 100; index++) check(`eviction-${index}`, { [`field${index}`]: 1, x: 2 });
let reads = [];
const getterObject = Object.defineProperties({}, { b: { enumerable: true, get() { reads.push("b"); return 2; } }, a: { enumerable: true, get() { reads.push("a"); return 1; } } });
const getterOutcomes = [];
for (const module of [original, prototype, original, prototype]) {
  reads = [];
  getterOutcomes.push({ value: module.canonicalJson(getterObject), reads: [...reads] });
}
assert.deepEqual(getterOutcomes[1], getterOutcomes[0]);
assert.deepEqual(getterOutcomes[3], getterOutcomes[2]);
const compareDescriptor = Object.getOwnPropertyDescriptor(String.prototype, "localeCompare");
try {
  Object.defineProperty(String.prototype, "localeCompare", { ...compareDescriptor, value: function(other) { return this.toString() < other ? 1 : this.toString() > other ? -1 : 0; } });
  check("changed-comparator", { b: 2, a: 1 });
} finally { Object.defineProperty(String.prototype, "localeCompare", compareDescriptor); }
const durations = [];
for (let round = 0; round < 7; round++) {
  const order = round % 2 ? [["prototype", prototype], ["original", original]] : [["original", original], ["prototype", prototype]];
  for (const [variant, module] of order) {
    const started = performance.now();
    for (const record of Object.values(state.records)) module.canonicalDigest(record, "shape-benchmark/v1");
    module.canonicalDigest(state);
    module.cloneCanonical(state);
    durations.push({ round, variant, ms: performance.now() - started });
  }
}
const report = { observedAt: new Date().toISOString(), sourceFile, sourceSha256: sha(source), prototypeSha256: sha(prototypeSource), positiveChecks: checks.length, getterOutcomes, durations, scope: "Unlanded in-memory key-order cache prototype; all canonical validation, values and hashes still run. This is a microbenchmark, not full query performance or SLO evidence." };
fs.writeFileSync(".work/memory-query-bundle/canonical-shape-prototype-20261029.cjs", prototypeSource, { flag: "wx" });
fs.writeFileSync(".work/memory-query-bundle/canonical-shape-experiment-20261029.json", JSON.stringify(report, null, 2) + "\n", { flag: "wx" });
console.log(JSON.stringify(report));
