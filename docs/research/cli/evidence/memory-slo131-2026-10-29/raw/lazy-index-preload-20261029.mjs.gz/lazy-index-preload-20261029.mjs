import { register, createRequire } from "node:module";
import fs from "node:fs";
import { fileURLToPath } from "node:url";
if (process.argv.includes("--worker")) {
  register(new URL("./lazy-index-loader-20261029.mjs", import.meta.url));
  if (process.env.CC_EXPERIMENT_CANONICAL_SHAPE === "1") {
    const sourceFile = new URL("../../packages/context-memory-kernel/lib/canonical.js", import.meta.url);
    const require = createRequire(sourceFile);
    const module = { exports: {} };
    const source = fs.readFileSync(new URL("./canonical-shape-prototype-20261029.cjs", import.meta.url), "utf8");
    new Function("module", "exports", "require", source)(module, module.exports, require);
    require(fileURLToPath(sourceFile));
    const key = require.resolve(fileURLToPath(sourceFile));
    require.cache[key].exports = module.exports;
  }
}
