# Astra 只读审查记录

审查代理：`/root/memory_cold_review`，模型 `gpt-6-astra`，用户已授权遇到问题找 Astra。代理未修改文件、运行基准或派发任务。当前运行时代码未改变，冻结候选仍为 `7a5d38d151d437f94f8c223dec1fbca52a44da5b`。

审查确认 100K、返回 20 条的类别列表会命中约 19 个 authority shard，每个平均约 390 条，需完整验证约 7,400 条。`normalizeState` 验证每条记录的规范摘要，再对原始 state 计算规范摘要，并 clone events / reconciliations。lazy posting 只能降低部分编译成本，键序缓存的局部收益也不足以证明冷 SLO。

兼容性问题：原 compiler 无条件执行每行的 `scopeKey()`，其中 `JSON.stringify([scope, scopeId])` 可能拒绝 JSON.parse 能接受的极深嵌套值。lazy 原型仅保留 tags / allowedSinks 迭代，在未请求 scope filter 时遗漏该拒绝。根代理用 12,000 层输入独立复现：原实现抛出 RangeError，原型却返回一条结果；原型不准入生产。这是直接 compiler 对照，不是伪造受保护 authority bundle 的生产漏洞证明。

建议的后续方向，均未实现或验收：

- 研究内部已解析 JSON / 已规范化合同对象的专用序列化，减少中间树和已知字段排序；保留公共 canonical 行为。不得用 normalized state 摘要替代原始 state 摘要。
- 研究未来新版本的小 authority 分片：3 位 hex / 4096 桶，同时保留 256 个 query frame，每 frame 覆盖 16 个 authority 子桶。估计选中完整验证的记录数可降至约 500，不能当成性能承诺。若仍要求检测旧大桶全部记录的损坏，该方案不能取得此收益。
- 新布局必须同步 manifest / schema、frame binding、reconciliation、事件序号、发布 / 清理、迁移、容量及 cursor generation。当前 schemaVersion=2，不能只修改 bucketOf。首次迁移须完整验证旧 authority 后原子发布，不能混入或移动 .131 冻结候选。

必须保留：每次完整验证 bundle 全 frame；尾部 frame 失败不得输出之前结果；身份 / 链接 / 目录 / 长度 / 尾随数据 / 读取变化校验；选中 authority 全部记录、未知字段、秘密材料、墓碑约束、record / state 摘要、桶归属、事件序号和 manifest 计数；cache 对物理身份、generation 与本次完整字节绑定；输出复制、权限过滤、游标顺序、分页和 recall 不提前截断。公共 canonical 还包括整数键、`__proto__`、继承 toJSON、getter 顺序、数组 holes / species / override 和英文排序。
