import fs from "node:fs";
import path from "node:path";
import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { performance } from "node:perf_hooks";
import { transform } from "./lazy-index-transform-20261029.mjs";
import { createDurableMemoryFixture } from "../../packages/cli/scripts/persistent-capacity-benchmark.mjs";
import { compileQueryIndex, encodeQueryIndex, selectQueryRows, normalizeListQuery } from "../../packages/cli/src/lib/context-memory-kernel/memory-query-index.js";
const sourceFile = path.resolve("packages/cli/src/lib/context-memory-kernel/memory-query-index.js");
const text = transform(fs.readFileSync(sourceFile, "utf8")).replace('import { createHash } from "node:crypto";', 'const { createHash } = require("node:crypto");').replaceAll("export ", "");
const module = { exports: {} };
new Function("module", "exports", "require", text + "\nmodule.exports = {compileQueryIndex};")(module, module.exports, createRequire(sourceFile));
const fixture = createDurableMemoryFixture(3000);
const bytes = encodeQueryIndex(fixture);
const descriptor = { digest: fixture.digest, recordCount: 3000 };
const first = Object.values(fixture.records)[0];
const queries = [{}, { category: first.category }, { category: "absent" }, { states: ["active", "reinforced"] }, { scopeAdmissions: [{ scope: first.scope, scopeId: first.scopeId }] }, { tags: first.tags.slice(0, 1) }, { sink: first.allowedSinks[0] }, { category: first.category, sink: first.allowedSinks[0], tags: first.tags.slice(0, 1), states: [first.state] }];
const original = compileQueryIndex(bytes, descriptor);
const lazy = module.exports.compileQueryIndex(bytes, descriptor);
for (const options of queries) {
  const query = normalizeListQuery(options);
  assert.deepEqual([...selectQueryRows(lazy, query)], [...selectQueryRows(original, query)]);
}
for (const field of Object.keys(original.postings)) assert.deepEqual(lazy.postings[field], original.postings[field]);
const invalid = [];
for (const [field, values] of [["tags", [null, 42, {}]], ["allowedSinks", [null, 42, {}]]])
  for (const value of values) {
    const broken = JSON.parse(bytes);
    broken.rows[0][field] = value;
    const input = Buffer.from(JSON.stringify(broken));
    assert.throws(() => compileQueryIndex(input, descriptor));
    assert.throws(() => module.exports.compileQueryIndex(input, descriptor));
    invalid.push({ field, value });
  }
const durations = [];
for (let round = 0; round < 7; round++) {
  for (const [name, compile] of (round % 2 ? [["lazy", module.exports.compileQueryIndex], ["original", compileQueryIndex]] : [["original", compileQueryIndex], ["lazy", module.exports.compileQueryIndex]])) {
    const started = performance.now();
    for (let n = 0; n < 20; n++) [...selectQueryRows(compile(bytes, descriptor), normalizeListQuery({ category: first.category }))];
    durations.push({ round, name, ms: performance.now() - started });
  }
}
const report = { observedAt: new Date().toISOString(), positiveQueries: queries.length, allPostingMapsEqual: true, unrequestedInvalidFieldRejections: invalid, durations, boundary: "In-memory compilation prototype only. Production compiler and trust checks remain unchanged. This is not an SLO or query speedup claim." };
fs.writeFileSync(".work/memory-query-bundle/lazy-index-parity-20261029.json", JSON.stringify(report, null, 2) + "\n", { flag: "wx" });
console.log(JSON.stringify(report));
