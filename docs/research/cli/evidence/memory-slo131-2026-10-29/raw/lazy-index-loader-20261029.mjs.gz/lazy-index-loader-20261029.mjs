import { transform } from "./lazy-index-transform-20261029.mjs";
export async function load(url, context, nextLoad) {
  const result = await nextLoad(url, context);
  if (!url.endsWith("/src/lib/context-memory-kernel/memory-query-index.js")) return result;
  return { ...result, source: transform(result.source.toString()) };
}
