import fs from "node:fs";
import assert from "node:assert/strict";
const directory=".work/cli131-ci-recovery-20261029";
const first=JSON.parse(fs.readFileSync(`${directory}/production-first-assets.json`));
const second=JSON.parse(fs.readFileSync(`${directory}/production-second-assets.json`));
assert.equal(first.builderSha256,second.builderSha256);assert.deepEqual(first.files,second.files);assert.deepEqual(first.generatedCandidates,second.generatedCandidates);assert.equal(first.randomBuildPathsFound,false);assert.equal(second.randomBuildPathsFound,false);assert.equal(first.parseErrors.length,0);assert.equal(second.parseErrors.length,0);
const receipt={schema:"chainlesschain.web-panel-production-repro/v1",verifiedAt:new Date().toISOString(),baseSource:first.baseSource,builderSha256:first.builderSha256,buildPolicyState:"uncommitted production-mode fix; final source binding follows commit",identicalFiles:first.files.length,identicalAcrossDifferentSourceRoots:true,identicalAcrossIndependentTemporaryBuildTrees:true,randomBuildPathsFound:false,totalNetworkCandidates:second.totalCandidates,generatedCandidates:second.generatedCandidates.map(row=>({path:row.path,digest:row.digest,calls:row.calls.length})),boundary:"Two Windows Node22.22.2 builds from identical locked inputs. Cross-OS reproducibility remains a required new exact-source CI gate. No paid/native admission."};
fs.writeFileSync(`${directory}/production-repro.json`,JSON.stringify(receipt,null,2)+"\n",{flag:"wx"});console.log(JSON.stringify(receipt));
