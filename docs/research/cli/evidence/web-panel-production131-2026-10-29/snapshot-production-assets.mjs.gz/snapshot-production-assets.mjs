import fs from "node:fs";
import path from "node:path";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { scanNetworkSources } from "../../packages/cli/scripts/lib/budget-egress-inventory.mjs";
const [label,location="snapshot"]=process.argv.slice(2);assert.match(label||"",/^[a-z0-9-]+$/);
const root=location==="main"?process.cwd():path.resolve(".work/cli131-clean-static-98c4");
const assets=path.join(root,"packages/cli/src/assets/web-panel");
const rows=[];
function visit(directory){for(const entry of fs.readdirSync(directory,{withFileTypes:true})){const file=path.join(directory,entry.name);assert.ok(!entry.isSymbolicLink());if(entry.isDirectory())visit(file);else{const bytes=fs.readFileSync(file);if(/\.(?:js|html)$/u.test(file))assert.ok(!/cc-web-panel-[A-Za-z0-9]{6}[\\/]/u.test(bytes.toString("utf8")),"Random build directory escaped into the production payload");rows.push({path:path.relative(assets,file).replaceAll("\\","/"),bytes:bytes.length,sha256:createHash("sha256").update(bytes).digest("hex")});}}}
visit(assets);rows.sort((a,b)=>a.path<b.path?-1:a.path>b.path?1:0);
const scan=scanNetworkSources(root,["packages/cli/src","packages/cli/scripts"]);
const generated=scan.networkCandidates.filter(row=>row.path.startsWith("packages/cli/src/assets/web-panel/"));
const builder=fs.readFileSync(path.join(root,"packages/cli/scripts/build-web-panel.mjs"));
const receipt={capturedAt:new Date().toISOString(),root,baseSource:"98c4be4a76e22b127518b1ea1116dabdfb95dd10",builderState:"uncommitted production-mode fix",builderSha256:createHash("sha256").update(builder).digest("hex"),files:rows,generatedCandidates:generated,randomBuildPathsFound:false,totalCandidates:scan.networkCandidates.length,parseErrors:scan.parseErrors};
fs.writeFileSync(`.work/cli131-ci-recovery-20261029/${label}.json`,JSON.stringify(receipt,null,2)+"\n",{flag:"wx"});console.log(JSON.stringify({label,files:rows.length,totalCandidates:receipt.totalCandidates,generated,randomBuildPathsFound:false}));
