import fs from "node:fs";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import YAML from "yaml";
const file=".github/workflows/cli-ci.yml";
const before=YAML.parse(execFileSync("git",["show",`98c4be4a76e22b127518b1ea1116dabdfb95dd10:${file}`],{encoding:"utf8",windowsHide:true}));
const after=YAML.parse(fs.readFileSync(file,"utf8"));
for(const [name,oldJob] of Object.entries(before.jobs)){
 const next=structuredClone(after.jobs[name]);
 if(["test-ubuntu","test-windows","test-macos"].includes(name)){
  assert.deepEqual(next.needs,["docs-scope","source-review-preflight"]);next.needs=oldJob.needs;
 }
 if(name==="verify-cli"){
  const added=next.steps.findIndex(step=>step.name==="Build reviewed Web Panel assets from locked sources");assert.ok(added>=0);assert.equal(next.steps[added+1].name,"Audit reviewed runtime and diagnostic script identities without paid admission");next.steps.splice(added,1);
 }
 assert.deepEqual(next,oldJob,`Existing job ${name} changed beyond the declared preparation`);
}
const visited=new Set(),active=new Set();
function visit(name){assert.ok(after.jobs[name]);if(visited.has(name))return;assert.ok(!active.has(name),"DAG cycle");active.add(name);const needs=after.jobs[name].needs||[];for(const dependency of typeof needs==="string"?[needs]:needs)visit(dependency);active.delete(name);visited.add(name);}
Object.keys(after.jobs).forEach(visit);
const early=after.jobs["source-review-preflight"];
assert.ok(early.steps.some(step=>step.name==="Verify exact source identity"));
for(const event of ["push","pull_request"])for(const input of ["packages/web-panel/**","packages/locales/seed/**","package.json"])assert.ok(after.on[event].paths.includes(input));
console.log(JSON.stringify({yamlParsed:true,acyclic:true,allExistingMatricesAndChecksPreserved:true,exactSourceEarlyCheck:true,inputPathsCovered:true}));
