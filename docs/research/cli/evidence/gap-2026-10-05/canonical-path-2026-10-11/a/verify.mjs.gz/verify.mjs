import assert from 'node:assert/strict';
export function inspect(probe){
  const v=probe.value;
  assert.equal(v.schema,'chainlesschain.canonical-path-function-slice/v1');assert.equal(v.status,'NOT_ADMITTED');assert.equal(v.admissionEligible,false);assert.equal(v.compatibilityConfirmed,false);assert.equal(v.sourceSliceOnly,true);
  assert.deepEqual(probe.identity,probe.identityAfter);assert.equal(probe.identity.token.inJob,true);assert.equal(probe.identity.token.capabilityCount,0);assert.equal(probe.identity.actor.pid,probe.adapter.pid);assert.equal(probe.identity.token.appContainerSid,probe.adapter.appContainerSid);assert.equal(probe.adapter.patches,6);assert.equal(probe.adapter.state,2);
  assert.equal(v.plainBefore.path,'X:\\scratch\\private-v4-junction-probe\\plain');assert.equal(v.plainBefore.lstat.directory,true);assert.equal(v.plainBefore.lstat.symbolicLink,false);assert.equal(v.plainBefore.native,v.plainBefore.path);assert.equal(v.plainBefore.nativeError,undefined);assert.equal(v.plainError,null);assert.equal(v.plainCreated,true);assert.equal(v.plainCalls,1);
  assert.equal(v.junction.path,'X:\\scratch\\private-v4-junction-probe\\link');
  assert.equal(v.rejected?.code,'CONTEXT_MEMORY_STORE_CORRUPT');assert.equal(v.junctionMkdirCalls,0);assert.deepEqual(v.beforeEntries,[]);assert.deepEqual(v.afterEntries,[]);
  assert.equal(v.mkdirCalls.length,1);assert.equal(v.mkdirCalls[0][0],'X:/scratch/private-v4-junction-probe/plain/nested');assert.deepEqual(v.mkdirCalls[0][1],{recursive:true,mode:448});
  const differing=typeof v.junction.native==='string'&&v.junction.native.toLowerCase()!==v.junction.path.toLowerCase();
  const denied=typeof v.junction.nativeError?.code==='string';assert(differing||denied||v.junction.lstat?.symbolicLink===true);
  return {observationsVerified:true,status:'NOT_ADMITTED',admissionEligible:false,compatibilityConfirmed:false,sourceSliceOnly:true,
    plainDirectoryUsable:true,junctionRejectedBeforeMkdir:true,junctionNativeCanonicalDifferent:differing,junctionNativeResolutionRejected:denied,
    allReparseTagsExcluded:false,continuousAuthorityProven:false,frozenReviewRun:false};
}
