"use strict";
const preload=require("X:/workspace/adapter/windows-node-private-v4-preload.cjs");
const addon=require("X:/workspace/adapter/windows-node-private-v4.node");
const fs=require("node:fs");const assert=require("node:assert/strict");const {dirname,resolve}=require("node:path");
const {lstatSync,realpathSync}=fs;const mkdirCalls=[];
const mkdirSync=(...args)=>{mkdirCalls.push(args);return fs.mkdirSync(...args);};
function directories(directory) {
  let current = resolve(directory);
  while (true) {
    const stat = lstatSync(current);
    // macOS exposes its system temporary tree through the root-owned /var
    // alias. This exact OS alias is not a user-controlled authority redirect.
    const systemAlias =
      process.platform === "darwin" &&
      ["/var", "/tmp"].includes(current) &&
      stat.isSymbolicLink() &&
      stat.uid === 0 &&
      realpathSync(current) === `/private${current}`;
    if (!systemAlias && (!stat.isDirectory() || stat.isSymbolicLink()))
      throw corruptStore(current, "authority directory is unsafe");
    if (process.platform === "win32") {
      // Some Windows runtime adapters report an ordinary directory for a
      // junction whose target cannot be decoded in their DOS namespace. Keep
      // the lstat guard and independently reject a different native canonical
      // coordinate before mkdir or lock acquisition. This is an additional
      // consistency check, not a proof against every reparse tag or a race.
      let canonical;
      try {
        canonical = realpathSync.native(current);
      } catch {
        throw corruptStore(current, "authority directory cannot be resolved");
      }
      if (
        typeof canonical !== "string" ||
        resolve(canonical).toLowerCase() !== current.toLowerCase()
      )
        throw corruptStore(current, "authority directory resolves elsewhere");
    }
    const parent = dirname(current);
    if (parent === current) break;
    current = parent;
  }
}
function existsSync(file) {
  try {
    lstatSync(file);
    return true;
  } catch (error) {
    if (error.code === "ENOENT") return false;
    throw error;
  }
}
function ensureSafeDirectory(directory) {
  let existing = resolve(directory);
  while (!existsSync(existing)) existing = dirname(existing);
  directories(existing);
  mkdirSync(directory, { recursive: true, mode: 0o700 });
  directories(directory);
}
function corruptStore(filePath, reason, cause) {
  const error = new Error(`Context/Memory store is invalid: ${reason}`, {
    ...(cause ? { cause } : {}),
  });
  error.code = "CONTEXT_MEMORY_STORE_CORRUPT";
  error.filePath = filePath;
  return error;
}
const identity=JSON.parse(addon.inspectPrivateIdentity());
const base="X:/scratch/private-v4-junction-probe",plain=base+"/plain",target=base+"/target",link=base+"/link";
fs.mkdirSync(base);fs.mkdirSync(plain);fs.mkdirSync(target);
function observe(candidate){const result={path:resolve(candidate)};try{const s=fs.lstatSync(candidate);result.lstat={directory:s.isDirectory(),symbolicLink:s.isSymbolicLink(),dev:s.dev,ino:s.ino};}catch(error){result.lstatError={code:error.code,errno:error.errno,syscall:error.syscall};}try{result.native=fs.realpathSync.native(candidate);}catch(error){result.nativeError={code:error.code,errno:error.errno,syscall:error.syscall};}return result;}
const plainBefore=observe(plain);let plainError=null;try{ensureSafeDirectory(plain+"/nested");}catch(error){plainError={code:error.code,message:error.message,filePath:error.filePath};}
const plainCalls=mkdirCalls.length;const plainCreated=fs.existsSync(plain+"/nested");
fs.symlinkSync(target,link,"junction");
const junction=observe(link);const reparse=JSON.parse(addon.probeReparse("X:\\scratch\\private-v4-junction-probe\\link"));
const beforeEntries=fs.readdirSync(target);let rejected=null;try{ensureSafeDirectory(link+"/nested");}catch(error){rejected={code:error.code,message:error.message,filePath:error.filePath};}
const afterEntries=fs.readdirSync(target);const identityAfter=JSON.parse(addon.inspectPrivateIdentity());const adapter=JSON.parse(addon.snapshot());
const value={schema:"chainlesschain.canonical-path-function-slice/v1",status:"NOT_ADMITTED",admissionEligible:false,compatibilityConfirmed:false,sourceSliceOnly:true,plainBefore,plainError,plainCreated,plainCalls,junction,reparse,rejected,beforeEntries,afterEntries,junctionMkdirCalls:mkdirCalls.length-plainCalls,mkdirCalls};
fs.writeFileSync("X:/scratch/canonical-probe.json",JSON.stringify({identity,identityAfter,value,adapter,preload:preload.snapshot()},null,2));
assert.equal(adapter.state,2);assert.equal(adapter.patches,6);
