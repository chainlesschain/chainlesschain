import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';import {pathToFileURL} from 'node:url';
const dir=path.resolve('.work/junction-canonical-20261011-a'),report=JSON.parse(fs.readFileSync(path.join(dir,'run/report.json'))),hash=b=>'sha256:'+createHash('sha256').update(b).digest('hex');
let inputBindings=0;
for(const row of [...report.sourceInputs,...report.binaryInputs,...report.copiedArtifacts.flatMap(p=>[p.source,p.destination])]){const raw=fs.readFileSync(row.path);assert.equal(hash(raw),row.digest);assert.equal(raw.length,row.bytes);inputBindings++;}
const origins=JSON.parse(fs.readFileSync(path.join(dir,'origins.json')));let unchangedNative=0;
for(const origin of origins){const name=path.basename(origin.path);const file=path.join(dir,'source',name);if(!fs.existsSync(file))continue;assert.deepEqual(fs.readFileSync(file),fs.readFileSync(origin.path));unchangedNative++;}assert.equal(unchangedNative,9);
const extraction=JSON.parse(fs.readFileSync(path.join(dir,'extraction.json'))),actor=fs.readFileSync(path.join(dir,'check.cjs'),'utf8');
assert.equal(hash(fs.readFileSync(path.join(dir,'segmented-memory-port.js'))),extraction.sourceDigest);assert.equal(hash(fs.readFileSync(path.join(dir,'durable-memory-port.js'))),extraction.errorDigest);
for(const fn of extraction.functions){const text=actor.slice(actor.indexOf('function '+fn.name+'('));const bytes=Buffer.from(text).subarray(0,fn.bytes);assert.equal(hash(bytes),fn.digest);}
const h=report.host,p=report.probe;assert.equal(report.execution.status,0);assert.equal(report.execution.signal,null);assert.equal(report.execution.error,null);
for(const key of ['completed','cleanupConfirmed','profileDeleted','loopbackExemptionAbsent','hostMapUnchanged','rootTokenAndSameJobProven','rootMapInstalled'])assert.equal(h[key],true);
assert.equal(h.rootWait,0);assert.equal(h.rootExit,0);assert.equal(h.jobActiveProcesses,0);assert.equal(h.requests,0);assert.equal(h.error,0);assert.equal(h.rootPid,p.identity.actor.pid);assert.equal(h.appContainerSid,p.identity.token.appContainerSid);assert.equal(h.creationLedger.length,1);
const ledger=h.creationLedger[0];assert.equal(ledger.pid,h.rootPid);assert.equal(ledger.wait,0);assert.equal(ledger.exitKnown,true);assert.equal(ledger.exit,0);assert.equal(ledger.inheritedHandleCount,9);assert.equal(ledger.launchRequests,0);assert.equal(ledger.registered,true);assert.equal(ledger.kind,'root');
assert.equal(report.receipts.length,2);assert.deepEqual(report.receipts.map(r=>r.phase).sort(),['exit','installed']);
for(const receipt of report.receipts){assert.equal(receipt.pid,h.rootPid);assert.equal(receipt.adapter.appContainerSid,h.appContainerSid);assert.equal(receipt.adapter.patches,6);assert.equal(receipt.adapter.inJob,true);assert.equal(receipt.adapter.capabilityCount,0);assert.equal(receipt.sessionId,h.sessionId);assert.equal(receipt.generation,h.generation);assert.equal(receipt.actor.registrationId,ledger.registrationId);}
const {inspect}=await import(pathToFileURL(path.join(dir,'verify.mjs')).href);
function validate(probe){
  const result=inspect(probe),v=probe.value,r=v.reparse;assert.equal(v.junction.lstat.directory,true);assert.equal(v.junction.lstat.symbolicLink,false);
  assert.equal(r.readOnly,true);assert.equal(r.openError,0);assert.equal(r.attributeRead,true);assert.equal(r.attributeError,0);assert.equal(r.attributes,0x410);assert.equal(r.attributeTag,0xa0000003);assert.equal(r.reparseRead,true);assert.equal(r.reparseError,0);assert.equal(r.rawTag,0xa0000003);assert.equal(r.mountPointDecoded,true);assert.equal(r.returnedBytes,r.dataLength+8);
  assert.equal(r.substituteName,'\\??\\Global\\'+probe.identity.root.physical.path+'\\scratch\\private-v4-junction-probe\\target');
  assert.equal(v.junction.native,'X:\\scratch\\private-v4-junction-probe\\target');assert.equal(v.rejected.filePath,v.junction.path);assert.equal(v.rejected.message,'Context/Memory store is invalid: authority directory resolves elsewhere');
  return result;
}
assert.deepEqual(validate(p),report.inspection);const checks=['actual-function-slice-result','native-inputs-unchanged','actor-functions-exact-source-bytes','original-handle-lifecycle'];
for(const [name,mutate]of [
  ['admission',x=>x.value.admissionEligible=true],['schema',x=>x.value.schema='wrong'],['slots',x=>x.adapter.patches=7],['identity',x=>x.identityAfter.actor.pid++],
  ['plain-failed',x=>x.value.plainError={code:'EPERM'}],['plain-canonical',x=>x.value.plainBefore.native+='wrong'],['plain-mkdir',x=>x.value.plainCalls=0],
  ['junction-mkdir',x=>x.value.junctionMkdirCalls=1],['target-mutated',x=>x.value.afterEntries=['nested']],['rejection',x=>x.value.rejected=null],
  ['real-canonical',x=>x.value.junction.native=x.value.junction.path],['fake-lstat',x=>x.value.junction.lstat.symbolicLink=true],
  ['fake-tag',x=>x.value.reparse.rawTag=0],['fake-attributes',x=>x.value.reparse.attributes=16],['read-failure',x=>x.value.reparse.reparseError=5],
  ['fake-substitute',x=>x.value.reparse.substituteName='X:\\target'],['fake-length',x=>x.value.reparse.returnedBytes++],['wrong-path',x=>x.value.rejected.filePath='X:\\scratch']
]){const copy=structuredClone(p);mutate(copy);assert.throws(()=>validate(copy));checks.push('rejected-'+name);}
const result={schema:'chainlesschain.canonical-path-independent-validation/v1',passed:checks.length,inputBindingsChecked:inputBindings,unchangedNativeInputs:unchangedNative,exactFunctionSlices:extraction.functions.length,checks,status:'NOT_ADMITTED',admissionEligible:false};
fs.writeFileSync('.work/canonical-path-independent-validation-20261011.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
