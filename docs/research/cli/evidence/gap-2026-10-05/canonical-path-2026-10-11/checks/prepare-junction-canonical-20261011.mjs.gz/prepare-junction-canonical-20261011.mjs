import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';
const out=path.resolve('.work/junction-canonical-20261011-a');fs.mkdirSync(out);
const hash=b=>'sha256:'+createHash('sha256').update(b).digest('hex');
const sourcePath='packages/cli/src/lib/context-memory-kernel/segmented-memory-port.js',errorPath='packages/cli/src/lib/context-memory-kernel/durable-memory-port.js';
const sourceBytes=fs.readFileSync(sourcePath),errorBytes=fs.readFileSync(errorPath);const source=sourceBytes.toString(),errorSource=errorBytes.toString();
const extract=(text,from,to)=>{const a=text.indexOf(from),b=text.indexOf(to,a);assert(a>=0&&b>a);return text.slice(a,b).trimEnd();};
const segments=[extract(source,'function directories(','\nfunction identity('),extract(source,'function existsSync(','\nfunction ensureSafeDirectory('),extract(source,'function ensureSafeDirectory(','\n/**'),extract(errorSource,'function corruptStore(','\nfunction assertRegularFile(')];
fs.writeFileSync(path.join(out,'segmented-memory-port.js'),sourceBytes);fs.writeFileSync(path.join(out,'durable-memory-port.js'),errorBytes);
fs.writeFileSync(path.join(out,'extraction.json'),JSON.stringify({sourcePath,sourceDigest:hash(sourceBytes),errorPath,errorDigest:hash(errorBytes),functions:segments.map(bytes=>({name:bytes.match(/function (\w+)/)[1],bytes:Buffer.byteLength(bytes),digest:hash(bytes)})),scope:'exact-function-source-slice-with-recording-mkdir-dependency; not full module or frozen review'},null,2)+'\n');
let driver=fs.readFileSync('.work/acl-owner-only-20261011-b/run.mjs','utf8');
const start=driver.indexOf("  fs.copyFileSync(path.join(output,'acl-probe.h')");const end=driver.indexOf("  write('origins.json',origins);",start);assert(start>0&&end>start);driver=driver.slice(0,start)+driver.slice(end);
driver=driver.replace("['run.mjs','check.cjs','verify.mjs','acl-probe.h']","['run.mjs','check.cjs','verify.mjs','extraction.json','segmented-memory-port.js','durable-memory-port.js']");
driver=driver.replaceAll('cc-private-v4-owner-acl-','cc-private-v4-canonical-').replaceAll('acl-probe.json','canonical-probe.json').replace('probe.value.contextBefore.pid','probe.identity.actor.pid');
fs.writeFileSync(path.join(out,'run.mjs'),driver);
const actor=`"use strict";
const preload=require("X:/workspace/adapter/windows-node-private-v4-preload.cjs");
const addon=require("X:/workspace/adapter/windows-node-private-v4.node");
const fs=require("node:fs");const assert=require("node:assert/strict");const {dirname,resolve}=require("node:path");
const {lstatSync,realpathSync}=fs;const mkdirCalls=[];
const mkdirSync=(...args)=>{mkdirCalls.push(args);return fs.mkdirSync(...args);};
${segments.join('\n')}
const identity=JSON.parse(addon.inspectPrivateIdentity());
const base="X:/scratch/private-v4-junction-probe",plain=base+"/plain",target=base+"/target",link=base+"/link";
fs.mkdirSync(base);fs.mkdirSync(plain);fs.mkdirSync(target);
function observe(candidate){const result={path:resolve(candidate)};try{const s=fs.lstatSync(candidate);result.lstat={directory:s.isDirectory(),symbolicLink:s.isSymbolicLink(),dev:s.dev,ino:s.ino};}catch(error){result.lstatError={code:error.code,errno:error.errno,syscall:error.syscall};}try{result.native=fs.realpathSync.native(candidate);}catch(error){result.nativeError={code:error.code,errno:error.errno,syscall:error.syscall};}return result;}
const plainBefore=observe(plain);let plainError=null;try{ensureSafeDirectory(plain+"/nested");}catch(error){plainError={code:error.code,message:error.message,filePath:error.filePath};}
const plainCalls=mkdirCalls.length;const plainCreated=fs.existsSync(plain+"/nested");
fs.symlinkSync(target,link,"junction");
const junction=observe(link);const reparse=JSON.parse(addon.probeReparse("X:\\\\scratch\\\\private-v4-junction-probe\\\\link"));
const beforeEntries=fs.readdirSync(target);let rejected=null;try{ensureSafeDirectory(link+"/nested");}catch(error){rejected={code:error.code,message:error.message,filePath:error.filePath};}
const afterEntries=fs.readdirSync(target);const identityAfter=JSON.parse(addon.inspectPrivateIdentity());const adapter=JSON.parse(addon.snapshot());
const value={schema:"chainlesschain.canonical-path-function-slice/v1",status:"NOT_ADMITTED",admissionEligible:false,compatibilityConfirmed:false,sourceSliceOnly:true,plainBefore,plainError,plainCreated,plainCalls,junction,reparse,rejected,beforeEntries,afterEntries,junctionMkdirCalls:mkdirCalls.length-plainCalls,mkdirCalls};
fs.writeFileSync("X:/scratch/canonical-probe.json",JSON.stringify({identity,identityAfter,value,adapter,preload:preload.snapshot()},null,2));
assert.equal(adapter.state,2);assert.equal(adapter.patches,6);
`;
fs.writeFileSync(path.join(out,'check.cjs'),actor);
console.log(out);
