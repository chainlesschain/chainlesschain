"use strict";
const preload = require("X:/workspace/adapter/windows-node-private-v4-preload.cjs");
const addon = require("X:/workspace/adapter/windows-node-private-v4.node");
const fs = require("node:fs");
const assert = require("node:assert/strict");
const identity = JSON.parse(addon.inspectPrivateIdentity());
fs.mkdirSync("X:/scratch/private-v4-acl-probe");
const value = JSON.parse(addon.observeFixedScratchAcl());
let argumentRejected = false;
try { addon.observeFixedScratchAcl("X:/scratch"); }
catch (error) { argumentRejected = error.code === "ACL_OBSERVATION_ARGUMENT"; }
const adapter = JSON.parse(addon.snapshot());
fs.writeFileSync("X:/scratch/acl-probe.json", JSON.stringify({identity,value,argumentRejected,adapter,preload:preload.snapshot()},null,2));
assert.equal(argumentRejected, true);
assert.equal(adapter.state, 2);
assert.equal(adapter.patches, 6);
assert.equal(value.admissionEligible, false);
assert.equal(value.compatibilityConfirmed, false);
// A complete negative observation is a successful diagnostic execution.
// The independent verifier, not this actor, evaluates the owner-only contract.
