// Read-only compatibility observation. Fixed actor-created object, no policy grant.
std::string aclHex(const BYTE* bytes, size_t length) {
  static constexpr char digits[] = "0123456789abcdef";
  std::string output; output.reserve(length * 2);
  for (size_t i = 0; i < length; ++i) { output += digits[bytes[i] >> 4]; output += digits[bytes[i] & 15]; }
  return output;
}
std::string aclSid(PSID sid) {
  if (!sid || !IsValidSid(sid)) return "null";
  LPWSTR value = nullptr;
  if (!ConvertSidToStringSidW(sid, &value)) return "null";
  const std::string output = "\"" + privateJson(value) + "\""; LocalFree(value); return output;
}
napi_value aclObservationCallback(napi_env env, napi_callback_info info) {
  napi_value argument[1]; size_t count = 1;
  if (state != 2 || api.napi_get_cb_info(env, info, &count, argument, nullptr, nullptr) != napi_ok || count != 0) {
    api.napi_throw_error(env, "ACL_OBSERVATION_ARGUMENT", "Installed adapter and no arguments required"); return nullptr;
  }
  const auto before = coordinateContext();
  WalkHandles held;
  const WCHAR* names[] = {L"X:\\scratch", L"X:\\scratch\\private-v4-acl-probe"};
  HANDLE target = INVALID_HANDLE_VALUE; std::string opens = "[";
  bool bound = before.expectedToken; DWORD openError = 0;
  for (unsigned i = 0; i < 2 && bound; ++i) {
    HANDLE handle = CreateFileW(names[i], READ_CONTROL | FILE_READ_ATTRIBUTES,
        FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_EXISTING,
        FILE_FLAG_BACKUP_SEMANTICS | FILE_FLAG_OPEN_REPARSE_POINT, nullptr);
    openError = handle == INVALID_HANDLE_VALUE ? GetLastError() : 0;
    WCHAR canonical[kPathChars] = {};
    bool matched = false;
    if (handle != INVALID_HANDLE_VALUE) {
      held.handles[held.count++] = handle;
      std::wstring expected = L"\\\\?\\"; expected += names[i];
      matched = plainObject(handle, true) && canonicalPrivateDos(handle, canonical) && expected == canonical;
      if (i == 1) target = handle;
    }
    if (i) opens += ",";
    opens += "{\"path\":\"" + privateJson(names[i]) + "\",\"desiredAccess\":131200,\"shareAccess\":3,\"openError\":" +
        std::to_string(openError) + ",\"opened\":" + (handle != INVALID_HANDLE_VALUE ? "true" : "false") +
        ",\"fixedPlainObjectMatched\":" + (matched ? "true" : "false") + "}";
    bound = bound && matched;
  }
  opens += "]";
  const std::string fileBefore = bound ? coordinateFile(target) : "null";
  PSECURITY_DESCRIPTOR descriptor = nullptr; PSID owner = nullptr; PACL returnedDacl = nullptr;
  DWORD securityError = ERROR_INVALID_HANDLE;
  if (bound) securityError = GetSecurityInfo(target, SE_FILE_OBJECT,
      OWNER_SECURITY_INFORMATION | DACL_SECURITY_INFORMATION, &owner, nullptr, &returnedDacl, nullptr, &descriptor);
  bool descriptorValid = securityError == ERROR_SUCCESS && descriptor && IsValidSecurityDescriptor(descriptor);
  SECURITY_DESCRIPTOR_CONTROL control = 0; DWORD revision = 0, controlError = 0, daclError = 0, infoError = 0, aceError = 0;
  BOOL present = FALSE, defaulted = FALSE; PACL dacl = nullptr; ACL_SIZE_INFORMATION size = {};
  bool controlRead = false, daclRead = false, aclValid = false, infoRead = false, completeAces = false;
  std::string aces = "[]", rawAcl = "null", ownerText = "null";
  if (descriptorValid) {
    ownerText = aclSid(owner);
    controlRead = GetSecurityDescriptorControl(descriptor, &control, &revision) != FALSE;
    if (!controlRead) controlError = GetLastError();
    daclRead = GetSecurityDescriptorDacl(descriptor, &present, &dacl, &defaulted) != FALSE;
    if (!daclRead) daclError = GetLastError();
    if (daclRead && present && dacl) {
      aclValid = IsValidAcl(dacl) != FALSE;
      if (aclValid) {
        rawAcl = "\"" + aclHex(reinterpret_cast<const BYTE*>(dacl), dacl->AclSize) + "\"";
        infoRead = GetAclInformation(dacl, &size, sizeof(size), AclSizeInformation) != FALSE;
        if (!infoRead) infoError = GetLastError();
        if (infoRead) {
          aces = "["; completeAces = true;
          for (DWORD i = 0; i < size.AceCount; ++i) {
            void* raw = nullptr;
            if (!GetAce(dacl, i, &raw)) { aceError = GetLastError(); completeAces = false; break; }
            const auto* header = static_cast<const ACE_HEADER*>(raw);
            const auto* bytes = static_cast<const BYTE*>(raw);
            const uintptr_t offset = bytes - reinterpret_cast<const BYTE*>(dacl);
            if (offset > dacl->AclSize || header->AceSize < sizeof(ACE_HEADER) || header->AceSize > dacl->AclSize - offset) {
              aceError = ERROR_INVALID_ACL; completeAces = false; break;
            }
            DWORD mask = 0; std::string sid = "null";
            const bool basic = header->AceType == ACCESS_ALLOWED_ACE_TYPE || header->AceType == ACCESS_DENIED_ACE_TYPE ||
                header->AceType == SYSTEM_AUDIT_ACE_TYPE || header->AceType == SYSTEM_ALARM_ACE_TYPE;
            if (header->AceSize >= 8) memcpy(&mask, bytes + 4, sizeof(mask));
            if (basic && header->AceSize >= 16) {
              const DWORD sidBytes = GetSidLengthRequired(bytes[9]);
              if (sidBytes <= header->AceSize - 8u) sid = aclSid(const_cast<BYTE*>(bytes + 8));
            }
            if (i) aces += ",";
            aces += "{\"index\":" + std::to_string(i) + ",\"type\":" + std::to_string(header->AceType) +
                ",\"flags\":" + std::to_string(header->AceFlags) + ",\"bytes\":" + std::to_string(header->AceSize) +
                ",\"mask\":" + std::to_string(mask) + ",\"sid\":" + sid + ",\"basicDecoded\":" +
                (basic && sid != "null" ? "true" : "false") + ",\"rawHex\":\"" + aclHex(bytes, header->AceSize) + "\"}";
          }
          aces += "]";
        }
      }
    }
  }
  const std::string fileAfter = bound ? coordinateFile(target) : "null";
  if (descriptor) LocalFree(descriptor);
  const auto after = coordinateContext();
  const bool stable = before.expectedToken && after.expectedToken && before.json == after.json;
  std::string value = "{\"schema\":\"chainlesschain.private-acl-observation/v1\",\"status\":\"NOT_ADMITTED\","
      "\"readOnly\":true,\"admissionEligible\":false,\"compatibilityConfirmed\":false,\"mappingChanged\":false,"
      "\"scope\":\"fixed-actor-created-scratch-directory\",\"path\":\"X:\\\\scratch\\\\private-v4-acl-probe\","
      "\"contextBefore\":" + before.json + ",\"contextAfter\":" + after.json + ",\"contextObservedStable\":" + (stable ? "true" : "false") +
      ",\"opens\":" + opens + ",\"fixedObjectBound\":" + (bound ? "true" : "false") + ",\"fileBefore\":" + fileBefore + ",\"fileAfter\":" + fileAfter +
      ",\"securityReadAttempted\":" + (bound ? "true" : "false") + ",\"securityError\":" + std::to_string(securityError) +
      ",\"descriptorValid\":" + (descriptorValid ? "true" : "false") + ",\"ownerSid\":" + ownerText +
      ",\"controlRead\":" + (controlRead ? "true" : "false") + ",\"controlError\":" + std::to_string(controlError) + ",\"control\":" + std::to_string(control) +
      ",\"descriptorRevision\":" + std::to_string(revision) + ",\"daclProtected\":" + (controlRead ? (control & SE_DACL_PROTECTED ? "true" : "false") : "null") +
      ",\"daclRead\":" + (daclRead ? "true" : "false") + ",\"daclError\":" + std::to_string(daclError) + ",\"daclPresent\":" + (daclRead ? (present ? "true" : "false") : "null") +
      ",\"daclNull\":" + (daclRead ? (dacl == nullptr ? "true" : "false") : "null") + ",\"daclDefaulted\":" + (daclRead ? (defaulted ? "true" : "false") : "null") +
      ",\"aclValid\":" + (aclValid ? "true" : "false") + ",\"aclInfoRead\":" + (infoRead ? "true" : "false") + ",\"aclInfoError\":" + std::to_string(infoError) +
      ",\"aclBytesInUse\":" + std::to_string(size.AclBytesInUse) + ",\"aclBytesFree\":" + std::to_string(size.AclBytesFree) +
      ",\"aceCount\":" + std::to_string(size.AceCount) + ",\"acesComplete\":" + (completeAces ? "true" : "false") + ",\"aceError\":" + std::to_string(aceError) +
      ",\"rawAclHex\":" + rawAcl + ",\"aces\":" + aces + "}";
  napi_value result;
  if (api.napi_create_string_utf8(env, value.c_str(), NAPI_AUTO_LENGTH, &result) != napi_ok) return nullptr;
  return result;
}
