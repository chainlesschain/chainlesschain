import assert from 'node:assert/strict';
export function inspect(probe) {
  const value = probe.value;
  assert.equal(value.schema, 'chainlesschain.private-acl-observation/v1');
  assert.equal(value.status, 'NOT_ADMITTED');
  assert.equal(value.readOnly, true);
  for (const key of ['admissionEligible','compatibilityConfirmed','mappingChanged']) assert.equal(value[key],false);
  assert.equal(value.path, 'X:\\scratch\\private-v4-acl-probe');
  assert.equal(probe.argumentRejected,true);
  assert.equal(probe.adapter.state,2);
  assert.equal(probe.adapter.patches,6);
  assert.equal(value.contextObservedStable,true);
  assert.deepEqual(value.contextBefore,value.contextAfter);
  const context=value.contextBefore;
  assert.equal(context.pid,probe.adapter.pid);
  assert.equal(context.appContainerSid,probe.adapter.appContainerSid);
  assert.equal(context.capabilityCount,0);
  assert.equal(context.appContainer,true);
  assert.equal(context.effectiveTokenKnown,true);
  assert.equal(context.noImpersonationObserved,true);
  assert.equal(context.threadTokenOpened,false);
  assert.equal(context.threadTokenError,1008);
  assert.equal(context.error,0);
  assert.equal(context.tokenType,1);
  assert(Number.isSafeInteger(context.threadId)&&context.threadId>0);
  assert.equal(value.opens.length,2);
  for(const [i,row] of value.opens.entries()) {
    assert.equal(row.path,i?'X:\\scratch\\private-v4-acl-probe':'X:\\scratch');
    assert.equal(row.desiredAccess,131200);assert.equal(row.shareAccess,3);
    assert.equal(row.opened,true);assert.equal(row.openError,0);assert.equal(row.fixedPlainObjectMatched,true);
  }
  assert.equal(value.fixedObjectBound,true);
  assert.deepEqual(value.fileBefore,value.fileAfter);
  assert.equal(value.fileBefore.observed,true);
  assert.equal(value.fileBefore.directory,true);
  assert.equal(value.fileBefore.reparse,false);
  assert.equal(value.securityReadAttempted,true);
  assert.equal(value.securityError,0);
  for(const key of ['descriptorValid','controlRead','daclRead','aclValid','aclInfoRead','acesComplete']) assert.equal(value[key],true);
  for(const key of ['controlError','daclError','aclInfoError','aceError']) assert.equal(value[key],0);
  assert.equal(value.daclPresent,true);assert.equal(value.daclNull,false);
  assert.equal(value.daclProtected,!!(value.control&0x1000));
  assert.equal(value.daclPresent,!!(value.control&4));
  assert.equal(value.daclDefaulted,!!(value.control&8));
  assert.equal(value.descriptorRevision,1);
  assert.match(value.ownerSid,/^S-1-/);
  assert.match(value.rawAclHex,/^(?:[0-9a-f]{2})+$/);
  const acl=Buffer.from(value.rawAclHex,'hex');
  assert.equal(acl.readUInt16LE(2),acl.length);
  assert.equal(acl.readUInt16LE(4),value.aceCount);
  assert.equal(acl.length,value.aclBytesInUse+value.aclBytesFree);
  assert.equal(value.aces.length,value.aceCount);
  let offset=8;
  for(const [index,ace] of value.aces.entries()) {
    assert.equal(ace.index,index);
    const raw=Buffer.from(ace.rawHex,'hex');
    assert.equal(raw.length,ace.bytes);assert.equal(raw.readUInt16LE(2),ace.bytes);
    assert.equal(raw[0],ace.type);assert.equal(raw[1],ace.flags);assert.equal(raw.readUInt32LE(4),ace.mask);
    assert.deepEqual(acl.subarray(offset,offset+raw.length),raw);offset+=raw.length;
    assert.equal(ace.basicDecoded,true);
    assert([0,1,2,3].includes(ace.type));
    const sid=raw.subarray(8);assert.equal(sid.length,8+sid[1]*4);
    const authority=sid.readUIntBE(2,6);
    const sub=Array.from({length:sid[1]},(_,i)=>sid.readUInt32LE(8+i*4));
    assert.equal(ace.sid,`S-${sid[0]}-${authority}-${sub.join('-')}`);
  }
  assert.equal(offset,value.aclBytesInUse);
  const checks={ownerEqualsCurrentUser:value.ownerSid===context.userSid,daclProtected:value.daclProtected,
    exactlyOneAce:value.aceCount===1,allAcesAllowedCurrentUserFullControl:value.aces.every(a=>a.type===0&&a.sid===context.userSid&&(a.mask&0x1f01ff)===0x1f01ff),
    directoryInheritanceAndNoPropagation:value.aces.every(a=>(a.flags&3)===3&&(a.flags&(4|8|16))===0)};
  return {observationsVerified:true,ownerOnlyContract:Object.values(checks).every(Boolean)?'PASS':'FAIL',checks,
    status:'NOT_ADMITTED',admissionEligible:false,compatibilityConfirmed:false,powershellSpawnObserved:false,
    authorityProven:false,continuousStabilityProven:false};
}
