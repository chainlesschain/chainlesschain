import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {pathToFileURL} from 'node:url';
const output=path.dirname(import.meta.filename);
const repo=path.resolve(output,'../..');
const sha='22ef588c1bb8f71c45feaa115df1d75d5ca505c5';
const [stage,...extra]=process.argv.slice(2);assert(['build','run'].includes(stage)&&!extra.length);
const hash=bytes=>'sha256:'+createHash('sha256').update(bytes).digest('hex');
const capture=file=>({path:path.resolve(file),bytes:fs.statSync(file).size,digest:hash(fs.readFileSync(file))});
const write=(name,value)=>fs.writeFileSync(path.join(output,name),JSON.stringify(value,null,2)+'\n',{flag:'wx'});
const compiler=path.join(repo,'.work/toolchains/llvm-mingw-20261006/llvm-mingw-20261006-ucrt-x86_64/bin/x86_64-w64-mingw32-clang++.exe');
const headers='C:/Users/longfa/AppData/Local/node-gyp/Cache/22.22.2/include/node';
const sources=['windows-node-private-v4-broker.cpp','windows-node-private-v4-adapter.cpp','windows-node-private-v4-adapter.h','windows-node-private-v4-paired.h','windows-node-private-v4-protocol.h','windows-esbuild-private-map-supervisor.cpp','windows-esbuild-private-map-shim.cpp','windows-node-private-v4-identity.cjs','windows-node-private-v4-preload.cjs'];
if(stage==='build') {
  fs.mkdirSync(path.join(output,'frozen'));fs.mkdirSync(path.join(output,'source'));
  const origins=[];
  for(const [gitPath,name] of [...sources.map(name=>['packages/cli/scripts/diagnostics/'+name,name]),['packages/cli/scripts/windows-node-private-v4-diagnostic.mjs','original-tracked-driver.mjs']]) {
    const run=spawnSync('git',['show',`${sha}:${gitPath}`],{cwd:repo,encoding:'buffer',windowsHide:true,maxBuffer:8*1024*1024});
    assert.equal(run.status,0,String(run.stderr));
    fs.writeFileSync(path.join(output,'frozen',name),run.stdout,{flag:'wx'});
    if(sources.includes(name))fs.writeFileSync(path.join(output,'source',name),run.stdout,{flag:'wx'});
    origins.push({commit:sha,gitPath,...capture(path.join(output,'frozen',name))});
  }
  fs.copyFileSync(path.join(repo,'.work/private-v4-coordinates-run.mjs'),path.join(output,'frozen/original-coordinate-driver.mjs'));
  fs.copyFileSync(path.join(output,'acl-probe.h'),path.join(output,'source/acl-probe.h'));
  const adapter=path.join(output,'source/windows-node-private-v4-adapter.cpp');
  let code=fs.readFileSync(adapter,'utf8');
  assert.equal(code.split('#include <sddl.h>').length,2);
  code=code.replace('#include <sddl.h>','#include <sddl.h>\n#include <aclapi.h>');
  assert.equal(code.split('napi_value rootCoordinateCallback(').length,2);
  code=code.replace('napi_value rootCoordinateCallback(','#include "acl-probe.h"\nnapi_value rootCoordinateCallback(');
  const exportPoint='  if (api.napi_create_function(env, "probeRootCoordinates",';
  assert.equal(code.split(exportPoint).length,2);
  code=code.replace(exportPoint,'  if (api.napi_create_function(env, "observeFixedScratchAcl", NAPI_AUTO_LENGTH, aclObservationCallback, nullptr, &fn) != napi_ok ||\n      api.napi_set_named_property(env, exports, "observeFixedScratchAcl", fn) != napi_ok) return nullptr;\n'+exportPoint);
  fs.writeFileSync(adapter,code);
  const diff=spawnSync('git',['diff','--no-index','--',path.join(output,'frozen/windows-node-private-v4-adapter.cpp'),adapter],{encoding:'buffer',windowsHide:true});
  assert.equal(diff.status,1);fs.writeFileSync(path.join(output,'adapter.diff'),diff.stdout);
  write('origins.json',origins);
  const commands=[];
  for(const [name,dest,kind] of [[sources[0],'broker.exe','exe'],[sources[1],'windows-node-private-v4.node','dll'],[sources[6],'esbuild-private-shim.dll','dll']]) {
    const args=['-std=c++17','-O2','-Wall','-Wextra','-Werror','-static',...(kind==='exe'?['-municode']:['-I',headers]),...(kind==='dll'?['-shared']:[]),path.join(output,'source',name),'-ladvapi32','-lbcrypt','-lshell32',...(kind==='exe'?['-luserenv']:[]),'-Wl,--no-insert-timestamp','-o',path.join(output,dest)];
    const started=new Date().toISOString();const run=spawnSync(compiler,args,{encoding:'buffer',timeout:60000,windowsHide:true});
    fs.writeFileSync(path.join(output,dest+'.build.stdout'),run.stdout||Buffer.alloc(0));fs.writeFileSync(path.join(output,dest+'.build.stderr'),run.stderr||Buffer.alloc(0));
    commands.push({args,started,finished:new Date().toISOString(),status:run.status,error:run.error?.message??null});
    fs.writeFileSync(path.join(output,'build.json'),JSON.stringify({compiler:capture(compiler),headers,compilerClosureVerified:false,commands},null,2)+'\n');
    assert.equal(run.status,0,String(run.stderr));
  }
  write('sources.json',[...fs.readdirSync(path.join(output,'source')).map(name=>capture(path.join(output,'source',name))),...['run.mjs','check.cjs','verify.mjs','acl-probe.h'].map(name=>capture(path.join(output,name)))]);
  write('binaries.json',['broker.exe','windows-node-private-v4.node','esbuild-private-shim.dll'].map(name=>capture(path.join(output,name))));
  console.log(JSON.stringify({stage,output,compiled:commands.length,frozenCommit:sha}));
} else {
  const inputs=JSON.parse(fs.readFileSync(path.join(output,'sources.json'))),binaries=JSON.parse(fs.readFileSync(path.join(output,'binaries.json')));
  for(const input of [...inputs,...binaries])assert.deepEqual(capture(input.path),input);
  const runDir=path.join(output,'run');fs.mkdirSync(runDir);
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'cc-private-v4-acl-'));
  const report={schema:'chainlesschain.private-acl-run/v1',status:'NOT_ADMITTED',admissionEligible:false,formalSample:false,frozenCommit:sha,root,sourceInputs:inputs,binaryInputs:binaries};
  try {
    for(const name of ['control','workspace/adapter','workspace/tree/node_modules/@esbuild/win32-x64','workspace/tree/packages/cli','scratch/adapter-receipts'])fs.mkdirSync(path.join(root,name),{recursive:true});
    assert.equal(capture(process.execPath).digest,'sha256:ae1a50511be58e987483fdbc12125407443926d2d394669ade2352776e920dd3');
    const pairs=[[process.execPath,path.join(root,'control/node.exe')],[path.join(output,'check.cjs'),path.join(root,'control/check.cjs')],...['windows-node-private-v4.node','esbuild-private-shim.dll'].map(name=>[path.join(output,name),path.join(root,'workspace/adapter',name)]),...['windows-node-private-v4-preload.cjs','windows-node-private-v4-identity.cjs'].map(name=>[path.join(output,'source',name),path.join(root,'workspace/adapter',name)]),[path.join(repo,'.work/native-toolchain-prepare-2026-10-08-canonical-pairs/tree/node_modules/@esbuild/win32-x64/esbuild.exe'),path.join(root,'workspace/tree/node_modules/@esbuild/win32-x64/esbuild.exe')]];
    report.copiedArtifacts=pairs.map(([from,to])=>{fs.copyFileSync(from,to);const source=capture(from),destination=capture(to);assert.equal(source.digest,destination.digest);assert.equal(source.bytes,destination.bytes);return {source,destination};});
    report.started=new Date().toISOString();
    const run=spawnSync(path.join(output,'broker.exe'),[root],{encoding:'buffer',windowsHide:true,timeout:60000,maxBuffer:4*1024*1024});
    report.finished=new Date().toISOString();
    fs.writeFileSync(path.join(runDir,'host.stdout'),run.stdout||Buffer.alloc(0));fs.writeFileSync(path.join(runDir,'host.stderr'),run.stderr||Buffer.alloc(0));
    report.execution={status:run.status,signal:run.signal,error:run.error?.message??null};
    try{report.host=JSON.parse(run.stdout);}catch{}
    report.receipts=[];
    for(const name of fs.readdirSync(path.join(root,'scratch/adapter-receipts'))) {
      const bytes=fs.readFileSync(path.join(root,'scratch/adapter-receipts',name));fs.writeFileSync(path.join(runDir,name),bytes);report.receipts.push(JSON.parse(bytes));
    }
    for(const [relative,name] of [['scratch/acl-probe.json','acl-probe.json'],['scratch/stdout','actor.stdout'],['scratch/stderr','actor.stderr'],['control/windows-node-private-v4.manifest.json','manifest.json']]) {
      if(fs.existsSync(path.join(root,relative)))fs.copyFileSync(path.join(root,relative),path.join(runDir,name));
    }
    report.producerInputsUnchanged=[...inputs,...binaries].every(input=>capture(input.path).digest===input.digest);
    report.copyInputsUnchanged=report.copiedArtifacts.every(pair=>capture(pair.source.path).digest===pair.source.digest&&capture(pair.destination.path).digest===pair.destination.digest);
    const probe=JSON.parse(fs.readFileSync(path.join(runDir,'acl-probe.json')));report.probe=probe;
    const {inspect}=await import(pathToFileURL(path.join(output,'verify.mjs')).href);report.inspection=inspect(probe);
    const host=report.host;
    assert.equal(run.status,0);assert.equal(run.signal,null);assert.equal(run.error,undefined);
    assert.equal(host.completed,true);assert.equal(host.cleanupConfirmed,true);assert.equal(host.jobActiveProcesses,0);assert.equal(host.profileDeleted,true);assert.equal(host.hostMapUnchanged,true);
    assert.equal(report.producerInputsUnchanged,true);assert.equal(report.copyInputsUnchanged,true);
    assert.equal(report.receipts.length,2);assert.deepEqual(report.receipts.map(r=>r.phase).sort(),['exit','installed']);
    for(const receipt of report.receipts)assert.equal(receipt.pid,probe.value.contextBefore.pid);
    report.diagnosticCompleted=true;
  } catch(error) {report.error=error.stack;report.diagnosticCompleted=false;}
  fs.writeFileSync(path.join(runDir,'report.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
  console.log(JSON.stringify({output,root,diagnosticCompleted:report.diagnosticCompleted,inspection:report.inspection,error:report.error,execution:report.execution}));
  process.exitCode=report.diagnosticCompleted?0:2;
}
