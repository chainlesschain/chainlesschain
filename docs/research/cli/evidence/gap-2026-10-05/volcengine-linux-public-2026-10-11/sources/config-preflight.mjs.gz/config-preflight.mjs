import { loadConfig } from "../packages/cli/src/lib/config-manager.js";
import { applyConfigLlmDefaults } from "../packages/cli/src/lib/llm-config-defaults.js";
import { BUILT_IN_PROVIDERS } from "../packages/cli/src/lib/llm-providers.js";
import { lookupRate, mergePricing } from "../packages/cli/src/lib/llm-pricing.js";

try {
  const config = loadConfig({ failIfUnavailable: true });
  const options = { provider: "volcengine", model: "deepseek-v4-flash-ga-260731" };
  applyConfigLlmDefaults(options, config.llm || {}, { explicitModel: options.model });
  options.apiKey ||= process.env.VOLCENGINE_API_KEY;
  const endpoint = (options.baseUrl || BUILT_IN_PROVIDERS.volcengine.baseUrl).replace(/\/$/u, "");
  const rate = lookupRate(options.provider, options.model, mergePricing(config.llm?.pricing));
  console.log(JSON.stringify({
    configuredProvider: config.llm?.provider || null,
    configuredModel: config.llm?.model || null,
    requestedProvider: options.provider,
    requestedModel: options.model,
    credentialPresent: Boolean(options.apiKey),
    endpointMatchesBuiltin: endpoint === BUILT_IN_PROVIDERS.volcengine.baseUrl,
    priced: Boolean(rate),
    rate,
    formalProviderAccountAttested: false,
    billingAttested: false,
  }));
} catch (error) {
  console.log(JSON.stringify({ status: "READ_FAILED", code: typeof error?.code === "string" ? error.code : "UNKNOWN" }));
  process.exitCode = 1;
}
