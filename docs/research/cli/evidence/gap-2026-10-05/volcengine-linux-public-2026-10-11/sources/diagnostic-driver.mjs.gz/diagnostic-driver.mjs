import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import crypto from "node:crypto";
import { spawn, execFileSync } from "node:child_process";
import { fileURLToPath, pathToFileURL } from "node:url";

const repository = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const evidenceRoot = path.join(repository, "docs/research/cli/evidence/gap-2026-10-05/volcengine-linux-public-2026-10-11");
let evidence = evidenceRoot;
const phase = process.argv[2];
const releaseCommit = "22ef588c1bb8f71c45feaa115df1d75d5ca505c5";
const version = "0.166.97";
const provider = "volcengine";
const model = "deepseek-v4-flash-ga-260731";
const endpoint = "https://ark.cn-beijing.volces.com/api/v3";
const secret = process.env.VOLCENGINE_API_KEY || "";
const sha256 = (bytes) => crypto.createHash("sha256").update(bytes).digest("hex");
const redact = (text) => secret ? text.replaceAll(secret, "[redacted]") : text;
function writeJson(name, value) {
  fs.writeFileSync(path.join(evidence, name), `${redact(JSON.stringify(value, null, 2))}\n`, { flag: "wx" });
}
function readJson(name) { return JSON.parse(fs.readFileSync(path.join(evidence, name), "utf8")); }
function processRun(name, command, args, options = {}) {
  const beganAt = new Date().toISOString();
  const timeoutMs = options.timeoutMs || 180000;
  const env = { ...process.env, ...(options.env || {}) };
  const child = spawn(command, args, { cwd: options.cwd, env, stdio: ["ignore", "pipe", "pipe"], detached: true });
  let stdout = "", stderr = "", timedOut = false, launchError = null;
  const started = { name, command, args, beganAt, timeoutMs, pid: child.pid || null };
  writeJson(`${name}.started.json`, started);
  console.log(JSON.stringify({ phase: name, status: "started", pid: child.pid || null }));
  const interval = setInterval(() => console.log(JSON.stringify({ phase: name, status: "running", elapsedSeconds: Math.floor((Date.now() - Date.parse(beganAt)) / 1000) })), 25000);
  const stop = () => { try { process.kill(-child.pid, "SIGKILL"); } catch {} };
  const timer = setTimeout(() => { timedOut = true; stop(); }, timeoutMs);
  child.stdout.on("data", (bytes) => { stdout += bytes.toString("utf8"); if (stdout.length > 4 * 1024 * 1024) stop(); });
  child.stderr.on("data", (bytes) => { stderr += bytes.toString("utf8"); if (stderr.length > 4 * 1024 * 1024) stop(); });
  child.on("error", (error) => { launchError = error.code || "UNKNOWN"; });
  return new Promise((resolve) => child.on("close", (code, signal) => {
    clearTimeout(timer); clearInterval(interval);
    stdout = redact(stdout); stderr = redact(stderr);
    fs.writeFileSync(path.join(evidence, `${name}.stdout`), stdout, { flag: "wx" });
    fs.writeFileSync(path.join(evidence, `${name}.stderr`), stderr, { flag: "wx" });
    const result = { ...started, finishedAt: new Date().toISOString(), exitCode: code, signal, timedOut, launchError, stdoutSha256: sha256(stdout), stderrSha256: sha256(stderr) };
    writeJson(`${name}.result.json`, result);
    console.log(JSON.stringify({ phase: name, status: "finished", exitCode: code, signal, timedOut }));
    resolve({ ...result, stdout, stderr });
  }));
}

async function prepare() {
  if (process.platform !== "linux" || process.arch !== "x64" || process.version !== "v22.12.0") throw new Error("Linux runtime does not match diagnostic target");
  fs.mkdirSync(evidence);
  const temporaryRoot = fs.mkdtempSync(path.join(os.tmpdir(), "cc-volcengine-public-20261011-"));
  const install = path.join(temporaryRoot, "install");
  const profile = path.join(temporaryRoot, "profile");
  const workspace = path.join(temporaryRoot, "workspace");
  for (const directory of [install, profile, workspace]) fs.mkdirSync(directory, { mode: 0o700 });
  fs.writeFileSync(path.join(install, "package.json"), JSON.stringify({ private: true, type: "module" }), { flag: "wx" });
  writeJson("prepared-state.json", { scope: "public-linux-cli-volcengine-diagnostic", formalSample: false, productionAttested: false, releaseCommit, version, provider, model, endpoint, temporaryRoot, install, profile, workspace, runtime: { platform: process.platform, arch: process.arch, node: process.version, osRelease: os.release(), osReleaseFile: fs.readFileSync("/etc/os-release", "utf8") }, preparedAt: new Date().toISOString(), cleanProfileAtStart: fs.readdirSync(profile).length === 0, cleanWorkspaceAtStart: fs.readdirSync(workspace).length === 0 });
  const npmCli = path.resolve(path.dirname(process.execPath), "../lib/node_modules/npm/bin/npm-cli.js");
  const result = await processRun("npm-install", process.execPath, [npmCli, "install", `chainlesschain@${version}`, "--ignore-scripts", "--omit=dev", "--no-audit", "--no-fund", "--loglevel=error", "--registry=https://registry.npmjs.org", "--cache", path.join(temporaryRoot, "npm-cache")], { cwd: install, timeoutMs: 240000 });
  if (result.exitCode !== 0) throw new Error("Public registry installation failed; original attempt retained");
  const packageDirectory = path.join(install, "node_modules/chainlesschain");
  const pkg = JSON.parse(fs.readFileSync(path.join(packageDirectory, "package.json"), "utf8"));
  const lockBytes = fs.readFileSync(path.join(install, "package-lock.json"));
  const locked = JSON.parse(lockBytes).packages["node_modules/chainlesschain"];
  if (pkg.version !== version || locked.version !== version || locked.resolved !== `https://registry.npmjs.org/chainlesschain/-/chainlesschain-${version}.tgz` || !locked.integrity?.startsWith("sha512-")) throw new Error("Public package identity differs");
  const sourceBindings = [];
  for (const file of ["bin/chainlesschain.js", "src/commands/agent.js", "src/runtime/headless-runner.js", "src/runtime/agent-core.js", "src/lib/formal-quality-eval-runtime.js"]) {
    const installed = fs.readFileSync(path.join(packageDirectory, file));
    const frozen = execFileSync("git", ["-C", repository, "show", `${releaseCommit}:packages/cli/${file}`], { maxBuffer: 8 * 1024 * 1024 });
    const matches = installed.equals(frozen);
    sourceBindings.push({ file, bytes: installed.length, sha256: sha256(installed), matchesReleaseGitBlob: matches });
    if (!matches) throw new Error("Installed CLI source differs from released Git blob");
  }
  fs.writeFileSync(path.join(evidence, "package-lock.json"), lockBytes, { flag: "wx" });
  writeJson("public-install.json", { version: pkg.version, resolved: locked.resolved, integrity: locked.integrity, packageLockSha256: sha256(lockBytes), lifecycleScriptsEnabled: false, packageDirectory, sourceBindings, nativeSqliteAssessed: false, formalSample: false });
  const versionCheck = await processRun("cli-version", process.execPath, [path.join(packageDirectory, "bin/chainlesschain.js"), "--version"], { cwd: workspace, env: { CHAINLESSCHAIN_HOME: profile } });
  if (versionCheck.exitCode !== 0 || !versionCheck.stdout.includes(version)) throw new Error("Installed CLI version command failed");
  writeJson("prepare-complete.json", { status: "READY_FOR_BOUNDED_DIAGNOSTIC", at: new Date().toISOString(), formalSample: false });
}

async function live() {
  readJson("prepare-complete.json");
  const state = readJson("prepared-state.json");
  if (!secret || process.platform !== "linux" || process.version !== "v22.12.0" || state.provider !== provider || state.model !== model) throw new Error("Live diagnostic binding is unavailable");
  const installed = readJson("public-install.json");
  const packageDirectory = installed.packageDirectory;
  const expected = "PUBLIC_LINUX_VOLCENGINE_OK\n";
  const attempt = process.argv[3];
  if (attempt) {
    if (attempt !== "attempt2") throw new Error("Unexpected diagnostic attempt");
    evidence = path.join(evidenceRoot, attempt);
    fs.mkdirSync(evidence);
    state.workspace = path.join(state.temporaryRoot, "workspace-attempt2");
    state.profile = path.join(state.temporaryRoot, "profile-attempt2");
    fs.mkdirSync(state.workspace, { mode: 0o700 });
    fs.mkdirSync(state.profile, { mode: 0o700 });
    const initial = "PUBLIC_LINUX_PLACEHOLDER\n";
    fs.writeFileSync(path.join(state.workspace, "probe.txt"), initial, { mode: 0o600, flag: "wx" });
    writeJson("attempt-preparation.json", { attempt, at: new Date().toISOString(), workspace: state.workspace, profile: state.profile, cleanProfileAtStart: fs.readdirSync(state.profile).length === 0, seededFiles: [{ path: "probe.txt", bytes: Buffer.byteLength(initial), sha256: sha256(initial) }], reason: "The exact mutation scope requires a pre-existing file; keep the original pre-model rejection and test overwriting a separate placeholder.", formalSample: false });
  }
  const prompt = `Complete this small file-tool check in the current directory. First use write_file to replace probe.txt with exactly ${JSON.stringify(expected)}. Then use read_file to read probe.txt and verify those exact bytes. Finally reply only PUBLIC_LINUX_VOLCENGINE_OK. Use only write_file and read_file, and do not inspect any other path. This is a diagnostic, not a VERIFY01 task.`;
  const args = [path.join(packageDirectory, "bin/chainlesschain.js"), "agent", "-p", prompt, "--provider", provider, "--model", model, "--base-url", endpoint, "--permission-mode", "acceptEdits", "--output-format", "stream-json", "--max-turns", "4", "--max-budget-usd", "0.05", "--allowed-tools", "write_file,read_file", "--ephemeral", "--no-project-memory", "--no-file-refs", "--no-slash-macros", "--no-mcp", "--no-ide", "--no-pdh", "--no-jetbrains"];
  writeJson("live-binding.json", { formalSample: false, scope: "public-linux-cli-volcengine-diagnostic", provider, model, endpoint, releaseCommit, version, prompt, expectedArtifact: { path: "probe.txt", sha256: sha256(expected), bytes: Buffer.byteLength(expected) }, maxTurns: 4, automaticRetries: 0, fallbackModels: [], estimatedSpendStopUSD: 0.05, providerHardQuotaVerified: false, budgetLimitation: "CLI stops following calls after returned usage estimates reach the cap; an in-flight call can exceed it, and billing can remain unknown.", hermeticRuntimeFlagUsed: true, hermeticFlagDoesNotAttestFormalAdmission: true });
  const result = await processRun("live-agent", process.execPath, args, { cwd: state.workspace, timeoutMs: 180000, env: { CHAINLESSCHAIN_HOME: state.profile, CC_MAX_RETRIES: "0", CLAUDE_CODE_MAX_RETRIES: "0", CC_FORMAL_QUALITY_EVAL_HERMETIC: "1", CC_FORMAL_QUALITY_EVAL_PROVIDER: provider, CC_FORMAL_QUALITY_EVAL_ISOLATION_ROOT: state.temporaryRoot, CC_FORMAL_QUALITY_EVAL_ALLOWED_FILES: JSON.stringify(["probe.txt"]), VOLCENGINE_API_KEY: secret } });
  const { verifyAgentTerminal } = await import(pathToFileURL(path.join(packageDirectory, "src/lib/eval/stream-terminal.js")));
  const { estimateCost } = await import(pathToFileURL(path.join(packageDirectory, "src/lib/llm-pricing.js")));
  const terminal = verifyAgentTerminal(result.stdout);
  const records = result.stdout.trim().split(/\r?\n/u).filter(Boolean).map((line) => JSON.parse(line));
  const init = records.find((record) => record.type === "system" && record.subtype === "init");
  const final = records.filter((record) => record.type === "result").at(-1);
  const toolUses = records.filter((record) => record.type === "tool_use").map((record) => ({ id: record.id, name: record.tool, input: record.args }));
  const toolResults = records.filter((record) => record.type === "tool_result");
  const exactToolPaths = toolUses.every((tool) => typeof tool.input?.path === "string" && path.resolve(state.workspace, tool.input.path) === path.join(state.workspace, "probe.txt"));
  const validToolIds = toolUses.every((tool) => typeof tool.id === "string" && tool.id.length > 0) && new Set(toolUses.map((tool) => tool.id)).size === toolUses.length;
  const writeResultIndex = records.findIndex((record) => record.type === "tool_result" && record.tool === "write_file" && record.is_error === false);
  const readUseIndex = records.findIndex((record) => record.type === "tool_use" && record.tool === "read_file");
  const toolsSettledSuccessfully = toolUses.length === 2 && validToolIds && exactToolPaths && toolUses[0].name === "write_file" && toolUses[0].input?.content === expected && toolUses[1].name === "read_file" && toolResults.length === 2 && writeResultIndex >= 0 && readUseIndex > writeResultIndex && toolUses.every((tool) => toolResults.some((record) => record.id === tool.id && record.tool === tool.name && record.is_error === false && !record.error));
  const readBack = toolResults.find((record) => record.tool === "read_file" && record.is_error === false);
  const readResultHasMarker = Boolean(readBack && readBack.result?.content === expected && !readBack.result.truncated && !readBack.result.nextRead);
  let actual = null;
  try { actual = fs.readFileSync(path.join(state.workspace, "probe.txt")); } catch {}
  const artifactMatches = Boolean(actual && actual.equals(Buffer.from(expected)));
  const files = fs.readdirSync(state.workspace);
  const usage = terminal.usage;
  const estimated = usage ? estimateCost({ provider, model, inputTokens: usage.inputTokens, outputTokens: usage.outputTokens, cacheReadTokens: usage.cacheReadInputTokens, cacheCreationTokens: usage.cacheCreationInputTokens }) : null;
  const knownUsageEstimatedSubtotalUSD = estimated?.matched && Number.isFinite(estimated.totalCost) ? estimated.totalCost : null;
  const passed = result.exitCode === 0 && !result.signal && terminal.terminalVerified && terminal.observedFallback === false && init?.provider === provider && init?.model === model && init?.permission_mode === "acceptEdits" && artifactMatches && files.length === 1 && files[0] === "probe.txt" && toolsSettledSuccessfully && readResultHasMarker && String(final?.result || "").trim() === "PUBLIC_LINUX_VOLCENGINE_OK";
  writeJson("diagnostic-result.json", { scope: "public-linux-cli-volcengine-diagnostic", formalSample: false, productionAttested: false, passed, runtime: state.runtime, version, releaseCommit, initIdentity: { provider: init?.provider || null, model: init?.model || null, permissionMode: init?.permission_mode || null }, terminal, resultSubtype: final?.subtype || null, tools: toolUses, toolsSettledSuccessfully, readResultHasMarker, artifact: { path: "probe.txt", present: Boolean(actual), matches: artifactMatches, bytes: actual?.length ?? null, sha256: actual ? sha256(actual) : null }, workspaceFiles: files, usage, estimatedCostUSD: terminal.totalCostUsd, knownUsageEstimatedSubtotalUSD, actualBilledCostUSD: null, providerAccountAttested: false, formal36Observed: 0, formal9Observed: 0 });
  if (actual) fs.writeFileSync(path.join(evidence, "probe.txt"), actual, { flag: "wx" });
  console.log(JSON.stringify({ phase: "diagnostic-check", passed, artifactMatches, tools: toolUses.map((tool) => tool.name), usageKnown: Boolean(usage), estimatedCostUSD: terminal.totalCostUsd, knownUsageEstimatedSubtotalUSD }));
  if (!passed) process.exitCode = 2;
}

try {
  if (phase === "prepare") await prepare();
  else if (phase === "live") await live();
  else throw new Error("Use prepare or live");
} catch (error) {
  console.log(JSON.stringify({ phase, status: "failed", message: redact(String(error.message)).slice(0, 300) }));
  if (fs.existsSync(evidence)) {
    try { writeJson(`${phase}-failure.json`, { phase, at: new Date().toISOString(), formalSample: false, message: redact(String(error.message)).slice(0, 300) }); } catch {}
  }
  process.exitCode = 1;
}
