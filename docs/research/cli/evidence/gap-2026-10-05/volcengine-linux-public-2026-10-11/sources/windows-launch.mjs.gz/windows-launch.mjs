import { spawn } from "node:child_process";
import { loadConfig } from "../packages/cli/src/lib/config-manager.js";
import { applyConfigLlmDefaults } from "../packages/cli/src/lib/llm-config-defaults.js";
import { BUILT_IN_PROVIDERS } from "../packages/cli/src/lib/llm-providers.js";

try {
  const config = loadConfig({ failIfUnavailable: true });
  const options = { provider: "volcengine", model: "deepseek-v4-flash-ga-260731" };
  applyConfigLlmDefaults(options, config.llm || {}, { explicitModel: options.model });
  options.apiKey ||= process.env.VOLCENGINE_API_KEY;
  const endpoint = (options.baseUrl || BUILT_IN_PROVIDERS.volcengine.baseUrl).replace(/\/$/u, "");
  if (!options.apiKey || endpoint !== BUILT_IN_PROVIDERS.volcengine.baseUrl) throw new Error("Volcengine binding unavailable");
  const env = { ...process.env, WSLENV: "VOLCENGINE_API_KEY", VOLCENGINE_API_KEY: options.apiKey };
  const child = spawn("wsl.exe", ["--", "bash", "-lc", "export PATH=/mnt/c/code/chainlesschain/.work/release-20261008/node-v22.12.0-linux-x64/bin:/usr/local/bin:/usr/bin:/bin; node /mnt/c/code/chainlesschain/.work/volcengine-linux-public-test-20261011.mjs live attempt2"], { env, windowsHide: true, stdio: ["ignore", "pipe", "pipe"] });
  let stdout = "", stderr = "";
  child.stdout.on("data", (bytes) => { stdout += bytes.toString("utf8"); });
  child.stderr.on("data", (bytes) => { stderr += bytes.toString("utf8"); });
  child.on("error", (error) => { console.log(JSON.stringify({ status: "LAUNCH_FAILED", code: error.code || "UNKNOWN" })); process.exitCode = 1; });
  child.on("close", (code, signal) => {
    process.stdout.write(stdout.replaceAll(options.apiKey, "[redacted]"));
    process.stderr.write(stderr.replaceAll(options.apiKey, "[redacted]"));
    if (signal) console.log(JSON.stringify({ status: "LAUNCH_SIGNALED", signal }));
    process.exitCode = Number.isInteger(code) ? code : 1;
  });
} catch (error) {
  console.log(JSON.stringify({ status: "CONFIGURATION_UNAVAILABLE", code: error.code || "UNKNOWN" }));
  process.exitCode = 1;
}
