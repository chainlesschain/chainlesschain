import { it as diagnosticIt, expect as diagnosticExpect } from "vitest";

import { it as controlIt, expect as controlExpect } from "vitest";
import { PassThrough as ControlInput } from "node:stream";
import { runAgentHeadlessStream as controlRunStream } from "../src/runtime/headless-stream.js";

controlIt("cancelling a pending approval delivers denial to the blocked tool", async () => {
  const input = new ControlInput();
  const controller = new AbortController();
  let toolVerdict = null;
  let approvalRequests = 0;
  input.write(JSON.stringify({ type: "user", text: "Request approval" }) + "\n");
  try {
    await controlRunStream({
      expandFileRefs: false,
      interactiveApprovals: true,
      settingsHooks: {},
      signal: controller.signal,
    }, {
      bootstrap: async () => ({ db: null }),
      getApprovalGate: async () => null,
      writeOut(line) {
        const event = JSON.parse(line);
        if (event.type === "approval_request") {
          approvalRequests++;
          queueMicrotask(() => controller.abort());
        }
      },
      writeErr() {},
      async *agentLoop(messages, options) {
        toolVerdict = await options.permissionConfirm({
          tool: "run_shell", command: "control-only", riskLevel: "medium",
          reason: "deterministic pending approval",
        });
        yield { type: "response-complete", content: "control finished" };
        yield { type: "run-ended", reason: "complete" };
      },
      input,
    });
    controlExpect(approvalRequests).toBe(1);
    // The emitted approval_resolved event can say false even if the suspended
    // tool receives true. Assert the actual permission promise's result.
    controlExpect(toolVerdict).toBe(false);
    controlExpect(input.destroyed).toBe(true);
  } finally {
    controller.abort();
    input.destroy();
  }
}, 15000);
