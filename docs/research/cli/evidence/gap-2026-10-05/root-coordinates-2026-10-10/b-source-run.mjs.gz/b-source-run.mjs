import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import {createHash} from "node:crypto";
import {spawnSync} from "node:child_process";
import {pathToFileURL} from "node:url";
const [stage,label]=process.argv.slice(2);
if(!["build","run"].includes(stage)||!/^[-a-z0-9]+$/.test(label??""))throw Error("stage and unique label required");
const output=path.resolve(".work/private-v4-coordinates-"+label);
const compiler=path.resolve(".work/toolchains/llvm-mingw-20261006/llvm-mingw-20261006-ucrt-x86_64/bin/x86_64-w64-mingw32-clang++.exe");
const headers="C:/Users/longfa/AppData/Local/node-gyp/Cache/22.22.2/include/node";
const hash=bytes=>"sha256:"+createHash("sha256").update(bytes).digest("hex");
const capture=file=>({path:file,bytes:fs.statSync(file).size,digest:hash(fs.readFileSync(file))});
if(stage==="build") {
  fs.mkdirSync(output);fs.mkdirSync(path.join(output,"source"));
  const sources=["windows-node-private-v4-broker.cpp","windows-node-private-v4-adapter.cpp","windows-node-private-v4-adapter.h","windows-node-private-v4-paired.h","windows-node-private-v4-protocol.h","windows-esbuild-private-map-supervisor.cpp","windows-esbuild-private-map-shim.cpp","windows-node-private-v4-identity.cjs","windows-node-private-v4-preload.cjs"];
  for(const name of sources)fs.copyFileSync(path.resolve("packages/cli/scripts/diagnostics",name),path.join(output,"source",name));
  fs.copyFileSync("packages/cli/scripts/windows-node-private-v4-coordinates.mjs",path.join(output,"source","verifier.mjs"));
  fs.copyFileSync(".work/private-v4-coordinates-check.cjs",path.join(output,"source","check.cjs"));
  fs.copyFileSync(import.meta.filename,path.join(output,"source","run.mjs"));
  const commands=[];
  for(const [name,dest,kind] of [[sources[0],"broker.exe","exe"],[sources[1],"windows-node-private-v4.node","dll"],[sources[6],"esbuild-private-shim.dll","dll"]]) {
    const args=["-std=c++17","-O2","-Wall","-Wextra","-Werror","-static",...(kind==="exe"?["-municode"]:["-I",headers]),...(kind==="dll"?["-shared"]:[]),path.join(output,"source",name),"-ladvapi32","-lbcrypt","-lshell32",...(kind==="exe"?["-luserenv"]:[]),"-Wl,--no-insert-timestamp","-o",path.join(output,dest)];
    const run=spawnSync(compiler,args,{encoding:"utf8",timeout:60000,windowsHide:true});commands.push({args,status:run.status,error:run.error?.message??null,stdout:run.stdout,stderr:run.stderr});
    fs.writeFileSync(path.join(output,"build.json"),JSON.stringify({commands},null,2));if(run.status!==0)throw Error("compile "+dest+" "+run.stderr);
  }
  fs.writeFileSync(path.join(output,"sources.json"),JSON.stringify(fs.readdirSync(path.join(output,"source")).map(name=>capture(path.join(output,"source",name))),null,2));
  fs.writeFileSync(path.join(output,"binaries.json"),JSON.stringify(["broker.exe","windows-node-private-v4.node","esbuild-private-shim.dll"].map(name=>capture(path.join(output,name))),null,2));
  console.log(JSON.stringify({stage,output,compiled:commands.length}));
}else{
  const inputs=JSON.parse(fs.readFileSync(path.join(output,"sources.json")));
  for(const input of inputs)if(capture(input.path).digest!==input.digest)throw Error("frozen input changed "+input.path);
  const runDir=path.join(output,"run");fs.mkdirSync(runDir);
  const root=fs.mkdtempSync(path.join(os.tmpdir(),"cc-private-v4-coordinates-"));
  for(const name of ["control","workspace/adapter","workspace/tree/node_modules/@esbuild/win32-x64","workspace/tree/packages/cli","scratch/adapter-receipts"])fs.mkdirSync(path.join(root,name),{recursive:true});
  if(capture(process.execPath).digest!=="sha256:ae1a50511be58e987483fdbc12125407443926d2d394669ade2352776e920dd3")throw Error("fixed Node runtime differs");
  fs.copyFileSync(process.execPath,path.join(root,"control/node.exe"));
  fs.copyFileSync(path.join(output,"source/check.cjs"),path.join(root,"control/check.cjs"));
  for(const name of ["windows-node-private-v4.node","esbuild-private-shim.dll"])fs.copyFileSync(path.join(output,name),path.join(root,"workspace/adapter",name));
  for(const name of ["windows-node-private-v4-preload.cjs","windows-node-private-v4-identity.cjs"])fs.copyFileSync(path.join(output,"source",name),path.join(root,"workspace/adapter",name));
  fs.copyFileSync(".work/native-toolchain-prepare-2026-10-08-canonical-pairs/tree/node_modules/@esbuild/win32-x64/esbuild.exe",path.join(root,"workspace/tree/node_modules/@esbuild/win32-x64/esbuild.exe"));
  const start=new Date().toISOString();
  const run=spawnSync(path.join(output,"broker.exe"),[root],{encoding:"utf8",windowsHide:true,timeout:60000,maxBuffer:4*1024*1024});
  fs.writeFileSync(path.join(runDir,"host.stdout"),run.stdout??"");fs.writeFileSync(path.join(runDir,"host.stderr"),run.stderr??"");
  let host;try{host=JSON.parse(run.stdout);}catch{}
  const receipts=fs.readdirSync(path.join(root,"scratch/adapter-receipts")).map(name=>{fs.copyFileSync(path.join(root,"scratch/adapter-receipts",name),path.join(runDir,name));return JSON.parse(fs.readFileSync(path.join(root,"scratch/adapter-receipts",name)));});
  const probeFile=path.join(root,"scratch/coordinate-probe.json");let probe=null;
  if(fs.existsSync(probeFile)){fs.copyFileSync(probeFile,path.join(runDir,"coordinate-probe.json"));probe=JSON.parse(fs.readFileSync(probeFile));}
  const {inspectPrivateV4RootCoordinates}=await import(pathToFileURL(path.join(output,"source/verifier.mjs")).href);
  const inspection=inspectPrivateV4RootCoordinates(probe?.value,{identity:probe?.identity});
  const unchanged=inputs.every(input=>capture(input.path).digest===input.digest);
  const report={schema:"chainlesschain.private-root-coordinate-run/v1",status:"NOT_ADMITTED",admissionEligible:false,formalSample:false,root,start,finished:new Date().toISOString(),producerInputsUnchanged:unchanged,host,probe,receipts,inspection,execution:{status:run.status,error:run.error?.message??null,signal:run.signal,stdout:run.stdout,stderr:run.stderr}};
  fs.writeFileSync(path.join(runDir,"report.json"),JSON.stringify(report,null,2));
  console.log(JSON.stringify({stage,root,execution:report.execution,inspection,producerInputsUnchanged:unchanged}));
  process.exitCode=run.status===0&&host?.completed&&host.cleanupConfirmed&&host.jobActiveProcesses===0&&host.profileDeleted&&host.hostMapUnchanged&&unchanged&&inspection.observationsVerified&&probe?.argumentRejected&&probe?.adapter.patches===6?0:2;
}
