"use strict";
const preload = require("X:/workspace/adapter/windows-node-private-v4-preload.cjs");
const addon = require("X:/workspace/adapter/windows-node-private-v4.node");
const fs = require("node:fs");
const assert = require("node:assert/strict");
const identity = JSON.parse(addon.inspectPrivateIdentity());
const value = JSON.parse(addon.probeRootCoordinates());
let argumentRejected = false;
try { addon.probeRootCoordinates("X:\\"); }
catch (error) { argumentRejected = error.code === "ROOT_COORDINATE_ARGUMENT"; }
const adapter = JSON.parse(addon.snapshot());
fs.writeFileSync("X:/scratch/coordinate-probe.json", JSON.stringify({identity,value,argumentRejected,adapter,preload:preload.snapshot()},null,2));
assert.equal(argumentRejected,true);
assert.equal(adapter.state,2);
assert.equal(adapter.patches,6);
assert.equal(value.admissionEligible,false);
assert.equal(value.compatibilityConfirmed,false);
