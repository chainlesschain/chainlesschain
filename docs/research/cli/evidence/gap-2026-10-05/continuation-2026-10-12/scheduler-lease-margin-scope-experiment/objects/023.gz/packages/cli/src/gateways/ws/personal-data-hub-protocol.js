/**
 * Personal Data Hub — WS protocol handlers.
 *
 * Mirrors the 10 IPC channels in
 * desktop-app-vue/src/main/ipc/personal-data-hub-ipc.js so cc ui / web-shell
 * users get the same surface. Per memory feedback_cross_shell_feature_pattern,
 * any hub-facing renderer code can target EITHER:
 *
 *   electron: window.electron.invoke("personal-data-hub:ask", {...})
 *   cc ui:    ws.executeJson({ type: "personal-data-hub.ask", ... })
 *
 * Topic names use dot-case here (cc WS convention) vs the colon-style IPC.
 * The renderer shell-helpers layer reconciles the two so SPA code can be
 * shell-agnostic.
 *
 * Each handler returns { result } or { error }. The dispatcher wraps that
 * with the standard envelope (id + type) before sending.
 */

import {
  getHub,
  getGovernedAnalysisHub,
  close as closeHub,
} from "../../lib/personal-data-hub-wiring.js";
import { importPdh } from "../../lib/pdh-load-error.js";
import { getAIChatWizard } from "../../lib/personal-data-hub-aichat-wizard.js";
import { runDedicatedBatchCollectors } from "../../lib/pdh-dedicated-batch-collectors.js";
import {
  existsSync,
  unlinkSync,
  readdirSync,
  mkdirSync,
  writeFileSync,
} from "node:fs";
import { join } from "node:path";
// Lazily import the pdh package the first time the system-data-android
// ingest topic is actually used. This module is pulled in by the
// agent/chat/serve/ui runtime chain at startup (ws-server →
// message-dispatcher → here), so a top-level static import would force the
// whole pdh graph to load on every `cc` invocation — and a partial/corrupt
// pdh install would brick unrelated commands. See the matching rationale in
// personal-data-hub-wiring.js.
let _ingestSnapshotFn = null;
async function ingestSystemDataAndroidSnapshot(hub, snapshot) {
  if (!_ingestSnapshotFn) {
    const pdhMod = await importPdh("@chainlesschain/personal-data-hub");
    const pdhPkg = pdhMod.default || pdhMod;
    _ingestSnapshotFn = pdhPkg.ingestSystemDataAndroidSnapshot;
  }
  return _ingestSnapshotFn(hub, snapshot);
}

/**
 * Adapters that must never consume an Android staging snapshot implicitly.
 * They either have a richer live bridge or read desktop-local state directly.
 * Exported as an immutable array so the transport contract can be guarded
 * without exercising ADB in unit tests.
 */
export const ADB_AUTO_PULL_BYPASS_ADAPTERS = Object.freeze([
  "system-data-android",
  "browser-history-chrome",
  "browser-history-edge",
  "browser-history-brave",
  "browser-history-opera",
  "browser-history-vivaldi",
  "browser-history-safari",
  "browser-history-firefox",
  "vscode",
  "vscodium",
  "cursor",
  "claude-code",
  "jetbrains-ide",
  "hbuilderx",
  "win-recent",
  "git-activity",
  "shell-history",
  "local-files",
  "meeting-tencent",
]);

const ADB_AUTO_PULL_BYPASS_SET = new Set(ADB_AUTO_PULL_BYPASS_ADAPTERS);
const EXPLICIT_LIVE_SOURCE_OPTION_KEYS = Object.freeze([
  "cookie",
  "cookies",
  "accessToken",
  "appKey",
  "apiKey",
  "token",
  "sourceUrl",
]);

export function hasExplicitLiveSourceOptions(options) {
  if (!options || typeof options !== "object") return false;
  return EXPLICIT_LIVE_SOURCE_OPTION_KEYS.some((key) => {
    const value = options[key];
    if (typeof value === "string") return value.trim().length > 0;
    if (Array.isArray(value)) return value.length > 0;
    return value != null && typeof value === "object";
  });
}

/**
 * If the caller didn't pass `inputPath`, try to pull a snapshot for
 * this adapter off the attached Android phone via `adb shell run-as
 * <pkg.debug> cat files/.chainlesschain/staging/<name>.json`. On
 * success, write the JSON to `hub.hubDir/staging/` and return an
 * `options` object with `inputPath` set so the adapter's _syncViaSnapshot
 * picks it up.
 *
 * Why this is needed: every social adapter (bilibili, weibo, douyin,
 * xiaohongshu, toutiao, kuaishou, qq, wechat, baidu-map, tencent-map,
 * jd, meituan, pinduoduo) is snapshot-only and the Android in-app
 * collectors write their JSON into the app's filesDir/.chainlesschain/
 * staging/. Without an auto-pull, the desktop 同步 button can never
 * reach a working state for these adapters — it just throws "needs
 * opts.inputPath".
 *
 * Best-effort: if anything fails (no device, package not debuggable,
 * snapshot file missing for that adapter, bridge module unavailable),
 * return the original options unchanged so the adapter's normal error
 * path fires and the UI banner shows a meaningful message.
 */
export async function _tryAdbAutoPullInputPath(hub, name, options) {
  if (
    options &&
    typeof options.inputPath === "string" &&
    options.inputPath.length > 0
  ) {
    return options; // caller already supplied a path
  }
  // An explicit live credential or endpoint is a stronger user intent than
  // an implicit, potentially stale Android staging snapshot. Every dual-mode
  // adapter checks inputPath first, so adding an auto-pulled path here would
  // silently turn a requested live sync into a snapshot import.
  if (hasExplicitLiveSourceOptions(options)) {
    return options;
  }
  // Skip auto-pull for adapters that have a live bridge mode — pulling
  // a stale snapshot file would short-circuit the bridge path which
  // yields fresher / richer data (e.g. system-data-android's bridge
  // mode pulls contacts + apps + sms + call_log live via ADB, while
  // an Android-collected snapshot only contains contacts + apps).
  // Keep this list in sync with adapters whose _syncViaBridge is
  // strictly richer than their snapshot output.
  // browser-history-*, vscode/vscodium/cursor, claude-code, and
  // jetbrains-ide read desktop-local files (browser profiles, editor/Agent
  // state, Claude Code transcripts, or JetBrains recentProjects.xml);
  // an ADB snapshot is meaningless for them.
  if (ADB_AUTO_PULL_BYPASS_SET.has(name)) {
    return options || {};
  }
  try {
    const { createHostAdbBridge } =
      await import("../../lib/host-adb-bridge.js");
    const bridge = createHostAdbBridge();
    const content = await bridge.invoke("snapshot.read", {
      fileName: `${name}.json`,
    });
    // Sanity: must be parseable JSON. If not, the adapter would fail
    // with a confusing parse error — surface a clearer one here.
    try {
      JSON.parse(content);
    } catch (_e) {
      return options; // leave to adapter — it'll report parse error
    }
    const stagingDir = join(hub.hubDir, "staging");
    mkdirSync(stagingDir, { recursive: true });
    const stagingPath = join(
      stagingDir,
      `${name}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}.json`,
    );
    writeFileSync(stagingPath, content, "utf-8");
    return {
      ...(options || {}),
      inputPath: stagingPath,
      _autoPulledViaAdb: true,
    };
  } catch (_e) {
    // Bridge unavailable / device not attached / file missing — let the
    // adapter throw its normal error so the banner explains.
    return options || {};
  }
}

async function withHub(fn, loadHub = getHub) {
  try {
    const hub = await loadHub();
    const result = await fn(hub);
    return { result };
  } catch (err) {
    return { error: err && err.message ? err.message : String(err) };
  }
}

function governedHubLoader(factory) {
  if (typeof factory === "function")
    return () => getGovernedAnalysisHub(factory);
  const error = new Error(
    "Personal Data Hub model egress requires an authenticated evolution composition factory",
  );
  error.code = "CC_AGENT_EVOLUTION_INGRESS_FAILED";
  throw error;
}

function validateEntityReference(entityType, entityId) {
  if (
    !["event", "person", "place", "item", "topic"].includes(entityType) ||
    typeof entityId !== "string" ||
    !entityId.trim() ||
    entityId.length > 1024
  ) {
    throw new Error("A valid entityType and entityId are required");
  }
}

export const PERSONAL_DATA_HUB_HANDLERS = {
  "personal-data-hub.ask": async (msg, context = {}) => {
    const factory = context.server?.evolutionCompositionFactory;
    return withHub(async (hub) => {
      if (!hub.engine) throw new Error("Analysis engine unavailable");
      return await hub.engine.ask(msg.question, msg.options || {});
    }, governedHubLoader(factory));
  },

  // Path Y: prompt context only, no LLM call. Lets web-shell / mobile host
  // its own inference (Volcengine Doubao, OpenRouter, etc.) while keeping
  // vault retrieval centralized.
  "personal-data-hub.retrieve-context": async (msg) =>
    withHub(async (hub) => {
      if (!hub.engine) throw new Error("Analysis engine unavailable");
      return await hub.engine.retrieveContext(msg.question, msg.options || {});
    }),

  // Path C: phone-collected ContentResolver + PackageManager snapshot →
  // staging file → syncAdapter(system-data-android). Returns SyncReport.
  "personal-data-hub.ingest-system-data-android": async (msg) =>
    withHub(
      async (hub) => await ingestSystemDataAndroidSnapshot(hub, msg.snapshot),
    ),

  "personal-data-hub.stats": async () =>
    withHub((hub) => ({
      vault: hub.vault.stats(),
      adapters: hub.registry.list(),
      hubDir: hub.hubDir,
      llm: hub.llm ? { name: hub.llm.name, isLocal: hub.llm.isLocal } : null,
    })),

  "personal-data-hub.health": async () =>
    withHub((hub) => ({
      vault: { ok: !!hub.vault.db, schemaVersion: hub.vault.schemaVersion() },
      llm: hub.llm
        ? { ok: true, isLocal: hub.llm.isLocal, name: hub.llm.name }
        : { ok: false, reason: "LLM unavailable" },
      kgSink: { ok: !!hub.kgSink },
      ragSink: { ok: !!hub.ragSink },
    })),

  "personal-data-hub.list-adapters": async () =>
    withHub((hub) => hub.registry.list()),

  "personal-data-hub.derivation-status": async (msg) =>
    withHub((hub) =>
      hub.registry.getDerivationStatus({
        adapter: msg.adapter,
        scope: msg.scope,
      }),
    ),

  "personal-data-hub.derivation-state": async (msg) =>
    withHub((hub) => {
      validateEntityReference(msg.entityType, msg.entityId);
      return hub.vault
        .getDerivationStore()
        .getState(msg.entityType, msg.entityId, {
          consumerId: hub.registry.consumerId,
        });
    }),

  "personal-data-hub.retry-derivations": async (msg) =>
    withHub((hub) =>
      hub.registry.retryDerivations({
        adapter: msg.adapter,
        scope: msg.scope,
        limit: msg.limit,
      }),
    ),

  "personal-data-hub.delete-entity": async (msg) =>
    withHub(async (hub) => {
      if (msg.confirm !== true)
        throw new Error("Entity deletion requires confirm: true");
      validateEntityReference(msg.entityType, msg.entityId);
      const deleted = hub.vault.deleteEntity(msg.entityType, msg.entityId);
      const derivations = await hub.registry.retryDerivations({ limit: 1000 });
      return { deleted, derivations };
    }),

  // Per-adapter readiness ("能否采集 + 不能的原因"). Probes each adapter's
  // authenticate({ readinessOnly: true }) — see AdapterRegistry.readiness().
  // The web-shell PersonalDataHub view renders this as a 就绪状态 column so
  // snapshot/device/credential sources show 待配置/需采集 instead of a
  // misleading "healthy".
  "personal-data-hub.adapter-readiness": async (msg) =>
    withHub((hub) =>
      hub.registry.readiness(
        msg && Number.isInteger(msg.timeoutMs)
          ? { timeoutMs: msg.timeoutMs }
          : {},
      ),
    ),

  "personal-data-hub.sync-adapter": async (msg) =>
    withHub(async (hub) => {
      const options = await _tryAdbAutoPullInputPath(
        hub,
        msg.name,
        msg.options,
      );
      try {
        return await hub.registry.syncAdapter(msg.name, options);
      } finally {
        // Best-effort cleanup of staging file we just wrote (don't shadow
        // a real adapter error with cleanup noise).
        if (options && options._autoPulledViaAdb && options.inputPath) {
          try {
            if (existsSync(options.inputPath)) unlinkSync(options.inputPath);
          } catch (_e) {
            /* ignore */
          }
        }
      }
    }),

  "personal-data-hub.sync-all": async (msg) =>
    withHub(async (hub) => {
      const reports = await hub.registry.syncAll(msg.options || {});
      return await runDedicatedBatchCollectors(hub, reports);
    }),

  "personal-data-hub.register-mock": async (msg) =>
    withHub((hub) => {
      const a = hub.registerMockAdapter({
        name: msg.name || "mock",
        count: typeof msg.count === "number" ? msg.count : 20,
        seed: typeof msg.seed === "number" ? msg.seed : 1,
      });
      return { name: a.name, version: a.version };
    }),

  "personal-data-hub.unregister": async (msg) =>
    withHub((hub) => ({ ok: hub.registry.unregister(msg.name) })),

  "personal-data-hub.query-events": async (msg) =>
    withHub((hub) =>
      hub.vault.queryEvents({
        subtype: msg.subtype,
        since: msg.since,
        until: msg.until,
        actor: msg.actor,
        adapter: msg.adapter,
        limit: msg.limit,
      }),
    ),

  // Phase 16 Vault Browser — full-text + faceted search over events.
  // See packages/personal-data-hub/lib/vault.js#searchEvents for the
  // query/result shape. The desktop browser view + Android "我的数据" tab
  // both consume this topic.
  "personal-data-hub.search-events": async (msg) =>
    withHub((hub) =>
      hub.vault.searchEvents({
        q: msg.q,
        adapter: msg.adapter,
        category: msg.category,
        subtype: msg.subtype,
        since: msg.since,
        until: msg.until,
        cursor: msg.cursor,
        limit: msg.limit,
      }),
    ),

  // Phase 16 Vault Browser — counts grouped by category/adapter/subtype,
  // honoring the same q + since/until filters as search-events. Powers
  // the sidebar badges + adapter chip counts in the browser UI.
  "personal-data-hub.facet-counts": async (msg) =>
    withHub((hub) =>
      hub.vault.facetCounts({
        q: msg.q,
        since: msg.since,
        until: msg.until,
      }),
    ),

  "personal-data-hub.recent-audit": async (msg) =>
    withHub((hub) =>
      hub.vault.queryAudit({
        since: msg.since,
        action: msg.action,
        limit: msg.limit,
      }),
    ),

  // ─── Destructive: wipe vault. Requires confirm:true. ────────────────
  "personal-data-hub.destroy": async (msg) => {
    if (!msg || msg.confirm !== true) {
      return {
        error:
          "Destructive: pass { confirm: true } to wipe vault. UI should require explicit user confirmation first.",
      };
    }
    const alsoWipeAccounts = !!msg.alsoWipeAccounts;
    const alsoWipeMasterKey = !!msg.alsoWipeMasterKey;
    const removed = [];
    try {
      const hub = await getHub();
      const hubDir = hub.hubDir;
      try {
        hub.vault.destroy();
        removed.push(
          join(hubDir, "vault.db"),
          join(hubDir, "vault.db-wal"),
          join(hubDir, "vault.db-shm"),
        );
      } catch (_e) {
        // best-effort
      }
      if (alsoWipeAccounts) {
        for (const f of ["email-accounts.json", "alipay-accounts.json"]) {
          const p = join(hubDir, f);
          try {
            if (existsSync(p)) {
              unlinkSync(p);
              removed.push(p);
            }
          } catch {
            // Account files are removed on a best-effort basis.
          }
        }
      }
      if (alsoWipeMasterKey) {
        const keyDir = join(hubDir, "keys");
        try {
          if (existsSync(keyDir)) {
            for (const f of readdirSync(keyDir)) {
              try {
                unlinkSync(join(keyDir, f));
                removed.push(join(keyDir, f));
              } catch {
                // Key fragments are removed on a best-effort basis.
              }
            }
          }
        } catch {
          // Key-directory cleanup is best-effort.
        }
      }
      try {
        closeHub();
      } catch {
        // The hub may already be closed after a partial wipe.
      }
      return { result: { ok: true, removed } };
    } catch (err) {
      return { error: err && err.message ? err.message : String(err) };
    }
  },

  // ─── Phase 5.6 — email config + event detail ─────────────────────────

  "personal-data-hub.test-email-auth": async (msg) =>
    withHub(async (hub) => await hub.testEmailAuth({ account: msg.account })),

  "personal-data-hub.register-email": async (msg) =>
    withHub(
      async (hub) =>
        await hub.registerEmailAdapter({
          account: msg.account,
          opts: msg.opts || {},
        }),
    ),

  "personal-data-hub.activate-email": async (msg) =>
    withHub(async (hub) => await hub.activateEmailAdapter(msg.email)),

  "personal-data-hub.unregister-email": async (msg) =>
    withHub(async (hub) => await hub.unregisterEmailAdapter(msg.email)),

  "personal-data-hub.list-email-accounts": async () =>
    withHub((hub) => hub.listEmailAccounts()),

  "personal-data-hub.event-detail": async (msg) =>
    withHub((hub) => hub.eventDetail(msg.eventId)),

  // ─── Phase 6 — Alipay bill import ─────────────────────────────────────

  "personal-data-hub.register-alipay": async (msg) =>
    withHub(
      async (hub) =>
        await hub.registerAlipayAdapter({
          account: msg.account,
          opts: msg.opts || {},
        }),
    ),

  "personal-data-hub.activate-alipay": async (msg) =>
    withHub(async (hub) => await hub.activateAlipayAdapter(msg.email)),

  "personal-data-hub.unregister-alipay": async (msg) =>
    withHub(async (hub) => await hub.unregisterAlipayAdapter(msg.email)),

  "personal-data-hub.list-alipay-accounts": async () =>
    withHub((hub) => hub.listAlipayAccounts()),

  "personal-data-hub.import-alipay-bill": async (msg) =>
    withHub(
      async (hub) =>
        await hub.importAlipayBill({
          zipPath: msg.zipPath,
          csvPath: msg.csvPath,
          zipPassword: msg.zipPassword,
        }),
    ),

  // ─── Phase 12.6.8 — WeChat env-probe + register / unregister / list ──

  "personal-data-hub.wechat-env-probe": async () =>
    withHub(async (hub) => await hub.probeWechatEnv()),

  "personal-data-hub.register-wechat": async (msg) =>
    withHub(
      async (hub) =>
        await hub.registerWechatAdapter({
          account: msg.account,
          dbPath: msg.dbPath,
          wechatDataPath: msg.wechatDataPath,
          fridaOpts: msg.fridaOpts,
          keyProviderOverride: msg.keyProviderOverride,
        }),
    ),

  "personal-data-hub.activate-wechat": async (msg) =>
    withHub(
      async (hub) =>
        await hub.activateWechatAdapter(msg.uin, {
          fridaOpts: msg.fridaOpts,
          keyProviderOverride: msg.keyProviderOverride,
        }),
    ),

  "personal-data-hub.unregister-wechat": async (msg) =>
    withHub(async (hub) => await hub.unregisterWechatAdapter(msg.uin)),

  "personal-data-hub.list-wechat-accounts": async () =>
    withHub((hub) => hub.listWechatAccounts()),

  // ─── Phase 1c — Bilibili C 路径 one-shot sync ─────────────────────────
  //
  // Pulls cookies from the user's Android Bilibili App via ADB, fetches 4
  // endpoints, ingests as a snapshot. Returns the standard
  // `{ok, report?, reason?, message?}` shape — see hub.bilibiliAdbSync for
  // the full reason taxonomy. UI maps reasons to banner strings.
  "personal-data-hub.bilibili-adb-sync": async (msg) =>
    withHub((hub) =>
      hub.bilibiliAdbSync({
        limits: msg && msg.limits,
        stagingDir: msg && msg.stagingDir,
        displayName: msg && msg.displayName,
      }),
    ),

  // Phase 1e — dry-run env probe (cookies path only, no API calls / vault writes)
  "personal-data-hub.bilibili-adb-doctor": async () =>
    withHub((hub) => hub.bilibiliAdbDoctor()),

  // Phase 2a — Douyin C 路径 one-shot sync (db extraction)
  "personal-data-hub.douyin-adb-sync": async (msg) =>
    withHub((hub) =>
      hub.douyinAdbSync({
        uid: msg && msg.uid,
        limits: msg && msg.limits,
        stagingDir: msg && msg.stagingDir,
        displayName: msg && msg.displayName,
      }),
    ),

  // Phase 3a — Weibo C 路径 one-shot sync (m.weibo.cn cookies + 4 endpoints)
  "personal-data-hub.weibo-adb-sync": async (msg) =>
    withHub((hub) =>
      hub.weiboAdbSync({
        limits: msg && msg.limits,
        stagingDir: msg && msg.stagingDir,
        displayName: msg && msg.displayName,
      }),
    ),

  // Phase 3c — Xhs C 路径 one-shot sync (xiaohongshu.com cookies + 4 endpoints X-S signed)
  "personal-data-hub.xhs-adb-sync": async (msg) =>
    withHub((hub) =>
      hub.xhsAdbSync({
        limits: msg && msg.limits,
        stagingDir: msg && msg.stagingDir,
        displayName: msg && msg.displayName,
      }),
    ),

  // Phase 6c — Toutiao C 路径 one-shot sync (www.toutiao.com cookies +
  // passport profile + 3 _signature endpoints). CLI/web context with no
  // desktop bridge: 3 signed endpoints short-circuit (no HTTP). Desktop
  // wiring uses ToutiaoSignBridge → ~100% hit.
  "personal-data-hub.toutiao-adb-sync": async (msg) =>
    withHub((hub) =>
      hub.toutiaoAdbSync({
        limits: msg && msg.limits,
        stagingDir: msg && msg.stagingDir,
        displayName: msg && msg.displayName,
      }),
    ),

  // Phase 6d — Kuaishou C 路径 one-shot sync (www.kuaishou.com cookies +
  // profile from api_ph payload + 3 GraphQL endpoints with __NS_sig3 +
  // kpf/kpn). CLI/web context: signed endpoints short-circuit (no HTTP).
  // Desktop wiring uses KuaishouSignBridge → ~100% hit.
  "personal-data-hub.kuaishou-adb-sync": async (msg) =>
    withHub((hub) =>
      hub.kuaishouAdbSync({
        limits: msg && msg.limits,
        stagingDir: msg && msg.stagingDir,
        displayName: msg && msg.displayName,
      }),
    ),

  // Phase 6e — Bridge dry-run doctor. Spins up Xhs / Toutiao / Kuaishou
  // sign bridges with empty cookie, probes for candidate signing globals,
  // times each phase. No phone needed. Detects SDK rotation BEFORE the
  // user starts a real sync. Desktop-only — CLI/web-shell-no-desktop
  // returns MODULE_LOAD_FAILED.
  "personal-data-hub.bridge-doctor": async () =>
    withHub((hub) => hub.bridgeDoctor()),

  // ─── Phase 8 — EntityResolver review / merge / unmerge ───────────────

  "personal-data-hub.review-queue-list": async (msg) =>
    withHub((hub) => hub.vault.listReviewQueue({ limit: msg.limit || 50 })),

  "personal-data-hub.review-decision": async (msg) =>
    withHub((hub) => {
      if (!hub.entityResolver) throw new Error("EntityResolver not wired");
      return hub.entityResolver.applyUserDecision({
        reviewId: msg.reviewId,
        decision: msg.decision,
      });
    }),

  "personal-data-hub.manual-merge": async (msg) =>
    withHub((hub) => {
      if (!hub.entityResolver) throw new Error("EntityResolver not wired");
      return hub.entityResolver.manualMerge({ aId: msg.aId, bId: msg.bId });
    }),

  "personal-data-hub.manual-unmerge": async (msg) =>
    withHub((hub) => {
      if (!hub.entityResolver) throw new Error("EntityResolver not wired");
      return hub.entityResolver.manualUnmerge(msg.personId);
    }),

  "personal-data-hub.resolver-drain": async (msg, context = {}) =>
    withHub(async (hub) => {
      if (!hub.entityResolver) throw new Error("EntityResolver not wired");
      const factory = context.server?.evolutionCompositionFactory;
      return await hub.drainResolver({ limit: msg.limit || 50 }, factory);
    }),

  "personal-data-hub.resolver-stats": async () =>
    withHub((hub) => ({
      queue: hub.vault.resolveQueueStats(),
      mergeGroups: hub.vault.stats().mergeGroups,
      reviewQueue:
        hub.vault.listReviewQueue({ limit: 1 }).length > 0
          ? hub.vault.listReviewQueue({ limit: 1000 }).length
          : 0,
    })),

  "personal-data-hub.merge-group-members": async (msg) =>
    withHub((hub) => hub.vault.getMergeGroupMembers(msg.personId)),

  // ─── Phase 11 — internal analysis skills ─────────────────────────────

  "personal-data-hub.skills-list": async () =>
    withHub((hub) => hub.analysisSkillNames || []),

  "personal-data-hub.run-skill": async (msg, context = {}) => {
    const factory = context.server?.evolutionCompositionFactory;
    return withHub(
      async (hub) => await hub.runSkill(msg.name, msg.options || {}),
      governedHubLoader(factory),
    );
  },

  // ─── Phase 10.3 — AIChat WebView 鉴权向导 (paste-mode on cc ui) ────────

  "personal-data-hub.aichat-open-login": async (msg) =>
    withHub(async (hub) => {
      const wiz = getAIChatWizard({ hubDir: hub.hubDir });
      return await wiz.openVendorLogin({
        vendor: msg.vendor,
        opts: msg.opts || {},
      });
    }),

  "personal-data-hub.aichat-probe-cookies": async (msg) =>
    withHub(async (hub) => {
      const wiz = getAIChatWizard({ hubDir: hub.hubDir });
      return await wiz.probeCookies({
        vendor: msg.vendor,
        cookieHeader: msg.cookieHeader,
      });
    }),

  "personal-data-hub.aichat-register-vendor": async (msg) =>
    withHub(async (hub) => {
      const wiz = getAIChatWizard({ hubDir: hub.hubDir });
      return await wiz.registerVendor({
        vendor: msg.vendor,
        cookies: msg.cookies,
        opts: msg.opts || {},
      });
    }),

  "personal-data-hub.aichat-rotate-login": async (msg) =>
    withHub(async (hub) => {
      const wiz = getAIChatWizard({ hubDir: hub.hubDir });
      return await wiz.rotateLoginPartition({ vendor: msg.vendor });
    }),

  "personal-data-hub.list-aichat-accounts": async () =>
    withHub(async (hub) => await hub.listAIChatAccounts()),

  "personal-data-hub.unregister-aichat": async (msg) =>
    withHub(async (hub) => await hub.unregisterAIChatVendor(msg.vendor)),

  "personal-data-hub.aichat-health-check-once": async () =>
    withHub(async (hub) => await hub.runAIChatHealthCheckOnce()),
};

/**
 * Phase 5.7 — streaming handlers. Same call pattern as session-core
 * streaming: handler receives `sender(payload)` to push intermediate
 * `{ type: "personal-data-hub.<topic>.event", ... }` messages while
 * sync is in flight, then the dispatcher wraps the final return with
 * `.end`. Adapter progress phases (connecting / fetching / done / error)
 * surface here; UI subscribes via the composable.
 */
export const PERSONAL_DATA_HUB_STREAMING_HANDLERS = {
  "personal-data-hub.sync-adapter-stream": async (msg, sender) => {
    const hub = await getHub();
    const original = hub.registry.onSyncEvent;
    hub.registry.onSyncEvent = (evt) => {
      try {
        sender({
          type: "personal-data-hub.sync-adapter-stream.event",
          event: evt,
        });
      } catch {
        // Streaming clients may disconnect while collection continues.
      }
      if (typeof original === "function") {
        try {
          original(evt);
        } catch {
          // A prior observer must not break collection telemetry.
        }
      }
    };
    const options = await _tryAdbAutoPullInputPath(hub, msg.name, msg.options);
    try {
      const report = await hub.registry.syncAdapter(msg.name, options);
      return { result: report };
    } finally {
      hub.registry.onSyncEvent = original;
      if (options && options._autoPulledViaAdb && options.inputPath) {
        try {
          if (existsSync(options.inputPath)) unlinkSync(options.inputPath);
        } catch (_e) {
          /* ignore */
        }
      }
    }
  },

  "personal-data-hub.sync-all-stream": async (msg, sender) => {
    const hub = await getHub();
    const original = hub.registry.onSyncEvent;
    hub.registry.onSyncEvent = (evt) => {
      try {
        sender({ type: "personal-data-hub.sync-all-stream.event", event: evt });
      } catch {
        // Streaming clients may disconnect while collection continues.
      }
      if (typeof original === "function") {
        try {
          original(evt);
        } catch {
          // A prior observer must not break collection telemetry.
        }
      }
    };
    try {
      const registryReports = await hub.registry.syncAll(msg.options || {});
      const reports = await runDedicatedBatchCollectors(hub, registryReports);
      return { result: reports };
    } finally {
      hub.registry.onSyncEvent = original;
    }
  },
};

/**
 * Topic names this protocol owns — exported so the dispatcher can list /
 * advertise them to clients via a capabilities probe.
 */
export const PERSONAL_DATA_HUB_TOPICS = Object.freeze([
  ...Object.keys(PERSONAL_DATA_HUB_HANDLERS),
  ...Object.keys(PERSONAL_DATA_HUB_STREAMING_HANDLERS),
]);
