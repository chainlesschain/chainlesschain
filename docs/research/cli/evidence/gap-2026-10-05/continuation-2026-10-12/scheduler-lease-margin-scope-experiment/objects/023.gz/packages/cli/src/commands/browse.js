/**
 * Browser automation commands
 * chainlesschain browse <url> | browse scrape <url> | browse screenshot <url>
 */

import chalk from "chalk";
import { numericOption } from "../lib/cli-numeric.js";
import ora from "ora";
import { logger } from "../lib/logger.js";
import {
  fetchPage,
  extractText,
  extractTitle,
  extractMeta,
  querySelectorAll,
  extractLinks,
  takeScreenshot,
} from "../lib/browser-automation.js";

export function registerBrowseCommand(program) {
  const browse = program
    .command("browse")
    .description("Headless browser automation and web scraping");

  // browse fetch — fetch and display page content
  browse
    .command("fetch")
    .description("Fetch a URL and display text content")
    .argument("<url>", "URL to fetch")
    .option("--html", "Show raw HTML instead of text")
    .option("--links", "Extract links only")
    .option("--json", "Output as JSON")
    .action(async (url, options) => {
      try {
        const spinner = ora(`Fetching ${url}...`).start();
        const result = await fetchPage(url);
        spinner.stop();

        const title = extractTitle(result.html);
        const text = extractText(result.html);
        const description = extractMeta(result.html);

        if (options.json) {
          const output = {
            url: result.url,
            status: result.status,
            title,
            description,
            size: result.size,
          };
          if (options.html) output.html = result.html;
          else if (options.links)
            output.links = extractLinks(result.html, result.url);
          else output.text = text;
          console.log(JSON.stringify(output, null, 2));
          return;
        }

        if (options.links) {
          const links = extractLinks(result.html, result.url);
          logger.log(
            chalk.bold(`Links from ${title || url} (${links.length}):\n`),
          );
          for (const link of links.slice(0, 50)) {
            logger.log(
              `  ${chalk.cyan(link.text.substring(0, 60).padEnd(62))} ${chalk.gray(link.href)}`,
            );
          }
          if (links.length > 50)
            logger.log(chalk.gray(`  ... and ${links.length - 50} more`));
          return;
        }

        if (options.html) {
          console.log(result.html);
          return;
        }

        logger.log(chalk.bold(title || url));
        if (description) logger.log(chalk.gray(description));
        logger.log(
          chalk.gray(`${result.size} bytes | ${result.contentType}\n`),
        );
        logger.log(text.substring(0, 5000));
        if (text.length > 5000) {
          logger.log(
            chalk.gray(`\n... truncated (${text.length} chars total)`),
          );
        }
      } catch (err) {
        logger.error(`Fetch failed: ${err.message}`);
        process.exit(1);
      }
    });

  // browse scrape — scrape elements matching a CSS selector
  browse
    .command("scrape")
    .description("Scrape elements from a URL using CSS selector")
    .argument("<url>", "URL to scrape")
    .requiredOption("-s, --selector <css>", "CSS selector (tag, .class, #id)")
    .option("-n, --limit <n>", "Max results", "20")
    .option("--json", "Output as JSON")
    .action(async (url, options) => {
      try {
        const spinner = ora(`Scraping ${url}...`).start();
        const result = await fetchPage(url);
        const elements = querySelectorAll(result.html, options.selector);
        spinner.stop();

        const limit = numericOption(options.limit, {
          name: "--limit",
          integer: true,
          min: 0,
          fallback: 20,
        });
        const limited = elements.slice(0, limit);

        if (options.json) {
          console.log(
            JSON.stringify(
              {
                url: result.url,
                selector: options.selector,
                count: elements.length,
                results: limited.map((e) => ({ text: e.text })),
              },
              null,
              2,
            ),
          );
          return;
        }

        if (elements.length === 0) {
          logger.info(`No elements matching "${options.selector}"`);
        } else {
          logger.log(
            chalk.bold(
              `Scraped ${elements.length} elements matching "${options.selector}":\n`,
            ),
          );
          for (let i = 0; i < limited.length; i++) {
            const text = limited[i].text.substring(0, 200).replace(/\n/g, " ");
            logger.log(`  ${chalk.gray(`[${i + 1}]`)} ${text}`);
          }
          if (elements.length > limit) {
            logger.log(chalk.gray(`  ... ${elements.length - limit} more`));
          }
        }
      } catch (err) {
        logger.error(`Scrape failed: ${err.message}`);
        process.exit(1);
      }
    });

  // browse screenshot — take a screenshot (requires playwright)
  browse
    .command("screenshot")
    .description("Take a screenshot of a URL (requires playwright)")
    .argument("<url>", "URL to screenshot")
    .option("-o, --output <path>", "Output file path", "screenshot.png")
    .option("--width <n>", "Viewport width", "1280")
    .option("--height <n>", "Viewport height", "720")
    .option("--full-page", "Capture full page")
    .option("--json", "Output as JSON")
    .action(async (url, options) => {
      try {
        const spinner = ora(`Taking screenshot of ${url}...`).start();
        const result = await takeScreenshot(url, options.output, {
          width: numericOption(options.width, {
            name: "--width",
            integer: true,
            min: 1,
            fallback: 1280,
          }),
          height: numericOption(options.height, {
            name: "--height",
            integer: true,
            min: 1,
            fallback: 720,
          }),
          fullPage: !!options.fullPage,
        });
        spinner.stop();

        if (options.json) {
          console.log(JSON.stringify(result, null, 2));
        } else if (result.success) {
          logger.success(`Screenshot saved: ${chalk.cyan(result.path)}`);
        } else {
          logger.error(result.error);
          logger.info("Install playwright: npm install -g playwright");
        }
      } catch (err) {
        logger.error(`Screenshot failed: ${err.message}`);
        process.exit(1);
      }
    });

  registerBrowseChromeCommand(browse);
  registerBrowseV2Command(browse);
}

/**
 * `cc browse chrome` — Chrome connector: attach to the USER'S real Chrome
 * over CDP so page state (DOM/console/network/screenshot) is captured WITH
 * their login sessions. `launch` starts a debuggable Chrome (dedicated
 * profile by default; `--default-profile` reuses the real one but requires
 * every Chrome window to be closed first); `status` checks the port;
 * `state` attaches, observes, and prints the page state.
 */
export function registerBrowseChromeCommand(browse) {
  const chrome = browse
    .command("chrome")
    .description(
      "Chrome connector — capture page state from YOUR logged-in Chrome over CDP",
    );

  chrome
    .command("status")
    .description("Is a debuggable Chrome listening on the CDP port?")
    .option("-p, --port <port>", "CDP port", "9222")
    .option("--json", "Output as JSON")
    .action(async (options) => {
      const { discoverCdp } = await import("../lib/chrome-connector.js");
      const port = numericOption(options.port, {
        name: "--port",
        integer: true,
        min: 1,
        fallback: 9222,
      });
      const res = await discoverCdp({ port });
      if (options.json) {
        console.log(JSON.stringify(res, null, 2));
        return;
      }
      if (res.ok) {
        logger.success(`Debuggable Chrome on port ${port}: ${res.browser}`);
      } else {
        logger.info(
          `No debuggable Chrome on port ${port}. Start one: cc browse chrome launch`,
        );
      }
    });

  chrome
    .command("launch")
    .description(
      "Launch a debuggable Chrome (dedicated profile; sign in once there and it persists)",
    )
    .option("-p, --port <port>", "CDP port", "9222")
    .option("-u, --url <url>", "Open this URL")
    .option(
      "--default-profile",
      "Reuse your REAL Chrome profile (requires ALL Chrome windows closed; the CDP port then controls your logged-in browser)",
    )
    .option("--profile <dir>", "Custom profile directory")
    .option("--json", "Output as JSON")
    .action(async (options) => {
      const { discoverCdp, launchChrome } =
        await import("../lib/chrome-connector.js");
      const port = numericOption(options.port, {
        name: "--port",
        integer: true,
        min: 1,
        fallback: 9222,
      });
      const existing = await discoverCdp({ port });
      if (existing.ok) {
        if (options.json) {
          console.log(
            JSON.stringify({ ok: true, already: true, port }, null, 2),
          );
        } else {
          logger.success(
            `A debuggable Chrome is already on port ${port} (${existing.browser})`,
          );
        }
        return;
      }
      const res = launchChrome({
        port,
        url: options.url,
        defaultProfile: options.defaultProfile === true,
        profileDir: options.profile,
      });
      if (options.json) {
        console.log(JSON.stringify({ ...res, port }, null, 2));
        return;
      }
      if (!res.ok) {
        logger.error(res.error);
        process.exitCode = 1;
        return;
      }
      logger.success(`Launched ${res.executable} (CDP port ${port})`);
      if (options.defaultProfile) {
        logger.info(
          "Default profile requested — if the window did NOT get the debug port, close every Chrome window and retry.",
        );
      } else {
        logger.info(
          "Dedicated connector profile — sign in to your sites once there; the login state persists.",
        );
      }
      logger.warn(
        "The CDP port is an unauthenticated local control channel — close this Chrome when you are done.",
      );
    });

  chrome
    .command("state")
    .description(
      "Attach to the connected Chrome and capture a tab's state (DOM/console/network/screenshot)",
    )
    .option("-p, --port <port>", "CDP port", "9222")
    .option("-t, --tab <n>", "Tab index (see the tabs list in the output)", "0")
    .option(
      "--watch-ms <ms>",
      "Observe console/network for this long (collected from attach time)",
      "3000",
    )
    .option(
      "--reload",
      "Reload the tab first so load-time console/network is captured",
    )
    .option("--no-dom", "Skip the DOM snapshot")
    .option("--dom-cap <chars>", "DOM snapshot cap", "150000")
    .option("--screenshot <file>", "Also write a screenshot")
    .option("--json", "Output as JSON")
    .action(async (options) => {
      const { captureState } = await import("../lib/chrome-connector.js");
      const state = await captureState({
        port: numericOption(options.port, {
          name: "--port",
          integer: true,
          min: 1,
          fallback: 9222,
        }),
        tab: numericOption(options.tab, {
          name: "--tab",
          integer: true,
          min: 0,
          fallback: 0,
        }),
        watchMs: numericOption(options.watchMs, {
          name: "--watch-ms",
          integer: true,
          min: 0,
          fallback: 3000,
        }),
        reload: options.reload === true,
        includeDom: options.dom !== false,
        domCap: numericOption(options.domCap, {
          name: "--dom-cap",
          integer: true,
          min: 1000,
          fallback: 150000,
        }),
        screenshotPath: options.screenshot || null,
      });
      if (options.json) {
        console.log(JSON.stringify(state, null, 2));
        return;
      }
      if (!state.ok) {
        logger.error(state.error);
        process.exitCode = 1;
        return;
      }
      logger.log(
        chalk.bold(`Tab ${state.tab}: ${state.title || "(untitled)"}`),
      );
      logger.log(`  ${chalk.cyan(state.url)}`);
      logger.log(
        `  tabs: ${state.tabs.length}  console: ${state.console.length}  network issues: ${state.network.length}` +
          (state.html
            ? `  dom: ${state.html.length}${state.htmlTruncated ? "+ (truncated)" : ""} chars`
            : ""),
      );
      for (const c of state.console.slice(0, 20)) {
        logger.log(`  [console:${c.type}] ${c.text}`);
      }
      for (const nw of state.network.slice(0, 20)) {
        logger.log(
          `  [net:${nw.kind}] ${nw.url}${nw.status ? ` → ${nw.status}` : ""}${nw.error ? ` (${nw.error})` : ""}`,
        );
      }
      if (state.screenshotPath) {
        logger.success(`Screenshot: ${state.screenshotPath}`);
      }
    });

  chrome
    .command("act")
    .description(
      "Perform EXPLICIT actions (click/type/press/navigate/waitForSelector/screenshot/assertText) in the connected Chrome — unlike 'state', this DRIVES your logged-in browser",
    )
    .option("-p, --port <port>", "CDP port", "9222")
    .option("-t, --tab <n>", "Tab index", "0")
    .requiredOption(
      "--actions <json|@file>",
      'JSON array of steps, e.g. \'[{"type":"click","selector":"#go"}]\', or @steps.json',
    )
    .option(
      "--continue-on-error",
      "Keep executing the remaining steps after a failed one (default: fail fast)",
    )
    .option("--json", "Output as JSON")
    .action(async (options) => {
      const { discoverCdp, performActions } =
        await import("../lib/chrome-connector.js");
      const port = numericOption(options.port, {
        name: "--port",
        integer: true,
        min: 1,
        fallback: 9222,
      });
      let actions;
      try {
        const raw = options.actions.startsWith("@")
          ? (await import("fs")).readFileSync(options.actions.slice(1), "utf-8")
          : options.actions;
        actions = JSON.parse(raw);
      } catch (err) {
        logger.error(
          `--actions must be a JSON array (or @file.json): ${err.message}`,
        );
        process.exit(1);
      }
      // Refuse outright when nothing is listening — an action command must
      // never silently no-op or launch a browser on its own.
      const probe = await discoverCdp({ port });
      if (!probe.ok) {
        const msg = `No debuggable Chrome on port ${port} — refusing to act. Start one first: cc browse chrome launch`;
        if (options.json) {
          console.log(JSON.stringify({ ok: false, error: msg }, null, 2));
        } else {
          logger.error(msg);
        }
        process.exitCode = 1;
        return;
      }
      const res = await performActions(actions, {
        port,
        tab: numericOption(options.tab, {
          name: "--tab",
          integer: true,
          min: 0,
          fallback: 0,
        }),
        continueOnError: options.continueOnError === true,
      });
      if (options.json) {
        console.log(JSON.stringify(res, null, 2));
        if (!res.ok) process.exitCode = 1;
        return;
      }
      if (res.error) {
        logger.error(res.error);
        process.exitCode = 1;
        return;
      }
      if (res.profileWarning) logger.warn(res.profileWarning);
      for (const step of res.steps) {
        const mark = step.ok ? chalk.green("ok") : chalk.red("FAIL");
        logger.log(
          `  [${mark}] ${step.action} ${chalk.gray(`(${step.durationMs}ms)`)} ${step.detail}`,
        );
      }
      logger.log(
        `  ${res.executed}/${actions.length} step(s) executed → ${chalk.cyan(res.url)}${res.title ? ` (${res.title})` : ""}`,
      );
      if (res.auditError) {
        logger.warn(`audit log write failed: ${res.auditError}`);
      }
      if (!res.ok) process.exitCode = 1;
    });
}

import {
  BROWSE_TARGET_MATURITY_V2,
  BROWSE_ACTION_LIFECYCLE_V2,
  registerBrowseTargetV2,
  activateBrowseTargetV2,
  degradeBrowseTargetV2,
  retireBrowseTargetV2,
  touchBrowseTargetV2,
  getBrowseTargetV2,
  listBrowseTargetsV2,
  createBrowseActionV2,
  startBrowseActionV2,
  completeBrowseActionV2,
  failBrowseActionV2,
  cancelBrowseActionV2,
  getBrowseActionV2,
  listBrowseActionsV2,
  setMaxActiveBrowseTargetsPerOwnerV2,
  getMaxActiveBrowseTargetsPerOwnerV2,
  setMaxPendingBrowseActionsPerTargetV2,
  getMaxPendingBrowseActionsPerTargetV2,
  setBrowseTargetIdleMsV2,
  getBrowseTargetIdleMsV2,
  setBrowseActionStuckMsV2,
  getBrowseActionStuckMsV2,
  autoDegradeIdleBrowseTargetsV2,
  autoFailStuckBrowseActionsV2,
  getBrowserAutomationStatsV2,
} from "../lib/browser-automation.js";

export function registerBrowseV2Command(browse) {
  browse
    .command("enums-v2")
    .description("Show V2 enums")
    .action(() => {
      console.log(
        JSON.stringify(
          { BROWSE_TARGET_MATURITY_V2, BROWSE_ACTION_LIFECYCLE_V2 },
          null,
          2,
        ),
      );
    });
  browse
    .command("register-target-v2")
    .description("Register a browse target (pending)")
    .requiredOption("--id <id>")
    .requiredOption("--owner <owner>")
    .option("--url <url>")
    .action((o) => {
      console.log(JSON.stringify(registerBrowseTargetV2(o), null, 2));
    });
  browse
    .command("activate-target-v2 <id>")
    .description("Activate target")
    .action((id) => {
      console.log(JSON.stringify(activateBrowseTargetV2(id), null, 2));
    });
  browse
    .command("degrade-target-v2 <id>")
    .description("Degrade target")
    .action((id) => {
      console.log(JSON.stringify(degradeBrowseTargetV2(id), null, 2));
    });
  browse
    .command("retire-target-v2 <id>")
    .description("Retire target (terminal)")
    .action((id) => {
      console.log(JSON.stringify(retireBrowseTargetV2(id), null, 2));
    });
  browse
    .command("touch-target-v2 <id>")
    .description("Refresh lastTouchedAt")
    .action((id) => {
      console.log(JSON.stringify(touchBrowseTargetV2(id), null, 2));
    });
  browse
    .command("get-target-v2 <id>")
    .description("Get a target")
    .action((id) => {
      console.log(JSON.stringify(getBrowseTargetV2(id), null, 2));
    });
  browse
    .command("list-targets-v2")
    .description("List targets")
    .action(() => {
      console.log(JSON.stringify(listBrowseTargetsV2(), null, 2));
    });
  browse
    .command("create-action-v2")
    .description("Create a browse action (queued)")
    .requiredOption("--id <id>")
    .requiredOption("--target-id <targetId>")
    .option("--kind <kind>", "fetch/scrape/screenshot", "fetch")
    .action((o) => {
      console.log(
        JSON.stringify(
          createBrowseActionV2({
            id: o.id,
            targetId: o.targetId,
            kind: o.kind,
          }),
          null,
          2,
        ),
      );
    });
  browse
    .command("start-action-v2 <id>")
    .description("Start action")
    .action((id) => {
      console.log(JSON.stringify(startBrowseActionV2(id), null, 2));
    });
  browse
    .command("complete-action-v2 <id>")
    .description("Complete action")
    .action((id) => {
      console.log(JSON.stringify(completeBrowseActionV2(id), null, 2));
    });
  browse
    .command("fail-action-v2 <id>")
    .description("Fail action")
    .option("--reason <r>")
    .action((id, o) => {
      console.log(JSON.stringify(failBrowseActionV2(id, o.reason), null, 2));
    });
  browse
    .command("cancel-action-v2 <id>")
    .description("Cancel action")
    .option("--reason <r>")
    .action((id, o) => {
      console.log(JSON.stringify(cancelBrowseActionV2(id, o.reason), null, 2));
    });
  browse
    .command("get-action-v2 <id>")
    .description("Get action")
    .action((id) => {
      console.log(JSON.stringify(getBrowseActionV2(id), null, 2));
    });
  browse
    .command("list-actions-v2")
    .description("List actions")
    .action(() => {
      console.log(JSON.stringify(listBrowseActionsV2(), null, 2));
    });
  browse
    .command("set-max-active-targets-v2 <n>")
    .description("Set per-owner active cap")
    .action((n) => {
      setMaxActiveBrowseTargetsPerOwnerV2(Number(n));
      console.log(
        JSON.stringify(
          {
            maxActiveBrowseTargetsPerOwner:
              getMaxActiveBrowseTargetsPerOwnerV2(),
          },
          null,
          2,
        ),
      );
    });
  browse
    .command("set-max-pending-actions-v2 <n>")
    .description("Set per-target pending cap")
    .action((n) => {
      setMaxPendingBrowseActionsPerTargetV2(Number(n));
      console.log(
        JSON.stringify(
          {
            maxPendingBrowseActionsPerTarget:
              getMaxPendingBrowseActionsPerTargetV2(),
          },
          null,
          2,
        ),
      );
    });
  browse
    .command("set-target-idle-ms-v2 <n>")
    .description("Set idle threshold")
    .action((n) => {
      setBrowseTargetIdleMsV2(Number(n));
      console.log(
        JSON.stringify(
          { browseTargetIdleMs: getBrowseTargetIdleMsV2() },
          null,
          2,
        ),
      );
    });
  browse
    .command("set-action-stuck-ms-v2 <n>")
    .description("Set stuck threshold")
    .action((n) => {
      setBrowseActionStuckMsV2(Number(n));
      console.log(
        JSON.stringify(
          { browseActionStuckMs: getBrowseActionStuckMsV2() },
          null,
          2,
        ),
      );
    });
  browse
    .command("auto-degrade-idle-targets-v2")
    .description("Auto-degrade idle targets")
    .action(() => {
      console.log(JSON.stringify(autoDegradeIdleBrowseTargetsV2(), null, 2));
    });
  browse
    .command("auto-fail-stuck-actions-v2")
    .description("Auto-fail stuck actions")
    .action(() => {
      console.log(JSON.stringify(autoFailStuckBrowseActionsV2(), null, 2));
    });
  browse
    .command("stats-v2")
    .description("V2 aggregate stats")
    .action(() => {
      console.log(JSON.stringify(getBrowserAutomationStatsV2(), null, 2));
    });
}

// === Iter20 V2 governance overlay ===
export function registerBagovV2Commands(program) {
  const parent = program.commands.find((c) => c.name() === "browse");
  if (!parent) return;
  const L = async () => await import("../lib/browser-automation.js");
  parent
    .command("bagov-enums-v2")
    .description("Show V2 enums")
    .action(async () => {
      const m = await L();
      console.log(
        JSON.stringify(
          {
            profileMaturity: m.BAGOV_PROFILE_MATURITY_V2,
            navigationLifecycle: m.BAGOV_NAVIGATION_LIFECYCLE_V2,
          },
          null,
          2,
        ),
      );
    });
  parent
    .command("bagov-config-v2")
    .description("Show V2 config")
    .action(async () => {
      const m = await L();
      console.log(
        JSON.stringify(
          {
            maxActive: m.getMaxActiveBagovProfilesPerOwnerV2(),
            maxPending: m.getMaxPendingBagovNavigationsPerProfileV2(),
            idleMs: m.getBagovProfileIdleMsV2(),
            stuckMs: m.getBagovNavigationStuckMsV2(),
          },
          null,
          2,
        ),
      );
    });
  parent
    .command("bagov-set-max-active-v2 <n>")
    .description("Set max active")
    .action(async (n) => {
      (await L()).setMaxActiveBagovProfilesPerOwnerV2(Number(n));
      console.log("ok");
    });
  parent
    .command("bagov-set-max-pending-v2 <n>")
    .description("Set max pending")
    .action(async (n) => {
      (await L()).setMaxPendingBagovNavigationsPerProfileV2(Number(n));
      console.log("ok");
    });
  parent
    .command("bagov-set-idle-ms-v2 <n>")
    .description("Set idle threshold ms")
    .action(async (n) => {
      (await L()).setBagovProfileIdleMsV2(Number(n));
      console.log("ok");
    });
  parent
    .command("bagov-set-stuck-ms-v2 <n>")
    .description("Set stuck threshold ms")
    .action(async (n) => {
      (await L()).setBagovNavigationStuckMsV2(Number(n));
      console.log("ok");
    });
  parent
    .command("bagov-register-v2 <id> <owner>")
    .description("Register V2 profile")
    .option("--engine <v>", "engine")
    .action(async (id, owner, o) => {
      const m = await L();
      console.log(
        JSON.stringify(
          m.registerBagovProfileV2({ id, owner, engine: o.engine }),
          null,
          2,
        ),
      );
    });
  parent
    .command("bagov-activate-v2 <id>")
    .description("Activate profile")
    .action(async (id) => {
      console.log(
        JSON.stringify((await L()).activateBagovProfileV2(id), null, 2),
      );
    });
  parent
    .command("bagov-stale-v2 <id>")
    .description("Stale profile")
    .action(async (id) => {
      console.log(JSON.stringify((await L()).staleBagovProfileV2(id), null, 2));
    });
  parent
    .command("bagov-archive-v2 <id>")
    .description("Archive profile")
    .action(async (id) => {
      console.log(
        JSON.stringify((await L()).archiveBagovProfileV2(id), null, 2),
      );
    });
  parent
    .command("bagov-touch-v2 <id>")
    .description("Touch profile")
    .action(async (id) => {
      console.log(JSON.stringify((await L()).touchBagovProfileV2(id), null, 2));
    });
  parent
    .command("bagov-get-v2 <id>")
    .description("Get profile")
    .action(async (id) => {
      console.log(JSON.stringify((await L()).getBagovProfileV2(id), null, 2));
    });
  parent
    .command("bagov-list-v2")
    .description("List profiles")
    .action(async () => {
      console.log(JSON.stringify((await L()).listBagovProfilesV2(), null, 2));
    });
  parent
    .command("bagov-create-navigation-v2 <id> <profileId>")
    .description("Create navigation")
    .option("--url <v>", "url")
    .action(async (id, profileId, o) => {
      const m = await L();
      console.log(
        JSON.stringify(
          m.createBagovNavigationV2({ id, profileId, url: o.url }),
          null,
          2,
        ),
      );
    });
  parent
    .command("bagov-navigating-navigation-v2 <id>")
    .description("Mark navigation as navigating")
    .action(async (id) => {
      console.log(
        JSON.stringify((await L()).navigatingBagovNavigationV2(id), null, 2),
      );
    });
  parent
    .command("bagov-complete-navigation-v2 <id>")
    .description("Complete navigation")
    .action(async (id) => {
      console.log(
        JSON.stringify((await L()).completeNavigationBagovV2(id), null, 2),
      );
    });
  parent
    .command("bagov-fail-navigation-v2 <id> [reason]")
    .description("Fail navigation")
    .action(async (id, reason) => {
      console.log(
        JSON.stringify((await L()).failBagovNavigationV2(id, reason), null, 2),
      );
    });
  parent
    .command("bagov-cancel-navigation-v2 <id> [reason]")
    .description("Cancel navigation")
    .action(async (id, reason) => {
      console.log(
        JSON.stringify(
          (await L()).cancelBagovNavigationV2(id, reason),
          null,
          2,
        ),
      );
    });
  parent
    .command("bagov-get-navigation-v2 <id>")
    .description("Get navigation")
    .action(async (id) => {
      console.log(
        JSON.stringify((await L()).getBagovNavigationV2(id), null, 2),
      );
    });
  parent
    .command("bagov-list-navigations-v2")
    .description("List navigations")
    .action(async () => {
      console.log(
        JSON.stringify((await L()).listBagovNavigationsV2(), null, 2),
      );
    });
  parent
    .command("bagov-auto-stale-idle-v2")
    .description("Auto-stale idle")
    .action(async () => {
      console.log(
        JSON.stringify((await L()).autoStaleIdleBagovProfilesV2(), null, 2),
      );
    });
  parent
    .command("bagov-auto-fail-stuck-v2")
    .description("Auto-fail stuck navigations")
    .action(async () => {
      console.log(
        JSON.stringify((await L()).autoFailStuckBagovNavigationsV2(), null, 2),
      );
    });
  parent
    .command("bagov-gov-stats-v2")
    .description("V2 gov stats")
    .action(async () => {
      console.log(
        JSON.stringify((await L()).getBrowserAutomationGovStatsV2(), null, 2),
      );
    });
}
