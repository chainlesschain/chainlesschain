/**
 * MCP (Model Context Protocol) commands
 * chainlesschain mcp servers|connect|disconnect|tools|call
 */

import fs from "fs";
import path from "path";
import { isProxy } from "node:util/types";
import chalk from "chalk";
import ora from "ora";
import { logger } from "../lib/logger.js";
import { bootstrap, shutdown } from "../runtime/bootstrap.js";
import {
  MCPClient,
  MCPServerConfig,
  MCP_CONFIG_SCOPES,
  inferTransport,
  normalizeMcpConfigScope,
} from "../harness/mcp-client.js";
import {
  validateMcpServer,
  annotateMcpCompatibility,
} from "@chainlesschain/session-core";
import {
  generateMcpServerScaffold,
  SUPPORTED_TRANSPORTS,
} from "../lib/mcp-scaffold.js";
import { parseJsonOption } from "../lib/parse-json-option.js";
import { resolveMcpAuthTarget, isUrlLike } from "../lib/mcp-auth-target.js";
import { notFoundWithSuggestion } from "../lib/suggest-name.js";
import { findGitProjectRoot } from "../lib/project-root.cjs";
import { redactConfigObject } from "../lib/config-redaction.js";
import { registerHostHooksV2Workspace } from "../lib/hooks-v2-workspace-context.js";
import {
  localMcpHeadersHelperFingerprint,
  recordLocalMcpHeadersHelperTrust,
  revokeLocalMcpHeadersHelperTrust,
} from "../lib/mcp-headers-helper-trust.js";
import {
  checkProjectMcpTrust,
  issueProjectMcpWorkspaceAuthority,
} from "../lib/project-mcp-trust.js";
import {
  consumeMcpStdioExecutionAuthority,
  MCP_STDIO_LOCAL_CODE_TRUST_REQUIRED_CODE,
  issueMcpStdioExecutionAuthority,
  materializeApprovedMcpStdioInvocation,
  resolveMcpStdioExecutionApproval,
  verifyMcpStdioApprovedWorkingDirectory,
} from "../lib/mcp-stdio-execution-authority.js";
import {
  MCP_STDIO_RUNTIME_KINDS,
  prepareMcpStdioExecutableIdentity,
} from "../lib/mcp-stdio-executable-identity.js";
import { resolveMcpStdioSandboxContext } from "../lib/mcp-stdio-workspace-authority.js";
import {
  MCP_SANDBOX_BOUNDARIES,
  MCP_SANDBOX_POLICY_INVALID_CODE,
  normalizeMcpSandboxPolicy,
  readMcpStdioCwd,
} from "../lib/mcp-sandbox-policy.js";
import {
  materializeMcpStdioNpmPackage,
  parseExactNpmPackageSpec,
} from "../lib/mcp-stdio-package-materialization.js";
import { executionBroker } from "../lib/process-execution-broker/index.js";
import {
  CATALOG as REGISTRY_CATALOG,
  CATEGORIES as REGISTRY_CATEGORIES,
  listServers as registryListServers,
  searchServers as registrySearchServers,
  getServer as registryGetServer,
} from "../lib/mcp-registry.js";

/**
 * Whether `mcp login` should NOT open a browser. True when either the canonical
 * `--no-open` flag or the Claude-Code-parity `--no-browser` alias is passed.
 * Commander maps each negatable flag to a boolean that is `false` when present.
 */
export function loginWantsNoBrowser(options = {}) {
  return options.open === false || options.browser === false;
}

/**
 * Detect a headless environment where opening a browser is futile, so `mcp
 * login` prints the authorize URL for manual opening instead of launching a
 * popup that can never appear (Claude-Code 2.1.191 parity: "headless
 * environments skip the browser popup and go straight to the paste-the-URL
 * prompt"). The localhost callback still catches the code, so login completes.
 *
 * Heuristics: a CI marker forces headless on any OS; macOS/Windows otherwise
 * always have a window server; on Linux/BSD a browser needs a display server
 * (`DISPLAY`/`WAYLAND_DISPLAY`) — its absence (e.g. SSH without X11 forwarding)
 * means headless. `CI=false`/`CI=0` are treated as not-CI.
 */
export function isHeadlessEnv(env = process.env, platform = process.platform) {
  const ci = env.CI;
  if (ci && ci !== "false" && ci !== "0") return true;
  if (platform === "darwin" || platform === "win32") return false;
  return !(env.DISPLAY || env.WAYLAND_DISPLAY);
}

// Singleton MCP client for commands that deliberately keep a connection open
// in the current process. Normal CLI queries use connectForQuery() so they do
// not depend on state from a previous (and therefore different) process.
let mcpClient = null;
const PROJECT_MCP_FILE_TRUST = Symbol("projectMcpFileTrust");

export function authorizeMcpRowForConnect(row, overrides = {}) {
  const config = { ...row, ...overrides };
  if (inferTransport(config) !== "stdio") return config;
  if (row?.[PROJECT_MCP_FILE_TRUST] === false) {
    const error = new Error(
      `Project MCP server "${String(row?.name)}" can execute local code; trust the current .mcp.json before connecting`,
    );
    error.code = MCP_STDIO_LOCAL_CODE_TRUST_REQUIRED_CODE;
    throw error;
  }
  const approvalKind =
    row?.configScope === "managed"
      ? "managed-settings"
      : row?.configScope === "project"
        ? "project-config"
        : "registered-config";
  config.mcpStdioExecutionAuthority = issueMcpStdioExecutionAuthority({
    serverName: row.name,
    config,
    approvalKind,
    approvalSource: `${row?.configScope || "user"}:${row?.configSource || "database"}:${row.name}`,
    workspaceRoot: projectMcpLocation(process.cwd()).root,
  });
  return config;
}

function commandWorkspaceBinding() {
  return registerHostHooksV2Workspace(projectMcpLocation(process.cwd()).root);
}

export function resolveMcpCommandStdioWorkingDirectory(
  serverName,
  config,
  approval,
  workspaceBinding = commandWorkspaceBinding(),
) {
  const context = resolveMcpStdioSandboxContext({
    serverName,
    config,
    workspaceBinding,
  });
  if (context.sandboxPolicy && config.cwd) {
    verifyMcpStdioApprovedWorkingDirectory(approval, context.workingDirectory);
  }
  return (
    context.workingDirectory || context.pluginWorkspaceRoot || process.cwd()
  );
}

function getClient() {
  if (!mcpClient) {
    mcpClient = new MCPClient({ workspaceBinding: commandWorkspaceBinding() });
  }
  return mcpClient;
}

/**
 * Resolve a `mcp login|logout <target>` argument (a URL or a configured server
 * NAME — Claude-Code 2.1.186 parity) to a concrete server URL. The DB is only
 * bootstrapped when a name lookup is actually needed, so a raw-URL login stays
 * dependency-free.
 */
async function resolveAuthTargetUrl(program, target) {
  if (isUrlLike(target)) return resolveMcpAuthTarget(target).url;
  const ctx = await bootstrap({ verbose: program.opts().verbose });
  const config = ctx.db ? new MCPServerConfig(ctx.db.getDatabase()) : null;
  const rows = config
    ? await effectiveMcpRows(config)
    : await readManagedMcpRows();
  const lookup = (name) => {
    try {
      return rows.find((row) => row.name === name) || null;
    } catch {
      return null; // a lookup failure surfaces as "unknown server" below
    }
  };
  return resolveMcpAuthTarget(target, lookup).url;
}

/**
 * Connect MCP server(s) for a one-shot query (tools / resources / prompts).
 * Connects
 * the named server, or every registered server when `serverName` is omitted.
 * Returns `{ client, connected }`; the caller must disconnect the client and
 * `await shutdown()`.
 */
async function connectForQuery(program, serverName) {
  const ctx = await bootstrap({ verbose: program.opts().verbose });
  if (!ctx.db) {
    logger.error("Database not available");
    process.exit(1);
  }
  const db = ctx.db.getDatabase();
  const config = new MCPServerConfig(db);
  const projectFlag = String(process.env.CC_PROJECT_MCP || "").toLowerCase();
  const visible = await effectiveMcpRows(config, {
    includeProjectFile:
      Boolean(serverName) || projectFlag === "1" || projectFlag === "true",
  });
  let rows;
  if (serverName) {
    const row = visible.find((entry) => entry.name === serverName);
    if (!row) {
      const names = visible.map((s) => s.name);
      logger.error(
        `${notFoundWithSuggestion(serverName, names, { noun: "Server" })}. Use 'mcp add' first.`,
      );
      await shutdown();
      process.exit(1);
    }
    rows = [row];
  } else {
    rows = visible;
  }
  const client = new MCPClient({ workspaceBinding: commandWorkspaceBinding() });
  const connected = [];
  for (const row of rows) {
    if (!row) continue;
    try {
      await client.connect(row.name, authorizeMcpRowForConnect(row));
      connected.push(row.name);
    } catch (err) {
      logger.log(
        chalk.yellow(`  Failed to connect "${row.name}": ${err.message}`),
      );
    }
  }
  return { client, connected };
}

// Phase 3 (Hosted MCP Policy): resolve runtime mode from --mode > env > local.
function resolveMode(options) {
  return (
    options?.mode ||
    process.env.CHAINLESSCHAIN_MODE ||
    "local"
  ).toLowerCase();
}

// Normalize a stored server row to mcp-policy's server shape.
function toPolicyServer(row) {
  return {
    name: row.name,
    command: row.command,
    args: row.args,
    env: row.env,
    transport: row.transport,
    url: row.url,
    modeCompatibility: row.modeCompatibility,
  };
}

export function diagnoseMcpTransportConfig(server = {}) {
  const transport = inferTransport(server);
  const supported = new Set(["stdio", "http", "https", "sse", "ws", "wss"]);
  if (!supported.has(transport)) {
    return {
      ok: false,
      code: "unsupported_transport",
      transport,
      message: `Unsupported MCP transport: ${transport}`,
    };
  }
  if (transport === "stdio") {
    return server.command
      ? { ok: true, code: "ok", transport }
      : {
          ok: false,
          code: "missing_command",
          transport,
          message: "stdio transport requires a command",
        };
  }
  let endpoint;
  try {
    endpoint = new URL(String(server.url || ""));
  } catch {
    return {
      ok: false,
      code: "malformed_url",
      transport,
      message: `${transport} transport requires a valid URL`,
    };
  }
  const expected =
    transport === "sse"
      ? new Set(["http:", "https:"])
      : new Set([`${transport}:`]);
  if (!expected.has(endpoint.protocol)) {
    return {
      ok: false,
      code: "scheme_mismatch",
      transport,
      message: `Transport ${transport} is incompatible with URL scheme ${endpoint.protocol}`,
    };
  }
  if (endpoint.username || endpoint.password) {
    return {
      ok: false,
      code: "url_credentials_forbidden",
      transport,
      message:
        "Credentials must be provided with headers/OAuth, not embedded in the URL",
    };
  }
  return { ok: true, code: "ok", transport };
}

function headersHelperField(value) {
  return typeof value === "string" && value.trim()
    ? { headersHelper: value }
    : {};
}

function invalidMcpSandboxPolicy(message) {
  const error = new TypeError(message);
  error.code = MCP_SANDBOX_POLICY_INVALID_CODE;
  return error;
}

function readMcpSandboxPolicy(owner, label) {
  if (!owner || typeof owner !== "object" || isProxy(owner)) {
    throw invalidMcpSandboxPolicy(`${label} must be a non-Proxy object`);
  }
  const descriptor = Object.getOwnPropertyDescriptor(owner, "sandboxPolicy");
  if (!descriptor) return { present: false, policy: null };
  if (!("value" in descriptor)) {
    throw invalidMcpSandboxPolicy(
      `${label}.sandboxPolicy must be an own data property`,
    );
  }
  return {
    present: true,
    policy: normalizeMcpSandboxPolicy(descriptor.value, {
      label: `${label}.sandboxPolicy`,
    }),
  };
}

function collectMcpSandboxBoundary(value, previous = []) {
  return [...previous, value];
}

export function mcpSandboxPolicyUpdateFromAddOptions(options = {}) {
  const boundaries = options.sandboxBoundary;
  if (boundaries !== undefined && !Array.isArray(boundaries)) {
    throw invalidMcpSandboxPolicy(
      "--sandbox-boundary must be supplied as a repeatable option",
    );
  }
  if (options.clearSandboxBoundaries && boundaries?.length > 0) {
    throw invalidMcpSandboxPolicy(
      "--clear-sandbox-boundaries cannot be combined with --sandbox-boundary",
    );
  }
  if (options.clearSandboxBoundaries) return null;
  if (!boundaries || boundaries.length === 0) return undefined;
  return normalizeMcpSandboxPolicy(
    { requiredBoundaries: boundaries },
    { label: "--sandbox-boundary" },
  );
}

export function managedMcpRowsFromSettings(settings, file) {
  const block = settings?.managedMcpServers || settings?.mcpServers || {};
  if (!block || typeof block !== "object" || Array.isArray(block)) return [];
  return Object.entries(block)
    .filter(([, config]) => config && typeof config === "object")
    .map(([name, config]) => {
      const { policy: sandboxPolicy } = readMcpSandboxPolicy(
        config,
        `Managed MCP server "${name}"`,
      );
      const { cwd } = readMcpStdioCwd(config, {
        label: `Managed MCP server "${name}"`,
      });
      return {
        name,
        command: config.command || null,
        args: Array.isArray(config.args) ? config.args : [],
        env: config.env && typeof config.env === "object" ? config.env : {},
        runtimeKind: config.runtimeKind || null,
        ...(cwd ? { cwd } : {}),
        ...(sandboxPolicy ? { sandboxPolicy } : {}),
        url: config.url || null,
        transport: inferTransport(config),
        headers:
          config.headers && typeof config.headers === "object"
            ? config.headers
            : {},
        ...headersHelperField(config.headersHelper),
        autoConnect: config.autoConnect !== false,
        configScope: "managed",
        configSource: file,
        projectPath: null,
      };
    });
}

async function readManagedMcpRows() {
  const { loadManagedSettings } = await import("../lib/settings-loader.cjs");
  const loaded = loadManagedSettings({ env: process.env });
  return managedMcpRowsFromSettings(loaded.settings, loaded.file);
}

function projectMcpLocation(cwd = process.cwd()) {
  const root = findGitProjectRoot(cwd, { fs, path }) || path.resolve(cwd);
  return { root, file: path.join(root, ".mcp.json") };
}

function readProjectMcpDocument(cwd = process.cwd()) {
  const location = projectMcpLocation(cwd);
  if (!fs.existsSync(location.file)) {
    return { ...location, document: { mcpServers: {} } };
  }
  let content;
  let document;
  try {
    content = fs.readFileSync(location.file, "utf8");
    document = JSON.parse(content);
  } catch (error) {
    throw new Error(
      `Cannot read project MCP config ${location.file}: ${error.message}`,
    );
  }
  if (!document || typeof document !== "object" || Array.isArray(document)) {
    throw new Error(
      `Project MCP config must be a JSON object: ${location.file}`,
    );
  }
  if (
    document.mcpServers != null &&
    (typeof document.mcpServers !== "object" ||
      Array.isArray(document.mcpServers))
  ) {
    throw new Error(`mcpServers must be an object in ${location.file}`);
  }
  return {
    ...location,
    content,
    document: { ...document, mcpServers: { ...(document.mcpServers || {}) } },
  };
}

export function readProjectMcpRows(cwd = process.cwd()) {
  const { root, file, content, document } = readProjectMcpDocument(cwd);
  let trusted = false;
  try {
    trusted = checkProjectMcpTrust(file, content).status === "trusted";
  } catch {
    // Listing remains available, but execution authority fails closed below.
  }
  return Object.entries(document.mcpServers)
    .filter(([, config]) => config && typeof config === "object")
    .map(([name, config]) => {
      const { policy: sandboxPolicy } = readMcpSandboxPolicy(
        config,
        `Project MCP server "${name}"`,
      );
      const { cwd } = readMcpStdioCwd(config, {
        label: `Project MCP server "${name}"`,
      });
      const row = {
        name,
        command: config.command || null,
        args: Array.isArray(config.args) ? config.args : [],
        env: config.env && typeof config.env === "object" ? config.env : {},
        runtimeKind: config.runtimeKind || null,
        ...(cwd ? { cwd } : {}),
        ...(sandboxPolicy ? { sandboxPolicy } : {}),
        url: config.url || null,
        transport: inferTransport(config),
        headers:
          config.headers && typeof config.headers === "object"
            ? config.headers
            : {},
        ...headersHelperField(config.headersHelper),
        autoConnect: true,
        configScope: "project",
        configSource: file,
        projectPath: root,
      };
      Object.defineProperty(row, PROJECT_MCP_FILE_TRUST, { value: trusted });
      if (trusted && (row.headersHelper || inferTransport(row) === "stdio")) {
        row.projectMcpWorkspaceAuthority = issueProjectMcpWorkspaceAuthority({
          file,
          content,
          workspaceRoot: root,
          serverName: name,
          config: row,
        });
      }
      return row;
    });
}

function writeProjectMcpDocument(file, document) {
  const temporary = `${file}.${process.pid}.${Date.now()}.tmp`;
  fs.writeFileSync(temporary, `${JSON.stringify(document, null, 2)}\n`, "utf8");
  try {
    fs.renameSync(temporary, file);
  } catch (error) {
    try {
      fs.unlinkSync(temporary);
    } catch {
      // best-effort temporary-file cleanup
    }
    throw error;
  }
}

export function writeProjectMcpServer(name, server, cwd = process.cwd()) {
  const { file, document } = readProjectMcpDocument(cwd);
  if (!server || typeof server !== "object" || isProxy(server)) {
    throw invalidMcpSandboxPolicy(
      `Project MCP server "${name}" must be a non-Proxy object`,
    );
  }
  const existing = document.mcpServers[name];
  const requestedPolicy = readMcpSandboxPolicy(
    server,
    `Project MCP server "${name}" update`,
  );
  const retainedPolicy = requestedPolicy.present
    ? requestedPolicy
    : existing && typeof existing === "object" && !Array.isArray(existing)
      ? readMcpSandboxPolicy(existing, `Existing project MCP server "${name}"`)
      : { present: false, policy: null };
  const requestedCwd = readMcpStdioCwd(server, {
    label: `Project MCP server "${name}" update`,
  });
  const existingCwd =
    existing && typeof existing === "object" && !Array.isArray(existing)
      ? readMcpStdioCwd(existing, {
          label: `Existing project MCP server "${name}"`,
        })
      : { present: false, cwd: null };
  const retainedCwd = requestedCwd.present
    ? requestedCwd.cwd
    : existingCwd.present
      ? existingCwd.cwd
      : null;
  const config = {};
  if (server.command) config.command = server.command;
  if (server.args?.length) config.args = server.args;
  if (server.env && Object.keys(server.env).length > 0) config.env = server.env;
  if (server.runtimeKind) config.runtimeKind = server.runtimeKind;
  if (typeof retainedCwd === "string" && retainedCwd.length > 0) {
    config.cwd = retainedCwd;
  }
  if (retainedPolicy.policy) config.sandboxPolicy = retainedPolicy.policy;
  if (server.url) config.url = server.url;
  if (server.transport) config.transport = server.transport;
  if (server.headers && Object.keys(server.headers).length > 0) {
    config.headers = server.headers;
  }
  Object.assign(config, headersHelperField(server.headersHelper));
  document.mcpServers[name] = config;
  writeProjectMcpDocument(file, document);
  return file;
}

export function removeProjectMcpServer(name, cwd = process.cwd()) {
  const { file, document } = readProjectMcpDocument(cwd);
  if (!Object.hasOwn(document.mcpServers, name)) return false;
  delete document.mcpServers[name];
  writeProjectMcpDocument(file, document);
  return true;
}

function firstMcpRowByName(rows) {
  const names = new Set();
  return rows.filter((row) => {
    if (names.has(row.name)) return false;
    names.add(row.name);
    return true;
  });
}

async function effectiveMcpRows(config, options = {}) {
  const scope = options.scope;
  const cwd = options.cwd || process.cwd();
  const project =
    options.includeProjectFile === false || (scope && scope !== "project")
      ? []
      : readProjectMcpRows(cwd);
  const stored =
    scope === "managed"
      ? []
      : scope
        ? config.list({ scope, cwd, allScopes: options.allScopes === true })
        : options.allScopes === true
          ? config.list({ allScopes: true })
          : [
              ...config.list({ scope: "local", cwd }),
              ...config.list({ scope: "project", cwd }),
              ...config.list({ scope: "user", cwd }),
            ];
  if (scope && scope !== "managed") {
    const rows = scope === "project" ? [...project, ...stored] : stored;
    return firstMcpRowByName(rows);
  }
  const managed = await readManagedMcpRows();
  if (options.allScopes === true) return [...managed, ...project, ...stored];
  const ordered = [
    ...managed,
    ...stored.filter((row) => row.configScope === "local"),
    ...project,
    ...stored.filter((row) => row.configScope === "project"),
    ...stored.filter((row) => row.configScope === "user"),
  ];
  return firstMcpRowByName(ordered);
}

export function registerMcpCommand(program) {
  const mcp = program
    .command("mcp")
    .description("MCP server management and tool execution");

  // mcp login — OAuth 2.0 (Auth Code + PKCE) for a remote MCP server.
  mcp
    .command("login <target>")
    .description(
      "Authorize a remote MCP server via OAuth (opens a browser, or prints the URL in headless/SSH environments); stores the token. <target> is a URL or a configured server name.",
    )
    .option("--scope <scope>", "OAuth scope(s) to request")
    .option(
      "--client-id <id>",
      "Use a pre-registered client_id instead of dynamic registration",
    )
    .option(
      "--redirect-uri <url>",
      "Exact pre-registered http://127.0.0.1:<port>/<path> callback URI",
    )
    .option(
      "--port <n>",
      "Localhost callback port",
      (v) => parseInt(v, 10),
      53682,
    )
    .option("--no-open", "Print the authorize URL instead of opening a browser")
    .option(
      "--no-browser",
      "Alias for --no-open (do not open a browser; print the URL — handy over SSH)",
    )
    .action(async (target, options) => {
      try {
        const url = await resolveAuthTargetUrl(program, target);
        const oauth = await import("../lib/mcp-oauth.js");
        const explicitNoBrowser = loginWantsNoBrowser(options);
        if (explicitNoBrowser || isHeadlessEnv()) {
          oauth._deps.openBrowser = () => false; // --no-open / --no-browser / headless
          if (!explicitNoBrowser) {
            logger.log(
              chalk.gray(
                "Headless environment — printing the authorize URL instead of opening a browser.",
              ),
            );
          }
        }
        logger.log(chalk.gray(`Authorizing ${url} …`));
        const rec = await oauth.authorizeInteractive(url, {
          scope: options.scope,
          clientId: options.clientId,
          redirectUri: options.redirectUri,
          port: options.port,
          writeOut: (s) => process.stdout.write(s),
        });
        logger.log(
          chalk.green(`✓ authorized ${rec.server}`) +
            chalk.gray(
              rec.expires_at
                ? `  (expires ${new Date(rec.expires_at).toISOString()})`
                : "",
            ),
        );
        logger.log(
          chalk.gray("The token is injected as a Bearer header on connect."),
        );
      } catch (err) {
        logger.error(chalk.red(`mcp login failed: ${err.message}`));
        process.exitCode = 1;
      }
    });

  // mcp logout — forget a stored OAuth token.
  mcp
    .command("logout <target>")
    .description(
      "Delete the stored OAuth token for a remote MCP server (<target> is a URL or a configured server name)",
    )
    .action(async (target) => {
      try {
        const url = await resolveAuthTargetUrl(program, target);
        const { deleteStoredToken, serverKey } =
          await import("../lib/mcp-oauth.js");
        const ok = deleteStoredToken(url);
        logger.log(
          ok
            ? chalk.green(`✓ removed token for ${serverKey(url)}`)
            : chalk.gray(`no stored token for ${serverKey(url)}`),
        );
      } catch (err) {
        logger.error(chalk.red(`mcp logout failed: ${err.message}`));
        process.exitCode = 1;
      }
    });

  // mcp auth — list stored OAuth tokens.
  mcp
    .command("auth")
    .description("List stored MCP OAuth tokens")
    .option("--json", "Output as JSON")
    .action(async (options) => {
      try {
        const { loadTokenStore, isTokenExpired } =
          await import("../lib/mcp-oauth.js");
        const store = loadTokenStore();
        const rows = Object.values(store).map((r) => ({
          server: r.server,
          expired: isTokenExpired(r),
          expires_at: r.expires_at || null,
          refresh: Boolean(r.refresh_token),
        }));
        if (options.json) {
          console.log(JSON.stringify(rows, null, 2));
          return;
        }
        if (rows.length === 0) {
          logger.log(
            chalk.gray("No MCP OAuth tokens. Run: cc mcp login <name|url>"),
          );
          return;
        }
        for (const r of rows) {
          const state = r.expired ? chalk.red("expired") : chalk.green("valid");
          logger.log(
            `  ${chalk.cyan(r.server)}  [${state}]${r.refresh ? chalk.gray(" +refresh") : ""}`,
          );
        }
      } catch (err) {
        logger.error(chalk.red(`mcp auth failed: ${err.message}`));
        process.exitCode = 1;
      }
    });

  // mcp serve — expose THIS machine's files as an MCP server
  mcp
    .command("serve")
    .description(
      "Expose local file tools (read/list/search/write, root-confined) as a Streamable-HTTP MCP server for other clients",
    )
    .option("--port <n>", "Port to listen on (default: random free port)", "0")
    .option("--root <dir>", "Serve root directory (default: cwd)")
    .option("--read-only", "Disable the write_file tool")
    .option("--token <token>", "Fixed Bearer token (default: random)")
    .option("--no-auth", "Disable Bearer auth (server binds 127.0.0.1 only)")
    .action(async (options) => {
      try {
        const { startMcpServe } = await import("../lib/mcp-serve.js");
        const handle = await startMcpServe({
          root: options.root,
          port: Number(options.port) || 0,
          readOnly: Boolean(options.readOnly),
          token: options.auth === false ? false : options.token || null,
        });
        logger.log(chalk.bold("MCP server ready (Streamable-HTTP)"));
        logger.log(`  URL:   ${chalk.cyan(handle.url)}`);
        logger.log(
          `  Root:  ${handle.root}${handle.readOnly ? "  (read-only)" : ""}`,
        );
        if (handle.token) {
          logger.log(`  Auth:  Bearer ${handle.token}`);
        } else {
          logger.log(chalk.yellow("  Auth:  disabled (--no-auth)"));
        }
        logger.log(chalk.gray("\nConnect from another cc via --mcp-config:"));
        logger.log(
          chalk.gray(
            JSON.stringify(
              {
                mcpServers: {
                  ccfiles: {
                    transport: "http",
                    url: handle.url,
                    ...(handle.token
                      ? { headers: { Authorization: `Bearer ${handle.token}` } }
                      : {}),
                  },
                },
              },
              null,
              2,
            ),
          ),
        );
        logger.log(chalk.gray("\nCtrl+C to stop."));
        // keep the process alive until killed
        await new Promise(() => {});
      } catch (err) {
        logger.error(chalk.red(`mcp serve failed: ${err.message}`));
        process.exitCode = 1;
      }
    });

  // mcp computer-use — expose GUI control verbs as an MCP server (opt-in)
  mcp
    .command("computer-use")
    .description(
      "Expose GUI control (screenshot/window-list/click/type/scroll/clipboard/app-launch) as a Streamable-HTTP MCP server. OFF by default; input verbs need confirm:true; high-risk apps (terminals/IDEs/settings/password managers) always confirm",
    )
    .option("--port <n>", "Port to listen on (default: random free port)", "0")
    .option(
      "--capabilities <list>",
      "Comma-separated subset (default: all): screenshot,window_list,app_launch,click,type,scroll,clipboard_read,clipboard_write",
    )
    .option(
      "--allow-apps <list>",
      "Comma-separated app allowlist for input/launch verbs (default: any app)",
    )
    .option(
      "--confirm-all",
      "Require confirm:true for every verb, not just input verbs",
    )
    .option("--token <token>", "Fixed Bearer token (default: random)")
    .option("--no-auth", "Disable Bearer auth (server binds 127.0.0.1 only)")
    .action(async (options) => {
      try {
        const { startComputerUseServer } =
          await import("../lib/computer-use/computer-use-server.js");
        const handle = await startComputerUseServer({
          port: Number(options.port) || 0,
          token: options.auth === false ? false : options.token || null,
          config: {
            capabilities: options.capabilities
              ? options.capabilities.split(",").map((s) => s.trim())
              : undefined,
            appAllowlist: options.allowApps
              ? options.allowApps.split(",").map((s) => s.trim())
              : undefined,
            confirmAll: options.confirmAll === true,
          },
        });
        logger.log(
          chalk.bold("Computer-use MCP server ready (Streamable-HTTP)"),
        );
        logger.log(`  URL:          ${chalk.cyan(handle.url)}`);
        logger.log(`  Capabilities: ${handle.capabilities.join(", ")}`);
        if (handle.token) {
          logger.log(`  Auth:         Bearer ${handle.token}`);
        } else {
          logger.log(chalk.yellow("  Auth:         disabled (--no-auth)"));
        }
        logger.log(
          chalk.yellow(
            "  ⚠ GUI control can act on anything on screen. Input verbs need confirm:true; high-risk apps always confirm.",
          ),
        );
        logger.log(chalk.gray("\nCtrl+C to stop."));
        await new Promise(() => {});
      } catch (err) {
        logger.error(chalk.red(`mcp computer-use failed: ${err.message}`));
        process.exitCode = 1;
      }
    });

  // mcp servers — list configured servers
  mcp
    .command("servers")
    .alias("list")
    .description("List configured MCP servers")
    .option("--json", "Output as JSON")
    .option("--mode <mode>", "Runtime mode (local | lan | hosted)")
    .option(
      "--scope <scope>",
      `Configuration scope: ${MCP_CONFIG_SCOPES.join(" | ")}`,
    )
    .option("--all-scopes", "Include project-local entries outside cwd")
    .action(async (options) => {
      try {
        const ctx = await bootstrap({ verbose: program.opts().verbose });
        if (!ctx.db) {
          logger.error("Database not available");
          process.exit(1);
        }

        const db = ctx.db.getDatabase();
        const config = new MCPServerConfig(db);
        const scope = options.scope
          ? normalizeMcpConfigScope(options.scope)
          : undefined;
        const servers = await effectiveMcpRows(config, {
          scope,
          allScopes: options.allScopes === true,
        });
        const mode = resolveMode(options);
        const annotated = servers.map((s) => {
          const { allowed, reason, transport } = validateMcpServer(
            toPolicyServer(s),
            mode,
          );
          const modes = annotateMcpCompatibility(
            toPolicyServer(s),
          )._modeCompatibility;
          return {
            ...s,
            _mode: mode,
            _allowed: allowed,
            _reason: reason,
            _transport: transport,
            _modeCompatibility: modes,
          };
        });

        if (options.json) {
          console.log(JSON.stringify(redactConfigObject(annotated), null, 2));
        } else if (servers.length === 0) {
          logger.info("No MCP servers configured. Use 'mcp add' to add one.");
        } else {
          logger.log(
            chalk.bold(`MCP Servers (${servers.length}) — mode: ${mode}\n`),
          );
          for (const s of annotated) {
            const auto = s.autoConnect ? chalk.green(" [auto]") : "";
            const flag = s._allowed
              ? chalk.green(" [ok]")
              : chalk.yellow(` [blocked: ${s._reason}]`);
            logger.log(`  ${chalk.cyan(s.name)}${auto}${flag}`);
            logger.log(
              `    ${chalk.gray("Scope:")} ${s.configScope || "user"} ${chalk.gray(`(${s.configSource || "legacy-database"})`)}`,
            );
            if (s.url) {
              logger.log(
                `    ${chalk.gray("URL:")} ${s.url} ${chalk.gray(`[${s.transport || s._transport || "http"}]`)}`,
              );
            } else {
              logger.log(
                `    ${chalk.gray("Command:")} ${s.command} ${s.args.join(" ")}`,
              );
            }
            if (s.headersHelper) {
              logger.log(`    ${chalk.gray("Headers helper:")} configured`);
            }
            logger.log(
              `    ${chalk.gray("Compatible:")} ${s._modeCompatibility.join(", ") || "(none)"}`,
            );
          }
        }

        await shutdown();
      } catch (err) {
        logger.error(`Failed: ${err.message}`);
        process.exit(1);
      }
    });

  mcp
    .command("materialize-package <name>")
    .description(
      "Replace one exact JavaScript package launcher with a content-addressed, guarded dependency capsule",
    )
    .requiredOption(
      "--package <name@version>",
      "Exact npm registry package version to install (ranges and tags are rejected)",
    )
    .option(
      "--bin <name>",
      "Select one exported bin when the package has several",
    )
    .option(
      "--scope <scope>",
      `Configuration scope: ${MCP_CONFIG_SCOPES.join(" | ")}`,
    )
    .option(
      "--json",
      "Output the materialized generation and closure identity as JSON",
    )
    .action(async (name, options) => {
      try {
        const exact = parseExactNpmPackageSpec(options.package);
        const ctx = await bootstrap({ verbose: program.opts().verbose });
        if (!ctx.db) throw new Error("Database not available");
        const configStore = new MCPServerConfig(ctx.db.getDatabase());
        const scope = options.scope
          ? normalizeMcpConfigScope(options.scope)
          : undefined;
        const rows = await effectiveMcpRows(configStore, { scope });
        const row = rows.find((entry) => entry.name === name);
        if (!row) {
          throw new Error(
            `${notFoundWithSuggestion(
              name,
              rows.map((entry) => entry.name),
              { noun: "Server" },
            )}. Use 'mcp add' first.`,
          );
        }
        if (inferTransport(row) !== "stdio") {
          throw new Error(
            `MCP server "${name}" does not use the stdio transport`,
          );
        }

        const authorized = authorizeMcpRowForConnect(row);
        const approval = consumeMcpStdioExecutionAuthority(
          authorized.mcpStdioExecutionAuthority,
          { serverName: name, config: authorized },
        );
        const invocation = materializeApprovedMcpStdioInvocation(approval);
        const approvedCwd = resolveMcpCommandStdioWorkingDirectory(
          name,
          invocation,
          approval,
        );
        const approvalRecord = resolveMcpStdioExecutionApproval(approval);
        const materialized = await materializeMcpStdioNpmPackage({
          approvalRecord,
          config: invocation,
          packageSpec: exact.spec,
          ...(options.bin ? { binName: options.bin } : {}),
          env: process.env,
          processBrokerRunSync: (command, args, spawnOptions) =>
            executionBroker.spawnSync(command, args, {
              ...spawnOptions,
              origin: `mcp:package-materialization:${name}`,
              policy: "allow",
              scope: "mcp",
              shell: false,
            }),
        });
        const prepared = prepareMcpStdioExecutableIdentity({
          serverName: name,
          config: invocation,
          approval,
          cwd: approvedCwd,
          env: process.env,
          retrust: true,
        });
        const result = {
          name,
          package: exact.spec,
          generation: materialized.generation,
          manifestDigest: materialized.manifestDigest,
          identityDigest: prepared.identityDigest,
          closure: materialized.identity,
          command: prepared.identity.command,
          entrypoints: prepared.identity.entrypoints,
        };
        if (options.json) {
          console.log(JSON.stringify(result, null, 2));
        } else {
          logger.log(
            chalk.green(
              `Materialized and trusted ${exact.spec} for MCP server "${name}".`,
            ),
          );
          logger.log(
            `  ${chalk.gray("Generation:")} ${materialized.generation}`,
          );
          logger.log(
            `  ${chalk.gray("Dependency closure:")} sha256:${materialized.identity.closureDigest} (${materialized.identity.fileCount} files, ${materialized.identity.totalBytes} bytes)`,
          );
          logger.log(
            `  ${chalk.gray("Execution capsule:")} sha256:${materialized.identity.capsule.sha256} (${materialized.identity.capsule.bytes} bytes, ${materialized.identity.capsule.inputCount} bundled inputs)`,
          );
        }
        await shutdown();
      } catch (err) {
        logger.error(`Failed: ${err.message}`);
        process.exitCode = 1;
        await shutdown();
      }
    });

  mcp
    .command("trust-executable <name>")
    .description(
      "Review and trust the current executable and interpreter-entrypoint bytes for one stdio MCP server",
    )
    .option(
      "--scope <scope>",
      `Configuration scope: ${MCP_CONFIG_SCOPES.join(" | ")}`,
    )
    .option("--json", "Output the trusted paths and SHA-256 identities as JSON")
    .action(async (name, options) => {
      try {
        const ctx = await bootstrap({ verbose: program.opts().verbose });
        if (!ctx.db) throw new Error("Database not available");
        const configStore = new MCPServerConfig(ctx.db.getDatabase());
        const scope = options.scope
          ? normalizeMcpConfigScope(options.scope)
          : undefined;
        const rows = await effectiveMcpRows(configStore, { scope });
        const row = rows.find((entry) => entry.name === name);
        if (!row) {
          throw new Error(
            `${notFoundWithSuggestion(
              name,
              rows.map((entry) => entry.name),
              { noun: "Server" },
            )}. Use 'mcp add' first.`,
          );
        }
        if (inferTransport(row) !== "stdio") {
          throw new Error(
            `MCP server "${name}" does not use the stdio transport`,
          );
        }

        const authorized = authorizeMcpRowForConnect(row);
        const approval = consumeMcpStdioExecutionAuthority(
          authorized.mcpStdioExecutionAuthority,
          { serverName: name, config: authorized },
        );
        const invocation = materializeApprovedMcpStdioInvocation(approval);
        const approvedCwd = resolveMcpCommandStdioWorkingDirectory(
          name,
          invocation,
          approval,
        );
        const prepared = prepareMcpStdioExecutableIdentity({
          serverName: name,
          config: invocation,
          approval,
          cwd: approvedCwd,
          env: process.env,
          retrust: true,
        });
        const result = {
          name,
          status: prepared.trustStatus,
          identityDigest: prepared.identityDigest,
          command: prepared.identity.command,
          entrypoints: prepared.identity.entrypoints,
        };
        if (options.json) {
          console.log(JSON.stringify(result, null, 2));
        } else {
          logger.log(
            chalk.green(`Trusted MCP stdio executable identity for "${name}".`),
          );
          logger.log(
            `  ${chalk.gray("Command:")} ${result.command.realPath}  sha256:${result.command.sha256}`,
          );
          for (const entrypoint of result.entrypoints) {
            logger.log(
              `  ${chalk.gray(`${entrypoint.role}:`)} ${entrypoint.realPath}  sha256:${entrypoint.sha256}`,
            );
          }
        }
        await shutdown();
      } catch (err) {
        logger.error(`Failed: ${err.message}`);
        process.exitCode = 1;
        await shutdown();
      }
    });

  // mcp add — add/update a server config
  mcp
    .command("add")
    .description("Add or update an MCP server configuration")
    .argument("<name>", "Server name")
    .option("-c, --command <cmd>", "Server command to run (stdio transport)")
    .option("-a, --args <args>", "Command arguments (comma-separated)")
    .option(
      "--runtime-kind <kind>",
      "stdio runtime semantics: native | node | python | posix-shell | powershell | java | dotnet",
    )
    .option(
      "--sandbox-boundary <boundary>",
      `Require a stdio sandbox boundary (${MCP_SANDBOX_BOUNDARIES.join(" | ")}); repeatable`,
      collectMcpSandboxBoundary,
    )
    .option(
      "--clear-sandbox-boundaries",
      "Explicitly remove previously configured stdio sandbox boundaries",
    )
    .option(
      "-u, --url <url>",
      "Server URL (http / https / ws / wss transports)",
    )
    .option(
      "-t, --transport <kind>",
      "Transport kind: stdio | http | https | sse | ws | wss",
    )
    .option(
      "--scope <scope>",
      `Configuration scope: ${MCP_CONFIG_SCOPES.join(" | ")}`,
      "local",
    )
    .option(
      "-H, --header <header...>",
      "HTTP header to include on requests (KEY=VALUE, repeatable)",
    )
    .option(
      "--headers-helper <command>",
      "Shell command that prints fresh HTTP headers as one JSON object",
    )
    .option("--auto-connect", "Auto-connect on startup")
    .option(
      "--mode <mode>",
      "Runtime mode to validate against (local | lan | hosted)",
    )
    .option("--json", "Output as JSON")
    .action(async (name, options) => {
      try {
        if (!options.command && !options.url) {
          logger.error(
            "Provide either -c <command> (stdio) or -u <url> (http/ws).",
          );
          process.exit(1);
        }
        if (options.command && options.url) {
          logger.error("Use either -c <command> or -u <url>, not both.");
          process.exit(1);
        }
        if (options.runtimeKind && !options.command) {
          throw new Error("--runtime-kind is only supported with --command");
        }
        if (
          options.runtimeKind &&
          !MCP_STDIO_RUNTIME_KINDS.includes(options.runtimeKind)
        ) {
          throw new Error(
            `Invalid --runtime-kind; expected one of: ${MCP_STDIO_RUNTIME_KINDS.join(", ")}`,
          );
        }
        const sandboxPolicyUpdate =
          mcpSandboxPolicyUpdateFromAddOptions(options);
        if (sandboxPolicyUpdate !== undefined && !options.command) {
          throw new Error(
            "--sandbox-boundary and --clear-sandbox-boundaries are only supported with --command",
          );
        }

        const ctx = await bootstrap({ verbose: program.opts().verbose });
        if (!ctx.db) {
          logger.error("Database not available");
          process.exit(1);
        }

        const db = ctx.db.getDatabase();
        const config = new MCPServerConfig(db);
        const args = options.args
          ? options.args.split(",").map((a) => a.trim())
          : [];

        // Parse -H KEY=VALUE into { headers }
        const headers = {};
        if (Array.isArray(options.header)) {
          for (const raw of options.header) {
            const eq = raw.indexOf("=");
            if (eq <= 0) {
              logger.warn(
                `Ignored malformed --header "${raw}" (expected KEY=VALUE)`,
              );
              continue;
            }
            headers[raw.slice(0, eq).trim()] = raw.slice(eq + 1);
          }
        }

        const configScope = normalizeMcpConfigScope(options.scope);
        if (configScope === "managed") {
          throw new Error(
            "Managed MCP configuration is read-only; provision it through managed settings",
          );
        }
        if (
          configScope === "project" &&
          Object.keys(headers).some((key) =>
            /authorization|proxy-authorization|cookie|api[-_]?key|token|secret/i.test(
              key,
            ),
          )
        ) {
          throw new Error(
            "Project-scoped .mcp.json must not contain credential headers; use OAuth login or local/user scope",
          );
        }

        const transport =
          options.transport ||
          (options.url ? inferTransport({ url: options.url }) : "stdio");

        if (options.headersHelper && !options.url) {
          throw new Error(
            "--headers-helper is only supported by HTTP, SSE, and WebSocket transports",
          );
        }

        const transportDiagnostic = diagnoseMcpTransportConfig({
          command: options.command,
          url: options.url,
          transport,
        });
        if (!transportDiagnostic.ok) {
          throw new Error(
            `${transportDiagnostic.code}: ${transportDiagnostic.message}`,
          );
        }

        const mode = resolveMode(options);
        const check = validateMcpServer(
          {
            name,
            command: options.command,
            args,
            url: options.url,
            transport,
          },
          mode,
        );
        if (!check.allowed) {
          logger.warn(
            `Server "${name}" is not compatible with mode "${mode}": ${check.reason}`,
          );
        }

        const workspaceRoot = projectMcpLocation(process.cwd()).root;
        const previousStored =
          configScope === "project"
            ? null
            : config.get(name, {
                scope: configScope,
                cwd: workspaceRoot,
              });
        const previousLocal = configScope === "local" ? previousStored : null;
        const effectiveSandboxPolicy =
          sandboxPolicyUpdate === undefined
            ? previousStored?.sandboxPolicy || null
            : sandboxPolicyUpdate;
        let configuredSandboxPolicy = effectiveSandboxPolicy;
        const storedConfig = {
          command: options.command || null,
          args,
          runtimeKind: options.command ? options.runtimeKind || null : null,
          ...(sandboxPolicyUpdate !== undefined
            ? { sandboxPolicy: sandboxPolicyUpdate }
            : effectiveSandboxPolicy
              ? { sandboxPolicy: effectiveSandboxPolicy }
              : {}),
          url: options.url || null,
          transport,
          env: {},
          autoConnect: !!options.autoConnect,
          headers: Object.keys(headers).length > 0 ? headers : undefined,
          ...headersHelperField(options.headersHelper),
          configScope,
          projectPath: configScope === "local" ? workspaceRoot : null,
        };
        let configSource;
        if (configScope === "project") {
          configSource = writeProjectMcpServer(
            name,
            storedConfig,
            process.cwd(),
          );
          configuredSandboxPolicy =
            readProjectMcpRows(process.cwd()).find((row) => row.name === name)
              ?.sandboxPolicy || null;
        } else {
          if (configScope === "local" && previousLocal?.headersHelper) {
            revokeLocalMcpHeadersHelperTrust({
              workspaceRoot,
              serverName: name,
              url: previousLocal.url,
              transport: previousLocal.transport,
              headersHelper: previousLocal.headersHelper,
            });
          }
          config.add(name, storedConfig);
          if (configScope === "local" && storedConfig.headersHelper) {
            recordLocalMcpHeadersHelperTrust({
              workspaceRoot,
              serverName: name,
              url: storedConfig.url,
              transport: storedConfig.transport,
              headersHelper: storedConfig.headersHelper,
            });
          }
          configSource =
            configScope === "user"
              ? "user-database"
              : `${configScope}:${workspaceRoot}`;
        }

        const payload = {
          name,
          command: options.command || null,
          args,
          runtimeKind: storedConfig.runtimeKind,
          ...(configuredSandboxPolicy
            ? { sandboxPolicy: configuredSandboxPolicy }
            : sandboxPolicyUpdate === null
              ? { sandboxPolicy: null }
              : {}),
          url: options.url || null,
          transport,
          autoConnect: !!options.autoConnect,
          headersHelper: storedConfig.headersHelper
            ? "<configured>"
            : undefined,
          configScope,
          configSource,
        };

        if (options.json) {
          console.log(JSON.stringify(payload));
        } else {
          logger.success(`MCP server "${chalk.cyan(name)}" configured`);
          if (options.url) {
            logger.log(
              `  ${chalk.gray("URL:")} ${options.url} ${chalk.gray(`[${transport}]`)}`,
            );
          } else {
            logger.log(
              `  ${chalk.gray("Command:")} ${options.command} ${args.join(" ")}`,
            );
            if (storedConfig.runtimeKind) {
              logger.log(
                `  ${chalk.gray("Runtime kind:")} ${storedConfig.runtimeKind}`,
              );
            }
            if (configuredSandboxPolicy) {
              logger.log(
                `  ${chalk.gray("Sandbox boundaries:")} ${configuredSandboxPolicy.requiredBoundaries.join(", ")}`,
              );
            }
          }
          if (configScope === "project") {
            logger.log(
              `  ${chalk.gray("Shared config:")} ${configSource} (run with --project-mcp after trust review)`,
            );
          }
          if (storedConfig.headersHelper) {
            logger.log(`  ${chalk.gray("Headers helper:")} configured`);
          }
        }

        await shutdown();
      } catch (err) {
        logger.error(`Failed: ${err.message}`);
        process.exit(1);
      }
    });

  // mcp remove — remove a server config
  mcp
    .command("remove")
    .description("Remove an MCP server configuration")
    .argument("<name>", "Server name")
    .option(
      "--scope <scope>",
      `Configuration scope: ${MCP_CONFIG_SCOPES.join(" | ")}`,
    )
    .action(async (name, options) => {
      try {
        const ctx = await bootstrap({ verbose: program.opts().verbose });
        if (!ctx.db) {
          logger.error("Database not available");
          process.exit(1);
        }

        const db = ctx.db.getDatabase();
        const config = new MCPServerConfig(db);
        const scope = options.scope
          ? normalizeMcpConfigScope(options.scope)
          : undefined;
        if (scope === "managed") {
          throw new Error(
            "Managed MCP configuration is read-only; change the managed settings source",
          );
        }
        const projectFlag = String(
          process.env.CC_PROJECT_MCP || "",
        ).toLowerCase();
        const visible = await effectiveMcpRows(config, {
          scope,
          includeProjectFile:
            Boolean(name) ||
            scope === "project" ||
            projectFlag === "1" ||
            projectFlag === "true",
        });
        const selected = visible.find((row) => row.name === name);
        if (selected?.configScope === "managed") {
          throw new Error(
            "Managed MCP configuration is read-only; change the managed settings source",
          );
        }
        const names = visible.map((s) => s.name);
        const projectFile = projectMcpLocation(process.cwd()).file;
        if (
          selected?.configScope === "local" &&
          selected.headersHelper &&
          selected.projectPath
        ) {
          revokeLocalMcpHeadersHelperTrust({
            workspaceRoot: selected.projectPath,
            serverName: name,
            url: selected.url,
            transport: selected.transport,
            headersHelper: selected.headersHelper,
          });
        }
        const removed =
          selected?.configScope === "project" &&
          path.resolve(selected.configSource || "") ===
            path.resolve(projectFile)
            ? removeProjectMcpServer(name, process.cwd())
            : config.remove(name, {
                scope: selected?.configScope || scope,
                cwd: process.cwd(),
              });

        if (removed) {
          logger.success(`MCP server "${name}" removed`);
        } else {
          logger.error(notFoundWithSuggestion(name, names, { noun: "Server" }));
        }

        await shutdown();
      } catch (err) {
        logger.error(`Failed: ${err.message}`);
        process.exit(1);
      }
    });

  // mcp connect — connect to a server
  mcp
    .command("get")
    .description("Show one MCP server configuration and its source")
    .argument("<name>", "Server name")
    .option(
      "--scope <scope>",
      `Configuration scope: ${MCP_CONFIG_SCOPES.join(" | ")}`,
    )
    .option("--json", "Output as JSON")
    .action(async (name, options) => {
      try {
        const ctx = await bootstrap({ verbose: program.opts().verbose });
        if (!ctx.db) throw new Error("Database not available");
        const config = new MCPServerConfig(ctx.db.getDatabase());
        const scope = options.scope
          ? normalizeMcpConfigScope(options.scope)
          : undefined;
        const visible = await effectiveMcpRows(config, { scope });
        const server = visible.find((row) => row.name === name) || null;
        if (!server) {
          throw new Error(
            notFoundWithSuggestion(
              name,
              visible.map((row) => row.name),
              { noun: "Server" },
            ),
          );
        }
        if (options.json) {
          console.log(JSON.stringify(redactConfigObject(server), null, 2));
        } else {
          logger.log(chalk.bold(server.name));
          logger.log(`  Scope:     ${server.configScope}`);
          logger.log(`  Source:    ${server.configSource}`);
          logger.log(`  Transport: ${server.transport}`);
          logger.log(
            server.url
              ? `  URL:       ${server.url}`
              : `  Command:   ${server.command} ${(server.args || []).join(" ")}`,
          );
          if (server.headersHelper) {
            logger.log("  Headers helper: configured");
          }
        }
        await shutdown();
      } catch (err) {
        logger.error(`Failed: ${err.message}`);
        process.exitCode = 1;
      }
    });

  mcp
    .command("doctor")
    .description("Validate MCP configuration and test transport handshakes")
    .argument("[name]", "Optional server name")
    .option(
      "--scope <scope>",
      `Configuration scope: ${MCP_CONFIG_SCOPES.join(" | ")}`,
    )
    .option("--timeout <ms>", "Connect/request timeout", "10000")
    .option("--json", "Output structured diagnostics as JSON")
    .action(async (name, options) => {
      const diagnostics = [];
      let client = null;
      try {
        const ctx = await bootstrap({ verbose: program.opts().verbose });
        if (!ctx.db) throw new Error("Database not available");
        const config = new MCPServerConfig(ctx.db.getDatabase());
        const scope = options.scope
          ? normalizeMcpConfigScope(options.scope)
          : undefined;
        const projectFlag = String(
          process.env.CC_PROJECT_MCP || "",
        ).toLowerCase();
        const visible = await effectiveMcpRows(config, {
          scope,
          includeProjectFile:
            Boolean(name) ||
            scope === "project" ||
            projectFlag === "1" ||
            projectFlag === "true",
        });
        const rows = name
          ? visible.filter((row) => row.name === name)
          : visible;
        if (name && rows.length === 0) {
          throw new Error(
            notFoundWithSuggestion(
              name,
              visible.map((row) => row.name),
              { noun: "Server" },
            ),
          );
        }
        const timeoutMs = Math.max(
          1,
          Number.parseInt(options.timeout, 10) || 10000,
        );
        for (const row of rows) {
          const staticCheck = diagnoseMcpTransportConfig(row);
          const record = {
            name: row.name,
            scope: row.configScope,
            source: row.configSource,
            transport: staticCheck.transport,
            ok: false,
            code: staticCheck.code,
            message: staticCheck.message || null,
          };
          if (!staticCheck.ok) {
            diagnostics.push(record);
            continue;
          }
          const policy = validateMcpServer(toPolicyServer(row), "local");
          if (!policy.allowed) {
            diagnostics.push({
              ...record,
              code: "policy_denied",
              message: policy.reason,
            });
            continue;
          }
          client = new MCPClient({
            workspaceBinding: commandWorkspaceBinding(),
          });
          try {
            const connected = await client.connect(
              row.name,
              authorizeMcpRowForConnect(row, {
                connectTimeoutMs: timeoutMs,
                requestTimeoutMs: timeoutMs,
              }),
            );
            diagnostics.push({
              ...record,
              ok: true,
              code: "ok",
              message: null,
              tools: connected.tools?.length || 0,
              resources: connected.resources?.length || 0,
              prompts: connected.prompts?.length || 0,
            });
          } catch (error) {
            diagnostics.push({
              ...record,
              code: error?.code || "connect_failed",
              message: error?.message || String(error),
              status: error?.status ?? null,
              closeCode: error?.closeCode ?? null,
            });
          } finally {
            await client.disconnectAll();
            client = null;
          }
        }
        if (options.json) {
          console.log(JSON.stringify(diagnostics, null, 2));
        } else if (diagnostics.length === 0) {
          logger.info("No MCP servers configured in the selected scope.");
        } else {
          for (const row of diagnostics) {
            const state = row.ok ? chalk.green("ok") : chalk.red(row.code);
            logger.log(
              `  ${chalk.cyan(row.name)} [${row.scope}/${row.transport}] ${state}`,
            );
            if (row.message) logger.log(`    ${chalk.gray(row.message)}`);
          }
        }
        if (diagnostics.some((row) => !row.ok)) process.exitCode = 1;
        await shutdown();
      } catch (err) {
        await client?.disconnectAll?.();
        logger.error(`MCP doctor failed: ${err.message}`);
        process.exitCode = 1;
      }
    });

  mcp
    .command("connect")
    .description("Connect to an MCP server and verify its capabilities")
    .argument("<name>", "Server name (configured or command)")
    .option("--mode <mode>", "Runtime mode (local | lan | hosted)")
    .option("--force", "Bypass mode compatibility check")
    .option(
      "--stay-open",
      "Keep the MCP connection open in this process until interrupted",
    )
    .option("--json", "Output as JSON")
    .action(async (name, options) => {
      let client = null;
      let spinner = null;
      let connectionEstablished = false;
      try {
        const ctx = await bootstrap({ verbose: program.opts().verbose });
        if (!ctx.db) {
          throw new Error("Database not available");
        }

        const db = ctx.db.getDatabase();
        const config = new MCPServerConfig(db);
        const visible = await effectiveMcpRows(config, {
          includeProjectFile: true,
        });
        const serverConfig = visible.find((row) => row.name === name) || null;

        if (!serverConfig) {
          const names = visible.map((s) => s.name);
          throw new Error(
            `${notFoundWithSuggestion(name, names, { noun: "Server" })}. Use 'mcp add' first.`,
          );
        }

        const mode = resolveMode(options);
        const check = validateMcpServer(
          toPolicyServer({ name, ...serverConfig }),
          mode,
        );
        if (!check.allowed && !options.force) {
          throw new Error(
            `Server "${name}" blocked in mode "${mode}": ${check.reason}. Use --force to override.`,
          );
        }

        spinner = ora(`Connecting to ${name}...`).start();
        client = getClient();

        const result = await client.connect(
          name,
          authorizeMcpRowForConnect(serverConfig),
        );
        connectionEstablished = true;
        spinner.stop();

        if (options.json) {
          console.log(JSON.stringify(result, null, 2));
        } else {
          // initialize succeeded but tools/list failed → connected, yet the
          // tool list is unreliable. Surface it rather than a misleading
          // "Tools: 0" (Claude-Code 2.1.181 parity).
          if (result.toolsError) {
            logger.warn(
              `${chalk.yellow("!")} Connected to ${chalk.cyan(name)} ${chalk.gray("·")} tools fetch failed: ${result.toolsError}`,
            );
          } else {
            logger.success(`Connected to ${chalk.cyan(name)}`);
            logger.log(`  ${chalk.gray("Tools:")} ${result.tools.length}`);
          }
          logger.log(
            `  ${chalk.gray("Resources:")} ${result.resources.length}`,
          );
          if (result.serverInfo?.name) {
            logger.log(`  ${chalk.gray("Server:")} ${result.serverInfo.name}`);
          }
        }

        if (options.stayOpen && !options.json) {
          logger.info("Connection kept open; press Ctrl+C to stop.");
        }
      } catch (err) {
        spinner?.stop();
        logger.error(`Connection failed: ${err.message}`);
        process.exitCode = 1;
      } finally {
        if (!options.stayOpen || !connectionEstablished) {
          await client?.disconnectAll();
          await shutdown();
        }
      }
    });

  // mcp disconnect — disconnect from a server
  mcp
    .command("disconnect")
    .description("Disconnect from an MCP server")
    .argument("<name>", "Server name")
    .action(async (name) => {
      try {
        const client = getClient();
        const ok = await client.disconnect(name);
        if (ok) {
          logger.success(`Disconnected from ${name}`);
        } else {
          logger.error(`Server "${name}" not connected`);
        }
      } catch (err) {
        logger.error(`Disconnect failed: ${err.message}`);
        process.exit(1);
      }
    });

  // mcp tools — list available tools
  mcp
    .command("tools")
    .description("List available MCP tools")
    .option("-s, --server <name>", "Filter by server name")
    .option("--json", "Output as JSON")
    .action(async (options) => {
      let client = null;
      try {
        ({ client } = await connectForQuery(program, options.server));
        const tools = client.listTools(options.server);

        if (options.json) {
          console.log(JSON.stringify(tools, null, 2));
        } else if (tools.length === 0) {
          logger.info("No tools available.");
        } else {
          logger.log(chalk.bold(`MCP Tools (${tools.length}):\n`));
          for (const t of tools) {
            logger.log(
              `  ${chalk.cyan(t.name)} ${chalk.gray(`[${t.server}]`)}`,
            );
            if (t.description) {
              logger.log(`    ${chalk.gray(t.description)}`);
            }
          }
        }
      } catch (err) {
        logger.error(`Failed: ${err.message}`);
        process.exitCode = 1;
      } finally {
        await client?.disconnectAll();
        await shutdown();
      }
    });

  // mcp call — call a tool
  mcp
    .command("call")
    .description("Call an MCP tool")
    .argument("<tool>", "Tool name")
    .option("-s, --server <name>", "Server name")
    .option("-a, --args <json>", "Tool arguments as JSON")
    .option("--json", "Output as JSON")
    .action(async (tool, options) => {
      let client = null;
      let spinner = null;
      try {
        ({ client } = await connectForQuery(program, options.server));

        // Find which server has this tool
        let serverName = options.server;
        if (!serverName) {
          const allTools = client.listTools();
          const match = allTools.find((t) => t.name === tool);
          if (!match) {
            logger.error(
              `Tool "${tool}" not found. Run 'mcp tools' to see available tools.`,
            );
            process.exitCode = 1;
            return;
          }
          serverName = match.server;
        }

        const args = parseJsonOption(options.args, "--args", {});
        spinner = ora(`Calling ${tool}...`).start();

        const result = await client.callTool(serverName, tool, args);
        spinner.stop();

        if (options.json) {
          console.log(JSON.stringify(result, null, 2));
        } else {
          // Display content blocks
          if (result?.content) {
            for (const block of result.content) {
              if (block.type === "text") {
                logger.log(block.text);
              } else if (block.type === "image") {
                logger.log(chalk.gray(`[Image: ${block.mimeType || "image"}]`));
              } else {
                logger.log(JSON.stringify(block, null, 2));
              }
            }
          } else {
            logger.log(JSON.stringify(result, null, 2));
          }
        }
      } catch (err) {
        spinner?.stop();
        logger.error(`Tool call failed: ${err.message}`);
        process.exitCode = 1;
      } finally {
        await client?.disconnectAll();
        await shutdown();
      }
    });

  // mcp resources — list resources exposed by configured servers
  mcp
    .command("resources")
    .description("List resources exposed by MCP servers")
    .option("-s, --server <name>", "Filter by / connect only this server")
    .option("--json", "Output as JSON")
    .action(async (options) => {
      try {
        const { client } = await connectForQuery(program, options.server);
        const resources = client.listResources(options.server);
        if (options.json) {
          console.log(JSON.stringify(resources, null, 2));
        } else if (resources.length === 0) {
          logger.info("No resources available.");
        } else {
          logger.log(chalk.bold(`MCP Resources (${resources.length}):\n`));
          for (const r of resources) {
            logger.log(`  ${chalk.cyan(r.uri)} ${chalk.gray(`[${r.server}]`)}`);
            if (r.name) logger.log(`    ${chalk.gray(r.name)}`);
            if (r.description) logger.log(`    ${chalk.gray(r.description)}`);
          }
        }
        await client.disconnectAll();
        await shutdown();
      } catch (err) {
        logger.error(`Failed: ${err.message}`);
        process.exit(1);
      }
    });

  // mcp read-resource — read a resource's contents by URI
  mcp
    .command("read-resource")
    .description("Read an MCP resource by URI")
    .argument("<uri>", "Resource URI")
    .option("-s, --server <name>", "Server that owns the resource")
    .option("--json", "Output as JSON")
    .action(async (uri, options) => {
      try {
        const { client } = await connectForQuery(program, options.server);
        let server = options.server;
        if (!server) {
          const match = client.listResources().find((r) => r.uri === uri);
          if (!match) {
            logger.error(
              `Resource "${uri}" not found. Run 'mcp resources' to list URIs.`,
            );
            await client.disconnectAll();
            await shutdown();
            process.exit(1);
          }
          server = match.server;
        }
        const result = await client.readResource(server, uri);
        if (options.json) {
          console.log(JSON.stringify(result, null, 2));
        } else if (Array.isArray(result?.contents)) {
          for (const c of result.contents) {
            if (typeof c.text === "string") {
              logger.log(c.text);
            } else if (c.blob) {
              logger.log(
                chalk.gray(
                  `[Binary: ${c.mimeType || "application/octet-stream"}]`,
                ),
              );
            } else {
              logger.log(JSON.stringify(c, null, 2));
            }
          }
        } else {
          logger.log(JSON.stringify(result, null, 2));
        }
        await client.disconnectAll();
        await shutdown();
      } catch (err) {
        logger.error(`Read failed: ${err.message}`);
        process.exit(1);
      }
    });

  // mcp prompts — list prompts (server-provided slash commands)
  mcp
    .command("prompts")
    .description("List prompts exposed by MCP servers")
    .option("-s, --server <name>", "Filter by / connect only this server")
    .option("--json", "Output as JSON")
    .action(async (options) => {
      try {
        const { client } = await connectForQuery(program, options.server);
        const prompts = client.listPrompts(options.server);
        if (options.json) {
          console.log(JSON.stringify(prompts, null, 2));
        } else if (prompts.length === 0) {
          logger.info("No prompts available.");
        } else {
          logger.log(chalk.bold(`MCP Prompts (${prompts.length}):\n`));
          for (const p of prompts) {
            logger.log(
              `  ${chalk.cyan(`/mcp__${p.server}__${p.name}`)} ${chalk.gray(`[${p.server}]`)}`,
            );
            if (p.description) logger.log(`    ${chalk.gray(p.description)}`);
            if (Array.isArray(p.arguments) && p.arguments.length > 0) {
              const argNames = p.arguments
                .map((a) => (a.required ? `${a.name}*` : a.name))
                .join(", ");
              logger.log(`    ${chalk.gray(`args: ${argNames}`)}`);
            }
          }
        }
        await client.disconnectAll();
        await shutdown();
      } catch (err) {
        logger.error(`Failed: ${err.message}`);
        process.exit(1);
      }
    });

  // mcp get-prompt — fetch a rendered prompt by name
  mcp
    .command("get-prompt")
    .description("Fetch a rendered MCP prompt by name")
    .argument("<name>", "Prompt name")
    .option("-s, --server <name>", "Server that owns the prompt")
    .option("-a, --args <json>", "Prompt arguments as JSON")
    .option("--json", "Output as JSON")
    .action(async (name, options) => {
      try {
        const { client } = await connectForQuery(program, options.server);
        let server = options.server;
        if (!server) {
          const match = client.listPrompts().find((p) => p.name === name);
          if (!match) {
            logger.error(
              `Prompt "${name}" not found. Run 'mcp prompts' to list prompts.`,
            );
            await client.disconnectAll();
            await shutdown();
            process.exit(1);
          }
          server = match.server;
        }
        const args = parseJsonOption(options.args, "--args", {});
        const result = await client.getPrompt(server, name, args);
        if (options.json) {
          console.log(JSON.stringify(result, null, 2));
        } else {
          if (result?.description) {
            logger.log(chalk.gray(result.description) + "\n");
          }
          for (const msg of result?.messages || []) {
            const blocks = Array.isArray(msg.content)
              ? msg.content
              : [msg.content];
            for (const b of blocks) {
              if (b && b.type === "text") {
                logger.log(`${chalk.gray(`[${msg.role}]`)} ${b.text}`);
              } else {
                logger.log(
                  `${chalk.gray(`[${msg.role}]`)} ${JSON.stringify(b)}`,
                );
              }
            }
          }
        }
        await client.disconnectAll();
        await shutdown();
      } catch (err) {
        logger.error(`Get prompt failed: ${err.message}`);
        process.exit(1);
      }
    });

  // mcp trust-helper — approve one exact workspace-local helper command
  mcp
    .command("trust-helper <name>")
    .description(
      "Trust the exact headers helper command for a workspace-local MCP server",
    )
    .option("--json", "Output as JSON")
    .action(async (name, options) => {
      try {
        const ctx = await bootstrap({ verbose: program.opts().verbose });
        if (!ctx.db) throw new Error("Database not available");
        const workspaceRoot = projectMcpLocation(process.cwd()).root;
        const config = new MCPServerConfig(ctx.db.getDatabase()).get(name, {
          scope: "local",
          cwd: workspaceRoot,
        });
        if (!config?.headersHelper) {
          throw new Error(
            `No workspace-local MCP headers helper is configured for "${name}"`,
          );
        }
        const spec = {
          workspaceRoot,
          serverName: name,
          url: config.url,
          transport: config.transport,
          headersHelper: config.headersHelper,
        };
        const trusted = recordLocalMcpHeadersHelperTrust(spec);
        const payload = {
          name,
          workspaceRoot,
          trusted,
          fingerprint: localMcpHeadersHelperFingerprint(spec).slice(0, 16),
        };
        if (options.json) console.log(JSON.stringify(payload, null, 2));
        else {
          logger.success(
            `Trusted headers helper for "${name}" (${payload.fingerprint})`,
          );
        }
        await shutdown();
      } catch (err) {
        logger.error(`Failed: ${err.message}`);
        process.exitCode = 1;
      }
    });

  // mcp scaffold — generate a boilerplate MCP server project
  mcp
    .command("trust-project")
    .description(
      "Re-trust the project .mcp.json after reviewing a content change (records its fingerprint for --project-mcp runs)",
    )
    .option("--json", "Output as JSON")
    .action(async (options) => {
      try {
        const fsMod = await import("node:fs");
        const { projectRootBase } = await import("../lib/project-root.cjs");
        const { recordProjectMcpTrust, projectMcpFingerprint } =
          await import("../lib/project-mcp-trust.js");
        const cwd = process.cwd();
        const candidates = [path.join(cwd, ".mcp.json")];
        const root = projectRootBase(cwd, { fs: fsMod.default, path });
        if (root) candidates.push(path.join(root, ".mcp.json"));
        const results = [];
        for (const file of [...new Set(candidates)]) {
          if (!fsMod.existsSync(file)) continue;
          const content = fsMod.readFileSync(file, "utf-8");
          const ok = recordProjectMcpTrust(file, content);
          results.push({
            file,
            trusted: ok,
            fingerprint: projectMcpFingerprint(content).slice(0, 16),
          });
        }
        if (options.json) {
          console.log(JSON.stringify(results, null, 2));
          return;
        }
        if (results.length === 0) {
          console.log("No .mcp.json found in this project.");
          return;
        }
        for (const r of results) {
          console.log(
            `${r.trusted ? "Trusted" : "FAILED to record"} ${r.file} (${r.fingerprint})`,
          );
        }
      } catch (err) {
        console.error(`Failed: ${err.message}`);
        process.exitCode = 1;
      }
    });

  mcp
    .command("scaffold <name>")
    .description("Scaffold a new MCP server project (stdio or http+sse)")
    .option("-d, --description <text>", "Short description of the server")
    .option(
      "-t, --transport <kind>",
      `Transport: ${SUPPORTED_TRANSPORTS.join("|")}`,
      "stdio",
    )
    .option("-o, --output <dir>", "Target directory (defaults to ./<name>)")
    .option("-a, --author <name>", "package.json author field")
    .option("-p, --port <n>", "HTTP port (http transport only)", (v) =>
      parseInt(v, 10),
    )
    .option("--force", "Overwrite existing files")
    .option("--dry-run", "Print files that would be written, don't touch disk")
    .option("--json", "Output as JSON")
    .action(async (name, options) => {
      try {
        const { files, summary } = generateMcpServerScaffold({
          name,
          description: options.description,
          transport: options.transport,
          author: options.author,
          port: options.port,
        });

        const targetDir = path.resolve(options.output || `./${summary.name}`);

        if (options.dryRun) {
          if (options.json) {
            console.log(JSON.stringify({ targetDir, summary, files }, null, 2));
          } else {
            logger.log(
              `${chalk.bold("Would write")} ${files.length} files to ${chalk.cyan(targetDir)}:`,
            );
            for (const f of files) {
              logger.log(
                `  ${chalk.cyan(f.path)} ` +
                  chalk.dim(`(${f.content.length} bytes)`),
              );
            }
          }
          return;
        }

        // Collision check — refuse to clobber unless --force.
        if (!options.force && fs.existsSync(targetDir)) {
          const clashing = files.filter((f) =>
            fs.existsSync(path.join(targetDir, f.path)),
          );
          if (clashing.length > 0) {
            logger.error(
              `Refusing to overwrite existing files in ${targetDir}: ` +
                clashing.map((f) => f.path).join(", ") +
                `. Re-run with --force to overwrite.`,
            );
            process.exit(1);
          }
        }

        fs.mkdirSync(targetDir, { recursive: true });
        for (const f of files) {
          const full = path.join(targetDir, f.path);
          fs.mkdirSync(path.dirname(full), { recursive: true });
          fs.writeFileSync(full, f.content, "utf-8");
        }

        if (options.json) {
          console.log(
            JSON.stringify(
              {
                targetDir,
                summary,
                files: files.map((f) => f.path),
              },
              null,
              2,
            ),
          );
        } else {
          logger.success(
            `Scaffolded ${chalk.cyan(summary.name)} ` +
              chalk.dim(
                `(${summary.transport}${summary.port ? `, port ${summary.port}` : ""})`,
              ),
          );
          logger.log(`  ${chalk.bold("Path:")}     ${targetDir}`);
          for (const f of files) {
            logger.log(`    ${chalk.dim("+")} ${f.path}`);
          }
          logger.log("");
          logger.log(chalk.bold("Next steps:"));
          logger.log(
            `  ${chalk.dim("$")} cd ${path.relative(process.cwd(), targetDir) || "."}`,
          );
          logger.log(`  ${chalk.dim("$")} npm install`);
          if (summary.transport === "stdio") {
            logger.log(
              `  ${chalk.dim("$")} cc mcp add ${summary.name} -c node -a "./index.js"`,
            );
          } else {
            logger.log(`  ${chalk.dim("$")} npm start`);
            logger.log(
              `  ${chalk.dim("$")} cc mcp add ${summary.name} -u http://localhost:${summary.port}/mcp`,
            );
          }
        }
      } catch (err) {
        logger.error(`Scaffold failed: ${err.message}`);
        process.exit(1);
      }
    });

  // mcp registry — browse + search + one-shot install from the bundled catalog
  const registry = mcp
    .command("registry")
    .description("Browse the curated catalog of community MCP servers");

  registry
    .command("list")
    .description("List catalog entries (filter by category/tag/author)")
    .option("-c, --category <name>", "Filter by category")
    .option("-t, --tags <list>", "Filter by comma-separated tags (any match)")
    .option("--author <name>", "Filter by author (substring, case-insensitive)")
    .option("--sort <field>", "Sort by 'name' | 'rating' | 'category'", "name")
    .option("--order <dir>", "'asc' | 'desc'", "asc")
    .option("--limit <n>", "Max results", (v) => parseInt(v, 10))
    .option("--offset <n>", "Pagination offset", (v) => parseInt(v, 10))
    .option("--json", "Output as JSON")
    .action((options) => {
      try {
        const tags = options.tags
          ? options.tags
              .split(",")
              .map((t) => t.trim())
              .filter(Boolean)
          : undefined;
        const { servers, total } = registryListServers({
          category: options.category,
          tags,
          author: options.author,
          sortBy: options.sort,
          sortOrder: options.order,
          limit: options.limit,
          offset: options.offset,
        });

        if (options.json) {
          console.log(JSON.stringify({ servers, total }, null, 2));
          return;
        }

        if (servers.length === 0) {
          logger.info("No catalog entries match your filters.");
          return;
        }

        logger.log(
          chalk.bold(`MCP Registry — ${servers.length}/${total} servers\n`),
        );
        for (const s of servers) {
          logger.log(
            `  ${chalk.cyan(s.name)} ${chalk.gray(`(${s.id})`)} ` +
              chalk.dim(`★${s.rating ?? "-"} ${s.category}`),
          );
          logger.log(`    ${chalk.gray(s.description)}`);
          if (s.tags?.length) {
            logger.log(
              `    ${chalk.gray("tags:")} ${s.tags.slice(0, 5).join(", ")}`,
            );
          }
        }
      } catch (err) {
        logger.error(`Registry list failed: ${err.message}`);
        process.exit(1);
      }
    });

  registry
    .command("search <keyword>")
    .description("Keyword search across name/description/tags")
    .option("--json", "Output as JSON")
    .action((keyword, options) => {
      try {
        const hits = registrySearchServers(keyword);
        if (options.json) {
          console.log(JSON.stringify({ hits, total: hits.length }, null, 2));
          return;
        }
        if (hits.length === 0) {
          logger.info(`No matches for "${keyword}".`);
          return;
        }
        logger.log(chalk.bold(`${hits.length} matches for "${keyword}":\n`));
        for (const s of hits) {
          logger.log(
            `  ${chalk.cyan(s.name)} ${chalk.gray(`(${s.id})`)} ` +
              chalk.dim(s.category),
          );
          logger.log(`    ${chalk.gray(s.description)}`);
        }
      } catch (err) {
        logger.error(`Registry search failed: ${err.message}`);
        process.exit(1);
      }
    });

  registry
    .command("show <idOrName>")
    .description("Show full catalog entry (id or short name)")
    .option("--json", "Output as JSON")
    .action((idOrName, options) => {
      try {
        const entry = registryGetServer(idOrName);
        if (!entry) {
          logger.error(`Not found: "${idOrName}".`);
          process.exit(1);
        }
        if (options.json) {
          console.log(JSON.stringify(entry, null, 2));
          return;
        }
        logger.log(
          `${chalk.bold(entry.displayName)} ${chalk.gray(`(${entry.id})`)}`,
        );
        logger.log(`  ${chalk.gray("Author:")}   ${entry.author}`);
        logger.log(`  ${chalk.gray("Category:")} ${entry.category}`);
        logger.log(`  ${chalk.gray("Version:")}  ${entry.version}`);
        logger.log(`  ${chalk.gray("Rating:")}   ★${entry.rating ?? "-"}`);
        logger.log(`  ${chalk.gray("Package:")}  ${entry.npmPackage}`);
        logger.log(
          `  ${chalk.gray("Command:")}  ${entry.command} ${entry.args.join(" ")}`,
        );
        logger.log(`  ${chalk.gray("Transport:")}${entry.transport}`);
        if (entry.homepage) {
          logger.log(`  ${chalk.gray("Homepage:")} ${entry.homepage}`);
        }
        logger.log(`\n  ${entry.description}`);
        if (entry.tools?.length) {
          logger.log(`\n  ${chalk.bold("Tools:")} ${entry.tools.join(", ")}`);
        }
        logger.log(
          `\n  ${chalk.dim("Install:")} cc mcp registry install ${entry.name}`,
        );
      } catch (err) {
        logger.error(`Registry show failed: ${err.message}`);
        process.exit(1);
      }
    });

  registry
    .command("install <idOrName>")
    .description("Install a catalog entry by registering it as an MCP server")
    .option("--as <name>", "Override the stored server name")
    .option("--auto-connect", "Mark the server to auto-connect on startup")
    .option("--json", "Output as JSON")
    .action(async (idOrName, options) => {
      try {
        const entry = registryGetServer(idOrName);
        if (!entry) {
          logger.error(
            `Not found: "${idOrName}". Try 'cc mcp registry list' or 'search'.`,
          );
          process.exit(1);
        }

        const ctx = await bootstrap({ verbose: program.opts().verbose });
        if (!ctx.db) {
          logger.error("Database not available");
          process.exit(1);
        }

        const db = ctx.db.getDatabase();
        const config = new MCPServerConfig(db);
        const storedName = (options.as || entry.name).trim();

        config.add(storedName, {
          command: entry.command,
          args: entry.args,
          autoConnect: !!options.autoConnect,
        });

        if (options.json) {
          console.log(
            JSON.stringify(
              {
                name: storedName,
                id: entry.id,
                command: entry.command,
                args: entry.args,
                autoConnect: !!options.autoConnect,
              },
              null,
              2,
            ),
          );
        } else {
          logger.success(
            `Installed ${chalk.cyan(storedName)} ` + chalk.dim(`(${entry.id})`),
          );
          logger.log(
            `  ${chalk.gray("Command:")} ${entry.command} ${entry.args.join(" ")}`,
          );
          logger.log(`  ${chalk.gray("Next:")} cc mcp connect ${storedName}`);
        }

        await shutdown();
      } catch (err) {
        logger.error(`Registry install failed: ${err.message}`);
        process.exit(1);
      }
    });

  registry
    .command("categories")
    .description("List available registry categories")
    .option("--json", "Output as JSON")
    .action((options) => {
      if (options.json) {
        console.log(JSON.stringify(REGISTRY_CATEGORIES, null, 2));
        return;
      }
      logger.log(chalk.bold("Categories:"));
      for (const c of REGISTRY_CATEGORIES) {
        const count = REGISTRY_CATALOG.filter((s) => s.category === c).length;
        logger.log(`  ${chalk.cyan(c)} ${chalk.dim(`(${count})`)}`);
      }
    });

  // ===== V2 governance subcommands (mcp-registry V2) =====
  mcp
    .command("server-maturities-v2")
    .description("List MCP server maturity states (V2)")
    .action(async () => {
      const m = await import("../lib/mcp-registry.js");
      console.log(JSON.stringify(m.MCP_SERVER_MATURITY_V2, null, 2));
    });
  mcp
    .command("invocation-lifecycle-v2")
    .description("List MCP invocation lifecycle states (V2)")
    .action(async () => {
      const m = await import("../lib/mcp-registry.js");
      console.log(JSON.stringify(m.MCP_INVOCATION_LIFECYCLE_V2, null, 2));
    });
  mcp
    .command("stats-v2")
    .description("Show MCP registry V2 stats")
    .action(async () => {
      const m = await import("../lib/mcp-registry.js");
      console.log(JSON.stringify(m.getMcpRegistryStatsV2(), null, 2));
    });
  mcp
    .command("config-v2")
    .description("Show MCP registry V2 config")
    .action(async () => {
      const m = await import("../lib/mcp-registry.js");
      console.log(
        JSON.stringify(
          {
            maxActiveServersPerOwner: m.getMaxActiveServersPerOwnerV2(),
            maxPendingInvocationsPerServer:
              m.getMaxPendingInvocationsPerServerV2(),
            serverIdleMs: m.getServerIdleMsV2(),
            invocationStuckMs: m.getInvocationStuckMsV2(),
          },
          null,
          2,
        ),
      );
    });
  mcp
    .command("register-server-v2 <id> <owner> <endpoint>")
    .description("Register an MCP server (V2)")
    .action(async (id, owner, endpoint) => {
      const m = await import("../lib/mcp-registry.js");
      console.log(
        JSON.stringify(m.registerServerV2({ id, owner, endpoint }), null, 2),
      );
    });
  mcp
    .command("activate-server-v2 <id>")
    .description("Activate an MCP server (V2)")
    .action(async (id) => {
      const m = await import("../lib/mcp-registry.js");
      console.log(JSON.stringify(m.activateServerV2(id), null, 2));
    });
  mcp
    .command("degrade-server-v2 <id>")
    .description("Degrade an MCP server (V2)")
    .action(async (id) => {
      const m = await import("../lib/mcp-registry.js");
      console.log(JSON.stringify(m.degradeServerV2(id), null, 2));
    });
  mcp
    .command("retire-server-v2 <id>")
    .description("Retire an MCP server (V2)")
    .action(async (id) => {
      const m = await import("../lib/mcp-registry.js");
      console.log(JSON.stringify(m.retireServerV2(id), null, 2));
    });
  mcp
    .command("touch-server-v2 <id>")
    .description("Touch an MCP server (V2)")
    .action(async (id) => {
      const m = await import("../lib/mcp-registry.js");
      console.log(JSON.stringify(m.touchServerV2(id), null, 2));
    });
  mcp
    .command("get-server-v2 <id>")
    .description("Get an MCP server (V2)")
    .action(async (id) => {
      const m = await import("../lib/mcp-registry.js");
      console.log(JSON.stringify(m.getServerV2(id), null, 2));
    });
  mcp
    .command("list-servers-v2")
    .description("List MCP servers (V2)")
    .action(async () => {
      const m = await import("../lib/mcp-registry.js");
      console.log(JSON.stringify(m.listServersV2(), null, 2));
    });
  mcp
    .command("create-invocation-v2 <id> <serverId> <tool>")
    .description("Create an MCP invocation (V2)")
    .action(async (id, serverId, tool) => {
      const m = await import("../lib/mcp-registry.js");
      console.log(
        JSON.stringify(m.createInvocationV2({ id, serverId, tool }), null, 2),
      );
    });
  mcp
    .command("dispatch-invocation-v2 <id>")
    .description("Dispatch an MCP invocation (V2)")
    .action(async (id) => {
      const m = await import("../lib/mcp-registry.js");
      console.log(JSON.stringify(m.dispatchInvocationV2(id), null, 2));
    });
  mcp
    .command("complete-invocation-v2 <id>")
    .description("Complete an MCP invocation (V2)")
    .action(async (id) => {
      const m = await import("../lib/mcp-registry.js");
      console.log(JSON.stringify(m.completeInvocationV2(id), null, 2));
    });
  mcp
    .command("fail-invocation-v2 <id> [reason]")
    .description("Fail an MCP invocation (V2)")
    .action(async (id, reason) => {
      const m = await import("../lib/mcp-registry.js");
      console.log(JSON.stringify(m.failInvocationV2(id, reason), null, 2));
    });
  mcp
    .command("cancel-invocation-v2 <id> [reason]")
    .description("Cancel an MCP invocation (V2)")
    .action(async (id, reason) => {
      const m = await import("../lib/mcp-registry.js");
      console.log(JSON.stringify(m.cancelInvocationV2(id, reason), null, 2));
    });
  mcp
    .command("get-invocation-v2 <id>")
    .description("Get an MCP invocation (V2)")
    .action(async (id) => {
      const m = await import("../lib/mcp-registry.js");
      console.log(JSON.stringify(m.getInvocationV2(id), null, 2));
    });
  mcp
    .command("list-invocations-v2")
    .description("List MCP invocations (V2)")
    .action(async () => {
      const m = await import("../lib/mcp-registry.js");
      console.log(JSON.stringify(m.listInvocationsV2(), null, 2));
    });
  mcp
    .command("auto-degrade-idle-servers-v2")
    .description("Auto-degrade idle MCP servers (V2)")
    .action(async () => {
      const m = await import("../lib/mcp-registry.js");
      console.log(JSON.stringify(m.autoDegradeIdleServersV2(), null, 2));
    });
  mcp
    .command("auto-fail-stuck-invocations-v2")
    .description("Auto-fail stuck MCP invocations (V2)")
    .action(async () => {
      const m = await import("../lib/mcp-registry.js");
      console.log(JSON.stringify(m.autoFailStuckInvocationsV2(), null, 2));
    });
  mcp
    .command("set-max-active-servers-v2 <n>")
    .description("Set max active servers per owner (V2)")
    .action(async (n) => {
      const m = await import("../lib/mcp-registry.js");
      m.setMaxActiveServersPerOwnerV2(parseInt(n, 10));
      console.log(
        JSON.stringify(
          { maxActiveServersPerOwner: m.getMaxActiveServersPerOwnerV2() },
          null,
          2,
        ),
      );
    });
  mcp
    .command("set-max-pending-invocations-v2 <n>")
    .description("Set max pending invocations per server (V2)")
    .action(async (n) => {
      const m = await import("../lib/mcp-registry.js");
      m.setMaxPendingInvocationsPerServerV2(parseInt(n, 10));
      console.log(
        JSON.stringify(
          {
            maxPendingInvocationsPerServer:
              m.getMaxPendingInvocationsPerServerV2(),
          },
          null,
          2,
        ),
      );
    });
  mcp
    .command("set-server-idle-ms-v2 <n>")
    .description("Set MCP server idle timeout in ms (V2)")
    .action(async (n) => {
      const m = await import("../lib/mcp-registry.js");
      m.setServerIdleMsV2(parseInt(n, 10));
      console.log(
        JSON.stringify({ serverIdleMs: m.getServerIdleMsV2() }, null, 2),
      );
    });
  mcp
    .command("set-invocation-stuck-ms-v2 <n>")
    .description("Set MCP invocation stuck timeout in ms (V2)")
    .action(async (n) => {
      const m = await import("../lib/mcp-registry.js");
      m.setInvocationStuckMsV2(parseInt(n, 10));
      console.log(
        JSON.stringify(
          { invocationStuckMs: m.getInvocationStuckMsV2() },
          null,
          2,
        ),
      );
    });
  mcp
    .command("reset-state-v2")
    .description("Reset MCP registry V2 in-memory state")
    .action(async () => {
      const m = await import("../lib/mcp-registry.js");
      m._resetStateMcpRegistryV2();
      console.log(JSON.stringify({ ok: true }, null, 2));
    });
}

// === Iter24 V2 governance overlay ===
export function registerMcpgovV2Commands(program) {
  const parent = program.commands.find((c) => c.name() === "mcp");
  if (!parent) return;
  const L = async () => await import("../lib/mcp-registry.js");
  parent
    .command("mcpgov-enums-v2")
    .description("Show V2 enums")
    .action(async () => {
      const m = await L();
      console.log(
        JSON.stringify(
          {
            profileMaturity: m.MCPGOV_PROFILE_MATURITY_V2,
            invocationLifecycle: m.MCPGOV_INVOCATION_LIFECYCLE_V2,
          },
          null,
          2,
        ),
      );
    });
  parent
    .command("mcpgov-config-v2")
    .description("Show V2 config")
    .action(async () => {
      const m = await L();
      console.log(
        JSON.stringify(
          {
            maxActive: m.getMaxActiveMcpgovProfilesPerOwnerV2(),
            maxPending: m.getMaxPendingMcpgovInvocationsPerProfileV2(),
            idleMs: m.getMcpgovProfileIdleMsV2(),
            stuckMs: m.getMcpgovInvocationStuckMsV2(),
          },
          null,
          2,
        ),
      );
    });
  parent
    .command("mcpgov-set-max-active-v2 <n>")
    .description("Set max active")
    .action(async (n) => {
      (await L()).setMaxActiveMcpgovProfilesPerOwnerV2(Number(n));
      console.log("ok");
    });
  parent
    .command("mcpgov-set-max-pending-v2 <n>")
    .description("Set max pending")
    .action(async (n) => {
      (await L()).setMaxPendingMcpgovInvocationsPerProfileV2(Number(n));
      console.log("ok");
    });
  parent
    .command("mcpgov-set-idle-ms-v2 <n>")
    .description("Set idle threshold ms")
    .action(async (n) => {
      (await L()).setMcpgovProfileIdleMsV2(Number(n));
      console.log("ok");
    });
  parent
    .command("mcpgov-set-stuck-ms-v2 <n>")
    .description("Set stuck threshold ms")
    .action(async (n) => {
      (await L()).setMcpgovInvocationStuckMsV2(Number(n));
      console.log("ok");
    });
  parent
    .command("mcpgov-register-v2 <id> <owner>")
    .description("Register V2 profile")
    .option("--transport <v>", "transport")
    .action(async (id, owner, o) => {
      const m = await L();
      console.log(
        JSON.stringify(
          m.registerMcpgovProfileV2({ id, owner, transport: o.transport }),
          null,
          2,
        ),
      );
    });
  parent
    .command("mcpgov-activate-v2 <id>")
    .description("Activate profile")
    .action(async (id) => {
      console.log(
        JSON.stringify((await L()).activateMcpgovProfileV2(id), null, 2),
      );
    });
  parent
    .command("mcpgov-suspend-v2 <id>")
    .description("Suspend profile")
    .action(async (id) => {
      console.log(
        JSON.stringify((await L()).suspendMcpgovProfileV2(id), null, 2),
      );
    });
  parent
    .command("mcpgov-archive-v2 <id>")
    .description("Archive profile")
    .action(async (id) => {
      console.log(
        JSON.stringify((await L()).archiveMcpgovProfileV2(id), null, 2),
      );
    });
  parent
    .command("mcpgov-touch-v2 <id>")
    .description("Touch profile")
    .action(async (id) => {
      console.log(
        JSON.stringify((await L()).touchMcpgovProfileV2(id), null, 2),
      );
    });
  parent
    .command("mcpgov-get-v2 <id>")
    .description("Get profile")
    .action(async (id) => {
      console.log(JSON.stringify((await L()).getMcpgovProfileV2(id), null, 2));
    });
  parent
    .command("mcpgov-list-v2")
    .description("List profiles")
    .action(async () => {
      console.log(JSON.stringify((await L()).listMcpgovProfilesV2(), null, 2));
    });
  parent
    .command("mcpgov-create-invocation-v2 <id> <profileId>")
    .description("Create invocation")
    .option("--tool <v>", "tool")
    .action(async (id, profileId, o) => {
      const m = await L();
      console.log(
        JSON.stringify(
          m.createMcpgovInvocationV2({ id, profileId, tool: o.tool }),
          null,
          2,
        ),
      );
    });
  parent
    .command("mcpgov-invoking-invocation-v2 <id>")
    .description("Mark invocation as invoking")
    .action(async (id) => {
      console.log(
        JSON.stringify((await L()).invokingMcpgovInvocationV2(id), null, 2),
      );
    });
  parent
    .command("mcpgov-complete-invocation-v2 <id>")
    .description("Complete invocation")
    .action(async (id) => {
      console.log(
        JSON.stringify((await L()).completeInvocationMcpgovV2(id), null, 2),
      );
    });
  parent
    .command("mcpgov-fail-invocation-v2 <id> [reason]")
    .description("Fail invocation")
    .action(async (id, reason) => {
      console.log(
        JSON.stringify((await L()).failMcpgovInvocationV2(id, reason), null, 2),
      );
    });
  parent
    .command("mcpgov-cancel-invocation-v2 <id> [reason]")
    .description("Cancel invocation")
    .action(async (id, reason) => {
      console.log(
        JSON.stringify(
          (await L()).cancelMcpgovInvocationV2(id, reason),
          null,
          2,
        ),
      );
    });
  parent
    .command("mcpgov-get-invocation-v2 <id>")
    .description("Get invocation")
    .action(async (id) => {
      console.log(
        JSON.stringify((await L()).getMcpgovInvocationV2(id), null, 2),
      );
    });
  parent
    .command("mcpgov-list-invocations-v2")
    .description("List invocations")
    .action(async () => {
      console.log(
        JSON.stringify((await L()).listMcpgovInvocationsV2(), null, 2),
      );
    });
  parent
    .command("mcpgov-auto-suspend-idle-v2")
    .description("Auto-suspend idle")
    .action(async () => {
      console.log(
        JSON.stringify((await L()).autoSuspendIdleMcpgovProfilesV2(), null, 2),
      );
    });
  parent
    .command("mcpgov-auto-fail-stuck-v2")
    .description("Auto-fail stuck invocations")
    .action(async () => {
      console.log(
        JSON.stringify((await L()).autoFailStuckMcpgovInvocationsV2(), null, 2),
      );
    });
  parent
    .command("mcpgov-gov-stats-v2")
    .description("V2 gov stats")
    .action(async () => {
      console.log(
        JSON.stringify((await L()).getMcpRegistryGovStatsV2(), null, 2),
      );
    });
}
