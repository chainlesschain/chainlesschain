/**
 * background-agent WS protocol — exposes the background-session transport to
 * web-panel / IDE clients so a "background agents" panel can list sessions,
 * live-follow their logs, and interactively take a session over (follow-up
 * prompts / stop-turn), reusing the exact same NDJSON pipe protocol that
 * `cc attach` speaks.
 *
 * Routes (request → reply):
 *   bg-list      {all?}            → {type:"bg-list", sessions}
 *   bg-view      {bgId, lines?}    → {type:"bg-view", session, log}
 *   bg-attach    {bgId, lines?, sinceSeq?} → {type:"bg-attach", bgId, hello,
 *                                    log, latestSeq, [reattached, replayed,
 *                                    replayTruncated]}
 *   bg-prompt    {bgId, text}      → {type:"bg-prompt", bgId, sent}
 *   bg-answer    {bgId, requestId, binding, answer}
 *                                  → {type:"bg-answer", bgId, sent}
 *   bg-stop-turn {bgId}            → {type:"bg-stop-turn", bgId, sent}
 *   bg-detach    {bgId}            → {type:"bg-detach", bgId}
 *   bg-stop      {bgId}            → {type:"bg-stop", session}   (kill whole session)
 *
 * While attached, the server pushes unsolicited frames to that client, each
 * stamped with a per-attachment monotonic `seq` (additive; older clients
 * ignore it) so the client can detect gaps and request a replay:
 *   {type:"bg-event", bgId, seq, event}  worker lifecycle events (turn-started /
 *                                    turn-ended / idle / accepted / error /
 *                                    transport-closed)
 *   {type:"bg-log",   bgId, seq, chunk}  log-file delta (500ms poll)
 *
 * Reconnect resilience: a panel whose WS blipped re-sends bg-attach with the
 * last `seq` it saw (`sinceSeq`); the still-live relay re-pushes the frames it
 * missed (bounded buffer) and reports `latestSeq`. If the missed range was
 * already evicted, `replayTruncated:true` tells the client to full-resync from
 * the log. If the relay was fully torn down (WS closed → cleanup), the fresh
 * attach returns hello + log tail as before and the client resets its tracker.
 *
 * Backpressure: if the WS client drains too slowly (ws.bufferedAmount over the
 * high water), DROPPABLE frames (bg-log) are shed while CRITICAL ones (bg-event
 * lifecycle) are always delivered. Dropped frames are still recorded (seq
 * advances), so the gap on the next delivered frame trips the client's
 * replaySince recovery. A one-shot {type:"bg-lag", bgId, lagging:true} marks
 * the start and {type:"bg-lag", bgId, lagging:false, dropped, latestSeq} the
 * recovery — the UI shows "catching up" instead of freezing. bg-lag frames
 * carry no seq (out-of-band control; the gap tracker ignores them).
 *
 * The state file's `transport.token` is the local takeover capability — it is
 * NEVER sent over WS. Sessions are serialized with `interactive: true/false`
 * instead; the server process (same user) performs the pipe handshake itself.
 */

import { existsSync, readFileSync } from "node:fs";
import { EventReplayBuffer } from "../../lib/event-seq-replay.js";
import {
  BackpressurePolicy,
  CRITICAL,
  DROPPABLE,
} from "../../lib/backpressure-policy.js";

const LOG_POLL_MS = 500;

async function loadSupervisor() {
  return import("../../lib/background-agent-supervisor.js");
}

/** Strip the takeover token before a session state crosses the WS boundary. */
export function sanitizeBackgroundSession(state) {
  if (!state) return state;
  const { transport, ...rest } = state;
  return { ...rest, interactive: Boolean(transport?.pipe) };
}

function sendError(server, id, ws, code, message) {
  server._send(ws, { id, type: "error", code, message });
}

function attachments(client) {
  if (!client._bgAttachments) client._bgAttachments = new Map();
  return client._bgAttachments;
}

function dropAttachment(client, bgId) {
  const map = client?._bgAttachments;
  const entry = map?.get(bgId);
  if (!entry) return false;
  map.delete(bgId);
  clearInterval(entry.poll);
  try {
    entry.conn.close();
  } catch {
    /* worker side already gone */
  }
  return true;
}

/** Tear down every transport relay a client holds (called on ws close). */
export function cleanupBgAttachments(client) {
  const map = client?._bgAttachments;
  if (!map) return;
  for (const bgId of [...map.keys()]) dropAttachment(client, bgId);
}

export async function handleBgList(server, id, ws, message) {
  try {
    const { listBackgroundAgents } = await loadSupervisor();
    const sessions = listBackgroundAgents({ all: message.all === true }).map(
      sanitizeBackgroundSession,
    );
    server._send(ws, { id, type: "bg-list", sessions });
  } catch (err) {
    sendError(server, id, ws, "BG_LIST_FAILED", err.message);
  }
}

export async function handleBgView(server, id, ws, message) {
  try {
    const {
      readBackgroundAgentState,
      effectiveBackgroundAgentState,
      readBackgroundAgentLog,
    } = await loadSupervisor();
    if (!message.bgId) {
      return sendError(server, id, ws, "NO_BG_ID", "bgId required");
    }
    const session = effectiveBackgroundAgentState(
      readBackgroundAgentState(message.bgId),
    );
    if (!session) {
      return sendError(
        server,
        id,
        ws,
        "BG_NOT_FOUND",
        `Background agent not found: ${message.bgId}`,
      );
    }
    const log = readBackgroundAgentLog(message.bgId, {
      lines: Number(message.lines) || 100,
    });
    server._send(ws, {
      id,
      type: "bg-view",
      session: sanitizeBackgroundSession(session),
      log,
    });
  } catch (err) {
    sendError(server, id, ws, "BG_VIEW_FAILED", err.message);
  }
}

export async function handleBgAttach(server, clientId, id, ws, message) {
  try {
    const client = server.clients.get(clientId);
    if (!client) {
      return sendError(server, id, ws, "NO_CLIENT", "client not registered");
    }
    if (!message.bgId) {
      return sendError(server, id, ws, "NO_BG_ID", "bgId required");
    }
    const bgId = message.bgId;
    const {
      readBackgroundAgentState,
      effectiveBackgroundAgentState,
      readBackgroundAgentLog,
      logPath,
    } = await loadSupervisor();

    const existing = attachments(client).get(bgId);
    if (existing) {
      // Idempotent re-attach: reply with the live handshake instead of
      // stacking a second relay (a reconnecting panel re-sends bg-attach).
      // If the panel reports the last seq it saw (`sinceSeq`), replay the
      // push frames it missed while the WS was blipped — re-sent as normal
      // bg-event/bg-log frames (their original seq), so the client's gap
      // tracker sees a contiguous run. `replayTruncated` tells the client the
      // hole predates our buffer and it must full-resync (re-read the log).
      const sinceSeq = Number(message.sinceSeq);
      let replayTruncated = false;
      let replayed = 0;
      if (Number.isFinite(sinceSeq)) {
        const { frames, truncated } = existing.buffer.replaySince(sinceSeq);
        replayTruncated = truncated;
        replayed = frames.length;
        for (const frame of frames) server._send(ws, frame);
      }
      server._send(ws, {
        id,
        type: "bg-attach",
        bgId,
        hello: existing.hello,
        log: "",
        reattached: true,
        latestSeq: existing.buffer.latestSeq,
        replayed,
        replayTruncated,
      });
      return;
    }

    const session = effectiveBackgroundAgentState(
      readBackgroundAgentState(bgId),
    );
    if (!session) {
      return sendError(
        server,
        id,
        ws,
        "BG_NOT_FOUND",
        `Background agent not found: ${bgId}`,
      );
    }
    if (session.status !== "running" || !session.transport?.pipe) {
      return sendError(
        server,
        id,
        ws,
        "BG_NOT_INTERACTIVE",
        `Background agent ${bgId} is ${session.status} and has no live session transport`,
      );
    }

    // Per-attachment replay buffer: stamps a monotonic seq on every push frame
    // and retains a bounded tail so a reconnecting client can fill gaps
    // (bg-attach { sinceSeq }). One buffer per relay instance — seq restarts
    // at 1 on a fresh attach, so the client resets its tracker then.
    const buffer = new EventReplayBuffer();
    // Backpressure: if the WS client drains too slowly (ws.bufferedAmount grows
    // past the high water), shed DROPPABLE frames (bg-log — recoverable) while
    // still delivering CRITICAL ones (bg-event lifecycle). Dropped frames are
    // still RECORDED (seq advances), so the seq gap on the next delivered frame
    // trips the client's replaySince recovery; a one-shot bg-lag notice lets
    // the UI show "catching up" instead of freezing. Buffer stays 0 in the
    // normal case → byte-identical legacy behavior.
    const backpressure = new BackpressurePolicy();
    const bufferedBytes = () =>
      ws && Number.isFinite(ws.bufferedAmount) ? ws.bufferedAmount : 0;
    const pushFrame = (base, frameClass) => {
      const frame = buffer.record(base); // record always → seq advances, replay recovers drops
      const d = backpressure.evaluate(bufferedBytes(), frameClass);
      if (d.lagStarted)
        server._send(ws, { type: "bg-lag", bgId, lagging: true });
      if (d.send) server._send(ws, frame);
      if (d.lagEnded) {
        server._send(ws, {
          type: "bg-lag",
          bgId,
          lagging: false,
          dropped: d.dropped,
          latestSeq: buffer.latestSeq,
        });
      }
    };
    const pushEvent = (event) =>
      pushFrame({ type: "bg-event", bgId, event }, CRITICAL);
    const pushLog = (chunk) =>
      pushFrame({ type: "bg-log", bgId, chunk }, DROPPABLE);

    const { connectBackgroundSession } =
      await import("../../lib/background-session-transport.js");
    let conn;
    try {
      conn = await connectBackgroundSession({
        pipePath: session.transport.pipe,
        token: session.transport.token,
        onEvent: (event) => pushEvent(event),
        onClose: () => {
          if (dropAttachment(client, bgId)) {
            pushEvent({ type: "transport-closed" });
          }
        },
      });
    } catch (err) {
      return sendError(
        server,
        id,
        ws,
        "BG_ATTACH_FAILED",
        `session transport unavailable: ${err.message}`,
      );
    }

    const logFile = logPath(bgId);
    let offset = existsSync(logFile) ? readFileSync(logFile, "utf8").length : 0;
    const poll = setInterval(() => {
      try {
        if (!existsSync(logFile)) return;
        const text = readFileSync(logFile, "utf8");
        if (offset > text.length) offset = 0; // truncated/rotated
        if (text.length > offset) {
          const chunk = text.slice(offset);
          offset = text.length;
          pushLog(chunk);
        }
      } catch {
        /* transient read failures skip one tick */
      }
    }, LOG_POLL_MS);
    poll.unref?.();

    attachments(client).set(bgId, { conn, poll, hello: conn.hello, buffer });
    server._send(ws, {
      id,
      type: "bg-attach",
      bgId,
      hello: conn.hello,
      log: readBackgroundAgentLog(bgId, {
        lines: Number(message.lines) || 100,
      }),
      latestSeq: buffer.latestSeq,
    });
  } catch (err) {
    sendError(server, id, ws, "BG_ATTACH_FAILED", err.message);
  }
}

function requireAttachment(server, clientId, id, ws, message) {
  const client = server.clients.get(clientId);
  const entry = client?._bgAttachments?.get(message.bgId);
  if (!message.bgId) {
    sendError(server, id, ws, "NO_BG_ID", "bgId required");
    return null;
  }
  if (!entry) {
    sendError(
      server,
      id,
      ws,
      "BG_NOT_ATTACHED",
      `not attached to ${message.bgId} — send bg-attach first`,
    );
    return null;
  }
  return entry;
}

export async function handleBgPrompt(server, clientId, id, ws, message) {
  const entry = requireAttachment(server, clientId, id, ws, message);
  if (!entry) return;
  const text = String(message.text || "").trim();
  if (!text) {
    return sendError(server, id, ws, "NO_TEXT", "prompt text required");
  }
  const sent = entry.conn.send({ type: "prompt", text });
  server._send(ws, { id, type: "bg-prompt", bgId: message.bgId, sent });
}

export async function handleBgAnswer(server, clientId, id, ws, message) {
  const entry = requireAttachment(server, clientId, id, ws, message);
  if (!entry) return;
  const requestId = String(message.requestId || "");
  if (!requestId) {
    return sendError(server, id, ws, "NO_REQUEST_ID", "requestId required");
  }
  if (
    !message.binding ||
    typeof message.binding !== "object" ||
    Array.isArray(message.binding)
  ) {
    return sendError(
      server,
      id,
      ws,
      "NO_INTERACTION_BINDING",
      "interaction binding required",
    );
  }
  const sent = entry.conn.send({
    type: "interaction_response",
    requestId,
    binding: message.binding,
    answer: message.answer,
    ...(message.error ? { error: message.error } : {}),
  });
  server._send(ws, {
    id,
    type: "bg-answer",
    bgId: message.bgId,
    requestId,
    sent,
  });
}

export async function handleBgStopTurn(server, clientId, id, ws, message) {
  const entry = requireAttachment(server, clientId, id, ws, message);
  if (!entry) return;
  const sent = entry.conn.send({ type: "stop" });
  server._send(ws, { id, type: "bg-stop-turn", bgId: message.bgId, sent });
}

export async function handleBgDetach(server, clientId, id, ws, message) {
  if (!message.bgId) {
    return sendError(server, id, ws, "NO_BG_ID", "bgId required");
  }
  const client = server.clients.get(clientId);
  const dropped = dropAttachment(client, message.bgId);
  server._send(ws, { id, type: "bg-detach", bgId: message.bgId, dropped });
}

export async function handleBgRename(server, id, ws, message) {
  try {
    if (!message.bgId) {
      return sendError(server, id, ws, "NO_BG_ID", "bgId required");
    }
    const { renameBackgroundAgent } = await loadSupervisor();
    const session = renameBackgroundAgent(message.bgId, message.title);
    server._send(ws, {
      id,
      type: "bg-rename",
      session: sanitizeBackgroundSession(session),
    });
  } catch (err) {
    sendError(server, id, ws, "BG_RENAME_FAILED", err.message);
  }
}

export async function handleBgResume(server, id, ws, message) {
  try {
    if (!message.bgId) {
      return sendError(server, id, ws, "NO_BG_ID", "bgId required");
    }
    const { resumeBackgroundAgent } = await loadSupervisor();
    const session = resumeBackgroundAgent(message.bgId, message.text);
    server._send(ws, {
      id,
      type: "bg-resume",
      session: sanitizeBackgroundSession(session),
    });
  } catch (err) {
    sendError(server, id, ws, "BG_RESUME_FAILED", err.message);
  }
}

export async function handleBgStop(server, clientId, id, ws, message) {
  try {
    if (!message.bgId) {
      return sendError(server, id, ws, "NO_BG_ID", "bgId required");
    }
    // Kill the whole session: drop our relay first so the worker's
    // "no clients" finalize path doesn't race the stop.
    dropAttachment(server.clients.get(clientId), message.bgId);
    const { stopBackgroundAgent } = await loadSupervisor();
    const session = stopBackgroundAgent(message.bgId);
    server._send(ws, {
      id,
      type: "bg-stop",
      session: sanitizeBackgroundSession(session),
    });
  } catch (err) {
    sendError(server, id, ws, "BG_STOP_FAILED", err.message);
  }
}
