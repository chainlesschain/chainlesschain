/**
 * ChainlessChain Agent Protocol — the versioned wire contract.
 *
 * This module is pure types + constants (no runtime I/O, browser-safe).
 * It formalizes the NDJSON `stream-json` protocol spoken by
 * `cc agent --input-format stream-json --output-format stream-json`
 * (source of truth: packages/cli/src/runtime/headless-stream.js) and the
 * background-session pipe protocol
 * (packages/cli/src/lib/background-session-transport.js), plus the
 * `bg-*` WebSocket relay frames
 * (packages/cli/src/gateways/ws/background-agent-protocol.js).
 *
 * Consumers: the Node SDK client in this package, the VS Code extension,
 * the web-panel, and (as documentation) the JetBrains plugin — Kotlin
 * consumes the same wire shapes via docs/PROTOCOL.md, which is generated
 * from the same field inventory. Any BREAKING field change here is a
 * protocol change: bump PROTOCOL_VERSION and update docs/PROTOCOL.md in
 * the same commit. Additive OPTIONAL fields stay on the current version
 * (consumers MUST tolerate their absence and ignore unknown fields) —
 * mirror packages/cli/src/lib/headless-manifest.js STREAM_PROTOCOL_VERSION.
 */

import type {
  AgentTranscriptReferences,
  ApprovalDecision,
  CanonicalAgentStreamEvent,
  PermissionGrant,
} from "./generated/app-protocol.js";
import { isAgentStreamEvent as isCanonicalAgentStreamEvent } from "./generated/app-protocol.js";

export const PROTOCOL_VERSION = 1;

/**
 * The oldest protocol version the CLI can still negotiate down to (the N-1 in
 * "N / N-1"). At v1 there is no older line shape, so it equals PROTOCOL_VERSION;
 * once a v2 line shape ships this drops to 1 so a v1-only client negotiates a
 * v1 session. Mirror of packages/cli/src/lib/capability-negotiation.js
 * PROTOCOL_MIN_VERSION.
 */
export const MIN_PROTOCOL_VERSION = 1;

/**
 * The wire-protocol features subject to negotiation — additive per-line fields
 * a client may or may not understand. Runtime capabilities (bare, worktree,
 * mcp, …) are NOT negotiated. Mirror of capability-negotiation.js
 * PROTOCOL_FEATURES.
 */
export const PROTOCOL_FEATURES = [
  "event_seq",
  "tool_use_id",
  "permission_decision",
  "trace_id",
] as const;

export type ProtocolFeature = (typeof PROTOCOL_FEATURES)[number];

/**
 * Additive per-line metadata (protocol v1, additive): every CLI → client
 * stream line MAY carry `seq`, a 1-based monotonically increasing emit
 * sequence number, unique within one session process, and `trace_id`, a
 * run-scoped correlation id repeated on every line of the run. Consumers MUST
 * tolerate their absence (older CLIs never send them), MUST NOT require
 * gap-free `seq` numbering across reconnects (it orders lines, nothing more),
 * and MUST NOT change behavior solely because `trace_id` is missing.
 */
export interface StreamEventMeta {
  /** Monotonic 1-based per-session-process emit sequence number. */
  seq?: number;
  /**
   * Run-scoped cross-event correlation id (same value on every line of one
   * run). Callers MAY inject it via `--trace-id` / `CC_TRACE_ID` to trace a
   * run end-to-end (IDE/Webview → Bridge → CLI → transcript/diagnostics);
   * otherwise the CLI mints one per process (distinct even when two runs
   * resume the same `session_id`).
   */
  trace_id?: string;
  /** Preserve additive fields on legacy ergonomic refinements. */
  [key: string]: unknown;
}

// ─────────────────────────────────────────────────────────────────────────────
// Agent output events (CLI → client), one JSON object per NDJSON line
// ─────────────────────────────────────────────────────────────────────────────

export interface TokenUsage {
  input_tokens?: number;
  output_tokens?: number;
  cache_read_input_tokens?: number;
  cache_creation_input_tokens?: number;
}

/** First event of a session; carries the resume id. */
export interface SystemInitEvent extends StreamEventMeta {
  type: "system";
  subtype: "init";
  session_id: string;
  model?: string;
  provider?: string;
  permission_mode?: string;
  /** Child-correlated display acknowledgement, never an execution grant. */
  permission_mode_state?: {
    correlation_id: string;
    requested: "default" | "acceptEdits" | "bypassPermissions";
    effective:
      | "default"
      | "acceptEdits"
      | "auto"
      | "bypassPermissions"
      | "dontAsk"
      | "plan";
    policy_revision: string;
  };
  tools?: string[];
  /** Session-scoped slash commands accepted over the live stream protocol. */
  slash_commands?: string[];
  input_format?: string;
  additional_directories?: string[];
  /** > 0 when the session was resumed from a prior transcript. */
  resumed_messages?: number;
  /** Send client_message_id only when the persistent CLI advertises version 1. */
  input_receipts?: { version: 0 | 1 };
}

/** Input acceptance only: does not prove execution started or completed. */
export interface InputAcceptedEvent extends StreamEventMeta {
  type: "system";
  subtype: "input_accepted";
  session_id: string;
  client_message_id: string;
  receipt: {
    sessionId: string;
    clientMessageId: string;
    inputDigest: string;
    eventHash: string;
    duplicate: boolean;
  };
}

export interface SystemEndEvent extends StreamEventMeta {
  type: "system";
  subtype: "end";
  turns?: number;
}

/**
 * Echo of the capability handshake (agent-sdk docs/PROTOCOL.md §1.3), emitted
 * once after the CLI receives a client `hello` on stdin. It reports the level
 * the two sides agreed on; the CLI then stamps only the `features` fields for
 * the rest of the run. Additive — a client that never sends `hello` never sees
 * this line, and older consumers ignore the unknown `subtype`.
 */
export interface NegotiatedCapabilitiesEvent extends StreamEventMeta {
  type: "system";
  subtype: "negotiated";
  session_id: string;
  /** Agreed protocol version (min of both maxes), or null when incompatible. */
  protocol_version: number | null;
  /** Effective wire features both sides support at the agreed version. */
  features: string[];
  /** true when the agreed version or feature set is below the CLI's own max. */
  downgraded: boolean;
  /** Server-offered features dropped in negotiation (version-gated or unaccepted). */
  disabled_features?: string[];
  /** false when the two version ranges don't overlap (CLI keeps its baseline). */
  ok: boolean;
  /** Human-readable cause when ok:false. */
  reason?: string | null;
}

export interface TextDelta {
  type: "text_delta";
  text: string;
}

export interface ThinkingDelta {
  type: "thinking_delta";
  thinking: string;
}

/** Partial-output event (requires --include-partial-messages). */
export interface ContentDeltaEvent extends StreamEventMeta {
  type: "stream_event";
  event: {
    type: "content_block_delta";
    delta: TextDelta | ThinkingDelta;
  };
}

export interface ToolUseEvent extends StreamEventMeta {
  type: "tool_use";
  /**
   * Additive (protocol v1): per-session tool-call correlation id
   * (`tu-<n>`, 1-based). The matching ToolResultEvent carries the SAME id.
   * Optional — older CLIs pair by adjacency (a tool_result follows its
   * tool_use); consumers MUST tolerate its absence.
   */
  id?: string;
  /** Approved plan item attributed to this tool call, when one matches. */
  plan_item_id?: string;
  /** 1-based agent turn that started the attributed plan item. */
  turn?: number;
  tool: string;
  args?: Record<string, unknown>;
}

export interface ToolResultEvent extends StreamEventMeta {
  type: "tool_result";
  /** Additive (protocol v1): id of the ToolUseEvent this result settles. */
  id?: string;
  /** Approved plan item settled by this result, when one matches. */
  plan_item_id?: string;
  turn?: number;
  tool: string;
  is_error?: boolean;
  error?: string | null;
  result?: unknown;
  /** Stable correlation id for a runtime permission gate, when one applied. */
  permission_decision_id?: string | null;
  /** Redacted runtime-authoritative explanation; clients must not re-evaluate it. */
  permission_decision?: PermissionDecision | null;
}

export interface PermissionDecision {
  version: 1;
  id: string | null;
  tool: string | null;
  decision: string | null;
  via: string | null;
  rule: string | null;
  reason: string | null;
  chain: Array<{
    layer: string | null;
    outcome: string | null;
    via: string | null;
    rule: string | null;
    reason: string | null;
  }>;
}

export interface TokenUsageEvent extends StreamEventMeta {
  type: "token_usage";
  usage: TokenUsage;
}

/**
 * Emitted when --interactive-approvals is on and a CONFIRM-tier decision
 * needs a human verdict. The tool is BLOCKED until an ApprovalResponse
 * arrives on stdin, or the CLI-side timeout fails closed
 * (CC_APPROVAL_TIMEOUT_MS, default 120 s).
 */
export interface ApprovalRequestEvent extends StreamEventMeta {
  type: "approval_request";
  id: string;
  session_id?: string;
  tool: string | null;
  command: string | null;
  risk: string | null;
  rule: string | null;
  reason: string | null;
  /** Digest binding for the exact tool call; structured responses must echo it. */
  binding?: string;
  /** Exact reusable permission requested by this operation. */
  requested_permissions?: PermissionGrant[];
}

export interface ApprovalResolvedEvent extends StreamEventMeta {
  type: "approval_resolved";
  id: string;
  approved: boolean;
  /** Canonical decision; absent only when talking to an older CLI. */
  decision?: ApprovalDecision;
  /** "user" when answered, "timeout" when the CLI failed closed. */
  via: string;
  session_id?: string;
}

/** ask_user_question round-trip (CC_INTERACTIVE_QUESTIONS=1). */
export interface InteractionBinding {
  backgroundAgentId: string | null;
  sessionId: string | null;
  turnId: string | null;
  toolUseId: string | null;
  sequence: number;
}

export interface QuestionRequestEvent extends StreamEventMeta {
  type: "question_request";
  id: string;
  question: string;
  options?: unknown[];
  multiSelect?: boolean;
  session_id?: string;
  /** Must be echoed unchanged by the answering host. */
  binding?: InteractionBinding;
  /** Present for host-routed MCP elicitation requests. */
  metadata?: {
    kind?: string;
    server?: string;
    requestId?: string | number;
    mode?: "form" | "url";
    requestedSchema?: unknown;
    elicitationId?: string;
    url?: string;
    urlHost?: string;
    [key: string]: unknown;
  };
}

export interface QuestionResolvedEvent extends StreamEventMeta {
  type: "question_resolved";
  id: string;
  answer?: unknown;
  via?: string;
  session_id?: string;
}

/** A non-interactive host could not service an MCP elicitation synchronously. */
export interface ElicitationDeferredEvent extends StreamEventMeta {
  type: "elicitation_deferred";
  session_id?: string;
  server: string | null;
  request_id: string | number | null;
  mode: "form" | "url";
  message: string;
  requested_schema?: unknown;
  elicitation_id?: string | null;
  url?: string | null;
  url_host?: string | null;
  reason: string;
  /** Standards-compliant action returned to the MCP server. */
  wire_action: "decline";
}

/** A server reported completion of a previously accepted URL elicitation. */
export interface ElicitationCompleteEvent extends StreamEventMeta {
  type: "elicitation_complete";
  session_id?: string;
  server: string | null;
  elicitation_id: string;
}

export interface PlanUpdateEvent extends StreamEventMeta {
  type: "plan_update";
  active?: boolean;
  state?: string | null;
  plan_id?: string | null;
  plan_version?: number | null;
  previous_plan_id?: string | null;
  items?: Array<{
    id?: string;
    title?: string;
    tool?: string;
    impact?: string;
    status?: string;
    turn?: number;
    tool_use_id?: string;
    started_at?: string;
    completed_at?: string;
    error?: string;
  }>;
  risk?: { level?: string; totalScore?: number } | null;
  execution_lock?: PlanExecutionLock;
}

export interface PlanExecutionLock {
  planId: string;
  permissionMode: string;
  approvedItemIds: string[];
  allowedTools: string[];
  createdAt?: string;
}

export interface CompactionEvent extends StreamEventMeta {
  type: "compaction";
  [key: string]: unknown;
}

export interface StreamRetryEvent extends StreamEventMeta {
  type: "stream_retry";
  [key: string]: unknown;
}

export interface IterationWarningEvent extends StreamEventMeta {
  type: "iteration_warning";
  message?: string;
}

export interface IterationBudgetExhaustedEvent extends StreamEventMeta {
  type: "iteration_budget_exhausted";
  budget?: number;
}

/** Non-protocol stdout or provider fallback / version-skew notices. */
export interface RawEvent extends StreamEventMeta {
  type: "raw";
  subtype?: string;
  text?: string;
  [key: string]: unknown;
}

export type ResultSubtype = "success" | "error" | "blocked" | "interrupted";

/** Terminal event of one turn. */
export interface ResultEvent extends StreamEventMeta {
  type: "result";
  subtype: ResultSubtype;
  is_error: boolean;
  result?: string;
  session_id?: string;
  num_turns?: number;
  duration_ms?: number;
  tool_calls?: number;
  usage?: TokenUsage;
  denials?: unknown[];
  /** Display association only; verify the referenced canonical history rows. */
  transcript_refs?: AgentTranscriptReferences;
}

/** Echo of an accepted input turn (--replay-user-messages). */
export interface UserEchoEvent extends StreamEventMeta {
  type: "user";
  [key: string]: unknown;
}

export interface FeedbackAckEvent extends StreamEventMeta {
  type: "feedback_ack";
  [key: string]: unknown;
}

export interface ResumeAckEvent extends StreamEventMeta {
  type: "resume_ack";
  [key: string]: unknown;
}

/**
 * Result of a read-only, session-scoped slash command requested over stdin.
 *
 * This is an additive protocol-v1 event. `request_id` correlates it with the
 * matching SlashCommandInput without borrowing the turn-level `result` event,
 * so clients can issue a status query without ending or starting an agent turn.
 */
export interface SlashCommandResultEvent extends StreamEventMeta {
  type: "slash_command_result";
  request_id: string;
  command: string;
  ok: boolean;
  text?: string;
  error?: {
    code: string;
    message: string;
  };
  session_id?: string;
}

/** Forward-compat: events this SDK version does not know yet. */
export interface UnknownAgentEvent {
  type: string;
  [key: string]: unknown;
}

/**
 * Canonical wire events come exclusively from the generated schema union.
 * `UnknownAgentEvent` keeps transport consumers forward compatible with an
 * additive event emitted by a newer CLI. The named interfaces above remain
 * source-compatible ergonomic refinements; they are not a second exhaustive
 * discriminator inventory.
 */
export type KnownAgentStreamEvent = CanonicalAgentStreamEvent;
export type AgentStreamEvent = KnownAgentStreamEvent | UnknownAgentEvent;

// ─────────────────────────────────────────────────────────────────────────────
// Agent input events (client → CLI stdin), one JSON object per NDJSON line
// ─────────────────────────────────────────────────────────────────────────────

/** Optional per-turn LLM override (privacy-tier switch). */
export interface LlmHint {
  provider?: string;
  model?: string;
  baseUrl?: string;
  apiKey?: string;
}

/**
 * Optional first stdin line: the client announces the protocol range + wire
 * features IT understands so the CLI can negotiate a common level and step
 * DOWN when they disagree (agent-sdk docs/PROTOCOL.md §1.3). Fully optional — a
 * client that never sends it gets full current-version behavior unchanged. The
 * CLI replies with a `system/negotiated` line.
 */
export interface ClientHelloInput {
  type: "hello";
  /** Highest protocol version the client can parse (default: the CLI's max). */
  protocol_version?: number;
  /** Lowest version the client will accept (default: protocol_version). */
  min_protocol_version?: number;
  /**
   * Wire features the client understands. Omit to accept whatever the agreed
   * version offers; send the array to narrow to a subset (e.g. ["trace_id"]).
   */
  features?: string[];
}

export interface UserMessageInput {
  type: "user";
  text: string;
  /** Session-scoped stable submission ID: 1–80 ASCII letters/digits/_/-. */
  client_message_id?: string;
  /** Absolute image file paths (≤ 8 are honored). */
  images?: string[];
  llm?: LlmHint;
}

export interface InterruptInput {
  type: "interrupt";
}

export interface CompactInput {
  type: "compact";
}

export interface StructuredApprovalResponseInput {
  type: "approval";
  id: string;
  decision: ApprovalDecision;
  /** Compatibility bit for an older CLI; must agree with decision when present. */
  approve?: boolean;
  /** Copied from ApprovalRequestEvent; required to approve on the new wire. */
  binding?: string;
}

/** @deprecated Use StructuredApprovalResponseInput. */
export interface LegacyApprovalResponseInput {
  type: "approval";
  id: string;
  approve: boolean;
  decision?: never;
  binding?: string;
}

export type ApprovalResponseInput =
  StructuredApprovalResponseInput | LegacyApprovalResponseInput;

export interface QuestionAnswerInput {
  type: "answer";
  id: string;
  /** null / absent cancels (handler resolves as user_timeout). */
  answer: unknown;
  /** Opaque binding copied from the matching QuestionRequestEvent. */
  binding?: InteractionBinding;
}

export interface PlanControlInput {
  type: "plan";
  action: "enter" | "approve" | "reject" | "revise" | "regenerate";
  /** Optional IDE review/audit payload written into the session transcript. */
  review?: {
    action?: string;
    reviewedAt?: string | null;
    conversationId?: string | null;
    revision?: number;
    comments?: Array<{
      id?: string;
      sourceLine?: number | null;
      itemId?: string | null;
      text: string;
      file?: string | null;
      line?: number | null;
      column?: number | null;
      turn?: number | null;
    }>;
    executionLock?: PlanExecutionLock;
    snapshot?: string;
  };
  /** Back-compat shorthand for review.snapshot. */
  snapshot?: string;
}

export interface FeedbackInput {
  type: "feedback";
  turn_id?: string | null;
  kind: "positive" | "negative" | "correction";
  comment?: string | null;
}

export interface ResumeAssistInput {
  type: "resume";
  token?: string | null;
  action: "completed" | "skip";
}

/**
 * Read-only query against the live stream-json session.
 *
 * `args` is the raw text following the command name. The CLI validates which
 * arguments each command supports and answers with SlashCommandResultEvent.
 */
export interface SlashCommandInput {
  type: "slash_command";
  request_id: string;
  command: string;
  args: string;
}

export type AgentInputEvent =
  | ClientHelloInput
  | UserMessageInput
  | InterruptInput
  | CompactInput
  | ApprovalResponseInput
  | QuestionAnswerInput
  | PlanControlInput
  | FeedbackInput
  | ResumeAssistInput
  | SlashCommandInput;

// ─────────────────────────────────────────────────────────────────────────────
// Background-session pipe protocol (cc attach / daemon workers)
// ─────────────────────────────────────────────────────────────────────────────

export interface BgHelloClient {
  type: "hello";
  token: string;
}

export interface BgPromptClient {
  type: "prompt";
  text: string;
}

export interface BgStatusClient {
  type: "status";
}

export interface BgStopClient {
  type: "stop";
}

export interface BgDetachClient {
  type: "detach";
}

export interface BgInteractionResponseClient {
  type: "interaction_response";
  requestId: string;
  binding: InteractionBinding;
  answer?: unknown;
  error?: { code?: string; message: string } | string;
}

export type BgClientMessage =
  | BgHelloClient
  | BgPromptClient
  | BgStatusClient
  | BgStopClient
  | BgDetachClient
  | BgInteractionResponseClient;

export interface BgHelloServer {
  type: "hello";
  id?: string;
  [key: string]: unknown;
}

export interface BgAcceptedServer {
  type: "accepted";
  queued: number;
}

export interface BgStatusServer {
  type: "status";
  [key: string]: unknown;
}

export interface BgErrorServer {
  type: "error";
  message: string;
}

export interface BgStoppingServer {
  type: "stopping";
}

export interface BgTurnStartedServer {
  type: "turn-started";
  turn?: number;
  prompt?: string;
}

export interface BgTurnEndedServer {
  type: "turn-ended";
  turn?: number;
  exitCode?: number;
}

export interface BgIdleServer {
  type: "idle";
  turn?: number;
}

export interface BgClosingServer {
  type: "closing";
}

export interface BgInteractionRequestServer {
  type: "interaction_request";
  requestId: string;
  binding: InteractionBinding;
  question: string;
  prompt?: string;
  options?: unknown[] | null;
  multiSelect?: boolean;
  [key: string]: unknown;
}

export interface BgInteractionReceivedServer {
  type: "received";
  requestId: string;
  accepted: boolean;
  duplicate: boolean;
}

export type BgServerMessage =
  | BgHelloServer
  | BgAcceptedServer
  | BgStatusServer
  | BgErrorServer
  | BgStoppingServer
  | BgTurnStartedServer
  | BgTurnEndedServer
  | BgIdleServer
  | BgClosingServer
  | BgInteractionRequestServer
  | BgInteractionReceivedServer
  | UnknownAgentEvent;

// ─────────────────────────────────────────────────────────────────────────────
// bg-* WebSocket relay frames (web-panel background-agents panel)
// ─────────────────────────────────────────────────────────────────────────────

export type BgWsRequestType =
  | "bg-list"
  | "bg-view"
  | "bg-attach"
  | "bg-prompt"
  | "bg-answer"
  | "bg-stop-turn"
  | "bg-detach"
  | "bg-stop"
  | "bg-rename"
  | "bg-resume";

export interface BgWsRequest {
  type: BgWsRequestType;
  bgId?: string;
  text?: string;
  name?: string;
  requestId?: string;
  /**
   * bg-attach only (additive): the last push `seq` the client saw. On a
   * re-attach to a still-live relay, the server re-pushes the frames after it
   * (gap replay) and answers with `latestSeq` / `replayTruncated`. Absent →
   * legacy behavior (no replay).
   */
  sinceSeq?: number;
  [key: string]: unknown;
}

/**
 * Unsolicited push while attached: relayed worker lifecycle event. `seq` is a
 * per-attachment monotonic 1-based number (additive) enabling gap detection +
 * replay; consumers MUST tolerate its absence and MUST reset their tracker on
 * a fresh (non-reattached) bg-attach, since a new relay restarts seq at 1.
 */
export interface BgWsEventFrame {
  type: "bg-event";
  bgId: string;
  event: BgServerMessage | { type: "transport-closed" };
  seq?: number;
}

/** Unsolicited push while attached: appended log chunk (seq additive). */
export interface BgWsLogFrame {
  type: "bg-log";
  bgId: string;
  chunk: string;
  seq?: number;
}

/**
 * Backpressure marker (additive): the relay is shedding droppable frames
 * because the client's send buffer is over the high water. `lagging:true`
 * starts a lag episode (show a "catching up" affordance, not a freeze);
 * `lagging:false` ends it, reporting how many frames were `dropped` and the
 * current `latestSeq` so the client can request a `sinceSeq` replay to recover
 * them. Carries NO `seq` (out-of-band control — do not feed it to a gap
 * tracker). Critical frames (bg-event) are never dropped.
 */
export interface BgWsLagFrame {
  type: "bg-lag";
  bgId: string;
  lagging: boolean;
  dropped?: number;
  latestSeq?: number;
}

export type BgWsPushFrame = BgWsEventFrame | BgWsLogFrame | BgWsLagFrame;

// ─────────────────────────────────────────────────────────────────────────────
// Session & checkpoint records (cc session list --json / cc checkpoint --json)
// ─────────────────────────────────────────────────────────────────────────────

export interface SessionRecord {
  id: string;
  title?: string;
  created_at?: string | number;
  updated_at?: string | number;
  messages?: number;
  [key: string]: unknown;
}

export interface CheckpointRecord {
  id: string;
  label?: string;
  created_at?: string | number;
  files?: number;
  [key: string]: unknown;
}

// ─────────────────────────────────────────────────────────────────────────────
// Type guards
// ─────────────────────────────────────────────────────────────────────────────

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null;
}

export function isAgentEvent(value: unknown): value is AgentStreamEvent {
  return isObject(value) && typeof value.type === "string";
}

/**
 * True only for event discriminators declared by the canonical protocol
 * schema. Use `isAgentEvent` when a transport must preserve unknown future
 * events instead of rejecting them.
 */
export function isKnownAgentEvent(
  value: unknown,
): value is CanonicalAgentStreamEvent {
  return isCanonicalAgentStreamEvent(value);
}

export function isSystemInit(
  event: AgentStreamEvent,
): event is SystemInitEvent {
  return (
    event.type === "system" &&
    (event as SystemInitEvent).subtype === "init" &&
    typeof (event as SystemInitEvent).session_id === "string"
  );
}

export function isContentDelta(
  event: AgentStreamEvent,
): event is ContentDeltaEvent {
  if (event.type !== "stream_event") return false;
  const inner = (event as ContentDeltaEvent).event;
  return isObject(inner) && inner.type === "content_block_delta";
}

/** Extract the delta payload, or null when not a content delta. */
export function contentDelta(
  event: AgentStreamEvent,
): { kind: "text" | "thinking"; text: string } | null {
  if (!isContentDelta(event)) return null;
  const delta = event.event.delta;
  if (delta.type === "text_delta") return { kind: "text", text: delta.text };
  if (delta.type === "thinking_delta")
    return { kind: "thinking", text: delta.thinking };
  return null;
}

export function isApprovalRequest(
  event: AgentStreamEvent,
): event is ApprovalRequestEvent {
  return (
    event.type === "approval_request" &&
    typeof (event as ApprovalRequestEvent).id === "string"
  );
}

export function isQuestionRequest(
  event: AgentStreamEvent,
): event is QuestionRequestEvent {
  return (
    event.type === "question_request" &&
    typeof (event as QuestionRequestEvent).id === "string"
  );
}

/** True when a question wire event is carrying an MCP elicitation form. */
export function isMcpElicitationRequest(
  event: AgentStreamEvent,
): event is QuestionRequestEvent {
  return isQuestionRequest(event) && event.metadata?.kind === "mcp_elicitation";
}

export function isResult(event: AgentStreamEvent): event is ResultEvent {
  return event.type === "result";
}

export function isSlashCommandResult(
  event: AgentStreamEvent,
): event is SlashCommandResultEvent {
  return (
    event.type === "slash_command_result" &&
    typeof (event as SlashCommandResultEvent).request_id === "string" &&
    typeof (event as SlashCommandResultEvent).command === "string" &&
    typeof (event as SlashCommandResultEvent).ok === "boolean"
  );
}
