/**
 * Instinct learning commands
 * chainlesschain instinct show|reset|categories
 */

import chalk from "chalk";
import { logger } from "../lib/logger.js";
import { bootstrap, shutdown } from "../runtime/bootstrap.js";
import {
  getInstincts,
  getStrongInstincts,
  exportInstincts,
  importInstincts,
  resetInstincts,
  deleteInstinct,
  decayInstincts,
  generateInstinctPrompt,
  INSTINCT_CATEGORIES,
  PROFILE_MATURITY_V2,
  OBSERVATION_LIFECYCLE_V2,
  getMaxActiveProfilesPerUserV2,
  setMaxActiveProfilesPerUserV2,
  getMaxPendingObsPerProfileV2,
  setMaxPendingObsPerProfileV2,
  getProfileIdleMsV2,
  setProfileIdleMsV2,
  getObsStuckMsV2,
  setObsStuckMsV2,
  getActiveProfileCountV2,
  getPendingObsCountV2,
  registerProfileV2,
  getProfileV2,
  listProfilesV2,
  activateProfileV2,
  dormantProfileV2,
  archiveProfileV2,
  touchProfileV2,
  createObservationV2,
  getObservationV2,
  listObservationsV2,
  reviewObservationV2,
  reinforceObservationV2,
  promoteObservationV2,
  discardObservationV2,
  autoDormantIdleProfilesV2,
  autoDiscardStaleObservationsV2,
  getInstinctManagerStatsV2,
} from "../lib/instinct-manager.js";

export function registerInstinctCommand(program) {
  const instinct = program
    .command("instinct")
    .description("Instinct learning — learned user preferences");

  // instinct show
  instinct
    .command("show", { isDefault: true })
    .description("Show learned instincts")
    .option("--category <cat>", "Filter by category")
    .option("-n, --limit <n>", "Max entries", "30")
    .option("--strong", "Show only high-confidence instincts (>= 70%)")
    .option("--json", "Output as JSON")
    .action(async (options) => {
      try {
        const ctx = await bootstrap({ verbose: program.opts().verbose });
        if (!ctx.db) {
          logger.error("Database not available");
          process.exit(1);
        }
        const db = ctx.db.getDatabase();

        const instincts = options.strong
          ? getStrongInstincts(db)
          : getInstincts(db, {
              category: options.category,
              limit: parseInt(options.limit) || 30,
            });

        if (options.json) {
          console.log(JSON.stringify(instincts, null, 2));
        } else if (instincts.length === 0) {
          logger.info(
            "No instincts learned yet. Use the agent to build up preferences.",
          );
        } else {
          logger.log(chalk.bold(`Learned Instincts (${instincts.length}):\n`));
          for (const inst of instincts) {
            const pct = (inst.confidence * 100).toFixed(0);
            // Clamp to [0,10] so a stored confidence outside [0,1]
            // (recordBatch upserts caller-supplied values unclamped) can't
            // make repeat() go negative and crash the whole list.
            const lvl = Math.max(
              0,
              Math.min(10, Math.round(inst.confidence * 10) || 0),
            );
            const bar = "█".repeat(lvl) + "░".repeat(10 - lvl);
            logger.log(
              `  ${chalk.gray(inst.id.slice(0, 8))}  ${chalk.cyan(inst.category.padEnd(18))} ${bar} ${pct}%`,
            );
            logger.log(`    ${chalk.white(inst.pattern)}`);
            logger.log(
              `    ${chalk.gray(`seen ${inst.occurrences}x | last: ${inst.last_seen || "unknown"}`)}`,
            );
          }
        }

        await shutdown();
      } catch (err) {
        logger.error(`Failed: ${err.message}`);
        process.exit(1);
      }
    });

  // instinct export — §8.3 cross-device backup: full dump of the instincts table
  instinct
    .command("export")
    .description("Export all instincts as JSON (module 101 §8.3 backup)")
    .option("--output <file>", "Write JSON array to file (default: stdout)")
    .option("--json", "Output JSON ({ok,count} with --output; array otherwise)")
    .action(async (options) => {
      try {
        const ctx = await bootstrap({ verbose: program.opts().verbose });
        if (!ctx.db) {
          logger.error("Database not available");
          process.exit(1);
        }
        const rows = exportInstincts(ctx.db.getDatabase());
        if (options.output) {
          const fs = await import("fs");
          fs.writeFileSync(options.output, JSON.stringify(rows), "utf-8");
          if (options.json) {
            console.log(
              JSON.stringify({
                ok: true,
                count: rows.length,
                output: options.output,
              }),
            );
          } else {
            logger.log(`exported ${rows.length} instincts → ${options.output}`);
          }
        } else {
          console.log(JSON.stringify(rows));
        }
        await shutdown();
      } catch (err) {
        logger.error(`instinct export failed: ${err.message}`);
        process.exit(1);
      }
    });

  // instinct import — §8.3 restore: idempotent upsert by id from a JSON-array file
  instinct
    .command("import")
    .description(
      "Import instincts from a JSON array file (idempotent upsert by id; §8.3)",
    )
    .requiredOption("--input <file>", "JSON array of instincts to import")
    .option("--json", "Output JSON result")
    .action(async (options) => {
      try {
        const fs = await import("fs");
        const rows = JSON.parse(fs.readFileSync(options.input, "utf-8"));
        if (!Array.isArray(rows)) {
          throw new Error("import: expected a JSON array of instincts");
        }
        const ctx = await bootstrap({ verbose: program.opts().verbose });
        if (!ctx.db) {
          logger.error("Database not available");
          process.exit(1);
        }
        const result = importInstincts(ctx.db.getDatabase(), rows);
        if (options.json) {
          console.log(JSON.stringify(result));
        } else {
          logger.log(`imported ${result.imported}, failed ${result.failed}`);
        }
        await shutdown();
        if (!result.ok) process.exitCode = 1;
      } catch (err) {
        logger.error(`instinct import failed: ${err.message}`);
        process.exit(1);
      }
    });

  // instinct categories
  instinct
    .command("categories")
    .description("List instinct categories")
    .action(async () => {
      logger.log(chalk.bold("Instinct Categories:\n"));
      for (const [key, value] of Object.entries(INSTINCT_CATEGORIES)) {
        logger.log(`  ${chalk.cyan(value.padEnd(20))} ${chalk.gray(key)}`);
      }
    });

  // instinct prompt
  instinct
    .command("prompt")
    .description("Generate a system prompt from learned instincts")
    .option("--json", "Output as JSON")
    .action(async (options) => {
      try {
        const ctx = await bootstrap({ verbose: program.opts().verbose });
        if (!ctx.db) {
          logger.error("Database not available");
          process.exit(1);
        }
        const db = ctx.db.getDatabase();
        const prompt = generateInstinctPrompt(db);

        if (options.json) {
          console.log(JSON.stringify({ prompt }, null, 2));
        } else if (!prompt) {
          logger.info("No strong instincts yet. Keep using the agent!");
        } else {
          logger.log(prompt);
        }

        await shutdown();
      } catch (err) {
        logger.error(`Failed: ${err.message}`);
        process.exit(1);
      }
    });

  // instinct delete
  instinct
    .command("delete")
    .description("Delete an instinct by ID")
    .argument("<id>", "Instinct ID (or prefix)")
    .action(async (id) => {
      try {
        const ctx = await bootstrap({ verbose: program.opts().verbose });
        if (!ctx.db) {
          logger.error("Database not available");
          process.exit(1);
        }
        const db = ctx.db.getDatabase();
        const ok = deleteInstinct(db, id);
        if (ok) {
          logger.success("Instinct deleted");
        } else {
          logger.error(`Instinct not found: ${id}`);
        }

        await shutdown();
      } catch (err) {
        logger.error(`Failed: ${err.message}`);
        process.exit(1);
      }
    });

  // instinct reset
  instinct
    .command("reset")
    .description("Reset all learned instincts")
    .option("--force", "Skip confirmation")
    .action(async (options) => {
      try {
        if (!options.force) {
          const { confirm } = await import("@inquirer/prompts");
          const ok = await confirm({
            message: "Reset all learned instincts? This cannot be undone.",
          });
          if (!ok) {
            logger.info("Cancelled");
            return;
          }
        }

        const ctx = await bootstrap({ verbose: program.opts().verbose });
        if (!ctx.db) {
          logger.error("Database not available");
          process.exit(1);
        }
        const db = ctx.db.getDatabase();
        const count = resetInstincts(db);
        logger.success(`Reset ${count} instincts`);

        await shutdown();
      } catch (err) {
        logger.error(`Failed: ${err.message}`);
        process.exit(1);
      }
    });

  // instinct decay
  instinct
    .command("decay")
    .description("Decay old instincts (reduce confidence of unused patterns)")
    .option("--days <n>", "Days threshold", "30")
    .action(async (options) => {
      try {
        const ctx = await bootstrap({ verbose: program.opts().verbose });
        if (!ctx.db) {
          logger.error("Database not available");
          process.exit(1);
        }
        const db = ctx.db.getDatabase();
        const decayed = decayInstincts(db, parseInt(options.days) || 30);
        logger.success(`Decayed ${decayed} old instincts`);

        await shutdown();
      } catch (err) {
        logger.error(`Failed: ${err.message}`);
        process.exit(1);
      }
    });

  // ─── V2 governance surface ─────────────────────────────────

  instinct
    .command("profile-maturities-v2")
    .description("List V2 profile maturity states")
    .action(() => {
      console.log(JSON.stringify(Object.values(PROFILE_MATURITY_V2), null, 2));
    });

  instinct
    .command("observation-lifecycles-v2")
    .description("List V2 observation lifecycle states")
    .action(() => {
      console.log(
        JSON.stringify(Object.values(OBSERVATION_LIFECYCLE_V2), null, 2),
      );
    });

  instinct
    .command("stats-v2")
    .description("Show V2 governance stats")
    .action(() => {
      console.log(JSON.stringify(getInstinctManagerStatsV2(), null, 2));
    });

  instinct
    .command("get-max-active-profiles-v2")
    .description("Get max active profiles per user")
    .action(() => console.log(getMaxActiveProfilesPerUserV2()));

  instinct
    .command("set-max-active-profiles-v2 <n>")
    .description("Set max active profiles per user")
    .action((n) => {
      setMaxActiveProfilesPerUserV2(Number(n));
      console.log(getMaxActiveProfilesPerUserV2());
    });

  instinct
    .command("get-max-pending-obs-v2")
    .description("Get max pending observations per profile")
    .action(() => console.log(getMaxPendingObsPerProfileV2()));

  instinct
    .command("set-max-pending-obs-v2 <n>")
    .description("Set max pending observations per profile")
    .action((n) => {
      setMaxPendingObsPerProfileV2(Number(n));
      console.log(getMaxPendingObsPerProfileV2());
    });

  instinct
    .command("get-profile-idle-ms-v2")
    .description("Get profile idle threshold (ms)")
    .action(() => console.log(getProfileIdleMsV2()));

  instinct
    .command("set-profile-idle-ms-v2 <n>")
    .description("Set profile idle threshold (ms)")
    .action((n) => {
      setProfileIdleMsV2(Number(n));
      console.log(getProfileIdleMsV2());
    });

  instinct
    .command("get-obs-stuck-ms-v2")
    .description("Get observation stuck threshold (ms)")
    .action(() => console.log(getObsStuckMsV2()));

  instinct
    .command("set-obs-stuck-ms-v2 <n>")
    .description("Set observation stuck threshold (ms)")
    .action((n) => {
      setObsStuckMsV2(Number(n));
      console.log(getObsStuckMsV2());
    });

  instinct
    .command("active-profile-count-v2 <userId>")
    .description("Count active profiles for a user")
    .action((userId) => console.log(getActiveProfileCountV2(userId)));

  instinct
    .command("pending-obs-count-v2 <profileId>")
    .description("Count pending observations for a profile")
    .action((profileId) => console.log(getPendingObsCountV2(profileId)));

  instinct
    .command("register-profile-v2 <id>")
    .description("Register a V2 profile")
    .requiredOption("-u, --user <userId>", "User id")
    .requiredOption("-c, --category <category>", "Category")
    .action((id, opts) => {
      const p = registerProfileV2(id, {
        userId: opts.user,
        category: opts.category,
      });
      console.log(JSON.stringify(p, null, 2));
    });

  instinct
    .command("get-profile-v2 <id>")
    .description("Get a V2 profile")
    .action((id) => {
      const p = getProfileV2(id);
      console.log(p ? JSON.stringify(p, null, 2) : "null");
    });

  instinct
    .command("list-profiles-v2")
    .description("List V2 profiles")
    .option("-u, --user <userId>", "Filter by user")
    .option("-c, --category <category>", "Filter by category")
    .option("-s, --status <status>", "Filter by status")
    .action((opts) => {
      console.log(
        JSON.stringify(
          listProfilesV2({
            userId: opts.user,
            category: opts.category,
            status: opts.status,
          }),
          null,
          2,
        ),
      );
    });

  instinct
    .command("activate-profile-v2 <id>")
    .description("pending|dormant → active")
    .action((id) =>
      console.log(JSON.stringify(activateProfileV2(id), null, 2)),
    );

  instinct
    .command("dormant-profile-v2 <id>")
    .description("active → dormant")
    .action((id) => console.log(JSON.stringify(dormantProfileV2(id), null, 2)));

  instinct
    .command("archive-profile-v2 <id>")
    .description("→ archived (terminal)")
    .action((id) => console.log(JSON.stringify(archiveProfileV2(id), null, 2)));

  instinct
    .command("touch-profile-v2 <id>")
    .description("Update lastSeenAt")
    .action((id) => console.log(JSON.stringify(touchProfileV2(id), null, 2)));

  instinct
    .command("create-observation-v2 <id>")
    .description("Create a V2 observation")
    .requiredOption("-p, --profile <profileId>", "Profile id")
    .requiredOption("-s, --signal <signal>", "Signal text")
    .action((id, opts) => {
      const o = createObservationV2(id, {
        profileId: opts.profile,
        signal: opts.signal,
      });
      console.log(JSON.stringify(o, null, 2));
    });

  instinct
    .command("get-observation-v2 <id>")
    .description("Get a V2 observation")
    .action((id) => {
      const o = getObservationV2(id);
      console.log(o ? JSON.stringify(o, null, 2) : "null");
    });

  instinct
    .command("list-observations-v2")
    .description("List V2 observations")
    .option("-p, --profile <profileId>", "Filter by profile")
    .option("-s, --status <status>", "Filter by status")
    .action((opts) => {
      console.log(
        JSON.stringify(
          listObservationsV2({
            profileId: opts.profile,
            status: opts.status,
          }),
          null,
          2,
        ),
      );
    });

  instinct
    .command("review-observation-v2 <id>")
    .description("captured → reviewed")
    .action((id) =>
      console.log(JSON.stringify(reviewObservationV2(id), null, 2)),
    );

  instinct
    .command("reinforce-observation-v2 <id>")
    .description("reviewed → reinforced")
    .action((id) =>
      console.log(JSON.stringify(reinforceObservationV2(id), null, 2)),
    );

  instinct
    .command("promote-observation-v2 <id>")
    .description("reviewed|reinforced → promoted (terminal)")
    .action((id) =>
      console.log(JSON.stringify(promoteObservationV2(id), null, 2)),
    );

  instinct
    .command("discard-observation-v2 <id>")
    .description("→ discarded (terminal)")
    .action((id) =>
      console.log(JSON.stringify(discardObservationV2(id), null, 2)),
    );

  instinct
    .command("auto-dormant-idle-profiles-v2")
    .description("Flip idle active profiles → dormant")
    .action(() =>
      console.log(JSON.stringify(autoDormantIdleProfilesV2(), null, 2)),
    );

  instinct
    .command("auto-discard-stale-observations-v2")
    .description("Flip stale captured/reviewed → discarded")
    .action(() =>
      console.log(JSON.stringify(autoDiscardStaleObservationsV2(), null, 2)),
    );
}

// === Iter18 V2 governance overlay ===
export function registerInstgovV2Commands(program) {
  const parent = program.commands.find((c) => c.name() === "instinct");
  if (!parent) return;
  const L = async () => await import("../lib/instinct-manager.js");
  parent
    .command("instgov-enums-v2")
    .description("Show V2 enums")
    .action(async () => {
      const m = await L();
      console.log(
        JSON.stringify(
          {
            profileMaturity: m.INSTGOV_PROFILE_MATURITY_V2,
            triggerLifecycle: m.INSTGOV_TRIGGER_LIFECYCLE_V2,
          },
          null,
          2,
        ),
      );
    });
  parent
    .command("instgov-config-v2")
    .description("Show V2 config")
    .action(async () => {
      const m = await L();
      console.log(
        JSON.stringify(
          {
            maxActive: m.getMaxActiveInstgovProfilesPerOwnerV2(),
            maxPending: m.getMaxPendingInstgovTriggersPerProfileV2(),
            idleMs: m.getInstgovProfileIdleMsV2(),
            stuckMs: m.getInstgovTriggerStuckMsV2(),
          },
          null,
          2,
        ),
      );
    });
  parent
    .command("instgov-set-max-active-v2 <n>")
    .description("Set max active")
    .action(async (n) => {
      (await L()).setMaxActiveInstgovProfilesPerOwnerV2(Number(n));
      console.log("ok");
    });
  parent
    .command("instgov-set-max-pending-v2 <n>")
    .description("Set max pending")
    .action(async (n) => {
      (await L()).setMaxPendingInstgovTriggersPerProfileV2(Number(n));
      console.log("ok");
    });
  parent
    .command("instgov-set-idle-ms-v2 <n>")
    .description("Set idle threshold ms")
    .action(async (n) => {
      (await L()).setInstgovProfileIdleMsV2(Number(n));
      console.log("ok");
    });
  parent
    .command("instgov-set-stuck-ms-v2 <n>")
    .description("Set stuck threshold ms")
    .action(async (n) => {
      (await L()).setInstgovTriggerStuckMsV2(Number(n));
      console.log("ok");
    });
  parent
    .command("instgov-register-v2 <id> <owner>")
    .description("Register V2 profile")
    .option("--priority <v>", "priority")
    .action(async (id, owner, o) => {
      const m = await L();
      console.log(
        JSON.stringify(
          m.registerInstgovProfileV2({ id, owner, priority: o.priority }),
          null,
          2,
        ),
      );
    });
  parent
    .command("instgov-activate-v2 <id>")
    .description("Activate profile")
    .action(async (id) => {
      console.log(
        JSON.stringify((await L()).activateInstgovProfileV2(id), null, 2),
      );
    });
  parent
    .command("instgov-dormant-v2 <id>")
    .description("Dormant profile")
    .action(async (id) => {
      console.log(
        JSON.stringify((await L()).dormantInstgovProfileV2(id), null, 2),
      );
    });
  parent
    .command("instgov-archive-v2 <id>")
    .description("Archive profile")
    .action(async (id) => {
      console.log(
        JSON.stringify((await L()).archiveInstgovProfileV2(id), null, 2),
      );
    });
  parent
    .command("instgov-touch-v2 <id>")
    .description("Touch profile")
    .action(async (id) => {
      console.log(
        JSON.stringify((await L()).touchInstgovProfileV2(id), null, 2),
      );
    });
  parent
    .command("instgov-get-v2 <id>")
    .description("Get profile")
    .action(async (id) => {
      console.log(JSON.stringify((await L()).getInstgovProfileV2(id), null, 2));
    });
  parent
    .command("instgov-list-v2")
    .description("List profiles")
    .action(async () => {
      console.log(JSON.stringify((await L()).listInstgovProfilesV2(), null, 2));
    });
  parent
    .command("instgov-create-trigger-v2 <id> <profileId>")
    .description("Create trigger")
    .option("--pattern <v>", "pattern")
    .action(async (id, profileId, o) => {
      const m = await L();
      console.log(
        JSON.stringify(
          m.createInstgovTriggerV2({ id, profileId, pattern: o.pattern }),
          null,
          2,
        ),
      );
    });
  parent
    .command("instgov-firing-trigger-v2 <id>")
    .description("Mark trigger as firing")
    .action(async (id) => {
      console.log(
        JSON.stringify((await L()).firingInstgovTriggerV2(id), null, 2),
      );
    });
  parent
    .command("instgov-complete-trigger-v2 <id>")
    .description("Complete trigger")
    .action(async (id) => {
      console.log(
        JSON.stringify((await L()).completeTriggerInstgovV2(id), null, 2),
      );
    });
  parent
    .command("instgov-fail-trigger-v2 <id> [reason]")
    .description("Fail trigger")
    .action(async (id, reason) => {
      console.log(
        JSON.stringify((await L()).failInstgovTriggerV2(id, reason), null, 2),
      );
    });
  parent
    .command("instgov-cancel-trigger-v2 <id> [reason]")
    .description("Cancel trigger")
    .action(async (id, reason) => {
      console.log(
        JSON.stringify((await L()).cancelInstgovTriggerV2(id, reason), null, 2),
      );
    });
  parent
    .command("instgov-get-trigger-v2 <id>")
    .description("Get trigger")
    .action(async (id) => {
      console.log(JSON.stringify((await L()).getInstgovTriggerV2(id), null, 2));
    });
  parent
    .command("instgov-list-triggers-v2")
    .description("List triggers")
    .action(async () => {
      console.log(JSON.stringify((await L()).listInstgovTriggersV2(), null, 2));
    });
  parent
    .command("instgov-auto-dormant-idle-v2")
    .description("Auto-dormant idle")
    .action(async () => {
      console.log(
        JSON.stringify((await L()).autoDormantIdleInstgovProfilesV2(), null, 2),
      );
    });
  parent
    .command("instgov-auto-fail-stuck-v2")
    .description("Auto-fail stuck triggers")
    .action(async () => {
      console.log(
        JSON.stringify((await L()).autoFailStuckInstgovTriggersV2(), null, 2),
      );
    });
  parent
    .command("instgov-gov-stats-v2")
    .description("V2 gov stats")
    .action(async () => {
      console.log(
        JSON.stringify((await L()).getInstinctManagerGovStatsV2(), null, 2),
      );
    });
}
