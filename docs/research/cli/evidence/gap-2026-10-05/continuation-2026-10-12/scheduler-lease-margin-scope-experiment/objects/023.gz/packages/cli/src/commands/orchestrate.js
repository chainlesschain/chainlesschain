/**
 * Orchestrate command — ChainlessChain as orchestration layer,
 * Claude Code / Codex as parallel execution agents.
 *
 * Usage:
 *   cc orchestrate "Fix the auth bug in login.ts"
 *   cc orchestrate "Refactor payment service" --agents 5 --ci "npm run test:unit"
 *   cc orchestrate --status
 *   cc orchestrate --watch --interval 10
 *   cc orchestrate detect        # Check which AI CLI is installed
 */

import chalk from "chalk";
import ora from "ora";
import fs from "fs";
import path from "path";
import { logger } from "../lib/logger.js";

function agentOptions(options) {
  if (options.cliTool && options.backends)
    throw new Error("Choose --cli-tool or --backends, not both");
  if (options.cliTool && !["claude", "codex"].includes(options.cliTool))
    throw new Error("--cli-tool must be claude or codex");
  const selected = options.backends || options.cliTool;
  const config = { strategy: options.strategy || "round-robin" };
  if (selected) {
    const types = selected.split(",").map((s) => s.trim());
    if (
      types.some(
        (type) =>
          ![
            "claude",
            "codex",
            "gemini",
            "openai",
            "anthropic",
            "ollama",
          ].includes(type),
      )
    ) {
      throw new Error("Unknown orchestrate backend; see orchestrate --help");
    }
    config.backends = types.map((type) => ({ type, weight: 1 }));
  }
  return config;
}

export function registerOrchestrateCommand(program, dependencies = {}) {
  const evolutionCompositionFactory =
    dependencies.evolutionCompositionFactory ?? null;
  const cmd = program
    .command("orchestrate [task]")
    .description(
      "Orchestrate AI coding tasks (experimental): API text generation only; external Claude/Codex execution is blocked pending governance admission. Use cc agent for tool execution.",
    )
    .option("-a, --agents <n>", "Max parallel agents", "3")
    .option(
      "--ci <command>",
      "CI command to run after agents complete",
      "npm test",
    )
    .option("--no-ci", "Skip CI/CD verification step")
    .option(
      "--source <type>",
      "Input source: cli|sentry|github|file|wecom|dingtalk|feishu",
      "cli",
    )
    .option("--file <path>", "Read task from file (use with --source file)")
    .option("--context <text>", "Extra context for the task (e.g. stack trace)")
    .option("--cwd <path>", "Project root directory (default: current dir)")
    .option("--provider <name>", "LLM provider for decomposition")
    .option("--model <name>", "Model for decomposition LLM calls")
    .option(
      "--cli-tool <name>",
      "Select claude|codex (currently blocked by governance preflight)",
    )
    .option(
      "--backends <list>",
      "Backends: claude,codex (blocked), gemini,openai,anthropic,ollama (text only)",
    )
    .option(
      "--strategy <name>",
      "Agent routing: round-robin|by-type|parallel-all|primary",
      "round-robin",
    )
    .option("--retries <n>", "Max CI retry cycles", "3")
    .option("--timeout <sec>", "Per-agent timeout in seconds", "300")
    .option("--no-notify", "Disable notifications")
    .option("--status", "Show orchestrator and agent pool status")
    .option("--watch", "Start cron watch mode")
    .option("--interval <min>", "Cron interval in minutes (watch mode)", "10")
    .option("--webhook", "Start HTTP webhook server for IM platform commands")
    .option("--webhook-port <port>", "Webhook server port", "18820")
    .option(
      "--webhook-secret-env <name>",
      "Environment variable containing the webhook HMAC secret",
      "CC_ORCHESTRATE_WEBHOOK_SECRET",
    )
    .option(
      "--webhook-auth-mode <mode>",
      "Webhook authentication: cc|vendor",
      "cc",
    )
    .option(
      "--webhook-max-body-bytes <n>",
      "Maximum authenticated webhook request body",
      "262144",
    )
    .option(
      "--webhook-rate-limit <n>",
      "Maximum webhook requests per source and minute",
      "30",
    )
    .option("--json", "Output as JSON")
    .option("--verbose", "Verbose output");

  cmd.action(async (task, options) => {
    // Special sub-keyword: cc orchestrate detect
    if (task === "detect") {
      const { detectClaudeCode, detectCodex } =
        await import("../lib/claude-code-bridge.js");
      const claude = detectClaudeCode();
      const codex = detectCodex();
      const { AgentRouter } = await import("../lib/agent-router.js");
      const backends = new AgentRouter({
        backends: [
          { type: "claude", installed: claude.found },
          { type: "codex", installed: codex.found },
        ],
      }).summary();
      if (options.json) {
        console.log(
          JSON.stringify(
            { cliTools: { claude, codex }, backends, alternative: "cc agent" },
            null,
            2,
          ),
        );
        return;
      }
      console.log(chalk.bold("\n\uD83D\uDD0D AI CLI Detection\n"));
      console.log(
        claude.found
          ? chalk.yellow(
              `  claude  ${claude.version} — installed, execution blocked`,
            )
          : chalk.red(
              "  \u2717 claude  not found (install: npm i -g @anthropic-ai/claude-code)",
            ),
      );
      console.log(
        codex.found
          ? chalk.yellow(
              `  codex   ${codex.version} — installed, execution blocked`,
            )
          : chalk.gray("  \u2717 codex   not found"),
      );
      console.log(
        chalk.yellow(
          "\n  External CLI model requests cannot be attested; installing a CLI does not enable execution. Use cc agent for tool execution.\n",
        ),
      );
      return;
    }

    const { Orchestrator } = await import("../lib/orchestrator.js");

    const cwd = options.cwd ? path.resolve(options.cwd) : process.cwd();

    // --status mode
    if (options.status) {
      await _showStatus(cwd, options);
      return;
    }

    // --watch mode
    if (options.watch) {
      await _watchMode(cwd, options, evolutionCompositionFactory);
      return;
    }

    // --webhook mode: start HTTP server to receive commands from IM platforms
    if (options.webhook) {
      await _webhookMode(cwd, options, evolutionCompositionFactory);
      return;
    }

    // Resolve task text
    let taskText = task || "";
    if (options.source === "file" && options.file) {
      try {
        taskText = fs.readFileSync(path.resolve(options.file), "utf-8").trim();
      } catch (err) {
        logger.error(`Cannot read file: ${err.message}`);
        process.exit(1);
      }
    }

    if (!taskText) {
      console.log(
        chalk.yellow('Usage: cc orchestrate "<task description>"') +
          chalk.gray(
            "\n       cc orchestrate --status\n       cc orchestrate --watch\n       cc orchestrate --webhook  # receive commands from WeCom/DingTalk/Feishu\n",
          ),
      );
      process.exit(1);
    }

    // Build agent backends from --backends option
    const agentsConfig = agentOptions(options);

    // Build orchestrator
    const orch = new Orchestrator({
      cwd,
      maxParallel: parseInt(options.agents, 10) || 3,
      maxRetries: parseInt(options.retries, 10) || 3,
      ciCommand: options.ci || "npm test",
      agents: agentsConfig,
      model: options.model || undefined,
      llm: options.provider
        ? { provider: options.provider, model: options.model }
        : {},
      verbose: options.verbose,
      evolutionCompositionFactory,
    });

    if (options.json) {
      _runJson(orch, taskText, options);
      return;
    }

    // Pretty output
    _runPretty(orch, taskText, options, cwd);
  });

  // ===== V2 governance subcommands (agent-router V2) =====
  const router = program
    .command("router")
    .description("Agent router V2 governance");
  router
    .command("maturities-v2")
    .description("List router profile maturity states (V2)")
    .action(async () => {
      const m = await import("../lib/agent-router.js");
      console.log(JSON.stringify(m.ROUTER_PROFILE_MATURITY_V2, null, 2));
    });
  router
    .command("dispatch-lifecycle-v2")
    .description("List router dispatch lifecycle states (V2)")
    .action(async () => {
      const m = await import("../lib/agent-router.js");
      console.log(JSON.stringify(m.ROUTER_DISPATCH_LIFECYCLE_V2, null, 2));
    });
  router
    .command("stats-v2")
    .description("Show agent-router V2 stats")
    .action(async () => {
      const m = await import("../lib/agent-router.js");
      console.log(JSON.stringify(m.getAgentRouterStatsV2(), null, 2));
    });
  router
    .command("config-v2")
    .description("Show agent-router V2 config")
    .action(async () => {
      const m = await import("../lib/agent-router.js");
      console.log(
        JSON.stringify(
          {
            maxActiveProfilesPerOwner: m.getMaxActiveProfilesPerOwnerRouterV2(),
            maxPendingDispatchesPerProfile:
              m.getMaxPendingDispatchesPerProfileV2(),
            profileIdleMs: m.getProfileIdleMsRouterV2(),
            dispatchStuckMs: m.getDispatchStuckMsV2(),
          },
          null,
          2,
        ),
      );
    });
  router
    .command("register-profile-v2 <id> <owner>")
    .description("Register a router profile (V2)")
    .action(async (id, owner) => {
      const m = await import("../lib/agent-router.js");
      console.log(
        JSON.stringify(m.registerRouterProfileV2({ id, owner }), null, 2),
      );
    });
  router.command("activate-profile-v2 <id>").action(async (id) => {
    const m = await import("../lib/agent-router.js");
    console.log(JSON.stringify(m.activateRouterProfileV2(id), null, 2));
  });
  router.command("degrade-profile-v2 <id>").action(async (id) => {
    const m = await import("../lib/agent-router.js");
    console.log(JSON.stringify(m.degradeRouterProfileV2(id), null, 2));
  });
  router.command("retire-profile-v2 <id>").action(async (id) => {
    const m = await import("../lib/agent-router.js");
    console.log(JSON.stringify(m.retireRouterProfileV2(id), null, 2));
  });
  router.command("touch-profile-v2 <id>").action(async (id) => {
    const m = await import("../lib/agent-router.js");
    console.log(JSON.stringify(m.touchRouterProfileV2(id), null, 2));
  });
  router.command("get-profile-v2 <id>").action(async (id) => {
    const m = await import("../lib/agent-router.js");
    console.log(JSON.stringify(m.getRouterProfileV2(id), null, 2));
  });
  router.command("list-profiles-v2").action(async () => {
    const m = await import("../lib/agent-router.js");
    console.log(JSON.stringify(m.listRouterProfilesV2(), null, 2));
  });
  router
    .command("create-dispatch-v2 <id> <profileId> [task]")
    .action(async (id, profileId, task) => {
      const m = await import("../lib/agent-router.js");
      console.log(
        JSON.stringify(m.createDispatchV2({ id, profileId, task }), null, 2),
      );
    });
  router.command("dispatch-v2 <id>").action(async (id) => {
    const m = await import("../lib/agent-router.js");
    console.log(JSON.stringify(m.dispatchDispatchV2(id), null, 2));
  });
  router.command("complete-dispatch-v2 <id>").action(async (id) => {
    const m = await import("../lib/agent-router.js");
    console.log(JSON.stringify(m.completeDispatchV2(id), null, 2));
  });
  router
    .command("fail-dispatch-v2 <id> [reason]")
    .action(async (id, reason) => {
      const m = await import("../lib/agent-router.js");
      console.log(JSON.stringify(m.failDispatchV2(id, reason), null, 2));
    });
  router
    .command("cancel-dispatch-v2 <id> [reason]")
    .action(async (id, reason) => {
      const m = await import("../lib/agent-router.js");
      console.log(JSON.stringify(m.cancelDispatchV2(id, reason), null, 2));
    });
  router.command("get-dispatch-v2 <id>").action(async (id) => {
    const m = await import("../lib/agent-router.js");
    console.log(JSON.stringify(m.getDispatchV2(id), null, 2));
  });
  router.command("list-dispatches-v2").action(async () => {
    const m = await import("../lib/agent-router.js");
    console.log(JSON.stringify(m.listDispatchesV2(), null, 2));
  });
  router.command("auto-degrade-idle-v2").action(async () => {
    const m = await import("../lib/agent-router.js");
    console.log(JSON.stringify(m.autoDegradeIdleProfilesRouterV2(), null, 2));
  });
  router.command("auto-fail-stuck-v2").action(async () => {
    const m = await import("../lib/agent-router.js");
    console.log(JSON.stringify(m.autoFailStuckDispatchesV2(), null, 2));
  });
  router.command("set-max-active-profiles-v2 <n>").action(async (n) => {
    const m = await import("../lib/agent-router.js");
    m.setMaxActiveProfilesPerOwnerRouterV2(parseInt(n, 10));
    console.log(
      JSON.stringify(
        { maxActiveProfilesPerOwner: m.getMaxActiveProfilesPerOwnerRouterV2() },
        null,
        2,
      ),
    );
  });
  router.command("set-max-pending-dispatches-v2 <n>").action(async (n) => {
    const m = await import("../lib/agent-router.js");
    m.setMaxPendingDispatchesPerProfileV2(parseInt(n, 10));
    console.log(
      JSON.stringify(
        {
          maxPendingDispatchesPerProfile:
            m.getMaxPendingDispatchesPerProfileV2(),
        },
        null,
        2,
      ),
    );
  });
  router.command("set-profile-idle-ms-v2 <n>").action(async (n) => {
    const m = await import("../lib/agent-router.js");
    m.setProfileIdleMsRouterV2(parseInt(n, 10));
    console.log(
      JSON.stringify({ profileIdleMs: m.getProfileIdleMsRouterV2() }, null, 2),
    );
  });
  router.command("set-dispatch-stuck-ms-v2 <n>").action(async (n) => {
    const m = await import("../lib/agent-router.js");
    m.setDispatchStuckMsV2(parseInt(n, 10));
    console.log(
      JSON.stringify({ dispatchStuckMs: m.getDispatchStuckMsV2() }, null, 2),
    );
  });
  router.command("reset-state-v2").action(async () => {
    const m = await import("../lib/agent-router.js");
    m._resetStateAgentRouterV2();
    console.log(JSON.stringify({ ok: true }, null, 2));
  });
}

// ─── Pretty (interactive) run ────────────────────────────────────

async function _runPretty(orch, taskText, options, cwd) {
  console.log(chalk.bold.cyan("\n⚡ ChainlessChain Orchestrator\n"));
  console.log(chalk.gray(`  Task:    `) + chalk.white(taskText.slice(0, 120)));
  console.log(chalk.gray(`  CWD:     `) + chalk.white(cwd));
  console.log(
    chalk.gray(`  Agents:  `) +
      chalk.white(`max ${options.agents} × ${orch.cliCommand}`),
  );
  if (options.ci !== false) {
    console.log(chalk.gray(`  CI:      `) + chalk.white(orch.ciCommand));
  }
  console.log();

  const spinner = ora("Decomposing task...").start();

  orch.on("task:decomposed", ({ subtasks }) => {
    spinner.text = `Decomposed into ${subtasks.length} subtask(s)`;
  });

  orch.on("agents:dispatched", ({ count }) => {
    spinner.text = `Dispatching ${count} subtask(s) to ${orch.cliCommand} agents...`;
  });

  orch.on("batch:start", ({ count }) => {
    spinner.text = `Running batch of ${count} agent(s)...`;
  });

  orch.on("agent:complete", ({ taskId, success, duration }) => {
    const icon = success ? chalk.green("✓") : chalk.red("✗");
    spinner.text = `Agent done: ${icon} ${taskId} (${Math.round(duration / 1000)}s)`;
  });

  orch.on("ci:checking", ({ attempt }) => {
    spinner.text = `Running CI check (attempt ${attempt + 1})...`;
  });

  orch.on("ci:fail", ({ attempt }) => {
    spinner.text = `CI failed (attempt ${attempt + 1}) — retrying with agents...`;
  });

  orch.on("task:complete", (task) => {
    spinner.succeed(
      chalk.green(`✅ Task completed`) +
        chalk.gray(` [${task.id}]  status: ${task.status}`),
    );
    _printSummary(task);
  });

  orch.on("task:failed", ({ task, error }) => {
    spinner.fail(chalk.red(`❌ Task failed: ${error}`));
    _printSummary(task);
  });

  orch.on("log", (msg) => {
    if (options.verbose) spinner.text = msg;
  });

  try {
    const { TASK_SOURCE } = await import("../lib/orchestrator.js");
    await orch.addTask(taskText, {
      source:
        options.source === "sentry"
          ? TASK_SOURCE.SENTRY
          : options.source === "github"
            ? TASK_SOURCE.GITHUB
            : options.source === "file"
              ? TASK_SOURCE.FILE
              : TASK_SOURCE.CLI,
      context: options.context || "",
      cwd,
      runCI: options.ci !== false,
      notify: options.notify !== false,
    });
  } catch (err) {
    spinner.fail(chalk.red(`Orchestration error: ${err.message}`));
    if (options.verbose) console.error(err);
    process.exit(1);
  }
}

// ─── JSON run ────────────────────────────────────────────────────

async function _runJson(orch, taskText, options) {
  const { TASK_SOURCE } = await import("../lib/orchestrator.js");
  try {
    const task = await orch.addTask(taskText, {
      source: TASK_SOURCE.CLI,
      context: options.context || "",
      runCI: options.ci !== false,
      notify: false,
    });
    console.log(JSON.stringify(task, null, 2));
  } catch (err) {
    console.log(JSON.stringify({ error: err.message }, null, 2));
    process.exit(1);
  }
}

// ─── Status ──────────────────────────────────────────────────────

async function _showStatus(cwd, options) {
  const { detectClaudeCode, detectCodex } =
    await import("../lib/claude-code-bridge.js");
  const claude = detectClaudeCode();
  const codex = detectCodex();

  const status = {
    cliTools: {
      claude: claude.found ? claude.version : "not found",
      codex: codex.found ? codex.version : "not found",
    },
    activeCliTool: "none",
    alternative: "cc agent",
  };

  const { AgentRouter } = await import("../lib/agent-router.js");
  const config = agentOptions(options);
  const router = config.backends
    ? new AgentRouter({
        ...config,
        backends: config.backends.map((b) => ({
          ...b,
          installed: { claude, codex }[b.type]?.found ?? null,
        })),
      })
    : AgentRouter.autoDetect({ ...config, cliDetections: { claude, codex } });
  const backends = router.summary();

  if (options.json) {
    console.log(JSON.stringify({ ...status, backends }, null, 2));
    return;
  }

  console.log(chalk.bold.cyan("\n⚡ Orchestrator Status\n"));
  console.log(chalk.bold("  CLI Tools"));
  console.log(
    `    ${chalk.gray("claude:")}  ` +
      (claude.found ? chalk.green(claude.version) : chalk.red("not installed")),
  );
  console.log(
    `    ${chalk.gray("codex:")}   ` +
      (codex.found ? chalk.green(codex.version) : chalk.gray("not installed")),
  );
  console.log();
  console.log(chalk.bold("  Auto-detected Backends"));
  for (const b of backends) {
    const icon = b.kind === "cli" ? "🖥" : "🌐";
    console.log(
      `    ${icon} ${chalk.cyan(b.type.padEnd(12))} ${b.executionMode} — ${b.blockedReason}`,
    );
  }

  console.log(
    chalk.yellow(
      "  Installed/configured does not mean runnable. Use cc agent for tool execution.",
    ),
  );

  console.log();
  console.log(chalk.bold("  Notification Channels"));
  const { NotificationManager } = await import("../lib/notifiers/index.js");
  const nm = NotificationManager.fromEnv();
  const channels = nm.activeChannels;
  if (channels.length === 0) {
    console.log(
      chalk.gray(
        "    (none configured — set TELEGRAM_BOT_TOKEN, WECOM_WEBHOOK_URL, etc.)",
      ),
    );
  } else {
    for (const ch of channels) {
      console.log(`    ${chalk.green("✓")} ${ch}`);
    }
  }
  console.log();
}

// ─── Webhook mode (receive commands from IM platforms) ─────────────

async function _webhookMode(cwd, options, evolutionCompositionFactory = null) {
  const { createServer } = await import("http");
  const { parseDingTalkIncoming, parseFeishuIncoming, parseWeComIncoming } =
    await import("../lib/notifiers/index.js");
  const { Orchestrator } = await import("../lib/orchestrator.js");
  const { WebhookSecurityGate } = await import("../lib/webhook-security.js");

  const port = parseInt(options.webhookPort, 10) || 18820;

  const orch = new Orchestrator({
    cwd,
    agents: agentOptions(options),
    verbose: options.verbose,
    evolutionCompositionFactory,
  });
  const secretEnvironmentName =
    options.webhookSecretEnv || "CC_ORCHESTRATE_WEBHOOK_SECRET";
  if (!/^[A-Z_][A-Z0-9_]{0,127}$/u.test(secretEnvironmentName)) {
    throw new Error("--webhook-secret-env must be a valid environment name");
  }
  const webhookAuthMode = String(options.webhookAuthMode || "cc").toLowerCase();
  if (!new Set(["cc", "vendor"]).has(webhookAuthMode)) {
    throw new Error("--webhook-auth-mode must be cc or vendor");
  }
  const securityGate = new WebhookSecurityGate({
    authMode: webhookAuthMode,
    secret:
      webhookAuthMode === "cc" ? process.env[secretEnvironmentName] : undefined,
    vendorCredentials: {
      dingtalkSecret:
        process.env.CC_ORCHESTRATE_DINGTALK_SECRET ||
        process.env.DINGTALK_SECRET,
      feishuEncryptKey:
        process.env.CC_ORCHESTRATE_FEISHU_ENCRYPT_KEY ||
        process.env.FEISHU_ENCRYPT_KEY,
      wecomToken:
        process.env.CC_ORCHESTRATE_WECOM_TOKEN || process.env.WECOM_TOKEN,
      wecomEncodingAesKey:
        process.env.CC_ORCHESTRATE_WECOM_ENCODING_AES_KEY ||
        process.env.WECOM_ENCODING_AES_KEY,
      wecomReceiveId:
        process.env.CC_ORCHESTRATE_WECOM_RECEIVE_ID ||
        process.env.WECOM_RECEIVE_ID,
    },
    maxRequestsPerMinute: parseInt(options.webhookRateLimit, 10) || 30,
  });
  const maxBodyBytes = Math.max(
    1,
    parseInt(options.webhookMaxBodyBytes, 10) || 262144,
  );

  const server = createServer(async (req, res) => {
    const requestUrl = new URL(req.url || "/", "http://127.0.0.1");
    const url = requestUrl.pathname;
    const query = Object.fromEntries(requestUrl.searchParams.entries());
    const channel =
      url === "/wecom"
        ? "wecom"
        : url === "/dingtalk"
          ? "dingtalk"
          : url === "/feishu"
            ? "feishu"
            : null;
    if (!channel) {
      res.writeHead(404);
      res.end("Not Found");
      return;
    }
    if (
      req.method === "GET" &&
      channel === "wecom" &&
      webhookAuthMode === "vendor"
    ) {
      try {
        const verified = securityGate.verifyWeComUrl({
          query,
          remoteAddress: req.socket.remoteAddress || "unknown",
        });
        res.writeHead(200, { "Content-Type": "text/plain; charset=utf-8" });
        res.end(verified.echo);
      } catch (error) {
        if (error?.retryAfterSeconds) {
          res.setHeader("Retry-After", String(error.retryAfterSeconds));
        }
        res.writeHead(error?.statusCode || 401);
        res.end("Unauthorized");
      }
      return;
    }
    if (req.method !== "POST") {
      res.writeHead(405);
      res.end("Method Not Allowed");
      return;
    }
    if (Number(req.headers["content-length"] || 0) > maxBodyBytes) {
      res.writeHead(413);
      res.end("Payload Too Large");
      req.resume();
      return;
    }
    const bodyChunks = [];
    let bodyBytes = 0;
    let bodyRejected = false;
    req.on("data", (chunk) => {
      if (bodyRejected) return;
      bodyBytes += chunk.length;
      if (bodyBytes > maxBodyBytes) {
        bodyRejected = true;
        res.writeHead(413);
        res.end("Payload Too Large");
        return;
      }
      bodyChunks.push(chunk);
    });
    req.on("end", async () => {
      if (bodyRejected) return;
      // Decode once: per-chunk toString() would corrupt a multi-byte UTF-8
      // char (e.g. Chinese IM webhook text) split across a chunk boundary.
      let body = Buffer.concat(bodyChunks).toString("utf-8");
      let taskText = null;
      let source = `webhook:${channel}`;
      let verified;

      try {
        verified = securityGate.verify({
          channel,
          headers: req.headers,
          body,
          query,
          remoteAddress: req.socket.remoteAddress || "unknown",
        });
        body = verified.body;
      } catch (error) {
        if (error?.retryAfterSeconds) {
          res.setHeader("Retry-After", String(error.retryAfterSeconds));
        }
        res.writeHead(error?.statusCode || 401);
        res.end("Unauthorized");
        return;
      }

      try {
        if (url === "/wecom") {
          taskText = parseWeComIncoming(body);
        } else if (url === "/dingtalk") {
          const parsed = JSON.parse(body);
          taskText = parseDingTalkIncoming(parsed);
        } else if (url === "/feishu") {
          const parsed = JSON.parse(body);
          // Feishu challenge verification
          if (parsed.challenge) {
            res.writeHead(200, { "Content-Type": "application/json" });
            res.end(JSON.stringify({ challenge: parsed.challenge }));
            return;
          }
          taskText = parseFeishuIncoming(parsed);
        }
      } catch {
        res.writeHead(400);
        res.end("Bad Request");
        return;
      }

      if (!taskText) {
        res.writeHead(200, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ ok: true, message: "no task detected" }));
        return;
      }

      // Acknowledge immediately (IM platforms require fast response)
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(
        JSON.stringify({
          ok: true,
          message: `task queued: ${taskText.slice(0, 60)}`,
        }),
      );

      // Run orchestration async
      if (!options.json) {
        console.log(
          chalk.cyan(`[webhook] Received task: `) + taskText.slice(0, 80),
        );
      }
      orch
        .addTask(taskText, {
          source,
          cwd,
          dataPolicy: verified.dataPolicy,
          runCI: options.ci !== false,
          notify: true,
        })
        .catch((err) =>
          console.error(chalk.red(`[webhook] Error: ${err.message}`)),
        );
    });
  });

  server.listen(port, "127.0.0.1", () => {
    console.log(chalk.bold.cyan("\n⚡ Orchestrator Webhook Server\n"));
    console.log(
      `  ${chalk.gray("WeCom:")}    POST http://localhost:${port}/wecom`,
    );
    console.log(
      `  ${chalk.gray("DingTalk:")} POST http://localhost:${port}/dingtalk`,
    );
    console.log(
      `  ${chalk.gray("Feishu:")}   POST http://localhost:${port}/feishu`,
    );
    console.log(`  ${chalk.gray("Auth:")}     ${webhookAuthMode}`);
    console.log(chalk.gray("\n  Press Ctrl+C to stop\n"));
  });

  process.on("SIGINT", () => {
    server.close();
    orch.stopCronWatch();
    console.log(chalk.gray("\nWebhook server stopped."));
    process.exit(0);
  });
}

// ─── Watch mode ──────────────────────────────────────────────────

async function _watchMode(cwd, options, evolutionCompositionFactory = null) {
  const { Orchestrator } = await import("../lib/orchestrator.js");
  const intervalMs = parseInt(options.interval, 10) * 60_000 || 600_000;

  const orch = new Orchestrator({
    cwd,
    agents: agentOptions(options),
    verbose: options.verbose,
    evolutionCompositionFactory,
  });
  orch.startCronWatch(intervalMs);

  orch.on("cron:tick", ({ at }) => {
    if (!options.json) console.log(chalk.gray(`[cron] tick at ${at}`));
  });

  console.log(
    chalk.cyan(`\n⚡ Orchestrator watch mode started`) +
      chalk.gray(` (interval: ${options.interval}m)`),
  );
  console.log(chalk.gray("  Press Ctrl+C to stop\n"));

  // Keep alive
  process.on("SIGINT", () => {
    orch.stopCronWatch();
    console.log(chalk.gray("\nOrchestrator stopped."));
    process.exit(0);
  });
}

// ─── Summary printer ─────────────────────────────────────────────

function _printSummary(task) {
  console.log();
  console.log(chalk.bold("  Summary"));
  console.log(chalk.gray("  ─────────────────────────────────"));
  console.log(`  ID:       ${chalk.cyan(task.id)}`);
  console.log(`  Source:   ${task.source}`);
  console.log(`  Retries:  ${task.retries}`);
  console.log(`  Status:   ${_statusColor(task.status)}`);

  if (task.subtasks?.length) {
    console.log(`  Subtasks: ${task.subtasks.length}`);
  }

  if (task.agentResults?.length) {
    const passed = task.agentResults.filter((r) => r.success).length;
    console.log(
      `  Agents:   ${chalk.green(passed)} passed / ${chalk.red(task.agentResults.length - passed)} failed`,
    );
  }
  console.log();
}

function _statusColor(status) {
  const colors = {
    completed: chalk.green,
    "ci-passed": chalk.green,
    failed: chalk.red,
    "ci-failed": chalk.red,
    retrying: chalk.yellow,
    dispatched: chalk.cyan,
    "ci-checking": chalk.cyan,
  };
  return (colors[status] || chalk.white)(status);
}

// === Iter17 V2 governance overlay ===
export function registerCcbgovV2Commands(program) {
  const parent = program.commands.find((c) => c.name() === "orchestrate");
  if (!parent) return;
  const L = async () => await import("../lib/claude-code-bridge.js");
  parent
    .command("ccbgov-enums-v2")
    .description("Show V2 enums")
    .action(async () => {
      const m = await L();
      console.log(
        JSON.stringify(
          {
            profileMaturity: m.CCBGOV_PROFILE_MATURITY_V2,
            invocationLifecycle: m.CCBGOV_INVOCATION_LIFECYCLE_V2,
          },
          null,
          2,
        ),
      );
    });
  parent
    .command("ccbgov-config-v2")
    .description("Show V2 config")
    .action(async () => {
      const m = await L();
      console.log(
        JSON.stringify(
          {
            maxActive: m.getMaxActiveCcbgovProfilesPerOwnerV2(),
            maxPending: m.getMaxPendingCcbgovInvocationsPerProfileV2(),
            idleMs: m.getCcbgovProfileIdleMsV2(),
            stuckMs: m.getCcbgovInvocationStuckMsV2(),
          },
          null,
          2,
        ),
      );
    });
  parent
    .command("ccbgov-set-max-active-v2 <n>")
    .description("Set max active")
    .action(async (n) => {
      (await L()).setMaxActiveCcbgovProfilesPerOwnerV2(Number(n));
      console.log("ok");
    });
  parent
    .command("ccbgov-set-max-pending-v2 <n>")
    .description("Set max pending")
    .action(async (n) => {
      (await L()).setMaxPendingCcbgovInvocationsPerProfileV2(Number(n));
      console.log("ok");
    });
  parent
    .command("ccbgov-set-idle-ms-v2 <n>")
    .description("Set idle threshold ms")
    .action(async (n) => {
      (await L()).setCcbgovProfileIdleMsV2(Number(n));
      console.log("ok");
    });
  parent
    .command("ccbgov-set-stuck-ms-v2 <n>")
    .description("Set stuck threshold ms")
    .action(async (n) => {
      (await L()).setCcbgovInvocationStuckMsV2(Number(n));
      console.log("ok");
    });
  parent
    .command("ccbgov-register-v2 <id> <owner>")
    .description("Register V2 profile")
    .option("--channel <v>", "channel")
    .action(async (id, owner, o) => {
      const m = await L();
      console.log(
        JSON.stringify(
          m.registerCcbgovProfileV2({ id, owner, channel: o.channel }),
          null,
          2,
        ),
      );
    });
  parent
    .command("ccbgov-activate-v2 <id>")
    .description("Activate profile")
    .action(async (id) => {
      console.log(
        JSON.stringify((await L()).activateCcbgovProfileV2(id), null, 2),
      );
    });
  parent
    .command("ccbgov-degrade-v2 <id>")
    .description("Degrade profile")
    .action(async (id) => {
      console.log(
        JSON.stringify((await L()).degradeCcbgovProfileV2(id), null, 2),
      );
    });
  parent
    .command("ccbgov-archive-v2 <id>")
    .description("Archive profile")
    .action(async (id) => {
      console.log(
        JSON.stringify((await L()).archiveCcbgovProfileV2(id), null, 2),
      );
    });
  parent
    .command("ccbgov-touch-v2 <id>")
    .description("Touch profile")
    .action(async (id) => {
      console.log(
        JSON.stringify((await L()).touchCcbgovProfileV2(id), null, 2),
      );
    });
  parent
    .command("ccbgov-get-v2 <id>")
    .description("Get profile")
    .action(async (id) => {
      console.log(JSON.stringify((await L()).getCcbgovProfileV2(id), null, 2));
    });
  parent
    .command("ccbgov-list-v2")
    .description("List profiles")
    .action(async () => {
      console.log(JSON.stringify((await L()).listCcbgovProfilesV2(), null, 2));
    });
  parent
    .command("ccbgov-create-invocation-v2 <id> <profileId>")
    .description("Create invocation")
    .option("--command <v>", "command")
    .action(async (id, profileId, o) => {
      const m = await L();
      console.log(
        JSON.stringify(
          m.createCcbgovInvocationV2({ id, profileId, command: o.command }),
          null,
          2,
        ),
      );
    });
  parent
    .command("ccbgov-running-invocation-v2 <id>")
    .description("Mark invocation as running")
    .action(async (id) => {
      console.log(
        JSON.stringify((await L()).runningCcbgovInvocationV2(id), null, 2),
      );
    });
  parent
    .command("ccbgov-complete-invocation-v2 <id>")
    .description("Complete invocation")
    .action(async (id) => {
      console.log(
        JSON.stringify((await L()).completeInvocationCcbgovV2(id), null, 2),
      );
    });
  parent
    .command("ccbgov-fail-invocation-v2 <id> [reason]")
    .description("Fail invocation")
    .action(async (id, reason) => {
      console.log(
        JSON.stringify((await L()).failCcbgovInvocationV2(id, reason), null, 2),
      );
    });
  parent
    .command("ccbgov-cancel-invocation-v2 <id> [reason]")
    .description("Cancel invocation")
    .action(async (id, reason) => {
      console.log(
        JSON.stringify(
          (await L()).cancelCcbgovInvocationV2(id, reason),
          null,
          2,
        ),
      );
    });
  parent
    .command("ccbgov-get-invocation-v2 <id>")
    .description("Get invocation")
    .action(async (id) => {
      console.log(
        JSON.stringify((await L()).getCcbgovInvocationV2(id), null, 2),
      );
    });
  parent
    .command("ccbgov-list-invocations-v2")
    .description("List invocations")
    .action(async () => {
      console.log(
        JSON.stringify((await L()).listCcbgovInvocationsV2(), null, 2),
      );
    });
  parent
    .command("ccbgov-auto-degrade-idle-v2")
    .description("Auto-degrade idle")
    .action(async () => {
      console.log(
        JSON.stringify((await L()).autoDegradeIdleCcbgovProfilesV2(), null, 2),
      );
    });
  parent
    .command("ccbgov-auto-fail-stuck-v2")
    .description("Auto-fail stuck invocations")
    .action(async () => {
      console.log(
        JSON.stringify((await L()).autoFailStuckCcbgovInvocationsV2(), null, 2),
      );
    });
  parent
    .command("ccbgov-gov-stats-v2")
    .description("V2 gov stats")
    .action(async () => {
      console.log(
        JSON.stringify((await L()).getClaudeCodeBridgeGovStatsV2(), null, 2),
      );
    });
}

// === Iter25 V2 governance overlay ===
export function registerArgovV2Commands(program) {
  const parent = program.commands.find((c) => c.name() === "orchestrate");
  if (!parent) return;
  const L = async () => await import("../lib/agent-router.js");
  parent
    .command("argov-enums-v2")
    .description("Show V2 enums")
    .action(async () => {
      const m = await L();
      console.log(
        JSON.stringify(
          {
            profileMaturity: m.ARGOV_PROFILE_MATURITY_V2,
            routingLifecycle: m.ARGOV_ROUTING_LIFECYCLE_V2,
          },
          null,
          2,
        ),
      );
    });
  parent
    .command("argov-config-v2")
    .description("Show V2 config")
    .action(async () => {
      const m = await L();
      console.log(
        JSON.stringify(
          {
            maxActive: m.getMaxActiveArgovProfilesPerOwnerV2(),
            maxPending: m.getMaxPendingArgovRoutingsPerProfileV2(),
            idleMs: m.getArgovProfileIdleMsV2(),
            stuckMs: m.getArgovRoutingStuckMsV2(),
          },
          null,
          2,
        ),
      );
    });
  parent
    .command("argov-set-max-active-v2 <n>")
    .description("Set max active")
    .action(async (n) => {
      (await L()).setMaxActiveArgovProfilesPerOwnerV2(Number(n));
      console.log("ok");
    });
  parent
    .command("argov-set-max-pending-v2 <n>")
    .description("Set max pending")
    .action(async (n) => {
      (await L()).setMaxPendingArgovRoutingsPerProfileV2(Number(n));
      console.log("ok");
    });
  parent
    .command("argov-set-idle-ms-v2 <n>")
    .description("Set idle threshold ms")
    .action(async (n) => {
      (await L()).setArgovProfileIdleMsV2(Number(n));
      console.log("ok");
    });
  parent
    .command("argov-set-stuck-ms-v2 <n>")
    .description("Set stuck threshold ms")
    .action(async (n) => {
      (await L()).setArgovRoutingStuckMsV2(Number(n));
      console.log("ok");
    });
  parent
    .command("argov-register-v2 <id> <owner>")
    .description("Register V2 profile")
    .option("--strategy <v>", "strategy")
    .action(async (id, owner, o) => {
      const m = await L();
      console.log(
        JSON.stringify(
          m.registerArgovProfileV2({ id, owner, strategy: o.strategy }),
          null,
          2,
        ),
      );
    });
  parent
    .command("argov-activate-v2 <id>")
    .description("Activate profile")
    .action(async (id) => {
      console.log(
        JSON.stringify((await L()).activateArgovProfileV2(id), null, 2),
      );
    });
  parent
    .command("argov-stale-v2 <id>")
    .description("Stale profile")
    .action(async (id) => {
      console.log(JSON.stringify((await L()).staleArgovProfileV2(id), null, 2));
    });
  parent
    .command("argov-archive-v2 <id>")
    .description("Archive profile")
    .action(async (id) => {
      console.log(
        JSON.stringify((await L()).archiveArgovProfileV2(id), null, 2),
      );
    });
  parent
    .command("argov-touch-v2 <id>")
    .description("Touch profile")
    .action(async (id) => {
      console.log(JSON.stringify((await L()).touchArgovProfileV2(id), null, 2));
    });
  parent
    .command("argov-get-v2 <id>")
    .description("Get profile")
    .action(async (id) => {
      console.log(JSON.stringify((await L()).getArgovProfileV2(id), null, 2));
    });
  parent
    .command("argov-list-v2")
    .description("List profiles")
    .action(async () => {
      console.log(JSON.stringify((await L()).listArgovProfilesV2(), null, 2));
    });
  parent
    .command("argov-create-routing-v2 <id> <profileId>")
    .description("Create routing")
    .option("--target <v>", "target")
    .action(async (id, profileId, o) => {
      const m = await L();
      console.log(
        JSON.stringify(
          m.createArgovRoutingV2({ id, profileId, target: o.target }),
          null,
          2,
        ),
      );
    });
  parent
    .command("argov-running-routing-v2 <id>")
    .description("Mark routing as running")
    .action(async (id) => {
      console.log(
        JSON.stringify((await L()).runningArgovRoutingV2(id), null, 2),
      );
    });
  parent
    .command("argov-complete-routing-v2 <id>")
    .description("Complete routing")
    .action(async (id) => {
      console.log(
        JSON.stringify((await L()).completeRoutingArgovV2(id), null, 2),
      );
    });
  parent
    .command("argov-fail-routing-v2 <id> [reason]")
    .description("Fail routing")
    .action(async (id, reason) => {
      console.log(
        JSON.stringify((await L()).failArgovRoutingV2(id, reason), null, 2),
      );
    });
  parent
    .command("argov-cancel-routing-v2 <id> [reason]")
    .description("Cancel routing")
    .action(async (id, reason) => {
      console.log(
        JSON.stringify((await L()).cancelArgovRoutingV2(id, reason), null, 2),
      );
    });
  parent
    .command("argov-get-routing-v2 <id>")
    .description("Get routing")
    .action(async (id) => {
      console.log(JSON.stringify((await L()).getArgovRoutingV2(id), null, 2));
    });
  parent
    .command("argov-list-routings-v2")
    .description("List routings")
    .action(async () => {
      console.log(JSON.stringify((await L()).listArgovRoutingsV2(), null, 2));
    });
  parent
    .command("argov-auto-stale-idle-v2")
    .description("Auto-stale idle")
    .action(async () => {
      console.log(
        JSON.stringify((await L()).autoStaleIdleArgovProfilesV2(), null, 2),
      );
    });
  parent
    .command("argov-auto-fail-stuck-v2")
    .description("Auto-fail stuck routings")
    .action(async () => {
      console.log(
        JSON.stringify((await L()).autoFailStuckArgovRoutingsV2(), null, 2),
      );
    });
  parent
    .command("argov-gov-stats-v2")
    .description("V2 gov stats")
    .action(async () => {
      console.log(
        JSON.stringify((await L()).getAgentRouterGovStatsV2(), null, 2),
      );
    });
}

// === Iter28 V2 governance overlay: Acrdgov ===
export function registerAcrdV2Commands(program) {
  const parent = program.commands.find((c) => c.name() === "orchestrate");
  if (!parent) return;
  const L = async () => await import("../lib/agent-coordinator.js");
  parent
    .command("acrdgov-enums-v2")
    .description("Show V2 enums")
    .action(async () => {
      const m = await L();
      console.log(
        JSON.stringify(
          {
            profileMaturity: m.ACRDGOV_PROFILE_MATURITY_V2,
            coordLifecycle: m.ACRDGOV_COORD_LIFECYCLE_V2,
          },
          null,
          2,
        ),
      );
    });
  parent
    .command("acrdgov-config-v2")
    .description("Show V2 config")
    .action(async () => {
      const m = await L();
      console.log(
        JSON.stringify(
          {
            maxActive: m.getMaxActiveAcrdProfilesPerOwnerV2(),
            maxPending: m.getMaxPendingAcrdCoordsPerProfileV2(),
            idleMs: m.getAcrdProfileIdleMsV2(),
            stuckMs: m.getAcrdCoordStuckMsV2(),
          },
          null,
          2,
        ),
      );
    });
  parent
    .command("acrdgov-set-max-active-v2 <n>")
    .description("Set max active")
    .action(async (n) => {
      (await L()).setMaxActiveAcrdProfilesPerOwnerV2(Number(n));
      console.log("ok");
    });
  parent
    .command("acrdgov-set-max-pending-v2 <n>")
    .description("Set max pending")
    .action(async (n) => {
      (await L()).setMaxPendingAcrdCoordsPerProfileV2(Number(n));
      console.log("ok");
    });
  parent
    .command("acrdgov-set-idle-ms-v2 <n>")
    .description("Set idle threshold ms")
    .action(async (n) => {
      (await L()).setAcrdProfileIdleMsV2(Number(n));
      console.log("ok");
    });
  parent
    .command("acrdgov-set-stuck-ms-v2 <n>")
    .description("Set stuck threshold ms")
    .action(async (n) => {
      (await L()).setAcrdCoordStuckMsV2(Number(n));
      console.log("ok");
    });
  parent
    .command("acrdgov-register-v2 <id> <owner>")
    .description("Register V2 profile")
    .option("--role <v>", "role")
    .action(async (id, owner, o) => {
      const m = await L();
      console.log(
        JSON.stringify(
          m.registerAcrdProfileV2({ id, owner, role: o.role }),
          null,
          2,
        ),
      );
    });
  parent
    .command("acrdgov-activate-v2 <id>")
    .description("Activate profile")
    .action(async (id) => {
      console.log(
        JSON.stringify((await L()).activateAcrdProfileV2(id), null, 2),
      );
    });
  parent
    .command("acrdgov-idle-v2 <id>")
    .description("Idle profile")
    .action(async (id) => {
      console.log(JSON.stringify((await L()).idleAcrdProfileV2(id), null, 2));
    });
  parent
    .command("acrdgov-archive-v2 <id>")
    .description("Archive profile")
    .action(async (id) => {
      console.log(
        JSON.stringify((await L()).archiveAcrdProfileV2(id), null, 2),
      );
    });
  parent
    .command("acrdgov-touch-v2 <id>")
    .description("Touch profile")
    .action(async (id) => {
      console.log(JSON.stringify((await L()).touchAcrdProfileV2(id), null, 2));
    });
  parent
    .command("acrdgov-get-v2 <id>")
    .description("Get profile")
    .action(async (id) => {
      console.log(JSON.stringify((await L()).getAcrdProfileV2(id), null, 2));
    });
  parent
    .command("acrdgov-list-v2")
    .description("List profiles")
    .action(async () => {
      console.log(JSON.stringify((await L()).listAcrdProfilesV2(), null, 2));
    });
  parent
    .command("acrdgov-create-coord-v2 <id> <profileId>")
    .description("Create coord")
    .option("--taskId <v>", "taskId")
    .action(async (id, profileId, o) => {
      const m = await L();
      console.log(
        JSON.stringify(
          m.createAcrdCoordV2({ id, profileId, taskId: o.taskId }),
          null,
          2,
        ),
      );
    });
  parent
    .command("acrdgov-coordinating-coord-v2 <id>")
    .description("Mark coord as coordinating")
    .action(async (id) => {
      console.log(
        JSON.stringify((await L()).coordinatingAcrdCoordV2(id), null, 2),
      );
    });
  parent
    .command("acrdgov-complete-coord-v2 <id>")
    .description("Complete coord")
    .action(async (id) => {
      console.log(JSON.stringify((await L()).completeCoordAcrdV2(id), null, 2));
    });
  parent
    .command("acrdgov-fail-coord-v2 <id> [reason]")
    .description("Fail coord")
    .action(async (id, reason) => {
      console.log(
        JSON.stringify((await L()).failAcrdCoordV2(id, reason), null, 2),
      );
    });
  parent
    .command("acrdgov-cancel-coord-v2 <id> [reason]")
    .description("Cancel coord")
    .action(async (id, reason) => {
      console.log(
        JSON.stringify((await L()).cancelAcrdCoordV2(id, reason), null, 2),
      );
    });
  parent
    .command("acrdgov-get-coord-v2 <id>")
    .description("Get coord")
    .action(async (id) => {
      console.log(JSON.stringify((await L()).getAcrdCoordV2(id), null, 2));
    });
  parent
    .command("acrdgov-list-coords-v2")
    .description("List coords")
    .action(async () => {
      console.log(JSON.stringify((await L()).listAcrdCoordsV2(), null, 2));
    });
  parent
    .command("acrdgov-auto-idle-idle-v2")
    .description("Auto-idle idle")
    .action(async () => {
      console.log(
        JSON.stringify((await L()).autoIdleIdleAcrdProfilesV2(), null, 2),
      );
    });
  parent
    .command("acrdgov-auto-fail-stuck-v2")
    .description("Auto-fail stuck coords")
    .action(async () => {
      console.log(
        JSON.stringify((await L()).autoFailStuckAcrdCoordsV2(), null, 2),
      );
    });
  parent
    .command("acrdgov-gov-stats-v2")
    .description("V2 gov stats")
    .action(async () => {
      console.log(JSON.stringify((await L()).getAcrdgovStatsV2(), null, 2));
    });
}
