// Track running cowork tasks for cancellation
const _runningTasks = new Map();

export async function handleCoworkTask(server, id, ws, message) {
  const { templateId = null, userMessage, files = [] } = message;

  if (!userMessage || typeof userMessage !== "string") {
    server._send(ws, {
      id,
      type: "error",
      code: "INVALID_MESSAGE",
      message: "userMessage field required",
    });
    return;
  }

  const ac = new AbortController();
  const trackingId = `cowork-${id}`;
  _runningTasks.set(trackingId, ac);

  try {
    const { runCoworkTask, runCoworkTaskParallel, runCoworkDebate } =
      await import("../../lib/cowork-task-runner.js");
    const { getTemplate } = await import("../../lib/cowork-task-templates.js");

    // Determine execution mode: debate > parallel > sequential
    const template = getTemplate(templateId);
    const useDebate =
      message.mode === "debate" ||
      (message.mode !== "agent" && template.mode === "debate");
    const useParallel =
      !useDebate &&
      (message.parallel === true ||
        (message.parallel !== false && template.parallelStrategy === "always"));

    server._send(ws, {
      id,
      type: "cowork:started",
      templateId,
      trackingId,
      parallel: useParallel,
      mode: useDebate ? "debate" : "agent",
    });

    const runner = useDebate
      ? runCoworkDebate
      : useParallel
        ? runCoworkTaskParallel
        : runCoworkTask;

    const result = await runner({
      templateId,
      userMessage,
      files,
      cwd: server.projectRoot || process.cwd(),
      llmOptions: {},
      evolutionCompositionFactory: server.evolutionCompositionFactory ?? null,
      signal: ac.signal,
      ...(message.mcpSessionId ? { mcpSessionId: message.mcpSessionId } : {}),
      ...(useParallel
        ? {
            agents: message.agents || 3,
            strategy: message.strategy,
          }
        : {}),
      ...(useDebate && message.perspectives
        ? { perspectives: message.perspectives }
        : {}),
      onProgress: (progress) => {
        server._send(ws, {
          id,
          type: "cowork:progress",
          event: progress.type,
          tool: progress.tool,
          iterationCount: progress.iterationCount,
          tokenCount: progress.tokenCount,
          ...(progress.sessionId ? { mcpSessionId: progress.sessionId } : {}),
          ...(Number.isInteger(progress.unsettled)
            ? { unsettled: progress.unsettled }
            : {}),
          ...(Number.isInteger(progress.incidents)
            ? { incidents: progress.incidents }
            : {}),
          ...(progress.recovery ? { recovery: progress.recovery } : {}),
        });
      },
    });

    server._send(ws, {
      id,
      type: "cowork:done",
      taskId: result.taskId,
      status: result.status,
      templateId: result.templateId,
      templateName: result.templateName,
      summary: result.result?.summary || "",
      artifacts: result.result?.artifacts || [],
      toolsUsed: result.result?.toolsUsed || [],
      iterationCount: result.result?.iterationCount || 0,
      tokenCount: result.result?.tokenCount || 0,
      parallel: result.parallel || false,
      subtaskCount: result.result?.subtaskCount || 0,
      ...(result.mcpSessionId ? { mcpSessionId: result.mcpSessionId } : {}),
      mode: result.mode || (useDebate ? "debate" : "agent"),
      ...(useDebate
        ? {
            verdict: result.result?.verdict,
            consensusScore: result.result?.consensusScore,
            reviews: result.result?.reviews || [],
            perspectives: result.result?.perspectives || [],
          }
        : {}),
    });
  } catch (err) {
    server._send(ws, {
      id,
      type: "error",
      code: "COWORK_FAILED",
      message: err.message,
    });
  } finally {
    _runningTasks.delete(trackingId);
  }
}

export function handleCoworkCancel(server, id, ws, message) {
  const { trackingId } = message;

  if (!trackingId) {
    server._send(ws, {
      id,
      type: "error",
      code: "INVALID_MESSAGE",
      message: "trackingId field required",
    });
    return;
  }

  const ac = _runningTasks.get(trackingId);
  if (ac) {
    ac.abort();
    _runningTasks.delete(trackingId);
    server._send(ws, { id, type: "cowork:cancelled", trackingId });
  } else {
    server._send(ws, {
      id,
      type: "error",
      code: "TASK_NOT_FOUND",
      message: `No running cowork task: ${trackingId}`,
    });
  }
}

export function handleSlashCommand(server, id, ws, message) {
  const { sessionId, command } = message;
  const handler = server.sessionHandlers.get(sessionId);

  if (!handler) {
    server._send(ws, {
      id,
      type: "error",
      code: "SESSION_NOT_FOUND",
      message: `No active session handler for: ${sessionId}`,
    });
    return;
  }

  handler.handleSlashCommand(command, id);
}

export async function handleCoworkHistory(server, id, ws, message) {
  const { limit = 50 } = message;
  const cwd = server.projectRoot || process.cwd();

  try {
    const { readFileSync, existsSync } = await import("node:fs");
    const { join } = await import("node:path");
    const histPath = join(cwd, ".chainlesschain", "cowork", "history.jsonl");

    if (!existsSync(histPath)) {
      server._send(ws, { id, type: "cowork:history", entries: [] });
      return;
    }

    const lines = readFileSync(histPath, "utf-8").split("\n").filter(Boolean);
    const entries = [];
    for (const line of lines.slice(-limit)) {
      try {
        entries.push(JSON.parse(line));
      } catch (_e) {
        // skip malformed lines
      }
    }

    server._send(ws, { id, type: "cowork:history", entries });
  } catch (err) {
    server._send(ws, {
      id,
      type: "error",
      code: "HISTORY_FAILED",
      message: err.message,
    });
  }
}

export async function handleCoworkTemplates(server, id, ws) {
  try {
    const { getTemplatesForUI } =
      await import("../../lib/cowork-task-templates.js");
    const templates = getTemplatesForUI();
    server._send(ws, { id, type: "cowork:templates", templates });
  } catch (err) {
    server._send(ws, {
      id,
      type: "error",
      code: "TEMPLATES_FAILED",
      message: err.message,
    });
  }
}

export async function handleOrchestrate(server, id, ws, message) {
  const {
    task,
    cwd,
    agents = 3,
    ci = "npm test",
    noCi = false,
    strategy,
  } = message;

  if (!task || typeof task !== "string") {
    server._send(ws, {
      id,
      type: "error",
      code: "INVALID_TASK",
      message: "task field required",
    });
    return;
  }

  try {
    const { Orchestrator, TASK_SOURCE } =
      await import("../../lib/orchestrator.js");

    const orch = new Orchestrator({
      cwd: cwd || server.projectRoot || process.cwd(),
      maxParallel: Math.min(parseInt(agents, 10) || 3, 10),
      ciCommand: ci,
      agents: strategy ? { strategy } : undefined,
      evolutionCompositionFactory: server.evolutionCompositionFactory ?? null,
      verbose: false,
    });

    const wsNotifier = orch.notifier.addWebSocketChannel({
      send: (data) => server._send(ws, data),
      requestId: id,
    });

    orch.on("agent:output", (ev) => wsNotifier.sendAgentOutput(ev));
    orch.on("task:added", (t) => wsNotifier.sendStatus(t));
    orch.on("task:decomposing", (t) => wsNotifier.sendStatus(t));
    orch.on("ci:checking", ({ task: t }) => wsNotifier.sendStatus(t));
    orch.on("task:retrying", ({ task: t }) => wsNotifier.sendStatus(t));

    const result = await orch.addTask(task, {
      source: TASK_SOURCE.CLI,
      cwd: cwd || server.projectRoot || process.cwd(),
      runCI: !noCi,
      notify: true,
    });

    server._send(ws, {
      id,
      type: "orchestrate:done",
      taskId: result.id,
      status: result.status,
      retries: result.retries,
      subtasks: result.subtasks?.length || 0,
    });
  } catch (err) {
    server._send(ws, {
      id,
      type: "error",
      code: "ORCHESTRATE_FAILED",
      message: err.message,
    });
  }
}

// ─── Workflow (N1) ───────────────────────────────────────────────────────────

function _cwd(server) {
  return server.projectRoot || process.cwd();
}

function _sendError(server, ws, id, code, message) {
  server._send(ws, { id, type: "error", code, message });
}

const WORKFLOW_EXECUTION_AUTHORITY_SCHEMA =
  "cc-session-execution-location-authority/v1";
const WORKFLOW_FORBIDDEN_EXECUTION_INPUT_KEYS = new Set([
  "execution",
  "llmoptions",
  "provider",
  "model",
  "apikey",
  "token",
  "password",
  "secret",
  "credential",
  "credentials",
  "credentialvalue",
  "credentialvalues",
]);

function hasForbiddenWorkflowExecutionInput(value, seen = new WeakSet()) {
  if (!value || typeof value !== "object") return false;
  if (seen.has(value)) return true;
  seen.add(value);
  for (const key of Reflect.ownKeys(value)) {
    if (typeof key !== "string") return true;
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    if (!descriptor || !Object.hasOwn(descriptor, "value")) return true;
    const normalizedKey = key
      .replaceAll("_", "")
      .replaceAll("-", "")
      .toLowerCase();
    if (WORKFLOW_FORBIDDEN_EXECUTION_INPUT_KEYS.has(normalizedKey)) {
      return true;
    }
    if (hasForbiddenWorkflowExecutionInput(descriptor.value, seen)) {
      return true;
    }
  }
  return false;
}

function _sendWorkflowBlocked(server, ws, id, details = {}) {
  server._send(ws, {
    id,
    type: "workflow:blocked",
    code: details.code || "WORKFLOW_RUN_BLOCKED",
    message: details.message || "workflow execution was blocked",
    workflowId: details.workflowId,
    definitionDigest: details.definitionDigest || null,
    admissionDigest: details.admissionDigest || null,
    preflightDigest: details.preflightDigest || null,
    executionLocationDigest: details.executionLocationDigest || null,
    preflight: details.preflight || null,
  });
}

function _sendWorkflowFailed(server, ws, id, details = {}) {
  server._send(ws, {
    id,
    type: "workflow:failed",
    code: details.code || "WORKFLOW_RUN_FAILED",
    message: details.message || "workflow execution failed",
    runId: details.runId,
    workflowId: details.workflowId,
    executionStarted: true,
    definitionDigest: details.definitionDigest || null,
    admissionDigest: details.admissionDigest || null,
    preflightDigest: details.preflightDigest || null,
    executionLocationDigest: details.executionLocationDigest || null,
  });
}

async function _resolveWorkflowExecutionAuthority(server, sessionId) {
  if (typeof sessionId !== "string" || sessionId.trim() === "") {
    const error = new Error("executionAuthoritySessionId is required");
    error.code = "WORKFLOW_EXECUTION_AUTHORITY_MISSING";
    throw error;
  }
  let provider;
  if (Object.hasOwn(server, "workflowExecutionAuthorityProvider")) {
    const descriptor = Object.getOwnPropertyDescriptor(
      server,
      "workflowExecutionAuthorityProvider",
    );
    if (!descriptor || !Object.hasOwn(descriptor, "value")) {
      const error = new Error(
        "workflow execution authority provider seam must be a data property",
      );
      error.code = "WORKFLOW_EXECUTION_AUTHORITY_PROVIDER_INVALID";
      throw error;
    }
    provider = descriptor.value;
  } else {
    ({ getVerifiedSessionExecutionLocationAuthority: provider } =
      await import("../../harness/jsonl-session-store.js"));
  }
  if (typeof provider !== "function") {
    const error = new Error(
      "workflow execution authority provider is unavailable",
    );
    error.code = "WORKFLOW_EXECUTION_AUTHORITY_PROVIDER_INVALID";
    throw error;
  }
  const verifiedProof = await provider(sessionId);
  let proof;
  try {
    proof = structuredClone(verifiedProof);
  } catch {
    const error = new Error(
      "verified execution authority could not be safely snapshotted",
    );
    error.code = "WORKFLOW_EXECUTION_AUTHORITY_INVALID";
    throw error;
  }
  if (proof?.sessionId !== sessionId) {
    const error = new Error(
      "verified execution authority does not match the requested session",
    );
    error.code = "WORKFLOW_EXECUTION_AUTHORITY_SESSION_MISMATCH";
    throw error;
  }
  return Object.freeze({
    schema: WORKFLOW_EXECUTION_AUTHORITY_SCHEMA,
    authority: proof.authority || "verified-session-start",
    sessionId: proof.sessionId,
    headHash: proof.headHash,
    eventCount: proof.eventCount,
    binding: proof.binding,
  });
}

async function _verifyWorkflowRunAuthorities(
  server,
  cwd,
  { workflowId, definitionDigest, executionAuthoritySessionId },
) {
  const { getWorkflowVersion } = await import("../../lib/cowork-workflow.js");
  // Resolve the asynchronous session proof first. The immutable workflow
  // version is the final read in this verifier, leaving no await window in
  // which it can be replaced after verification but before it is returned.
  const executionLocationAuthority = await _resolveWorkflowExecutionAuthority(
    server,
    executionAuthoritySessionId,
  );
  const definitionAuthority = getWorkflowVersion(
    cwd,
    workflowId,
    definitionDigest,
  );
  if (
    !definitionAuthority ||
    definitionAuthority.definitionDigest !== definitionDigest
  ) {
    const error = new Error(
      "the exact admitted workflow definition version is no longer available",
    );
    error.code = "CC_DYNAMIC_WORKFLOW_DEFINITION_AUTHORITY_DRIFT";
    throw error;
  }
  return Object.freeze({
    definitionAuthority,
    executionLocationAuthority,
  });
}

export async function handleWorkflowList(server, id, ws) {
  try {
    const { listWorkflows } = await import("../../lib/cowork-workflow.js");
    const workflows = listWorkflows(_cwd(server));
    server._send(ws, { id, type: "workflow:list", workflows });
  } catch (err) {
    _sendError(server, ws, id, "WORKFLOW_LIST_FAILED", err.message);
  }
}

export async function handleWorkflowGet(server, id, ws, message) {
  const { id: wfId } = message || {};
  if (!wfId) return _sendError(server, ws, id, "MISSING_ID", "id required");
  try {
    const { getWorkflowRecord } = await import("../../lib/cowork-workflow.js");
    const record = getWorkflowRecord(_cwd(server), wfId);
    server._send(ws, {
      id,
      type: "workflow:get",
      workflow: record?.definition || null,
      definitionAuthority: record
        ? {
            status: record.status,
            recordSchema: record.recordSchema,
            definitionSchema: record.definitionSchema,
            definitionDigest: record.definitionDigest,
          }
        : null,
    });
  } catch (err) {
    _sendError(server, ws, id, "WORKFLOW_GET_FAILED", err.message);
  }
}

export async function handleWorkflowSave(server, id, ws, message) {
  const { workflow } = message || {};
  if (!workflow || typeof workflow !== "object") {
    return _sendError(
      server,
      ws,
      id,
      "INVALID_WORKFLOW",
      "workflow object required",
    );
  }
  try {
    const { getWorkflowRecord, validateWorkflow, saveWorkflow } =
      await import("../../lib/cowork-workflow.js");
    const result = validateWorkflow(workflow);
    if (!result.valid) {
      return _sendError(
        server,
        ws,
        id,
        "WORKFLOW_INVALID",
        result.errors.join("; "),
      );
    }
    saveWorkflow(_cwd(server), workflow);
    const record = getWorkflowRecord(_cwd(server), workflow.id);
    server._send(ws, {
      id,
      type: "workflow:save",
      saved: true,
      workflowId: workflow.id,
      definitionDigest: record.definitionDigest,
      definitionSchema: record.definitionSchema,
    });
  } catch (err) {
    _sendError(server, ws, id, "WORKFLOW_SAVE_FAILED", err.message);
  }
}

export async function handleWorkflowRemove(server, id, ws, message) {
  const { id: wfId } = message || {};
  if (!wfId) return _sendError(server, ws, id, "MISSING_ID", "id required");
  try {
    const { removeWorkflow } = await import("../../lib/cowork-workflow.js");
    const removed = removeWorkflow(_cwd(server), wfId);
    server._send(ws, { id, type: "workflow:remove", removed });
  } catch (err) {
    _sendError(server, ws, id, "WORKFLOW_REMOVE_FAILED", err.message);
  }
}

export async function handleWorkflowRun(server, id, ws, message) {
  const {
    id: wfId,
    definitionDigest,
    executionAuthoritySessionId,
    maxParallel,
  } = message || {};
  if (!wfId) return _sendError(server, ws, id, "MISSING_ID", "id required");
  if (
    [
      "binding",
      "executionLocation",
      "executionLocationAuthority",
      "executionLocationBinding",
    ].some((field) => Object.hasOwn(message || {}, field))
  ) {
    return _sendWorkflowBlocked(server, ws, id, {
      code: "WORKFLOW_EXECUTION_AUTHORITY_INLINE_FORBIDDEN",
      message:
        "execution authority must be selected by executionAuthoritySessionId",
      workflowId: wfId,
    });
  }
  if (hasForbiddenWorkflowExecutionInput(message)) {
    return _sendWorkflowBlocked(server, ws, id, {
      code: "WORKFLOW_EXECUTION_SECRET_INPUT_FORBIDDEN",
      message:
        "workflow execution options and credential values are not accepted over WS",
      workflowId: wfId,
    });
  }
  if (
    typeof executionAuthoritySessionId !== "string" ||
    executionAuthoritySessionId.trim() === ""
  ) {
    return _sendWorkflowBlocked(server, ws, id, {
      code: "WORKFLOW_EXECUTION_AUTHORITY_MISSING",
      message: "executionAuthoritySessionId is required",
      workflowId: wfId,
    });
  }

  let executionStarted = false;
  let definitionRecord = null;
  let runId = null;
  let eventDigests = null;
  try {
    const { getWorkflowRecord, getWorkflowVersion, executeWorkflow } =
      await import("../../lib/cowork-workflow.js");
    const { executeDynamicWorkflowWithAdmission } =
      await import("../../lib/dynamic-workflow-facade.js");
    let workflowRunTask;
    if (Object.hasOwn(server, "workflowRunTask")) {
      const descriptor = Object.getOwnPropertyDescriptor(
        server,
        "workflowRunTask",
      );
      if (!descriptor || !Object.hasOwn(descriptor, "value")) {
        throw new Error("Workflow task runner seam must be a data property");
      }
      workflowRunTask = descriptor.value;
    } else {
      ({ runCoworkTask: workflowRunTask } =
        await import("../../lib/cowork-task-runner.js"));
    }
    if (typeof workflowRunTask !== "function") {
      throw new Error("Workflow task runner is unavailable");
    }
    definitionRecord = definitionDigest
      ? getWorkflowVersion(_cwd(server), wfId, definitionDigest)
      : getWorkflowRecord(_cwd(server), wfId);
    if (!definitionRecord) {
      return _sendError(
        server,
        ws,
        id,
        "WORKFLOW_NOT_FOUND",
        `No workflow: ${wfId}`,
      );
    }

    runId = `wf-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

    const onStepStart = ({ stepId, message: stepMessage }) => {
      server._send(ws, {
        id,
        type: "workflow:step-start",
        runId,
        stepId,
        message: stepMessage,
        ...eventDigests,
      });
    };
    const onStepComplete = (outcome) => {
      server._send(ws, {
        id,
        type: "workflow:step-complete",
        runId,
        stepId: outcome?.id,
        status: outcome?.status,
        summary: outcome?.result?.summary,
        ...eventDigests,
      });
    };

    const outcome = await executeDynamicWorkflowWithAdmission(
      {
        definitionAuthority: definitionRecord,
        executionAuthoritySessionId,
        maxParallel,
        execution: {
          cwd: _cwd(server),
          onStepStart,
          onStepComplete,
        },
        onAdmitted(admission) {
          executionStarted = true;
          eventDigests = Object.freeze({
            definitionDigest: admission.definitionDigest,
            admissionDigest: admission.admissionDigest,
            preflightDigest: admission.preflightDigest,
            executionLocationDigest: admission.executionLocationDigest,
          });
          server._send(ws, {
            id,
            type: "workflow:started",
            runId,
            workflowId: wfId,
            ...eventDigests,
          });
        },
      },
      {
        executeWorkflow: (execution) =>
          executeWorkflow({ ...execution, runTask: workflowRunTask }),
        verifyAuthorities: (lookup) =>
          _verifyWorkflowRunAuthorities(server, _cwd(server), lookup),
      },
    );
    if (!outcome.allowed) {
      return _sendWorkflowBlocked(server, ws, id, {
        code: outcome.error?.code,
        message: outcome.error?.message,
        workflowId: wfId,
        definitionDigest: outcome.definitionDigest,
        admissionDigest: outcome.admissionDigest,
        preflightDigest: outcome.preflightDigest,
        executionLocationDigest: outcome.executionLocationDigest,
        preflight: outcome.preflight,
      });
    }
    const record = outcome.record;

    server._send(ws, {
      id,
      type: "workflow:done",
      runId,
      status: record?.status || "completed",
      steps: record?.steps || [],
      ...eventDigests,
    });
  } catch (err) {
    if (!executionStarted && err.executionStarted !== true) {
      _sendWorkflowBlocked(server, ws, id, {
        code: err.code || "WORKFLOW_RUN_ADMISSION_FAILED",
        message: err.message,
        workflowId: wfId,
        definitionDigest: definitionRecord?.definitionDigest,
      });
      return;
    }
    _sendWorkflowFailed(server, ws, id, {
      code: err.code,
      message: err.message,
      runId,
      workflowId: wfId,
      ...eventDigests,
    });
  }
}
