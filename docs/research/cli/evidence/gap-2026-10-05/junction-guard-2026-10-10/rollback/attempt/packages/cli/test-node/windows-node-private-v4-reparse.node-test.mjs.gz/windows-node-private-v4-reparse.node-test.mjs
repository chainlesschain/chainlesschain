import assert from "node:assert/strict";
import { test } from "node:test";
import { inspectPrivateV4ReparseReceipts } from "../scripts/windows-node-private-v4-result.mjs";

function fixture() {
  const host = {
    junctionCompatibility: true,
    creationLedger: [
      { pid: 11, kind: "root" },
      { pid: 22, kind: "vitest-worker" },
    ],
  };
  const report = {
    mode: "review-baseline",
    review: { junctionCompatibility: "readonly-private-junction-v1" },
    receipts: host.creationLedger.flatMap(({ pid }) =>
      ["installed", "exit"].map((phase) => ({
        pid,
        phase,
        adapter: {
          patches: 7,
          reparseCompatibility: {
            profile: "readonly-private-junction-v1",
            readOnly: true,
            scope: "existing-plain-scratch-target",
            source: "kernel-mount-point-substitute",
            identity: "held-root-source-followed-target-file-id-nt",
            printNameTrusted: false,
            passthroughIsDenial: false,
            rawTag: 2684354563,
            slotInstalled: true,
            slotProtection: 2,
            calls: phase === "exit" ? 5 : 0,
            candidates: phase === "exit" ? 3 : 0,
            mapped: phase === "exit" ? 3 : 0,
            untranslated: 0,
          },
        },
      })),
    ),
  };
  return { report, host };
}
const inspect = (v) => inspectPrivateV4ReparseReceipts(v.report, v.host);
test("explicit seven-slot profile requires final successful representation observations", () =>
  assert.deepEqual(inspect(fixture()), { verified: true, errors: [] }));
test("legacy six-slot profile does not acquire compatibility claims", () =>
  assert.deepEqual(
    inspectPrivateV4ReparseReceipts(
      { receipts: [{ adapter: { patches: 6 } }] },
      { junctionCompatibility: false },
    ),
    { verified: true, errors: [] },
  ));
const cases = [
  ["missing host flag", (v) => delete v.host.junctionCompatibility],
  ["missing profile", (v) => delete v.report.review.junctionCompatibility],
  ["unknown profile", (v) => (v.report.review.junctionCompatibility = "other")],
  ["original mode", (v) => (v.report.mode = "original")],
  [
    "missing receipt proof",
    (v) => delete v.report.receipts[0].adapter.reparseCompatibility,
  ],
  [
    "missing worker exit despite op4",
    (v) => {
      v.host.creationLedger[1].terminationRequested = true;
      v.report.receipts.pop();
    },
  ],
  [
    "duplicate exit",
    (v) => v.report.receipts.push(structuredClone(v.report.receipts[1])),
  ],
  ["unowned receipt", (v) => (v.report.receipts[0].pid = 99)],
  [
    "counter regression",
    (v) => {
      v.report.receipts[0].adapter.reparseCompatibility.calls = 8;
    },
  ],
  ["missing actors", (v) => (v.host.creationLedger = [])],
  ["malformed actors", (v) => (v.host.creationLedger = {})],
];
for (const [field, bad] of Object.entries({
  profile: "other",
  readOnly: false,
  scope: "ambient",
  source: "print-name",
  identity: "strings-only",
  printNameTrusted: true,
  passthroughIsDenial: true,
  rawTag: 0,
  slotInstalled: false,
  slotProtection: 4,
  calls: -1,
  candidates: 7,
  mapped: NaN,
  untranslated: 1,
}))
  cases.push([
    `invalid ${field}`,
    (v) => (v.report.receipts[1].adapter.reparseCompatibility[field] = bad),
  ]);
for (const [name, mutate] of cases)
  test(`rejects ${name}`, () => {
    const v = fixture();
    mutate(v);
    assert.equal(inspect(v).verified, false);
  });
test("real untranslated passthrough cannot be claimed as safe denial", () => {
  const v = fixture();
  Object.assign(v.report.receipts[1].adapter.reparseCompatibility, {
    calls: 4,
    candidates: 4,
    mapped: 3,
    untranslated: 1,
  });
  assert.match(inspect(v).errors.join(";"), /untranslated/);
});
