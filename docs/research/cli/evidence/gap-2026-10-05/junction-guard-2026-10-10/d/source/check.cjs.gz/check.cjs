"use strict";
const preload = require("X:/workspace/adapter/windows-node-private-v4-preload.cjs");
const addon = require("X:/workspace/adapter/windows-node-private-v4.node");
const fs = require("node:fs");
const assert = require("node:assert/strict");
const path = require("node:path");
const mode = JSON.parse(fs.readFileSync("X:/control/probe-mode.json", "utf8"));
const base = "X:\\scratch\\private-v4-junction-probe", target = path.join(base,"target"), link = path.join(base,"link");
const evidence = {mode, status:"NOT_ADMITTED", admissionEligible:false, phases:[]};
const phase = (name, value) => {evidence.phases.push({name,value});fs.writeFileSync("X:/scratch/junction-probe.json",JSON.stringify(evidence,null,2));};
(async()=>{
  fs.mkdirSync(target,{recursive:true});fs.writeFileSync(path.join(target,"sentinel"),"unchanged-target");
  fs.symlinkSync(mode==="outside"?"X:\\workspace":target,link,"junction");
  if(mode==="replaced") fs.renameSync(target,target+"-moved");
  phase("raw-before",JSON.parse(addon.probeReparse(link)));
  if(mode!=="positive") {
    let actual;
    try {actual={link:fs.readlinkSync(link)};}catch(error){actual={code:error.code};}
    phase("untranslated-real-result",actual);
    const proof=JSON.parse(addon.snapshot()).reparseCompatibility;
    assert.equal(proof.untranslated>0,true);assert.equal(actual.code,"EINVAL");
    phase("expected-compatibility-refusal",proof);
    fs.rmdirSync(link);return;
  }
  const guards=JSON.parse(addon.probeReparseGuards());
  assert.equal(guards.opens.length,5);for(const row of guards.opens)assert.equal(row.error,32);
  phase("sharing-guards",guards);
  const check = (lstat,readlink,stat) => {
    assert.equal(lstat.isSymbolicLink(),true);assert.equal(lstat.isDirectory(),false);
    assert.equal(readlink,target);assert.equal(stat.isDirectory(),true);
    const targetStat=fs.statSync(target);assert.equal(stat.ino,targetStat.ino);assert.equal(stat.dev,targetStat.dev);
    return {mode:lstat.mode,symbolic:lstat.isSymbolicLink(),readlink,targetIdentity:{dev:stat.dev,ino:stat.ino}};
  };
  phase("sync",check(fs.lstatSync(link),fs.readlinkSync(link),fs.statSync(link)));
  phase("async",check(await fs.promises.lstat(link),await fs.promises.readlink(link),await fs.promises.stat(link)));
  phase("raw-after",JSON.parse(addon.probeReparse(link)));
  for(const operation of ["unlink-sync","unlink-async","rm-sync","rm-async"]) {
    const name=path.join(base,operation);fs.symlinkSync(target,name,"junction");
    if(operation==="unlink-sync")fs.unlinkSync(name);
    if(operation==="unlink-async")await fs.promises.unlink(name);
    if(operation==="rm-sync")fs.rmSync(name,{recursive:true});
    if(operation==="rm-async")await fs.promises.rm(name,{recursive:true});
    assert.equal(fs.existsSync(name),false);assert.equal(fs.readFileSync(path.join(target,"sentinel"),"utf8"),"unchanged-target");
    phase(operation,{linkAbsent:true,targetUnchanged:true});
  }
  fs.unlinkSync(link);assert.equal(fs.readFileSync(path.join(target,"sentinel"),"utf8"),"unchanged-target");
  const proof=JSON.parse(addon.snapshot()).reparseCompatibility;
  assert.equal(proof.mapped>0,true);assert.equal(proof.untranslated,0);
  phase("completed",proof);
})().catch(error=>{phase("failed",{message:error.message,code:error.code,stack:error.stack,adapter:JSON.parse(addon.snapshot())});process.exitCode=1;}).finally(()=>{phase("final",preload.snapshot().adapter.reparseCompatibility);});
