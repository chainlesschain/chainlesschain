import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const [id,sha]=process.argv.slice(2);assert.match(id??'',/^[1-9]\d*$/u);assert.match(sha??'',/^[a-f0-9]{40}$/u);
const root=path.resolve('.work/release098-failures',id,new Date().toISOString().replaceAll(':','-'));
fs.mkdirSync(root,{recursive:true});const files=[];
function api(route,name){
  const bytes=execFileSync('gh',['api','repos/chainlesschain/chainlesschain/'+route],
    {windowsHide:true,timeout:55000,maxBuffer:64*1024*1024,stdio:['ignore','pipe','pipe']});
  fs.writeFileSync(path.join(root,name),bytes,{flag:'wx'});
  files.push({name,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')});return bytes;
}
const run=JSON.parse(api('actions/runs/'+id,'run.json'));assert.equal(run.head_sha,sha);
const listing=JSON.parse(api(`actions/runs/${id}/attempts/${run.run_attempt}/jobs?per_page=100`,'jobs.json'));
assert.equal(listing.total_count,listing.jobs.length);
const failed=listing.jobs.filter(job=>job.conclusion==='failure');
for(const job of failed){
  assert.equal(job.head_sha,sha);assert.equal(job.run_id,run.id);assert.equal(job.run_attempt,run.run_attempt);
  const log=api(`actions/jobs/${job.id}/logs`,`job-${job.id}.log`).toString('utf8');
  console.log(JSON.stringify({jobId:job.id,name:job.name,failedSteps:job.steps.filter(step=>step.conclusion==='failure').map(step=>step.name),
    tail:log.split(/\r?\n/u).slice(-95)}));
}
fs.writeFileSync(path.join(root,'collection.json'),JSON.stringify({capturedAt:new Date().toISOString(),sha,
  id,attempt:run.run_attempt,url:run.html_url,status:run.status,conclusion:run.conclusion,files},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({root,id,sha,failedCount:failed.length}));
