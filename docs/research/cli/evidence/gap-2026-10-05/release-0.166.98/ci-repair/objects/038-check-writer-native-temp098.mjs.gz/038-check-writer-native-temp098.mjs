import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {spawnSync,execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
assert.equal(process.platform,'win32');
const repository=process.cwd();
assert.equal(execFileSync('git',['status','--porcelain','--untracked-files=all'],{encoding:'utf8',windowsHide:true}).trim(),'');
const sha=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8',windowsHide:true}).trim();
const root=fs.mkdtempSync(path.join(repository,'.work/writer-native-temp098-'));
const physical=path.join(root,'physical temporary root'),alias=path.join(root,'alias');
fs.mkdirSync(physical);fs.symlinkSync(physical,alias,'junction');
assert.equal(fs.realpathSync.native(alias),physical);assert.notEqual(alias,physical);
const output=path.join(root,'writer-receipt.json');
const args=['packages/context-memory-kernel/scripts/context-memory-writer-probe.mjs','--candidate-sha',sha,'--output',output];
const startedAt=new Date().toISOString();
const result=spawnSync(process.execPath,args,{cwd:repository,env:{...process.env,TEMP:alias,TMP:alias,TMPDIR:alias},
  encoding:'utf8',windowsHide:true,timeout:120000,maxBuffer:16*1024*1024});
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
fs.writeFileSync(path.join(root,'stdout.txt'),result.stdout??'',{flag:'wx'});
fs.writeFileSync(path.join(root,'stderr.txt'),result.stderr??'',{flag:'wx'});
const sourcePaths=['packages/context-memory-kernel/scripts/context-memory-writer-probe.mjs',
  'packages/cli/src/lib/context-memory-kernel/segmented-memory-port.js','packages/cli/src/lib/context-memory-kernel/durable-memory-port.js'];
const bindings=sourcePaths.map(file=>({path:file,sha256:hash(fs.readFileSync(file))}));
const report={startedAt,finishedAt:new Date().toISOString(),node:process.version,platform:process.platform,
  executable:process.execPath,args,sha,root,temporaryAlias:alias,physicalRoot:physical,bindings,
  exitCode:result.status,signal:result.signal,error:result.error?.message??null,
  fixtureCleaned:fs.readdirSync(physical).every(name=>!name.startsWith('cc-context-memory-writer-probe-')),
  allTemporaryEntries:fs.readdirSync(physical),providerCalls:0,formalSample:false,observationsProduced:0};
fs.writeFileSync(path.join(root,'process.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
assert.equal(result.status,0,result.stderr||result.error?.message);
const receipt=JSON.parse(fs.readFileSync(output,'utf8'));
assert.equal(receipt.candidateSha,sha);assert.equal(receipt.status,'passed');
assert.equal(receipt.runtime.cli.canonicalStoreCreated,true);
assert.equal(report.fixtureCleaned,true);
console.log(JSON.stringify({root,sha,status:receipt.status,fixtureCleaned:report.fixtureCleaned,
  canonicalMutation:receipt.runtime.cli.canonicalMutationStatus,bindings}));
