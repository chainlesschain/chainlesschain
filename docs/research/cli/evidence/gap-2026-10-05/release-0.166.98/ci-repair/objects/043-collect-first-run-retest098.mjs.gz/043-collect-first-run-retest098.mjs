import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {createHash} from 'node:crypto';
import {listZipEntries,readZipEntry} from '../packages/vscode-extension/scripts/verify-vsix.mjs';

const execute=promisify(execFile);
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const args=process.argv.slice(2),planOnly=args[0]==='--plan';
if(planOnly)args.shift();
const [id,executionSha,releaseSha,...extra]=args;
assert.match(id??'',/^[1-9]\d*$/u);
for(const sha of [executionSha,releaseSha])assert.match(sha??'',/^[a-f0-9]{40}$/u);
assert.equal(extra.length,0,'Usage: [--plan] <run-id> <execution-sha> <public-release-sha>');
if(planOnly){
  console.log(JSON.stringify({status:'PREPARED_NOT_EXECUTED',id,executionSha,releaseSha,
    providerCalls:0,hostCandidateExecution:false,formalStatus:'NOT_RUN'}));
  process.exit(0);
}
const root=path.resolve('.work/first-run-retest098',id,new Date().toISOString().replaceAll(':','-'));
fs.mkdirSync(root,{recursive:true});
const files=[];
function save(name,bytes){
  const target=path.resolve(root,name);
  assert(target.startsWith(root+path.sep));
  fs.mkdirSync(path.dirname(target),{recursive:true});
  fs.writeFileSync(target,bytes,{flag:'wx'});
  files.push({path:name,bytes:bytes.length,sha256:hash(bytes)});
}
function json(name,value){save(name,Buffer.from(JSON.stringify(value,null,2)+'\n'));}
async function api(route,name){
  const {stdout}=await execute('gh',['api','repos/chainlesschain/chainlesschain/'+route,'-H','Cache-Control: no-cache'],
    {encoding:'buffer',windowsHide:true,timeout:55000,maxBuffer:256*1024*1024});
  save(name,stdout);return stdout;
}
json('invocation.json',{id,executionSha,releaseSha,collectorSha256:hash(fs.readFileSync(process.argv[1])),
  startedAt:new Date().toISOString(),providerCalls:0,hostCandidateExecution:false});
try{
  const run=JSON.parse(await api('actions/runs/'+id,'run.raw.json'));
  assert.equal(String(run.id),id);assert.equal(run.head_sha,executionSha);
  assert.equal(run.name,'VERIFY01 First Run CLI Diagnostic');
  assert.equal(run.path,'.github/workflows/verify01-first-run-cli-diagnostic.yml');
  assert.equal(run.head_branch,'feature/cli-first-run-retest-016698');
  assert.equal(run.status,'completed');assert(['push','workflow_dispatch'].includes(run.event));
  if(run.event==='push'){
    const commit=JSON.parse(await api('commits/'+executionSha,'execution-commit.raw.json'));
    assert(commit.commit.message.includes('[volcengine-first-run-diagnostic]'),'No explicit paid marker');
  }
  const listing=JSON.parse(await api(`actions/runs/${id}/attempts/${run.run_attempt}/jobs?per_page=100`,'jobs.raw.json'));
  assert.equal(listing.total_count,1);assert.equal(listing.jobs.length,1);
  const job=listing.jobs[0];assert.equal(job.name,'diagnostic');
  assert.equal(String(job.run_id),id);assert.equal(job.head_sha,executionSha);assert.equal(job.run_attempt,run.run_attempt);
  assert.equal(job.status,'completed');
  await api(`actions/jobs/${job.id}/logs`,'job.raw.log');
  const artifacts=JSON.parse(await api(`actions/runs/${id}/artifacts?per_page=100`,'artifacts.raw.json'));
  assert.equal(artifacts.total_count,artifacts.artifacts.length);assert(artifacts.total_count<=100);
  const expectedName=`verify01-first-run-cli-diagnostic-${executionSha}-${run.run_attempt}`;
  const matches=artifacts.artifacts.filter(row=>row.name===expectedName);
  assert.equal(matches.length,1,'Missing/duplicate exact-attempt evidence; preserve collection failure');
  const artifact=matches[0];assert.equal(artifact.expired,false);
  assert.equal(artifact.workflow_run.head_sha,executionSha);assert.equal(String(artifact.workflow_run.id),id);
  const zip=await api(`actions/artifacts/${artifact.id}/zip`,'artifact.zip');
  assert.equal('sha256:'+hash(zip),artifact.digest);
  const extracted=[];
  for(const [name,entry]of listZipEntries(zip)){
    assert(!/[\\:\0]/u.test(name)&&!name.startsWith('/')&&!name.split('/').filter(Boolean).some(part=>['.','..'].includes(part)),
      'Unsafe artifact path');
    if(name.endsWith('/'))continue;
    const bytes=readZipEntry(zip,entry);assert(bytes.length<=32*1024*1024,'Oversized artifact entry');
    save('files/'+name,bytes);extracted.push({path:name,bytes:bytes.length,sha256:hash(bytes)});
  }
  json('extracted.json',{artifactId:artifact.id,artifactDigest:artifact.digest,entries:extracted});
  const summaries=extracted.filter(row=>row.path==='verify01-first-run-cli-diagnostic/summary.json');
  assert.equal(summaries.length,1,'Journey did not produce its final summary');
  const summary=JSON.parse(fs.readFileSync(path.join(root,'files',summaries[0].path),'utf8'));
  assert.equal(summary.sourceCommit,executionSha);assert.equal(summary.releaseCommit,releaseSha);
  assert.equal(summary.publicVersion,'0.166.98');assert.equal(summary.taskId,'verify-04');
  assert.equal(summary.projectCommit,'b2aa3aba082873570e85dce39b00754e5504ff37');
  assert.equal(summary.planDigest,'sha256:665a5254c32a9a267cec5e5c85ccb52f938cd0884470546a92f58fae5dcf87a0');
  assert.equal(summary.formalSample,false);assert.equal(summary.observationsProduced,0);
  assert.equal(summary.formalStatus,'NOT_RUN');assert.equal(summary.billingVerified,false);
  assert.equal(summary.limits.turns,20);assert.equal(summary.limits.estimatedToolSpendStopUSD,0.25);
  assert.deepEqual(summary.stages.map(row=>row.stage),['install','configure','authenticate','tool','artifact']);
  const workflowEntries=extracted.filter(row=>row.path==='verify01-first-run-cli-workflow/workflow.json');
  assert.equal(workflowEntries.length,1);
  const context=JSON.parse(fs.readFileSync(path.join(root,'files',workflowEntries[0].path),'utf8'));
  assert.equal(context.sourceCommit,executionSha);assert.equal(String(context.runId),id);
  assert.equal(Number(context.runAttempt),run.run_attempt);assert.equal(context.formalSample,false);
  assert.equal(context.observationsProduced,0);
  const candidates=summary.stages.find(row=>row.stage==='tool').candidates??[];
  const tool=summary.stages.find(row=>row.stage==='tool');
  const analysis={capturedAt:new Date().toISOString(),runId:id,runAttempt:run.run_attempt,url:run.html_url,
    executionSourceCommit:executionSha,publicReleaseCommit:releaseSha,publicCliVersion:summary.publicVersion,
    conclusion:run.conclusion,passed:summary.passed,runtime:summary.runtime,
    stages:summary.stages.map(({trace,candidates,...row})=>row),costAccounting:summary.costAccounting,
    model:tool.trace??null,candidates,formalSample:false,observationsProduced:0,
    providerCallsByCollector:0,hostCandidateExecution:false,
    boundary:'Static digest-bound collection only; actual candidates were evaluated in the workflow Docker checker. No invoice or formal admission is established.'};
  json('analysis.json',analysis);
  json('download.json',{status:'COLLECTED_COMPLETE_EVIDENCE',capturedAt:new Date().toISOString(),id,
    executionSha,releaseSha,files:[...files]});
  console.log(JSON.stringify({root,id,executionSha,releaseSha,conclusion:run.conclusion,passed:summary.passed,
    stages:analysis.stages.map(({stage,executed,passed})=>({stage,executed,passed})),costAccounting:analysis.costAccounting,
    candidates,extractedCount:extracted.length,formalStatus:'NOT_RUN'}));
}catch(error){
  json('collection-failure.json',{status:'PARTIAL_EVIDENCE_NOT_ACCEPTED',at:new Date().toISOString(),
    id,executionSha,releaseSha,message:error.message,files:[...files],formalSample:false,observationsProduced:0});
  throw error;
}
