import assert from 'node:assert/strict';
import {test} from 'node:test';
import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
import {preflightPolicies,verifyPreflightGate,npmSuccessJobs,npmSkippedJobs,npmRequiredSteps,verifyNpmPublicationJobs,selectReleasePreflightRun} from './release098-workflow-contract.mjs';
import {vscodeRequiredJobs,vscodeConditionalSkips,verifyIdeWorkflowObservation} from './readback-ide-workflow098.mjs';
const sha=process.env.CC_READBACK_TEST_SHA || execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8',windowsHide:true}).trim();
const run={id:123,run_attempt:2,head_sha:sha,status:'completed',conclusion:'success',event:'pull_request',head_branch:'feature/cli-ide-gap-20261011'};
const jobs=names=>names.map((name,i)=>({id:i+1,name,run_id:123,run_attempt:2,head_sha:sha,status:'completed',conclusion:'success',steps:[]}));
test('all four complete preflight matrices pass exact name and identity contracts',()=>{
  assert.deepEqual(preflightPolicies.map(p=>p.names.length),[71,5,19,10]);
  for(const p of preflightPolicies) {
    const list=jobs(p.names);
    if(p.name==='IDE Extensions')list.at(-1).conclusion='skipped';
    assert.equal(verifyPreflightGate({...run,name:p.name,path:`.github/workflows/${p.workflow}`},list,p,sha).status,'VERIFIED');
  }
});
test('same-count replaced jobs, wrong workflow/attempt and skipped platform fail closed',()=>{
  const p=preflightPolicies[0], r={...run,name:p.name,path:`.github/workflows/${p.workflow}`};
  for(const mutate of [list=>{list[0].name='replacement';},list=>{list[0].run_attempt=1;},list=>{list[0].conclusion='skipped';}]) {
    const list=jobs(p.names);mutate(list);assert.throws(()=>verifyPreflightGate(r,list,p,sha));
  }
  assert.throws(()=>verifyPreflightGate({...r,path:'.github/workflows/wrong.yml'},jobs(p.names),p,sha));
});
test('newer IDE/npm tags, unrelated branches and events cannot replace scoped preflight',()=>{
  for(const policy of preflightPolicies) {
    const original={...run,name:policy.name,path:`.github/workflows/${policy.workflow}`};
    const candidates=[original,
      ...['ide-vscode-v0.37.142','ide-jetbrains-v0.4.160','v-npm-0-166-98','feature/unrelated'].flatMap((head_branch,i)=>
        ['push','workflow_dispatch','pull_request'].map((event,n)=>({...original,id:200+i*3+n,head_branch,event}))),
      {...original,id:999,event:'schedule',head_branch:'main'},
    ];
    assert.equal(selectReleasePreflightRun(candidates,policy,sha).id,123);
    const newer={...original,id:150,status:'in_progress',conclusion:null};
    assert.equal(selectReleasePreflightRun([...candidates,newer],policy,sha).id,150);
    const main={...original,id:160,event:'push',head_branch:'main'};
    assert.equal(selectReleasePreflightRun([...candidates,newer,main],policy,sha).id,160);
    assert.equal(selectReleasePreflightRun(candidates.slice(1),policy,sha),undefined);
  }
});
function npmFixture() {
  const list=jobs([...npmSuccessJobs,...npmSkippedJobs]);
  for(const j of list) {
    if(npmSkippedJobs.includes(j.name)){j.conclusion='skipped';continue;}
    const names=npmRequiredSteps[j.name]??['Verify source and native build architecture','Build static helper from canonical source',
      'Verify packaged execution without compiler or network','Upload tested architecture payload','Upload no-compiler cleanup evidence'];
    j.steps=names.map(name=>({name,status:'completed',conclusion:'success'}));
  }
  return {r:{...run,event:'push',path:'.github/workflows/npm-publish.yml',head_branch:'v-npm-0-166-98'},list};
}
const workflow=execFileSync('git',['show',`${sha}:.github/workflows/npm-publish.yml`],{encoding:'utf8',windowsHide:true});
const npmExpected={sha,version:'0.166.98',runId:'123'};
test('all seven exact npm jobs and OIDC configured steps pass',()=>{
  const {r,list}=npmFixture();assert.equal(verifyNpmPublicationJobs(r,list,npmExpected,workflow).status,'VERIFIED');
});
test('npm skipped publish, missing child/provenance/OIDC step, wrong tag and token config fail',()=>{
  for(const name of ['Enable npm Trusted Publishing support','Publish @chainlesschain/session-core','Verify published CLI npm provenance']) {
    const {r,list}=npmFixture();list.find(j=>j.name==='publish').steps.find(s=>s.name===name).conclusion='skipped';
    assert.throws(()=>verifyNpmPublicationJobs(r,list,npmExpected,workflow));
  }
  const {r,list}=npmFixture();
  assert.throws(()=>verifyNpmPublicationJobs({...r,head_branch:'v-npm-0-166-97'},list,npmExpected,workflow));
  assert.throws(()=>verifyNpmPublicationJobs(r,list,npmExpected,workflow.replace('id-token: write','id-token: read')));
  assert.throws(()=>verifyNpmPublicationJobs(r,list,npmExpected,workflow+'\n      NODE_AUTH_TOKEN: token\n'));
});
test('CLI cannot publish before all child steps and registry installation checks',()=>{
  const {r,list}=npmFixture(),steps=list.find(j=>j.name==='publish').steps;
  const cli=steps.splice(steps.findIndex(s=>s.name==='Publish chainlesschain (CLI)'),1)[0];
  steps.unshift(cli);
  assert.throws(()=>verifyNpmPublicationJobs(r,list,npmExpected,workflow),/order differs/);
});
function vscodeFixture(){
  const list=jobs([...vscodeRequiredJobs,...vscodeConditionalSkips]);
  for(const j of list)if(vscodeConditionalSkips.includes(j.name))j.conclusion='skipped';
  const publisher=list.find(j=>j.name==='VS Code extension (Linux host gate + publish)');
  publisher.steps=['Verify immutable candidate manifest before publishing','Require published CLI before VS Code release',
    'Preflight Open VSX credential','Publish to Open VSX','Verify Open VSX listing'].map(name=>({name,status:'completed',conclusion:'success'}));
  publisher.steps.push(...['Preflight VS Code Marketplace credential','Publish to VS Code Marketplace','Verify VS Code Marketplace listing and exact VSIX']
    .map(name=>({name,status:'completed',conclusion:'skipped'})));
  return {r:{...run,event:'push',path:'.github/workflows/ide-extensions.yml',head_branch:'ide-vscode-v0.37.142'},list};
}
const vsExpected={kind:'vscode',sha,version:'0.37.142',runId:'123'};
test('VS release tag requires 14 jobs, not 19, and exact Open VSX publisher steps',()=>{
  const {r,list}=vscodeFixture();assert.equal(list.length,14);
  assert.equal(verifyIdeWorkflowObservation(r,{total_count:14,jobs:list},vsExpected).workflowComplete,true);
});
test('VS missing matrix, unjustified skip and skipped Open VSX upload are rejected',()=>{
  for(const mutate of [list=>list.pop(),list=>{list[0].conclusion='skipped';},list=>{
    list.find(j=>j.name==='VS Code extension (Linux host gate + publish)').steps.find(s=>s.name==='Publish to Open VSX').conclusion='skipped';
  }]){const {r,list}=vscodeFixture();mutate(list);assert.throws(()=>verifyIdeWorkflowObservation(r,{total_count:list.length,jobs:list},vsExpected));}
});
