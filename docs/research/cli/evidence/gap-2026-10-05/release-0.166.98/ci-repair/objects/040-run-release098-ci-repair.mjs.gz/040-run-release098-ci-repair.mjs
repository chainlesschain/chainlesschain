import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const root=process.cwd(),mode=process.argv[2];
const commands={
  'memory-units':{cwd:path.join(root,'packages/cli'),args:[path.join(root,'node_modules/vitest/vitest.mjs'),'run',
    '__tests__/unit/memory-query-index.test.js','__tests__/unit/segmented-memory-port.test.js']},
  'kernel-units':{cwd:path.join(root,'packages/context-memory-kernel'),args:['--test',
    ...fs.readdirSync('packages/context-memory-kernel/test').filter(name=>name.endsWith('.test.js')).map(name=>'test/'+name)]},
  metadata:{cwd:root,args:['node_modules/prettier/bin/prettier.cjs','--check','package-lock.json','packages/cli/package.json',
    'packages/cli/scripts/memory-query-index-benchmark.mjs','packages/context-memory-kernel/package.json',
    'packages/context-memory-kernel/scripts/context-memory-writer-probe.mjs']},
};
if(!commands[mode])throw Error('Unknown mode');
const invocation=commands[mode],startedAt=new Date().toISOString();
const result=spawnSync(process.execPath,invocation.args,{cwd:invocation.cwd,windowsHide:true,encoding:'utf8',
  timeout:120000,maxBuffer:32*1024*1024});
const directory=path.join(root,'.work/release098-ci-repair',startedAt.replaceAll(':','-'));fs.mkdirSync(directory,{recursive:true});
const sourcePaths=['packages/cli/scripts/memory-query-index-benchmark.mjs','packages/context-memory-kernel/scripts/context-memory-writer-probe.mjs',
  'packages/context-memory-kernel/package.json','packages/cli/package.json','package-lock.json'];
const bindings=sourcePaths.map(file=>{
  const bytes=Buffer.from(fs.readFileSync(file,'utf8').replaceAll('\r\n','\n'));
  return {path:file,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')};
});
const file=path.join(directory,mode+'.json');
fs.writeFileSync(file,JSON.stringify({startedAt,finishedAt:new Date().toISOString(),mode,node:process.version,
  platform:process.platform,...invocation,bindings,exitCode:result.status,signal:result.signal,error:result.error?.message??null,
  stdout:result.stdout,stderr:result.stderr,providerCalls:0,formalSample:false,observationsProduced:0},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({file,mode,exitCode:result.status,error:result.error?.message??null,
  tail:result.stdout?.split(/\r?\n/).slice(-14),stderr:result.stderr?.slice(-2500)}));process.exitCode=result.status??1;
