import assert from 'node:assert/strict';
import {test} from 'node:test';
import {jetbrainsRequiredJobs,jetbrainsConditionalSkips,postVerificationJob,verifyIdeWorkflowObservation} from './readback-ide-workflow098.mjs';

const expected={kind:'jetbrains',sha:'a'.repeat(40),version:'0.4.160',runId:'123'};
function fixture() {
  const run={id:123,run_attempt:2,head_sha:expected.sha,event:'push',head_branch:'ide-jetbrains-v0.4.160',
    path:'.github/workflows/ide-extensions.yml',status:'completed',conclusion:'success'};
  const jobs=[...jetbrainsRequiredJobs,...jetbrainsConditionalSkips,postVerificationJob].map((name,index)=>({
    name,id:index+1,run_id:123,run_attempt:2,head_sha:expected.sha,status:'completed',
    conclusion:jetbrainsConditionalSkips.includes(name)?'skipped':'success',steps:[],
  }));
  jobs.find(j=>j.name==='JetBrains plugin (build + publish)').steps=[
    'Require published CLI before JetBrains release','Publish to JetBrains Marketplace',
  ].map(name=>({name,status:'completed',conclusion:'success'}));
  return {run,listing:{total_count:jobs.length,jobs}};
}
function pending() {
  const value=fixture();value.run.status='in_progress';value.run.conclusion=null;
  Object.assign(value.listing.jobs.find(j=>j.name===postVerificationJob),{status:'queued',conclusion:null});
  return value;
}
const check=value=>verifyIdeWorkflowObservation(value.run,value.listing,expected);

test('complete exact tag succeeds; only post check pending produces non-public observation',()=>{
  assert.equal(check(fixture()).workflowComplete,true);
  const value=pending();
  for(const status of ['queued','in_progress','waiting']) {
    value.listing.jobs.at(-1).status=status;
    assert.deepEqual(check(value),{state:'PUBLISHER_SUCCEEDED_POST_VERIFICATION_PENDING',workflowComplete:false,
      postVerificationJobId:value.listing.jobs.at(-1).id,publicationState:'PENDING_NOT_PUBLIC'});
  }
});
test('a required non-post job cannot be queued, failed or skipped',()=>{
  for(const [status,conclusion] of [['queued',null],['in_progress',null],['completed','failure'],['completed','skipped']]) {
    const value=pending();Object.assign(value.listing.jobs[0],{status,conclusion});assert.throws(()=>check(value));
  }
});
test('post failure, timeout, cancellation and failed steps never become pending',()=>{
  for(const conclusion of ['failure','timed_out','cancelled','skipped']) {
    const value=pending();Object.assign(value.listing.jobs.at(-1),{status:'completed',conclusion});assert.throws(()=>check(value));
  }
  const value=pending();value.listing.jobs.at(-1).steps=[{conclusion:'failure'}];assert.throws(()=>check(value));
});
test('required actual upload and public CLI prerequisite steps cannot be skipped',()=>{
  for(const index of [0,1]) {
    const value=pending();value.listing.jobs.find(j=>j.name==='JetBrains plugin (build + publish)').steps[index].conclusion='skipped';
    assert.throws(()=>check(value));
  }
});
test('missing, duplicate, extra and wrong-attempt or SHA jobs fail closed',()=>{
  for(const mutate of [
    value=>value.listing.jobs.pop(),
    value=>{value.listing.jobs[1].name=value.listing.jobs[0].name;},
    value=>{value.listing.jobs[1].name='Unexpected new gate';},
    value=>{value.listing.jobs[1].run_attempt=1;},
    value=>{value.listing.jobs[1].head_sha='b'.repeat(40);},
  ]){const value=pending();mutate(value);assert.throws(()=>check(value));}
});
test('completed failure run and VS Code pending run remain rejected',()=>{
  const value=fixture();value.run.conclusion='failure';assert.throws(()=>check(value));
  const vscode=pending();vscode.run.head_branch='ide-vscode-v0.37.142';
  assert.throws(()=>verifyIdeWorkflowObservation(vscode.run,vscode.listing,{...expected,kind:'vscode',version:'0.37.142'}));
});
