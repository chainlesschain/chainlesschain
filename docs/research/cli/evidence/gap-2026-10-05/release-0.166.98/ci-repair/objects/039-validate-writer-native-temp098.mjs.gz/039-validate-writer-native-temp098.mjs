import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
const root=path.resolve(process.argv[2]);
assert(root.startsWith(path.resolve('.work')+path.sep));
assert(path.basename(root).startsWith('writer-native-temp098-'));
const processReceipt=JSON.parse(fs.readFileSync(path.join(root,'process.json'),'utf8'));
const receipt=JSON.parse(fs.readFileSync(path.join(root,'writer-receipt.json'),'utf8'));
assert.equal(processReceipt.exitCode,0);assert.equal(receipt.status,'passed');
assert.equal(receipt.candidateSha,processReceipt.sha);
assert.equal(receipt.runtime.cli.canonicalStoreCreated,true);
assert.equal(receipt.runtime.cli.canonicalMutationStatus,'committed');
const entries=fs.readdirSync(processReceipt.physicalRoot);
assert(entries.every(name=>!name.startsWith('cc-context-memory-writer-probe-')));
assert.deepEqual(entries,['chainlesschain-test']);
const report={status:'PASS_WRITER_AND_SCOPED_FIXTURE_CLEANUP',observedAt:new Date().toISOString(),
  sourceCommit:processReceipt.sha,processExit:0,providerCalls:0,formalSample:false,observationsProduced:0,
  originalDriverAllTemporaryRootEmptyAssertion:false,writerFixtureCleaned:true,remainingTemporaryEntries:entries,
  boundary:'The original driver required the whole temporary root to be empty and failed after the product already exited 0. Desktop logger.js creates a separate chainlesschain-test/logs directory on import. Static readback checks the writer probe fixture prefix only; original process receipt is preserved. No product rerun or provider request was made.'};
fs.writeFileSync(path.join(root,'validation.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({root,...report}));
