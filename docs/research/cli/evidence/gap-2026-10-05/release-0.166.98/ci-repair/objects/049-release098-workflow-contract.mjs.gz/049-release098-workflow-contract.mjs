import assert from 'node:assert/strict';
import {jetbrainsRequiredJobs,jetbrainsConditionalSkips,postVerificationJob} from './readback-ide-workflow098.mjs';

const oses=['ubuntu-latest','windows-latest','macos-latest'];
const cliJobs=[...oses.map(os=>`PDH native release tests (${os})`),
  ...['x64','arm64'].map(arch=>`linux-subreaper / Linux packaged subreaper (${arch})`),
  ...['ubuntu','windows','macos'].flatMap(os=>['unit','integration','e2e'].flatMap(suite=>{
    const count=suite==='unit'?(os==='windows'?16:4):suite==='integration'?8:4;
    return Array.from({length:count},(_,index)=>`test-${os} / ${suite} (${os}-latest, shard ${index+1}/${count})`);
  })),...oses.map(os=>`verify-cli (${os})`),
  'Test-only PM exploration recovery three-OS aggregate','pack-linux-dryrun','dry-run-publish'];
export const preflightPolicies=[
  {name:'CLI CI',workflow:'cli-ci.yml',names:cliJobs},
  {name:'CLI Strict Sandbox',workflow:'cli-strict-sandbox.yml',names:[
    'macOS latest native capability',...['ubuntu-24.04','macos-15','windows-latest','ubuntu-24.04-arm'].map(os=>`strict native boundary (${os})`)]},
  {name:'IDE Extensions',workflow:'ide-extensions.yml',names:[...jetbrainsRequiredJobs,...jetbrainsConditionalSkips,postVerificationJob]},
  {name:'IDE ARM64 Host Validation',workflow:'ide-arm64-validation.yml',names:[
    'VS Code architecture-neutral candidate',...['linux','windows','macos'].map(os=>`VS Code ARM64 (${os})`),
    ...['linux','macos'].flatMap(os=>['2024.2','2025.2'].map(version=>`JetBrains ARM64 (${os}, ${version})`)),
    'JetBrains ARM64 (windows, 2026.2.0.1)','Aggregate 11-cell IDE ARM64 evidence']},
];
export const releasePreflightBranch='feature/cli-ide-gap-20261011';
export function isReleasePreflightRun(run,policy,sha) {
  if(run.head_sha!==sha||run.name!==policy.name||run.path!==`.github/workflows/${policy.workflow}`) return false;
  // All four current workflows restrict ordinary push validation to main.
  // PR heads and manually dispatched source branches are explicitly scoped to
  // this release task. Neither IDE nor npm tags can enter this candidate set.
  if(run.event==='pull_request') return run.head_branch===releasePreflightBranch;
  if(run.event==='push') return run.head_branch==='main';
  if(run.event==='workflow_dispatch') return ['main',releasePreflightBranch].includes(run.head_branch);
  return false;
}
export function selectReleasePreflightRun(runs,policy,sha) {
  return runs.filter(run=>isReleasePreflightRun(run,policy,sha)).sort((a,b)=>b.id-a.id)[0];
}
export function exactJobs(run,jobs,names,sha) {
  assert.equal(run.head_sha,sha);
  assert(Number.isSafeInteger(run.run_attempt)&&run.run_attempt>0);
  assert.equal(jobs.length,names.length,'Incomplete or extra job matrix');
  assert.equal(new Set(jobs.map(j=>j.id)).size,jobs.length,'Duplicate job id');
  const map=new Map(jobs.map(j=>[j.name,j]));
  assert.equal(map.size,jobs.length,'Duplicate job name');
  for(const job of jobs) {
    assert(names.includes(job.name),`Unexpected job: ${job.name}`);
    assert.equal(job.head_sha,sha); assert.equal(job.run_id,run.id); assert.equal(job.run_attempt,run.run_attempt);
  }
  return map;
}
export function verifyPreflightGate(run,jobs,policy,sha) {
  assert(isReleasePreflightRun(run,policy,sha),'Run is outside this release preflight event/branch/workflow/SHA cohort');
  assert.equal(run.status,'completed'); assert.equal(run.conclusion,'success');
  const map=exactJobs(run,jobs,policy.names,sha);
  for(const [name,job] of map) {
    const skipped=policy.name==='IDE Extensions'&&name===postVerificationJob ||
      policy.name==='CLI CI'&&name==='dry-run-publish'&&run.event!=='pull_request';
    assert.equal(job.status,'completed',name); assert.equal(job.conclusion,skipped?'skipped':'success',name);
  }
  return {workflow:policy.workflow,runId:run.id,attempt:run.run_attempt,sha,jobs:jobs.length,status:'VERIFIED'};
}
export const npmSuccessJobs=['exact-sha-gate','linux-subreaper / Linux packaged subreaper (x64)',
  'linux-subreaper / Linux packaged subreaper (arm64)','package-cli','publish'];
export const npmSkippedJobs=['test','dry-run'];
export const npmRequiredSteps={
  'exact-sha-gate':['Verify immutable npm tag identity','Verify CLI CI and CLI Strict Sandbox for exact SHA','Upload exact-SHA gate attestation'],
  'package-cli':['Build CLI package assets before packing','Download tested Linux x64 helper','Download tested Linux ARM64 helper',
    'Resolve and pack immutable CLI tarball','Generate CLI release SBOM from immutable tarball','Upload immutable CLI release artifact'],
  publish:['Enable npm Trusted Publishing support','Download exact verified CLI tarball','Verify immutable CLI tarball before publishing','Set publish command',
    ...['agent-protocol','core-env','core-mtc','core-multisig','core-settlement','shared-logger','core-config','core-db','core-infra',
      'session-core','context-memory-kernel','agent-sdk','personal-data-hub'].map(name=>`Publish @chainlesschain/${name}`),
    'Verify Agent Protocol registry bytes and npm provenance','Verify published Context Memory Kernel registry bytes and npm provenance',
    'Verify published Agent SDK registry bytes and npm provenance','Verify public child bytes and registry-only dependencies before CLI publish',
    'Publish chainlesschain (CLI)','Verify published CLI npm provenance','Upload public npm readback evidence'],
};
export function verifyNpmPublicationJobs(run,jobs,{sha,version,runId},workflowSource) {
  assert.equal(String(run.id),runId); assert.equal(run.path,'.github/workflows/npm-publish.yml');
  assert.equal(run.event,'push'); assert.equal(run.head_branch,`v-npm-${version.replaceAll('.','-')}`);
  assert.equal(run.status,'completed'); assert.equal(run.conclusion,'success');
  const map=exactJobs(run,jobs,[...npmSuccessJobs,...npmSkippedJobs],sha);
  for(const [name,job] of map) {
    assert.equal(job.status,'completed',name); assert.equal(job.conclusion,npmSkippedJobs.includes(name)?'skipped':'success',name);
    for(const step of job.steps??[]) assert(['success','skipped'].includes(step.conclusion),`Failed or incomplete step: ${name}/${step.name}`);
  }
  for(const name of npmSuccessJobs) {
    const steps=map.get(name).steps;
    const required=npmRequiredSteps[name]??['Verify source and native build architecture','Build static helper from canonical source',
      'Verify packaged execution without compiler or network','Upload tested architecture payload','Upload no-compiler cleanup evidence'];
    for(const stepName of required) {
      const matches=steps.filter(s=>s.name===stepName); assert.equal(matches.length,1,`${name}/${stepName}`);
      assert.equal(matches[0].status,'completed',stepName); assert.equal(matches[0].conclusion,'success',stepName);
    }
  }
  const publishSteps=map.get('publish').steps;
  const index=name=>publishSteps.findIndex(step=>step.name===name);
  const registryIndex=index('Verify public child bytes and registry-only dependencies before CLI publish');
  const cliIndex=index('Publish chainlesschain (CLI)');
  assert(registryIndex<cliIndex&&cliIndex<index('Verify published CLI npm provenance'),'CLI publish/readback order differs');
  for(const name of npmRequiredSteps.publish.filter(name=>name.startsWith('Publish @chainlesschain/'))) {
    assert(index('Enable npm Trusted Publishing support')<index(name)&&index(name)<registryIndex,'Child publish must precede registry validation and CLI');
  }
  const publishSource=workflowSource.split(/^  publish:\s*$/mu)[1]; assert(publishSource,'Missing publish job source');
  assert.match(publishSource,/id-token:\s*write/u);
  assert.match(publishSource,/npm install --global npm@11\.18\.0/u);
  assert.match(publishSource,/FLAGS=--provenance --access public/u);
  assert(!/\b(?:NODE_AUTH_TOKEN|NPM_TOKEN)\s*:/u.test(publishSource),'Unexpected token publishing configuration');
  return {status:'VERIFIED',runId:run.id,attempt:run.run_attempt,sha,jobs:jobs.length,
    oidcEvidence:'Exact workflow id-token permission, successful Trusted Publishing step and independently checked signed provenance receipts'};
}
