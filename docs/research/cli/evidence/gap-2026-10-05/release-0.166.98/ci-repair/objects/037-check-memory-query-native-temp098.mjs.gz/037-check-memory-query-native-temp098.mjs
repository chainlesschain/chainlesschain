import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import crypto from 'node:crypto';

const phase=process.argv[2];assert(['before','after'].includes(phase));
const repository=process.cwd();
const root=fs.mkdtempSync(path.join(repository,'.work','memory-query-native-temp098-'));
const physical=path.join(root,'physical temporary root');
const alias=path.join(root,'aliased-temp');
fs.mkdirSync(physical);fs.symlinkSync(physical,alias,process.platform==='win32'?'junction':'dir');
assert.notEqual(alias,fs.realpathSync.native(alias));
const script='packages/cli/scripts/memory-query-index-benchmark.mjs';
const hash=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const source=fs.readFileSync(script);fs.writeFileSync(path.join(root,'benchmark-source.mjs'),source,{flag:'wx'});
const guards=['packages/cli/src/lib/context-memory-kernel/segmented-memory-port.js','packages/cli/src/lib/context-memory-kernel/durable-memory-port.js'];
const args=[script,'--counts','1000','--samples','1','--output',path.join(root,'measurement.json')];
const startedAt=new Date().toISOString();
const result=spawnSync(process.execPath,args,{cwd:repository,env:{...process.env,TMP:alias,TEMP:alias,TMPDIR:alias},encoding:'utf8',windowsHide:true,timeout:120000,maxBuffer:8*1024*1024});
fs.writeFileSync(path.join(root,'stdout.txt'),result.stdout??'',{flag:'wx'});
fs.writeFileSync(path.join(root,'stderr.txt'),result.stderr??'',{flag:'wx'});
const report={phase,startedAt,finishedAt:new Date().toISOString(),platform:process.platform,node:process.version,executable:process.execPath,args,
  temporaryRoot:alias,nativeTemporaryRoot:fs.realpathSync.native(alias),scriptSha256:hash(script),guardSha256:Object.fromEntries(guards.map(file=>[file,hash(file)])),
  status:result.status,signal:result.signal,error:result.error?.message??null,root};
fs.writeFileSync(path.join(root,'process.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
if(phase==='before') {assert.notEqual(result.status,0);assert.match(result.stderr,/authority directory (?:resolves elsewhere|is unsafe)/);}
else {
  assert.equal(result.status,0,result.stderr||result.error?.message);
  const measurement=JSON.parse(fs.readFileSync(path.join(root,'measurement.json')));
  assert.equal(measurement.tiers.length,1);
  for(const group of Object.values(measurement.tiers[0].groups))assert.equal(group.samples[0].rowsDigest,measurement.tiers[0].expectedDigest);
  assert.deepEqual(fs.readdirSync(physical),[],'Canonical benchmark fixture cleanup did not complete');
}
console.log(JSON.stringify(report));
