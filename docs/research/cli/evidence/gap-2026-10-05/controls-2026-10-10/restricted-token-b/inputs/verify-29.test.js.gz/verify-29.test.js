import { it as diagnosticIt, expect as diagnosticExpect } from "vitest";

import { it as controlIt, expect as controlExpect } from "vitest";
import { createRequire as controlCreateRequire } from "node:module";
const { acceptModeAcknowledgement: controlAcceptMode } =
  controlCreateRequire(import.meta.url)("../../vscode-extension/src/chat/permission-mode-state.js");

controlIt("matching request IDs cannot authorize another session's mode ACK", () => {
  const conversation = {
    sessionId: "control-session",
    modeRequestId: "control-mode-request",
    mode: "acceptEdits",
    effectiveMode: "default",
    modeStatus: "pending",
    policyRevision: null,
    modeError: "",
  };
  const before = { ...conversation };
  const event = {
    session_id: "different-session",
    permission_mode_state: {
      correlation_id: conversation.modeRequestId,
      requested: conversation.mode,
      effective: "acceptEdits",
      policy_revision: "a".repeat(64),
    },
  };
  controlExpect(controlAcceptMode(conversation, event)).toBe(false);
  controlExpect(conversation).toEqual(before);
  controlExpect(controlAcceptMode(conversation, {
    ...event, session_id: conversation.sessionId,
  })).toBe(true);
  controlExpect(conversation).toMatchObject({
    effectiveMode: "acceptEdits",
    modeStatus: "effective",
    policyRevision: event.permission_mode_state.policy_revision,
  });
});
