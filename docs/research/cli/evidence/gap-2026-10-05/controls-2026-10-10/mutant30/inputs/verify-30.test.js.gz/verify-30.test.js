import { it as diagnosticIt, expect as diagnosticExpect } from "vitest";

import { inspectImageBudget } from "../../vscode-extension/src/chat/image-decode-budget.js";
// APNG has one animation frame and a separate default-image canvas. Payload
// bytes are only inspected here; codec decoding is a separate admission step.
function diagnosticPngChunk(type, payload) {
  const chunk = Buffer.alloc(payload.length + 12);
  chunk.writeUInt32BE(payload.length, 0);
  chunk.write(type, 4, 4, "ascii");
  payload.copy(chunk, 8);
  let crc = 0xffffffff;
  for (const byte of chunk.subarray(4, -4)) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit++) crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0);
  }
  chunk.writeUInt32BE((crc ^ 0xffffffff) >>> 0, chunk.length - 4);
  return chunk;
}
function diagnosticFallbackPng(width, height) {
  const header = Buffer.alloc(13);
  header.writeUInt32BE(width, 0);
  header.writeUInt32BE(height, 4);
  header[8] = 8;
  header[9] = 6;
  const animation = Buffer.alloc(8);
  animation.writeUInt32BE(1, 0);
  const frame = Buffer.alloc(26);
  frame.writeUInt32BE(width, 4);
  frame.writeUInt32BE(height, 8);
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), diagnosticPngChunk("IHDR", header), diagnosticPngChunk("acTL", animation), diagnosticPngChunk("IDAT", Buffer.from([120, 156])), diagnosticPngChunk("fcTL", frame), diagnosticPngChunk("fdAT", Buffer.alloc(4)), diagnosticPngChunk("IEND", Buffer.alloc(0))]);
}
diagnosticIt("includes the separate APNG default canvas in the cumulative pixel budget", () => {
  diagnosticExpect(inspectImageBudget(diagnosticFallbackPng(5000, 4000))).toMatchObject({ frames: 1, extraCanvases: 1, decodedPixels: 40000000 });
  diagnosticExpect(() => inspectImageBudget(diagnosticFallbackPng(5001, 4000))).toThrow(/fallback exceed/);
});
diagnosticIt("counts every GIF animation canvas", () => {
  const gif = Buffer.from("R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7", "base64");
  const animated = Buffer.concat([gif.subarray(0, 19), ...Array(3).fill(gif.subarray(19, -1)), Buffer.from([0x3b])]);
  diagnosticExpect(inspectImageBudget(animated)).toMatchObject({ frames: 3, decodedPixels: 3 });
});
