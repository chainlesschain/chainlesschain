import { it as diagnosticIt, expect as diagnosticExpect } from "vitest";

import { transformBackgroundLaunchArgv, canonicalizeBackgroundSessionArgv } from "../src/lib/background-command-argv.js";
diagnosticIt("preserves empty, spaced and quoted argument boundaries", () => {
  const tail = ["", "two words", 'a"quoted"path', "$(literal)"];
  const argv = ["agent", "--background", "--", ...tail];
  const grammar = { commandNames: ["agent"], optionSpecs: [{ long: "--background" }] };
  diagnosticExpect(transformBackgroundLaunchArgv(argv, grammar)).toEqual(["agent", "--", ...tail]);
  diagnosticExpect(canonicalizeBackgroundSessionArgv(["agent", "--", ...tail], { ...grammar, sessionId: "child" })).toEqual(["agent", "--session", "child", "--", ...tail]);
  diagnosticExpect(argv).toEqual(["agent", "--background", "--", ...tail]);
});
