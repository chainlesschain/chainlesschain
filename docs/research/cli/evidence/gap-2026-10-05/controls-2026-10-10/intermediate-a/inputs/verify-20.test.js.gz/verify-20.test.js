import { it as diagnosticIt, expect as diagnosticExpect } from "vitest";

import { buildPermissionDecision } from "../src/lib/permission-decision.js";
diagnosticIt("keeps policy deny above a conflicting approval and terminal allow", () => {
  const approval = { decision: "allow", via: "user" };
  const permissionChain = [{ layer: "approval", outcome: "allow" }];
  diagnosticExpect(buildPermissionDecision({ result: { approval, permissionChain } }).decision).toBe("allow");
  const result = buildPermissionDecision({ result: { policy: { decision: "deny", via: "managed" }, approval, permissionChain } });
  diagnosticExpect(result.decision).toBe("deny");
  diagnosticExpect(result.via).toBe("managed");
});
