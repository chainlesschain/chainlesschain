/** Trusted operator acceptance code. Candidate code runs only in Docker.
 * Generated setup/check files inline these bytes; no mutable helper imports.
 */
import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import { spawnSync } from "node:child_process";
import { createHash, randomUUID } from "node:crypto";

// Frozen permission tests invoke real git; the slim image omits it.
export const REVIEW_IMAGE = "node:22.12.0-bookworm";
const MAX_OUTPUT = 8 * 1024 * 1024;
const MAX_STAGE_MS = 10 * 60 * 1000;
const CLEANUP_RESERVE_MS = 40000;
const hash = (bytes) => createHash("sha256").update(bytes).digest("hex");
function requireCondition(condition, detail) {
  if (!condition) throw new Error(detail);
}

function regularFile(root, relative) {
  requireCondition(
    typeof relative === "string" &&
      relative
        .split("/")
        .every((part) => part && part !== "." && part !== "..") &&
      !/[\\:*?<>|"\u0000]/u.test(relative) &&
      !relative.startsWith("/"),
    "acceptance path must be an exact relative file",
  );
  let current = root;
  for (const part of relative.split("/")) {
    current = path.join(current, part);
    requireCondition(
      !fs.lstatSync(current).isSymbolicLink(),
      "acceptance path traverses a link",
    );
  }
  const stat = fs.statSync(current);
  requireCondition(
    stat.isFile() && stat.nlink === 1 && stat.size <= 16 * 1024 * 1024,
    "acceptance file must be a bounded regular file without hard-link aliases",
  );
  return current;
}

/** The Docker client gets only platform plumbing, never account credentials or
 * NODE_OPTIONS. No host environment variables are forwarded to the container.
 */
export function reviewEnvironment(input = process.env) {
  const result = {};
  for (const key of [
    "SystemRoot",
    "WINDIR",
    "PATH",
    "TEMP",
    "TMP",
    "DOCKER_HOST",
    "DOCKER_CONTEXT",
  ])
    if (input[key]) result[key] = input[key];
  return result;
}

export function reviewDockerArgs({
  workspace,
  control,
  containerName,
  setup = false,
  command,
  imageId,
  uid,
  gid,
  timeoutMs = MAX_STAGE_MS,
}) {
  requireCondition(
    /^sha256:[a-f0-9]{64}$/u.test(imageId || ""),
    "acceptance requires an externally pinned Docker image ID",
  );
  requireCondition(
    [uid, gid].every(
      (value) =>
        Number.isSafeInteger(value) && value >= 0 && value < 0xffffffff,
    ),
    "acceptance requires the Linux operator's numeric UID and GID",
  );
  requireCondition(
    path.isAbsolute(workspace) && path.isAbsolute(control),
    "Docker mounts must be absolute",
  );
  requireCondition(
    ![workspace, control].some((value) => /[,\r\n\u0000]/u.test(value)),
    "unsupported Docker mount path",
  );
  requireCondition(
    Number.isSafeInteger(timeoutMs) &&
      timeoutMs > 0 &&
      timeoutMs <= MAX_STAGE_MS,
    "container acceptance requires a bounded positive deadline",
  );
  return [
    "run",
    "--rm",
    "--init",
    // With all capabilities dropped, container root cannot write private
    // runner-owned bind mounts. Keep the operator's actual file identity.
    "--user",
    `${uid}:${gid}`,
    "--name",
    containerName,
    "--network",
    setup ? "bridge" : "none",
    "--read-only",
    "--cap-drop",
    "ALL",
    "--security-opt",
    "no-new-privileges",
    "--pids-limit",
    "256",
    "--memory",
    "4g",
    "--cpus",
    "2",
    "--tmpfs",
    "/tmp:rw,nosuid,nodev,size=1g",
    "--mount",
    `type=bind,source=${workspace},target=/workspace${setup ? "" : ",readonly"}`,
    "--mount",
    `type=bind,source=${control},target=/review,readonly`,
    "--workdir",
    "/workspace",
    "--env",
    "HOME=/tmp/review-home",
    "--env",
    "CI=1",
    imageId,
    // The daemon's PID namespace keeps its own deadline even if an outer
    // evaluator cancellation kills the Docker client before finally can run.
    "timeout",
    "--signal=TERM",
    "--kill-after=5s",
    `${Math.max(1, timeoutMs - 5000) / 1000}s`,
    ...command,
  ];
}

export function parseReviewTests(
  result,
  { mutant = false, baseline = false } = {},
) {
  requireCondition(
    !result.error && !result.signal,
    "test runner failed or timed out",
  );
  let report;
  try {
    report = JSON.parse(result.stdout.trim());
  } catch {
    throw new Error("test runner did not emit one valid JSON report");
  }
  const cases = (report.testResults || []).flatMap(
    (file) => file.assertionResults || [],
  );
  requireCondition(
    cases.length > 0 && report.numTotalTests === cases.length,
    "acceptance requires executed test cases",
  );
  requireCondition(
    cases.every((test) =>
      (baseline
        ? ["passed", "failed", "pending"]
        : ["passed", "failed"]
      ).includes(test.status),
    ) &&
      (baseline || report.numPendingTests === 0) &&
      (report.numTodoTests || 0) === 0,
    "skipped, pending, todo or empty tests cannot pass acceptance",
  );
  if (mutant) {
    requireCondition(
      result.status === 1 &&
        report.numFailedTests > 0 &&
        report.success === false,
      "candidate tests did not reject the behavioral mutant",
    );
    requireCondition(
      cases.some(
        (test) =>
          test.status === "failed" &&
          (test.failureMessages || []).some(
            (message) =>
              /^AssertionError(?:\s*\[[^\]]+\])?(?::|\b)/mu.test(message) ||
              // Vitest serializes rejects/resolves assertion failures as Error.
              // Require its assertion frame as well as the mismatch message;
              // arbitrary Error, import and rejected application errors fail.
              (/^Error: (?:promise (?:resolved|rejected)[^\n]*instead of|expected [^\n]* to )/u.test(
                message,
              ) &&
                /at _Assertion\.__VITEST_(?:REJECTS|RESOLVES)__ \([^\n]*[/\\]@vitest[/\\]expect[/\\]/u.test(
                  message,
                )),
          ),
      ),
      "mutant failure must include an assertion, not a syntax/import/runner error",
    );
    requireCondition(
      (report.testResults || []).every(
        (file) =>
          !file.message ||
          !/SyntaxError|Cannot find module|ERR_MODULE_NOT_FOUND|Failed to load/iu.test(
            file.message,
          ),
      ),
      "mutant failed because of loading rather than behavior",
    );
  } else {
    requireCondition(
      result.status === 0 &&
        report.success === true &&
        report.numFailedTests === 0 &&
        report.numPassedTests > 0 &&
        report.numPassedTests + (baseline ? report.numPendingTests : 0) ===
          cases.length,
      "candidate or baseline regression failed",
    );
  }
  return {
    total: cases.length,
    passed: report.numPassedTests,
    failed: report.numFailedTests,
  };
}

export function applyReviewMutation(source, mutant) {
  requireCondition(
    typeof mutant.find === "string" &&
      mutant.find.length > 0 &&
      typeof mutant.replace === "string" &&
      mutant.find !== mutant.replace,
    "invalid behavioral mutation",
  );
  const offset = source.indexOf(mutant.find);
  requireCondition(
    offset >= 0 && source.indexOf(mutant.find, offset + mutant.find.length) < 0,
    `mutation ${mutant.name} no longer has one exact match; independent re-review required`,
  );
  return (
    source.slice(0, offset) +
    mutant.replace +
    source.slice(offset + mutant.find.length)
  );
}

export function reviewStageDeadline(now, externalDeadline) {
  const outer = externalDeadline ?? now + MAX_STAGE_MS + CLEANUP_RESERVE_MS;
  requireCondition(
    Number.isSafeInteger(now) && Number.isSafeInteger(outer),
    "acceptance requires a valid evaluator deadline",
  );
  const deadline = Math.min(now + MAX_STAGE_MS, outer - CLEANUP_RESERVE_MS);
  requireCondition(
    deadline > now,
    "remaining task budget cannot provide container cleanup time",
  );
  return deadline;
}

function controller(workspace, spec, execute = spawnSync, externalDeadline) {
  const deadline = reviewStageDeadline(Date.now(), externalDeadline);
  // This is not the task's review root and is never mounted writable in a test.
  const control = fs.mkdtempSync(
    path.join(os.tmpdir(), "cc-verify01-control-"),
  );
  const executions = [];
  const containerNames = new Set();
  requireCondition(
    /^sha256:[a-f0-9]{64}$/u.test(spec.imageId || ""),
    "acceptance requires an externally pinned Docker image ID",
  );
  function run(command, { setup = false } = {}) {
    const containerName = `cc-verify01-${randomUUID()}`;
    const started = Date.now();
    const timeoutMs = deadline - started;
    requireCondition(timeoutMs > 0, "acceptance stage deadline exhausted");
    containerNames.add(containerName);
    const result = execute(
      "docker",
      reviewDockerArgs({
        workspace,
        control,
        containerName,
        setup,
        command,
        imageId: spec.imageId,
        uid: process.getuid(),
        gid: process.getgid(),
        timeoutMs,
      }),
      {
        env: reviewEnvironment(),
        encoding: "utf8",
        shell: false,
        timeout: timeoutMs,
        maxBuffer: MAX_OUTPUT,
        windowsHide: true,
      },
    );
    executions.push({
      command,
      setup,
      ms: Date.now() - started,
      exitCode: result.status ?? null,
      signal: result.signal ?? null,
      stdout: result.stdout || "",
      stderr: result.stderr || "",
      error: result.error?.message || null,
    });
    if (result.error || result.signal) {
      const fence = execute("docker", ["rm", "--force", containerName], {
        env: reviewEnvironment(),
        encoding: "utf8",
        shell: false,
        timeout: 30000,
        maxBuffer: MAX_OUTPUT,
        windowsHide: true,
      });
      requireCondition(
        fence.status === 0 && !fence.error,
        "acceptance container cleanup is unconfirmed",
      );
    }
    containerNames.delete(containerName);
    return result;
  }
  function tests(files, mutant = false, baseline = false) {
    files.forEach((file) => regularFile(workspace, file));
    for (const support of spec.testSupport) {
      const bytes = fs.readFileSync(regularFile(workspace, support.path));
      requireCondition(
        `sha256:${hash(bytes)}` === support.digest,
        "frozen test setup support changed",
      );
    }
    // A locked external config prevents task-controlled Vitest include/exclude,
    // passWithNoTests, reporters and setup files from redefining acceptance.
    fs.writeFileSync(
      path.join(control, "vitest.config.mjs"),
      `export default ${JSON.stringify({
        test: {
          root: "/workspace",
          include: files,
          globals: true,
          pool: "forks",
          maxWorkers: 1,
          testTimeout: 90000,
          hookTimeout: 120000,
          teardownTimeout: 30000,
          passWithNoTests: false,
          cache: false,
          setupFiles: spec.testSupport
            .filter((file) => file.kind === "setup")
            .map((file) => `/workspace/${file.path}`),
          globalSetup: spec.testSupport
            .filter((file) => file.kind === "globalSetup")
            .map((file) => `/workspace/${file.path}`),
        },
      })};\n`,
    );
    return parseReviewTests(
      run([
        "node",
        "/workspace/node_modules/vitest/vitest.mjs",
        "run",
        "--config",
        "/review/vitest.config.mjs",
        "--configLoader",
        "native",
        "--reporter=json",
      ]),
      { mutant, baseline },
    );
  }
  function close() {
    requireCondition(
      containerNames.size === 0,
      "acceptance has an unfenced container",
    );
    fs.rmSync(control, { recursive: true });
  }
  return { run, tests, close, executions, control };
}

function verifyDocument(workspace, spec, runner) {
  const body = fs.readFileSync(
    regularFile(workspace, spec.expectedFiles[0]),
    "utf8",
  );
  requireCondition(
    body.trim().length >= 300,
    "runbook must contain substantive operating instructions",
  );
  for (const expression of [
    "task-outcome-report\\.mjs",
    "--fingerprint",
    "INSUFFICIENT_EVIDENCE",
    "(?:null|unknown|未知)",
    "(?:退出|exit|code)[^\\n]{0,40}2",
    "(?:不得|禁止|not|never)[^\\n]{0,60}(?:PASS|改善)",
  ])
    requireCondition(
      new RegExp(expression, "iu").test(body),
      `runbook misses ${expression}`,
    );
  // The frozen project predates this plan directory. It is evaluator input,
  // pinned in the generated script and mounted read-only outside the project.
  fs.writeFileSync(
    path.join(runner.control, "plan.json"),
    JSON.stringify(spec.frozenPlan),
  );
  const plan = "/review/plan.json";
  const script = "packages/cli/scripts/task-outcome-report.mjs";
  const fingerprint = runner.run([
    "node",
    script,
    "--plan",
    plan,
    "--fingerprint",
  ]);
  requireCondition(
    fingerprint.status === 0 && /sha256:[a-f0-9]{64}/u.test(fingerprint.stdout),
    "real fingerprint command failed",
  );
  const empty = runner.run([
    "node",
    script,
    "--plan",
    plan,
    "--plan-digest",
    fingerprint.stdout.trim(),
  ]);
  requireCondition(
    empty.status === 2 && !empty.error && !empty.signal,
    "missing observations must return exit 2",
  );
  const report = JSON.parse(empty.stdout);
  requireCondition(
    report.status === "INSUFFICIENT_EVIDENCE" &&
      report.task.observed === 0 &&
      report.task.missing === 36 &&
      report.firstRun.missing === 9 &&
      report.task.totalCost === null,
    "real missing-sample/unknown-cost report changed",
  );
  return {
    fingerprint: fingerprint.stdout.trim(),
    missingTaskSamples: 36,
    missingFirstRunSamples: 9,
  };
}

export function runReviewStage(
  workspaceInput,
  spec,
  stage,
  { execute = spawnSync, deadline } = {},
) {
  const workspace = fs.realpathSync(workspaceInput);
  requireCondition(
    stage === "setup" || stage === "check",
    "unknown review stage",
  );
  requireCondition(
    process.platform === "linux",
    "this Docker acceptance pack supports Linux strata only; native IDE/Windows/macOS reviews remain separate",
  );
  requireCondition(/^verify-\d{2}$/u.test(spec.taskId), "unknown review task");
  const runner = controller(workspace, spec, execute, deadline);
  const receipt = {
    scope: "verify01-operator-acceptance",
    taskId: spec.taskId,
    stage,
    productionAttested: false,
    providerAssessed: false,
    isolation: "docker",
    imageReference: REVIEW_IMAGE,
    imageId: spec.imageId,
    operator: { uid: process.getuid(), gid: process.getgid() },
    tests: [],
    mutations: [],
    executions: runner.executions,
  };
  let sourceFile, original;
  try {
    const version = runner.run(["node", "--version"]);
    requireCondition(
      version.status === 0 && version.stdout.trim() === "v22.12.0",
      "pinned acceptance image does not supply Node 22.12.0",
    );
    if (stage === "setup") {
      requireCondition(
        spec.expectedFiles.every(
          (file) => !fs.existsSync(path.join(workspace, file)),
        ),
        "setup must not preinstall answer deliverables",
      );
      const installation = runner.run(
        [
          "npm",
          "ci",
          "--workspace",
          "packages/cli",
          // Frozen DOM tests depend on the root's locked happy-dom package.
          "--include-workspace-root=true",
          "--legacy-peer-deps",
          "--ignore-scripts",
          "--no-audit",
          "--no-fund",
          "--cache",
          "/tmp/npm-cache",
          "--userconfig",
          "/dev/null",
        ],
        { setup: true },
      );
      requireCondition(
        installation.status === 0 &&
          !installation.error &&
          !installation.signal,
        "locked dependency installation failed",
      );
      // npm lifecycle hooks stay disabled. Explicitly invoke only the locked
      // native dependency's prebuild installer, before any candidate exists.
      // Do not fall back to arbitrary install scripts or a source build.
      const native = runner.run(
        [
          "node",
          "--input-type=commonjs",
          "--eval",
          'process.chdir("/workspace/node_modules/better-sqlite3"); require("/workspace/node_modules/prebuild-install/bin.js");',
        ],
        { setup: true },
      );
      requireCondition(
        native.status === 0 && !native.error && !native.signal,
        "locked SQLite native prebuild installation failed",
      );
      const nativeProbe = runner.run([
        "node",
        "--input-type=commonjs",
        "--eval",
        'const fs=require("node:fs"),crypto=require("node:crypto"),Database=require("/workspace/node_modules/better-sqlite3"); const db=new Database(":memory:"); if(db.prepare("select 42 as value").get().value!==42) throw new Error("SQLite native probe failed"); db.close(); const bytes=fs.readFileSync("/workspace/node_modules/better-sqlite3/build/Release/better_sqlite3.node"); console.log(JSON.stringify({sha256:crypto.createHash("sha256").update(bytes).digest("hex"),sqliteVerified:true}));',
      ]);
      requireCondition(
        nativeProbe.status === 0 && !nativeProbe.error && !nativeProbe.signal,
        "installed SQLite native prebuild cannot execute",
      );
      receipt.nativeDependency = JSON.parse(nativeProbe.stdout.trim());
      if (spec.baselineTests.length)
        receipt.tests.push({
          kind: "baseline",
          ...runner.tests(spec.baselineTests, false, true),
        });
    } else if (spec.doc) {
      receipt.document = verifyDocument(workspace, spec, runner);
    } else {
      receipt.tests.push({
        kind: "baseline",
        ...runner.tests(spec.baselineTests, false, true),
      });
      receipt.tests.push({
        kind: "candidate",
        ...runner.tests(spec.expectedFiles),
      });
      sourceFile = regularFile(workspace, spec.sourcePath);
      original = fs.readFileSync(sourceFile);
      requireCondition(
        spec.mutants.length > 0,
        "behavioral mutants are required",
      );
      for (const mutant of spec.mutants) {
        const changed = applyReviewMutation(original.toString("utf8"), mutant);
        fs.writeFileSync(sourceFile, changed);
        const syntax = runner.run([
          "node",
          "--check",
          `/workspace/${spec.sourcePath}`,
        ]);
        requireCondition(
          syntax.status === 0 && !syntax.error && !syntax.signal,
          "behavioral mutation has invalid syntax",
        );
        receipt.mutations.push({
          name: mutant.name,
          sourceSha256: hash(Buffer.from(changed)),
          ...runner.tests(spec.expectedFiles, true),
        });
        fs.writeFileSync(sourceFile, original);
      }
    }
    receipt.pass = true;
    receipt.detail =
      "Independent operator checks passed; this is not a provider or task-outcome sample.";
  } catch (error) {
    receipt.pass = false;
    receipt.detail = error.message;
  } finally {
    if (sourceFile && original) {
      requireCondition(
        regularFile(workspace, spec.sourcePath) === sourceFile,
        "mutated source identity changed before restoration",
      );
      fs.writeFileSync(sourceFile, original);
    }
    runner.close();
  }
  return receipt;
}

const spec = {"taskId":"verify-34","sourcePath":"packages/cli/scripts/task-outcome-report.mjs","baselineTests":["packages/cli/__tests__/unit/task-outcome-report.test.js"],"doc":true,"requiredCommands":["packages/cli/scripts/task-outcome-report.mjs","--plan","--fingerprint","--plan-digest"],"conditions":["Bind the reviewed frozen plan fingerprint before generating a report.","Missing planned samples retain the fixed denominator and produce exit code 2.","Unknown costs remain null; never substitute zero.","A local baseline report must not be described as improvement PASS or production attestation."],"mutants":[],"expectedFiles":["docs/development/verify-34-outcome-runbook.md"],"imageId":"sha256:344dbe71e1c47a59db0e94bebdcc94ef3a7bc8bd828393c820168993539048da","testSupport":[{"kind":"globalSetup","path":"packages/cli/test/global-setup/windows-sandbox-adapter-temp-root.js","digest":"sha256:6038c0e7b3d40886fee5f16c7803e62488f945554e6ef234b60947fc93341637"},{"kind":"setup","path":"packages/cli/test/setup/windows-sandbox-adapter-cleanup.js","digest":"sha256:c81f9ac1ae76d541b60ed2befa5eac8e553470856409d6c11c46d5ac640d15ad"},{"kind":"setup","path":"packages/cli/test/setup/agent-evolution-test-boundary.js","digest":"sha256:c55bfb7e020ebfaa61c5d4187a14f6e0b4a541eb0b559b9bdba48592990f4516"}],"frozenPlan":{"schema":"chainlesschain.outcome-plan/v1","commitSha":"b2aa3aba082873570e85dce39b00754e5504ff37","currency":"USD","window":{"start":"2026-10-05T00:00:00.000Z","end":"2026-10-12T00:00:00.000Z"},"samples":[{"id":"verify-01","kind":"task","taskId":"verify-01","stratum":"win32-cli-volcengine","comparisonDigest":"sha256:c176a7a1e00b08aa5c6e124db50a15d64d48b79d8e07b75f08abd1cecefaee64","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-02","kind":"task","taskId":"verify-02","stratum":"win32-vscode-volcengine","comparisonDigest":"sha256:b87fc3194d257b819b6e27c6ce9e12577e092cc061d5c34c4bbbbd386a634d5c","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-03","kind":"task","taskId":"verify-03","stratum":"win32-jetbrains-volcengine","comparisonDigest":"sha256:978b15be2d74757c9ed87188744f72a83746232b1eddaf55062e99e103788933","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-04","kind":"task","taskId":"verify-04","stratum":"linux-cli-volcengine","comparisonDigest":"sha256:de69246028ab35e3063f4361f39eea43ad4e0a831001a016679b597604d07bdb","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-05","kind":"task","taskId":"verify-05","stratum":"linux-vscode-volcengine","comparisonDigest":"sha256:4177b758b9ae924d2251679c65b9634a4e157b0525e7d5f03bb8b6adc945dea0","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-06","kind":"task","taskId":"verify-06","stratum":"linux-jetbrains-volcengine","comparisonDigest":"sha256:1b5e5fd872dbe39b5c02c4d7e78b2b9a80b149b1ba7bbda017093374cc981ef7","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-07","kind":"task","taskId":"verify-07","stratum":"darwin-cli-volcengine","comparisonDigest":"sha256:9c680b8d67a42104335c8a920d04ef963698b792100fc3dec4332884d0f0bfe7","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-08","kind":"task","taskId":"verify-08","stratum":"darwin-vscode-volcengine","comparisonDigest":"sha256:0c73a8bb9ae948a96a2a40adc0af4fc442c9fddd8246ed19abb4705493944361","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-09","kind":"task","taskId":"verify-09","stratum":"darwin-jetbrains-volcengine","comparisonDigest":"sha256:5bf3630291366fae1fff1e08a5c3a27ddeb865f40c3c297f25a30c6fa65ca703","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-10","kind":"task","taskId":"verify-10","stratum":"win32-cli-openai","comparisonDigest":"sha256:6e97d8cca2d845d000ccab9988d9ad23832c71a8e65c22d8984ff4c0a60b4982","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-11","kind":"task","taskId":"verify-11","stratum":"win32-vscode-openai","comparisonDigest":"sha256:f29cb6508b21a3380ecd9262ff2e35becda6c501b4426dae164db52c359d6d26","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-12","kind":"task","taskId":"verify-12","stratum":"win32-jetbrains-openai","comparisonDigest":"sha256:0097eb516d082fee2d2aad67530eb2aa7e6e0d35dd6f5a39ead842a682fb961e","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-13","kind":"task","taskId":"verify-13","stratum":"linux-cli-openai","comparisonDigest":"sha256:a9960328a3f7115a9de63f401ab5efd3c5300240dfec5a5e8850652f76edc27c","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-14","kind":"task","taskId":"verify-14","stratum":"linux-vscode-openai","comparisonDigest":"sha256:c85373d1bb4b42621a73687d243cb1be72e01a5151eda28ae68aec3b6b43bd7c","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-15","kind":"task","taskId":"verify-15","stratum":"linux-jetbrains-openai","comparisonDigest":"sha256:8cd57b4f5f0d57a95571ef1e2a27c67b491686319eb3b881b24dd24d75206e44","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-16","kind":"task","taskId":"verify-16","stratum":"darwin-cli-openai","comparisonDigest":"sha256:60f0c3583484c86813b3d7f5e651a35c7aa113c872943ef875cd067ea6c56e63","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-17","kind":"task","taskId":"verify-17","stratum":"darwin-vscode-openai","comparisonDigest":"sha256:9722493e74f1a6010d2af7a7ea9513455c3223b82f1e8894f2cbb54f61b0d4cb","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-18","kind":"task","taskId":"verify-18","stratum":"darwin-jetbrains-openai","comparisonDigest":"sha256:8a05412b84d28c5d55a20fc66df8cdb04e80efc53a3077502d8bcf50831f3e49","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-19","kind":"task","taskId":"verify-19","stratum":"win32-cli-volcengine","comparisonDigest":"sha256:c176a7a1e00b08aa5c6e124db50a15d64d48b79d8e07b75f08abd1cecefaee64","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-20","kind":"task","taskId":"verify-20","stratum":"win32-vscode-volcengine","comparisonDigest":"sha256:b87fc3194d257b819b6e27c6ce9e12577e092cc061d5c34c4bbbbd386a634d5c","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-21","kind":"task","taskId":"verify-21","stratum":"win32-jetbrains-volcengine","comparisonDigest":"sha256:978b15be2d74757c9ed87188744f72a83746232b1eddaf55062e99e103788933","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-22","kind":"task","taskId":"verify-22","stratum":"linux-cli-volcengine","comparisonDigest":"sha256:de69246028ab35e3063f4361f39eea43ad4e0a831001a016679b597604d07bdb","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-23","kind":"task","taskId":"verify-23","stratum":"linux-vscode-volcengine","comparisonDigest":"sha256:4177b758b9ae924d2251679c65b9634a4e157b0525e7d5f03bb8b6adc945dea0","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-24","kind":"task","taskId":"verify-24","stratum":"linux-jetbrains-volcengine","comparisonDigest":"sha256:1b5e5fd872dbe39b5c02c4d7e78b2b9a80b149b1ba7bbda017093374cc981ef7","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-25","kind":"task","taskId":"verify-25","stratum":"darwin-cli-volcengine","comparisonDigest":"sha256:9c680b8d67a42104335c8a920d04ef963698b792100fc3dec4332884d0f0bfe7","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-26","kind":"task","taskId":"verify-26","stratum":"darwin-vscode-volcengine","comparisonDigest":"sha256:0c73a8bb9ae948a96a2a40adc0af4fc442c9fddd8246ed19abb4705493944361","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-27","kind":"task","taskId":"verify-27","stratum":"darwin-jetbrains-volcengine","comparisonDigest":"sha256:5bf3630291366fae1fff1e08a5c3a27ddeb865f40c3c297f25a30c6fa65ca703","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-28","kind":"task","taskId":"verify-28","stratum":"win32-cli-openai","comparisonDigest":"sha256:6e97d8cca2d845d000ccab9988d9ad23832c71a8e65c22d8984ff4c0a60b4982","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-29","kind":"task","taskId":"verify-29","stratum":"win32-vscode-openai","comparisonDigest":"sha256:f29cb6508b21a3380ecd9262ff2e35becda6c501b4426dae164db52c359d6d26","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-30","kind":"task","taskId":"verify-30","stratum":"win32-jetbrains-openai","comparisonDigest":"sha256:0097eb516d082fee2d2aad67530eb2aa7e6e0d35dd6f5a39ead842a682fb961e","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-31","kind":"task","taskId":"verify-31","stratum":"linux-cli-openai","comparisonDigest":"sha256:a9960328a3f7115a9de63f401ab5efd3c5300240dfec5a5e8850652f76edc27c","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-32","kind":"task","taskId":"verify-32","stratum":"linux-vscode-openai","comparisonDigest":"sha256:c85373d1bb4b42621a73687d243cb1be72e01a5151eda28ae68aec3b6b43bd7c","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-33","kind":"task","taskId":"verify-33","stratum":"linux-jetbrains-openai","comparisonDigest":"sha256:8cd57b4f5f0d57a95571ef1e2a27c67b491686319eb3b881b24dd24d75206e44","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-34","kind":"task","taskId":"verify-34","stratum":"darwin-cli-openai","comparisonDigest":"sha256:60f0c3583484c86813b3d7f5e651a35c7aa113c872943ef875cd067ea6c56e63","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-35","kind":"task","taskId":"verify-35","stratum":"darwin-vscode-openai","comparisonDigest":"sha256:9722493e74f1a6010d2af7a7ea9513455c3223b82f1e8894f2cbb54f61b0d4cb","costBudget":2,"timeBudgetMs":1200000},{"id":"verify-36","kind":"task","taskId":"verify-36","stratum":"darwin-jetbrains-openai","comparisonDigest":"sha256:8a05412b84d28c5d55a20fc66df8cdb04e80efc53a3077502d8bcf50831f3e49","costBudget":2,"timeBudgetMs":1200000},{"id":"first-run-win32-cli","kind":"first-run","taskId":"verify-01","stratum":"win32-cli-volcengine","comparisonDigest":"sha256:c176a7a1e00b08aa5c6e124db50a15d64d48b79d8e07b75f08abd1cecefaee64","costBudget":3,"timeBudgetMs":1800000},{"id":"first-run-win32-vscode","kind":"first-run","taskId":"verify-02","stratum":"win32-vscode-volcengine","comparisonDigest":"sha256:b87fc3194d257b819b6e27c6ce9e12577e092cc061d5c34c4bbbbd386a634d5c","costBudget":3,"timeBudgetMs":1800000},{"id":"first-run-win32-jetbrains","kind":"first-run","taskId":"verify-03","stratum":"win32-jetbrains-volcengine","comparisonDigest":"sha256:978b15be2d74757c9ed87188744f72a83746232b1eddaf55062e99e103788933","costBudget":3,"timeBudgetMs":1800000},{"id":"first-run-linux-cli","kind":"first-run","taskId":"verify-04","stratum":"linux-cli-volcengine","comparisonDigest":"sha256:de69246028ab35e3063f4361f39eea43ad4e0a831001a016679b597604d07bdb","costBudget":3,"timeBudgetMs":1800000},{"id":"first-run-linux-vscode","kind":"first-run","taskId":"verify-05","stratum":"linux-vscode-volcengine","comparisonDigest":"sha256:4177b758b9ae924d2251679c65b9634a4e157b0525e7d5f03bb8b6adc945dea0","costBudget":3,"timeBudgetMs":1800000},{"id":"first-run-linux-jetbrains","kind":"first-run","taskId":"verify-06","stratum":"linux-jetbrains-volcengine","comparisonDigest":"sha256:1b5e5fd872dbe39b5c02c4d7e78b2b9a80b149b1ba7bbda017093374cc981ef7","costBudget":3,"timeBudgetMs":1800000},{"id":"first-run-darwin-cli","kind":"first-run","taskId":"verify-07","stratum":"darwin-cli-volcengine","comparisonDigest":"sha256:9c680b8d67a42104335c8a920d04ef963698b792100fc3dec4332884d0f0bfe7","costBudget":3,"timeBudgetMs":1800000},{"id":"first-run-darwin-vscode","kind":"first-run","taskId":"verify-08","stratum":"darwin-vscode-volcengine","comparisonDigest":"sha256:0c73a8bb9ae948a96a2a40adc0af4fc442c9fddd8246ed19abb4705493944361","costBudget":3,"timeBudgetMs":1800000},{"id":"first-run-darwin-jetbrains","kind":"first-run","taskId":"verify-09","stratum":"darwin-jetbrains-volcengine","comparisonDigest":"sha256:5bf3630291366fae1fff1e08a5c3a27ddeb865f40c3c297f25a30c6fa65ca703","costBudget":3,"timeBudgetMs":1800000}]}};
const receipt = runReviewStage(process.argv[1], spec, "check", {deadline:process.argv[2] === undefined ? undefined : Number(process.argv[2])});
const evidenceDir = path.join(process.cwd(), "acceptance-evidence");
fs.mkdirSync(evidenceDir, {recursive:true, mode:0o700});
const evidenceName = spec.taskId + "-check-" + randomUUID() + ".json";
const bytes = JSON.stringify(receipt, null, 2) + "\n";
fs.writeFileSync(path.join(evidenceDir,evidenceName),bytes,{flag:"wx",mode:0o600});
console.log(JSON.stringify({pass:receipt.pass,detail:receipt.detail,receipt:evidenceName,receiptDigest:"sha256:"+hash(bytes)}));
