import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
const checkout = path.resolve(".work/gap-source-attrs-7ded47b376");
const output = path.resolve(".work/soak-source-product-7ded47b376");
fs.mkdirSync(output, { recursive: false });
const args = ["packages/cli/scripts/team-distributed-soak.mjs", "--verify-source-only", "--expected-sha=7ded47b376a028e669d2f7a3cad5aa47d5e798ab"];
const result = spawnSync(process.execPath, args, { cwd: checkout, windowsHide: true, timeout: 600000, maxBuffer: 16 * 1024 * 1024 });
const hash = (bytes) => "sha256:" + createHash("sha256").update(bytes).digest("hex");
const streams = [];
for (const key of ["stdout", "stderr"]) {
  const file = key + ".txt";
  fs.writeFileSync(path.join(output, file), result[key]);
  streams.push({ file, bytes: result[key].length, digest: hash(result[key]) });
}
let report;
if (result.status === 0) report = JSON.parse(result.stdout.toString("utf8"));
fs.writeFileSync(path.join(output, "invocation.json"), JSON.stringify({ node: process.version, platform: process.platform, command: [process.execPath, ...args], checkout, expectedSha: "7ded47b376a028e669d2f7a3cad5aa47d5e798ab", status: result.status, signal: result.signal, error: result.error?.message ?? null, source: report?.sourceBytes, streams, completeCiMatrix: false, formalSample: false }, null, 2) + "\n");
if (result.status !== 0 || result.error || result.signal || !report?.success || !report?.sourceBytes?.matches) throw new Error("full product source verification failed: " + result.stderr.toString());
console.log(JSON.stringify({ expectedSha: report.expectedSha, trackedEntries: report.sourceBytes.trackedEntries, trackedBytes: report.sourceBytes.trackedBytes, matches: report.sourceBytes.matches }));
