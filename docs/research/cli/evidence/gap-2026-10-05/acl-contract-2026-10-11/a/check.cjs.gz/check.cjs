"use strict";
const preload=require("X:/workspace/adapter/windows-node-private-v4-preload.cjs");
const addon=require("X:/workspace/adapter/windows-node-private-v4.node");
const fs=require("node:fs");
const assert=require("node:assert/strict");
const identity=JSON.parse(addon.inspectPrivateIdentity());
fs.mkdirSync("X:/scratch/private-v4-owner-acl-probe");
fs.writeFileSync("X:/scratch/private-v4-owner-acl-probe/existing.txt","owner-only-probe");
let argumentRejected=false;
try{addon.probeFixedOwnerOnlyAcl("X:/scratch");}catch(error){argumentRejected=error.code==="OWNER_ACL_PROBE_ARGUMENT";}
assert.equal(argumentRejected,true);
const value=JSON.parse(addon.probeFixedOwnerOnlyAcl());
const adapter=JSON.parse(addon.snapshot());
fs.writeFileSync("X:/scratch/acl-probe.json",JSON.stringify({identity,value,argumentRejected,adapter,preload:preload.snapshot()},null,2));
assert.equal(adapter.state,2);assert.equal(adapter.patches,6);
assert.equal(value.admissionEligible,false);assert.equal(value.compatibilityConfirmed,false);
