import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
function ownerOnly(value,userSid,directory){
  assert.equal(value.error,0);assert.equal(value.valid,true);assert.equal(value.ownerSid,userSid);assert.equal(value.controlRead,true);assert.equal(value.daclRead,true);assert.equal(value.daclPresent,true);assert.equal(value.revision,1);
  assert.equal(!!(value.control&4),true);assert.equal(!!(value.control&8),value.daclDefaulted);assert.equal(!!(value.control&0x1000),true);
  assert.match(value.rawAclHex,/^(?:[0-9a-f]{2})+$/);const raw=Buffer.from(value.rawAclHex,'hex');assert(raw.length>=24);assert.equal(raw.readUInt16LE(2),raw.length);assert.equal(raw.readUInt16LE(4),1);
  const size=raw.readUInt16LE(10);assert(size>=16&&8+size<=raw.length);const entry=raw.subarray(8,8+size),sid=entry.subarray(8);
  assert.equal(entry[0],0);assert.equal(entry[1],directory?3:0);assert.equal(entry.readUInt32LE(4),0x1f01ff);assert.equal(sid[0],1);assert.equal(sid.length,8+sid[1]*4);
  const authority=sid.readUIntBE(2,6),sub=Array.from({length:sid[1]},(_,j)=>sid.readUInt32LE(8+j*4));assert.equal(`S-${sid[0]}-${authority}-${sub.join('-')}`,userSid);
}
export function inspect(probe,setup,final){
  const v=probe.value,c=v.contextBefore;
  assert.equal(v.schema,'chainlesschain.host-owner-acl-io/v1');assert.equal(v.status,'NOT_ADMITTED');
  for(const key of ['admissionEligible','compatibilityConfirmed','mappingChanged'])assert.equal(v[key],false);
  assert.equal(v.scope,'lowbox-opens-host-narrowed-fixed-scratch');assert.equal(probe.argumentRejected,true);
  assert.equal(probe.adapter.state,2);assert.equal(probe.adapter.patches,6);assert.equal(v.contextObservedStable,true);assert.deepEqual(c,v.contextAfter);
  assert.equal(c.pid,probe.adapter.pid);assert.equal(c.pid,probe.identity.actor.pid);assert.equal(c.appContainerSid,probe.adapter.appContainerSid);assert.equal(c.appContainerSid,probe.identity.token.appContainerSid);
  assert.equal(probe.identity.token.inJob,true);assert.equal(probe.identity.token.capabilityCount,0);
  assert.equal(c.capabilityCount,0);assert.equal(c.appContainer,true);assert.equal(c.effectiveTokenKnown,true);assert.equal(c.noImpersonationObserved,true);assert.equal(c.threadTokenOpened,false);assert.equal(c.threadTokenError,1008);assert.equal(c.error,0);assert.equal(c.tokenType,1);
  assert(Number.isSafeInteger(c.threadId)&&c.threadId>0);
  assert.equal(setup.schema,'chainlesschain.host-owner-acl-setup/v1');assert.equal(setup.status,'NOT_ADMITTED');assert.equal(setup.scope,'host-narrows-fixed-new-scratch-objects');assert.equal(setup.actorObjectHandlesAdded,0);assert.equal(setup.ownerSid,c.userSid);assert.equal(setup.ok,true);assert.equal(setup.rows.length,2);
  const digest=createHash('sha256').update('owner-only-probe').digest('hex');
  for(const [i,row]of setup.rows.entries()){
    assert.equal(row.kind,i?'file':'directory');assert.equal(row.ok,true);assert.equal(row.setError,0);assert.equal(row.writeHandleClosed,true);assert.equal(row.setupHandleInheritable,false);assert.equal(row.metadataHandleInheritable,false);assert.equal(row.metadataAccess,131200);
    assert.deepEqual(row.before,row.after);assert.deepEqual(row.after,row.reopened);assert.deepEqual(row.finalSecurity,row.reopenedSecurity);ownerOnly(row.finalSecurity,c.userSid,i===0);
    assert.equal(row.before.directory,i===0);assert.equal(row.before.reparse,false);assert.equal(row.before.links,1);assert.match(row.before.fileId,/^[0-9a-f]{32}$/);assert.match(row.before.volumeSerial,/^[0-9]+$/);
    const physical=probe.identity.root.physical;assert.equal(row.before.ntPath,physical.ntPath+'\\scratch\\private-v4-owner-acl-probe'+(i?'\\existing.txt':''));assert.equal(row.before.volumeSerial,physical.volumeSerial);
    assert.equal(row.sha256,i?digest:'');
  }
  assert.equal(v.operationsAttempted,true);assert.deepEqual(v.operations.map(r=>r.name),['reopen-directory','read-existing','write-existing','create-file','create-directory','delete-existing']);
  for(const [i,row]of v.operations.entries()){
    assert.equal(typeof row.ok,'boolean');assert(Number.isSafeInteger(row.error)&&row.error>=0);assert.equal(row.error===0,row.ok);
    if(i<4){assert.equal(row.access,[131201,0x80000000,2,0x40000000][i]);assert.equal(row.creation,i===3?1:3);assert.equal(row.ioAttempted,row.ok&&i>0);assert.equal(row.closed,row.ok);assert.equal(row.closeError,0);
      if(!row.ok){assert.equal(row.identity,null);assert.equal(row.ioOk,false);assert.equal(row.ioError,0);assert.equal(row.bytes,0);assert.equal(row.security,null);}
      else if(i===0){assert.equal(row.identity.fileId,setup.rows[0].before.fileId);assert.equal(row.identity.volumeSerial,setup.rows[0].before.volumeSerial);ownerOnly(row.security,c.userSid,true);}
      else {assert.equal(row.ioError===0,row.ioOk);assert.equal(row.security,null);if(row.ioOk)assert.equal(row.bytes,i===1?16:5);}
    }
  }
  assert.equal(final.schema,'chainlesschain.host-owner-acl-final/v1');assert.equal(final.rows.length,2);
  const allDenied=v.operations.every(r=>!r.ok&&r.error===5);
  if(allDenied)for(const [i,row]of final.rows.entries()){assert.equal(row.error,0);assert.equal(row.closed,true);assert.equal(row.kind,setup.rows[i].kind);assert.deepEqual(row.identity,setup.rows[i].before);assert.deepEqual(row.security,setup.rows[i].finalSecurity);assert.equal(row.sha256,setup.rows[i].sha256);}
  return {observationsVerified:true,status:'NOT_ADMITTED',admissionEligible:false,compatibilityConfirmed:false,authorityProven:false,continuousStabilityProven:false,
    ownerOnlyEstablishedByHost:true,actorTargetHandleInherited:false,allSixOperationsDeniedWithAccessDenied:allDenied,
    result:allDenied?'OWNER_ONLY_LOWBOX_IO_DENIED':'OWNER_ONLY_MIXED_IO_OBSERVATION',operationResults:v.operations.map(r=>({name:r.name,ok:r.ok,error:r.error}))};
}
