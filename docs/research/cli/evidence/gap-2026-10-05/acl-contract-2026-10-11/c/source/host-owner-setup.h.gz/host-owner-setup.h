#include <aclapi.h>
// Host narrows two newly-created, fixed objects. All setup handles are non-inheritable.
std::string ownerProbeHex(const BYTE* bytes, size_t length) {
  static constexpr char digits[]="0123456789abcdef";
  std::string out; out.reserve(length*2);
  for(size_t i=0;i<length;++i){out+=digits[bytes[i]>>4];out+=digits[bytes[i]&15];}return out;
}
std::string ownerProbeSecurity(HANDLE handle) {
  PSECURITY_DESCRIPTOR sd=nullptr;PSID owner=nullptr;PACL dacl=nullptr;
  const DWORD error=GetSecurityInfo(handle,SE_FILE_OBJECT,OWNER_SECURITY_INFORMATION|DACL_SECURITY_INFORMATION,&owner,nullptr,&dacl,nullptr,&sd);
  bool valid=error==0&&sd&&IsValidSecurityDescriptor(sd);
  std::string sid="null",raw="null";SECURITY_DESCRIPTOR_CONTROL control=0;DWORD revision=0;
  bool controlOk=false;BOOL present=FALSE,defaulted=FALSE;PACL actual=nullptr;
  bool daclOk=false;
  if(valid){
    LPWSTR text=nullptr;
    if(owner&&IsValidSid(owner)&&ConvertSidToStringSidW(owner,&text)){sid="\""+jsonText(text)+"\"";LocalFree(text);}
    controlOk=GetSecurityDescriptorControl(sd,&control,&revision)!=FALSE;
    daclOk=GetSecurityDescriptorDacl(sd,&present,&actual,&defaulted)!=FALSE;
    if(daclOk&&present&&actual&&IsValidAcl(actual))raw="\""+ownerProbeHex(reinterpret_cast<const BYTE*>(actual),actual->AclSize)+"\"";
  }
  if(sd)LocalFree(sd);
  return "{\"error\":"+std::to_string(error)+",\"valid\":"+(valid?"true":"false")+",\"ownerSid\":"+sid+
    ",\"controlRead\":"+(controlOk?"true":"false")+",\"control\":"+std::to_string(control)+",\"revision\":"+std::to_string(revision)+
    ",\"daclRead\":"+(daclOk?"true":"false")+",\"daclPresent\":"+(present?"true":"false")+",\"daclDefaulted\":"+(defaulted?"true":"false")+",\"rawAclHex\":"+raw+"}";
}
static std::string hostOwnerIdentity(HANDLE h){
  FILE_ID_INFO id={};BY_HANDLE_FILE_INFORMATION basic={};WCHAR nt[4096]={};
  DWORD length=GetFinalPathNameByHandleW(h,nt,4096,VOLUME_NAME_NT);
  if(!GetFileInformationByHandleEx(h,FileIdInfo,&id,sizeof(id))||!GetFileInformationByHandle(h,&basic)||!length||length>=4096)return "null";
  return "{\"volumeSerial\":\""+std::to_string(id.VolumeSerialNumber)+"\",\"fileId\":\""+ownerProbeHex(id.FileId.Identifier,16)+"\",\"ntPath\":\""+jsonText(nt)+"\",\"directory\":"+((basic.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)?"true":"false")+",\"reparse\":"+((basic.dwFileAttributes&FILE_ATTRIBUTE_REPARSE_POINT)?"true":"false")+",\"links\":"+std::to_string(basic.nNumberOfLinks)+"}";
}
static bool hostOwnerSetup(const std::wstring& scratch,const std::wstring& control,const std::wstring& owner,Handles& held){
  const auto folder=scratch+L"\\private-v4-owner-acl-probe",file=folder+L"\\existing.txt";
  if(!CreateDirectoryW(folder.c_str(),nullptr))return false;
  if(!writeFresh(file,"owner-only-probe"))return false;
  PSID user=nullptr;if(!ConvertStringSidToSidW(owner.c_str(),&user))return false;
  std::string rows="[";bool all=true;unsigned i=0;
  for(const auto& target:{folder,file}){
    const bool directory=i==0;
    HANDLE h=CreateFileW(target.c_str(),WRITE_DAC|READ_CONTROL|FILE_READ_ATTRIBUTES|(directory?0:FILE_READ_DATA),FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,nullptr,OPEN_EXISTING,FILE_FLAG_OPEN_REPARSE_POINT|(directory?FILE_FLAG_BACKUP_SEMANTICS:0),nullptr);
    if(h==INVALID_HANDLE_VALUE){all=false;break;}
    const auto before=hostOwnerIdentity(h);const auto initial=ownerProbeSecurity(h);
    FILE_ATTRIBUTE_TAG_INFO tag={};bool plain=GetFileInformationByHandleEx(h,FileAttributeTagInfo,&tag,sizeof(tag))&&!(tag.FileAttributes&FILE_ATTRIBUTE_REPARSE_POINT)&&!!(tag.FileAttributes&FILE_ATTRIBUTE_DIRECTORY)==directory;
    alignas(ACL) BYTE raw[1024]={};PACL acl=reinterpret_cast<PACL>(raw);
    bool prepared=plain&&InitializeAcl(acl,sizeof(raw),ACL_REVISION)&&AddAccessAllowedAceEx(acl,ACL_REVISION,directory?OBJECT_INHERIT_ACE|CONTAINER_INHERIT_ACE:0,FILE_ALL_ACCESS,user);
    DWORD setError=prepared?SetSecurityInfo(h,SE_FILE_OBJECT,DACL_SECURITY_INFORMATION|PROTECTED_DACL_SECURITY_INFORMATION,nullptr,nullptr,acl,nullptr):ERROR_INVALID_DATA;
    const auto final=ownerProbeSecurity(h),after=hostOwnerIdentity(h);const auto digest=directory?"":fileDigest(h);
    DWORD handleFlags=0;bool flagsRead=GetHandleInformation(h,&handleFlags)!=FALSE;
    bool closed=CloseHandle(h)!=FALSE;
    // Hold only a non-inheritable metadata handle. The actor never receives it.
    HANDLE proof=CreateFileW(target.c_str(),READ_CONTROL|FILE_READ_ATTRIBUTES,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,nullptr,OPEN_EXISTING,FILE_FLAG_OPEN_REPARSE_POINT|(directory?FILE_FLAG_BACKUP_SEMANTICS:0),nullptr);
    std::string reopened="null",reopenedSecurity="null";DWORD proofFlags=0;bool proofFlagsRead=false;
    if(proof!=INVALID_HANDLE_VALUE){held.add(proof);reopened=hostOwnerIdentity(proof);reopenedSecurity=ownerProbeSecurity(proof);proofFlagsRead=GetHandleInformation(proof,&proofFlags)!=FALSE;}
    bool ok=prepared&&setError==0&&closed&&flagsRead&&!(handleFlags&HANDLE_FLAG_INHERIT)&&proofFlagsRead&&!(proofFlags&HANDLE_FLAG_INHERIT)&&before==after&&after==reopened&&final==reopenedSecurity;
    if(i++)rows+=",";
    rows+="{\"kind\":\""+std::string(directory?"directory":"file")+"\",\"before\":"+before+",\"after\":"+after+",\"reopened\":"+reopened+",\"initialSecurity\":"+initial+",\"finalSecurity\":"+final+",\"reopenedSecurity\":"+reopenedSecurity+",\"setError\":"+std::to_string(setError)+",\"writeHandleClosed\":"+(closed?"true":"false")+",\"setupHandleInheritable\":"+((handleFlags&HANDLE_FLAG_INHERIT)?"true":"false")+",\"metadataHandleInheritable\":"+((proofFlags&HANDLE_FLAG_INHERIT)?"true":"false")+",\"metadataAccess\":131200,\"sha256\":\""+digest+"\",\"ok\":"+(ok?"true":"false")+"}";
    all=all&&ok;
  }
  LocalFree(user);rows+="]";
  const std::string report="{\"schema\":\"chainlesschain.host-owner-acl-setup/v1\",\"status\":\"NOT_ADMITTED\",\"scope\":\"host-narrows-fixed-new-scratch-objects\",\"actorObjectHandlesAdded\":0,\"ownerSid\":\""+jsonText(owner)+"\",\"rows\":"+rows+",\"ok\":"+(all&&i==2?"true":"false")+"}";
  return writeFresh(control+L"\\host-owner-acl-before.json",report)&&all&&i==2;
}
static bool hostOwnerFinal(const std::wstring& scratch,const std::wstring& control){
  const auto folder=scratch+L"\\private-v4-owner-acl-probe",file=folder+L"\\existing.txt";
  std::string rows="[";unsigned i=0;
  for(const auto& target:{folder,file}){
    const bool directory=i==0;
    HANDLE h=CreateFileW(target.c_str(),READ_CONTROL|FILE_READ_ATTRIBUTES|(directory?0:FILE_READ_DATA),FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,nullptr,OPEN_EXISTING,FILE_FLAG_OPEN_REPARSE_POINT|(directory?FILE_FLAG_BACKUP_SEMANTICS:0),nullptr);
    DWORD error=h==INVALID_HANDLE_VALUE?GetLastError():0;std::string identity="null",security="null",digest="";bool closed=false;
    if(h!=INVALID_HANDLE_VALUE){identity=hostOwnerIdentity(h);security=ownerProbeSecurity(h);if(!directory)digest=fileDigest(h);closed=CloseHandle(h)!=FALSE;}
    if(i++)rows+=",";
    rows+="{\"kind\":\""+std::string(directory?"directory":"file")+"\",\"error\":"+std::to_string(error)+",\"identity\":"+identity+",\"security\":"+security+",\"sha256\":\""+digest+"\",\"closed\":"+(closed?"true":"false")+"}";
  }
  rows+="]";
  return writeFresh(control+L"\\host-owner-acl-after.json","{\"schema\":\"chainlesschain.host-owner-acl-final/v1\",\"rows\":"+rows+"}");
}
