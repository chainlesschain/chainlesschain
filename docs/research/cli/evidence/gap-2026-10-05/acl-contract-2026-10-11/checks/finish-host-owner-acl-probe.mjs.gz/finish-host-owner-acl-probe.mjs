import fs from 'node:fs';import path from 'node:path';
const out=path.resolve('.work/acl-host-owner-only-20261011-a');
const previous=fs.readFileSync('.work/acl-owner-only-20261011-b/acl-probe.h','utf8');
const operations=previous.slice(previous.indexOf('  std::string operations="["'),previous.indexOf('  operations+="]";'));
const head=`napi_value hostOwnerOnlyIoCallback(napi_env env,napi_callback_info info){
  napi_value args[1];size_t count=1;
  if(state!=2||api.napi_get_cb_info(env,info,&count,args,nullptr,nullptr)!=napi_ok||count!=0){api.napi_throw_error(env,"OWNER_ACL_PROBE_ARGUMENT","Installed adapter and no arguments required");return nullptr;}
  static LONG invoked=0;if(InterlockedCompareExchange(&invoked,1,0)!=0){api.napi_throw_error(env,"OWNER_ACL_PROBE_ONCE","Fixed probe is one-shot");return nullptr;}
  constexpr WCHAR folder[]=L"X:\\\\scratch\\\\private-v4-owner-acl-probe";
  const auto before=coordinateContext();
  const bool operationsAttempted=before.expectedToken;
`;
const tail=`  operations+="]";const auto after=coordinateContext();
  const std::string value="{\\\"schema\\\":\\\"chainlesschain.host-owner-acl-io/v1\\\",\\\"status\\\":\\\"NOT_ADMITTED\\\",\\\"admissionEligible\\\":false,\\\"compatibilityConfirmed\\\":false,\\\"mappingChanged\\\":false,\\\"scope\\\":\\\"lowbox-opens-host-narrowed-fixed-scratch\\\",\\\"contextBefore\\\":"+before.json+",\\\"contextAfter\\\":"+after.json+",\\\"contextObservedStable\\\":"+(before.expectedToken&&after.expectedToken&&before.json==after.json?"true":"false")+",\\\"operationsAttempted\\\":"+(operationsAttempted?"true":"false")+",\\\"operations\\\":"+operations+"}";
  napi_value result;if(api.napi_create_string_utf8(env,value.c_str(),NAPI_AUTO_LENGTH,&result)!=napi_ok)return nullptr;return result;
}
`;
fs.appendFileSync(path.join(out,'acl-probe.h'),head+operations+tail);
console.log(out);
