import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';import {pathToFileURL} from 'node:url';
const root=path.resolve('.work');
const hash=b=>'sha256:'+createHash('sha256').update(b).digest('hex');
const names=['acl-owner-only-20261011-b','acl-host-owner-only-20261011-a'];
const checks=[];let assertions=0;
for(const name of names){
  const dir=path.join(root,name),report=JSON.parse(fs.readFileSync(path.join(dir,'run/report.json')));
  for(const artifact of [...report.sourceInputs,...report.binaryInputs,...report.copiedArtifacts.flatMap(x=>[x.source,x.destination])]){const raw=fs.readFileSync(artifact.path);assert.equal(hash(raw),artifact.digest);assert.equal(raw.length,artifact.bytes);assertions++;}
  const h=report.host,p=report.probe;
  assert.equal(report.execution.status,0);assert.equal(report.execution.signal,null);assert.equal(report.execution.error,null);
  for(const key of ['completed','cleanupConfirmed','profileDeleted','loopbackExemptionAbsent','hostMapUnchanged','rootTokenAndSameJobProven','rootMapInstalled'])assert.equal(h[key],true);
  assert.equal(h.rootWait,0);assert.equal(h.rootExit,0);assert.equal(h.jobActiveProcesses,0);assert.equal(h.requests,0);assert.equal(h.error,0);
  assert.equal(h.rootPid,p.identity.actor.pid);assert.equal(h.appContainerSid,p.identity.token.appContainerSid);assert.equal(p.identity.token.capabilityCount,0);assert.equal(p.identity.token.inJob,true);
  assert.equal(h.creationLedger.length,1);const actor=h.creationLedger[0];assert.equal(actor.pid,h.rootPid);assert.equal(actor.wait,0);assert.equal(actor.exitKnown,true);assert.equal(actor.exit,0);assert.equal(actor.inheritedHandleCount,9);assert.equal(actor.launchRequests,0);assert.equal(actor.registered,true);assert.equal(actor.kind,'root');
  for(const receipt of report.receipts){assert.equal(receipt.pid,h.rootPid);assert.equal(receipt.adapter.appContainerSid,h.appContainerSid);assert.equal(receipt.adapter.patches,6);assert.equal(receipt.adapter.inJob,true);assert.equal(receipt.adapter.capabilityCount,0);assert.equal(receipt.sessionId,h.sessionId);assert.equal(receipt.generation,h.generation);assert.equal(receipt.actor.registrationId,actor.registrationId);}
  const {inspect}=await import(pathToFileURL(path.join(dir,'verify.mjs')).href);
  const invoke=(probe=p,setup=report.hostAcl,final=report.hostAclAfter)=>inspect(probe,setup,final);
  assert.deepEqual(invoke(),report.inspection);checks.push({name,kind:'actual-report-and-inputs',passed:true});
  const mutations=[
    ['schema',x=>x.value.schema='wrong'],['admission',x=>x.value.admissionEligible=true],['scope',x=>x.value.scope='arbitrary-path'],
    ['capability',x=>{x.value.contextBefore.capabilityCount=1;x.value.contextAfter.capabilityCount=1;}],['thread',x=>x.value.contextAfter.threadId++],
    ['impersonation',x=>{x.value.contextBefore.noImpersonationObserved=false;x.value.contextAfter.noImpersonationObserved=false;}],
    ['pid',x=>x.identity.actor.pid++],['arguments',x=>x.argumentRejected=false],['patches',x=>x.adapter.patches=7]
  ];
  if(report.hostAcl)mutations.push(['missing-operation',x=>x.value.operations.pop()],['fake-denied-error',x=>x.value.operations[0].error=0],['fake-io',x=>x.value.operations[1].ioOk=true],['fake-access',x=>x.value.operations[2].access=1]);
  else mutations.push(['fake-set',x=>x.value.setAttempted=true],['fake-writedac',x=>x.value.writeOpenError=0],['fake-after-acl',x=>x.value.securityAfter.control|=0x1000],['unexpected-io',x=>x.value.operations.push({})]);
  for(const [label,mutate]of mutations){const copy=structuredClone(p);mutate(copy);assert.throws(()=>invoke(copy));checks.push({name,kind:'rejected-'+label,passed:true});}
  if(report.hostAcl){
    for(const [label,mutate]of [
      ['owner',x=>x.ownerSid='S-1-5-18'],['inherited-handle',x=>x.actorObjectHandlesAdded=1],['metadata-inheritable',x=>x.rows[0].metadataHandleInheritable=true],
      ['write-open',x=>x.rows[0].writeHandleClosed=false],['acl-protection',x=>{x.rows[0].finalSecurity.control&=~0x1000;x.rows[0].reopenedSecurity.control&=~0x1000;}],
      ['file-bytes',x=>x.rows[1].sha256='0'.repeat(64)],['root-identity',x=>x.rows[0].before.volumeSerial='1']
    ]){const copy=structuredClone(report.hostAcl);mutate(copy);assert.throws(()=>invoke(p,copy));checks.push({name,kind:'rejected-host-'+label,passed:true});}
    for(const [label,mutate]of [['final-owner',x=>x.rows[0].security.ownerSid='S-1-5-18'],['final-bytes',x=>x.rows[1].sha256='0'.repeat(64)],['final-id',x=>x.rows[0].identity.fileId='0'.repeat(32)]]){
      const copy=structuredClone(report.hostAclAfter);mutate(copy);assert.throws(()=>invoke(p,report.hostAcl,copy));checks.push({name,kind:'rejected-'+label,passed:true});
    }
  }
}
const denied=JSON.parse(fs.readFileSync(path.join(root,'acl-owner-only-20261011-a/run/report.json')));assert.equal(denied.host.stage,'host-token');assert.equal(denied.host.rootPid,0);assert.equal(denied.diagnosticCompleted,false);checks.push({name:'acl-owner-only-20261011-a',kind:'blocked-host-no-actor',passed:true});
const value={schema:'chainlesschain.acl-contract-independent-validation/v1',status:'NOT_ADMITTED',admissionEligible:false,passed:checks.length,inputBindingsChecked:assertions,checks};
fs.writeFileSync(path.join(root,'acl-contract-independent-validation-20261011.json'),JSON.stringify(value,null,2)+'\n');console.log(JSON.stringify({passed:checks.length,inputBindingsChecked:assertions}));
