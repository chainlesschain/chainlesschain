import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';import {gzipSync,gunzipSync} from 'node:zlib';import {spawnSync} from 'node:child_process';
const repo=process.cwd(),dest=path.resolve('docs/research/cli/evidence/gap-2026-10-05/acl-contract-2026-10-11');
fs.mkdirSync(dest,{recursive:true});assert.equal(fs.readdirSync(dest).length,0);
const hash=b=>'sha256:'+createHash('sha256').update(b).digest('hex');
const sha=spawnSync('git',['rev-parse','53ad9df8c4'],{encoding:'utf8',windowsHide:true});assert.equal(sha.status,0);
const entries=[],largeBinaries=[];
const keep=(source,relative)=>{const raw=fs.readFileSync(source),z=gzipSync(raw,{level:9});const target=path.join(dest,relative+'.gz');fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,z,{flag:'wx'});assert.deepEqual(gunzipSync(z),raw);entries.push({source:path.relative(repo,source).replaceAll('\\','/'),artifact:relative+'.gz',rawBytes:raw.length,rawDigest:hash(raw),gzipBytes:z.length,gzipDigest:hash(z)});};
for(const [label,folder]of [['a','acl-owner-only-20261011-a'],['b','acl-owner-only-20261011-b'],['c','acl-host-owner-only-20261011-a']]){
  const source=path.resolve('.work',folder);
  const walk=(dir,relative='')=>{for(const entry of fs.readdirSync(dir,{withFileTypes:true})){const file=path.join(dir,entry.name),name=relative?relative+'/'+entry.name:entry.name;
    if(entry.isDirectory()){assert(['source','frozen','run'].includes(entry.name));walk(file,name);continue;}
    assert(entry.isFile());if(/\.(exe|dll|node)$/i.test(entry.name)){const raw=fs.readFileSync(file);largeBinaries.push({round:label,path:path.relative(repo,file).replaceAll('\\','/'),bytes:raw.length,digest:hash(raw),archived:false});continue;}
    keep(file,label+'/'+name);
  }};walk(source);
}
for(const name of ['acl-contract-verify-tests.mjs','acl-contract-independent-validation-20261011.json','prepare-owner-acl-probe.mjs','prepare-host-owner-acl-probe.mjs','finish-host-owner-acl-probe.mjs','archive-acl-contract-20261011.mjs'])keep(path.resolve('.work',name),'checks/'+name);
const manifest={schema:'chainlesschain.acl-contract-evidence/v1',status:'NOT_ADMITTED',admissionEligible:false,compatibilityConfirmed:false,frozenBaseCommit:sha.stdout.trim(),rounds:{a:'restricted host rejected at host-token; no actor',b:'actor WRITE_DAC open denied; no SetSecurityInfo or subsequent I/O',c:'host fixed objects owner-only; six native LowBox operations denied'},compilerClosureVerified:false,productionSourcesChangedByExperiment:false,formalSample:false,largeBinaries,entries};
fs.writeFileSync(path.join(dest,'manifest.json'),JSON.stringify(manifest,null,2)+'\n');
let bytes=0;for(const entry of entries){const z=fs.readFileSync(path.join(dest,entry.artifact)),raw=gunzipSync(z);assert.equal(z.length,entry.gzipBytes);assert.equal(hash(z),entry.gzipDigest);assert.equal(raw.length,entry.rawBytes);assert.equal(hash(raw),entry.rawDigest);assert.deepEqual(raw,fs.readFileSync(path.resolve(entry.source)));bytes+=raw.length;}
const validation={schema:'chainlesschain.acl-contract-archive-validation/v1',entries:entries.length,rawBytes:bytes,doubleDigestsVerified:true,originalBytesMatched:true,manifestDigest:hash(fs.readFileSync(path.join(dest,'manifest.json'))),independentDiagnosticValidation:JSON.parse(fs.readFileSync('.work/acl-contract-independent-validation-20261011.json')),status:'NOT_ADMITTED',admissionEligible:false};
fs.writeFileSync(path.join(dest,'archive-validation.json'),JSON.stringify(validation,null,2)+'\n');
console.log(JSON.stringify({dest,entries:entries.length,rawBytes:bytes,largeBinaries:largeBinaries.length}));
