import assert from 'node:assert/strict';
function security(value,userSid){
  assert.equal(value.error,0);assert.equal(value.valid,true);assert.equal(value.controlRead,true);assert.equal(value.daclRead,true);assert.equal(value.daclPresent,true);assert.equal(value.revision,1);
  assert.equal(!!(value.control&4),true);assert.equal(!!(value.control&8),value.daclDefaulted);
  assert.match(value.rawAclHex,/^(?:[0-9a-f]{2})+$/);
  const raw=Buffer.from(value.rawAclHex,'hex');assert(raw.length>=8);assert.equal(raw.readUInt16LE(2),raw.length);
  const count=raw.readUInt16LE(4),aces=[];let offset=8;
  for(let i=0;i<count;i++){
    assert(offset+8<=raw.length);const size=raw.readUInt16LE(offset+2);assert(size>=16&&offset+size<=raw.length);
    const entry=raw.subarray(offset,offset+size),sid=entry.subarray(8);assert.equal(sid[0],1);assert.equal(sid.length,8+sid[1]*4);
    const authority=sid.readUIntBE(2,6),sub=Array.from({length:sid[1]},(_,j)=>sid.readUInt32LE(8+j*4));
    aces.push({type:entry[0],flags:entry[1],mask:entry.readUInt32LE(4),sid:`S-${sid[0]}-${authority}-${sub.join('-')}`});offset+=size;
  }
  return {ownerOnly:value.ownerSid===userSid&&!!(value.control&0x1000)&&aces.length===1&&aces[0].type===0&&aces[0].flags===3&&aces[0].mask===0x1f01ff&&aces[0].sid===userSid,aces,protected:!!(value.control&0x1000)};
}
export function inspect(probe){
  const v=probe.value,c=v.contextBefore;
  assert.equal(v.schema,'chainlesschain.private-owner-acl-probe/v1');assert.equal(v.status,'NOT_ADMITTED');
  for(const key of ['admissionEligible','compatibilityConfirmed','mappingChanged'])assert.equal(v[key],false);
  assert.equal(v.scope,'fixed-actor-created-scratch-only');assert.equal(probe.argumentRejected,true);
  assert.equal(probe.adapter.state,2);assert.equal(probe.adapter.patches,6);assert.equal(v.contextObservedStable,true);assert.deepEqual(c,v.contextAfter);
  assert.equal(c.pid,probe.adapter.pid);assert.equal(c.pid,probe.identity.actor.pid);assert.equal(c.appContainerSid,probe.adapter.appContainerSid);assert.equal(c.appContainerSid,probe.identity.token.appContainerSid);
  assert.equal(c.capabilityCount,0);assert.equal(c.appContainer,true);assert.equal(c.effectiveTokenKnown,true);assert.equal(c.noImpersonationObserved,true);assert.equal(c.threadTokenOpened,false);assert.equal(c.threadTokenError,1008);assert.equal(c.error,0);assert.equal(c.tokenType,1);
  assert(Number.isSafeInteger(c.threadId)&&c.threadId>0);assert.equal(v.bound,true);assert.equal(v.opens.length,2);
  for(const [i,row]of v.opens.entries()){assert.equal(row.path,i?'X:\\scratch\\private-v4-owner-acl-probe':'X:\\scratch');assert.equal(row.access,131200);assert.equal(row.share,3);assert.equal(row.error,0);assert.equal(row.opened,true);assert.equal(row.matched,true);}
  assert.deepEqual(v.fileBefore,v.fileAfter);assert.equal(v.fileBefore.observed,true);assert.equal(v.fileBefore.directory,true);assert.equal(v.fileBefore.reparse,false);
  const initial=security(v.securityBefore,c.userSid),after=security(v.securityAfter,c.userSid);
  assert.equal(initial.ownerOnly,false);
  assert.equal(v.writeHandleClosed,true);assert.equal(v.targetHandleClosed,true);assert.equal(v.writeCloseError,0);assert.equal(v.targetCloseError,0);
  assert.equal(typeof v.writeOpened,'boolean');assert.equal(v.writeOpenError===0,v.writeOpened);
  if(v.writeOpened)assert.deepEqual(v.writeIdentity,v.fileBefore);
  assert.equal(v.aclPrepared,v.writeOpened&&v.aclPrepareError===0);
  assert.equal(v.setAttempted,v.writeOpened&&v.aclPrepared);
  const setSucceeded=v.setAttempted&&v.setError===0;
  assert.equal(v.operationsAttempted,setSucceeded);
  if(setSucceeded)assert.equal(after.ownerOnly,true);
  else {assert.deepEqual(v.securityAfter,v.securityBefore);assert.equal(v.operations.length,0);}
  if(v.operationsAttempted){
    assert.deepEqual(v.operations.map(r=>r.name),['reopen-directory','read-existing','write-existing','create-file','create-directory','delete-existing']);
    for(const [i,row]of v.operations.entries()){
      assert.equal(typeof row.ok,'boolean');assert(Number.isSafeInteger(row.error)&&row.error>=0);assert.equal(row.error===0,row.ok);
      if(i<4){
        assert.equal(row.access,[131201,0x80000000,2,0x40000000][i]);assert.equal(row.creation,i===3?1:3);
        assert.equal(row.ioAttempted,row.ok&&i>0);assert.equal(row.closed,row.ok);assert.equal(row.closeError,0);
        if(!row.ok){assert.equal(row.identity,null);assert.equal(row.ioOk,false);assert.equal(row.ioError,0);assert.equal(row.bytes,0);assert.equal(row.security,null);}
        else if(i===0){assert.deepEqual(row.identity,v.fileBefore);assert.equal(security(row.security,c.userSid).ownerOnly,true);}
        else {assert.equal(row.ioError===0,row.ioOk);assert.equal(row.security,null);if(row.ioOk)assert.equal(row.bytes,i===1?16:5);}
      }
    }
  }
  return {observationsVerified:true,status:'NOT_ADMITTED',admissionEligible:false,compatibilityConfirmed:false,authorityProven:false,continuousStabilityProven:false,
    initialAcl:initial,afterAcl:after,setAttempted:v.setAttempted,setSucceeded,
    writeDacOpenError:v.writeOpenError,setError:v.setError,
    operationResults:v.operations.map(r=>({name:r.name,ok:r.ok,error:r.error,ioOk:r.ioOk??null,ioError:r.ioError??null})),
    result:!setSucceeded?'OWNER_ONLY_SET_NOT_ESTABLISHED':v.operations.every(r=>r.ok&&(!r.ioAttempted||r.ioOk))?'OWNER_ONLY_IO_OBSERVED':'OWNER_ONLY_REOPEN_OR_IO_DENIED'};
}
