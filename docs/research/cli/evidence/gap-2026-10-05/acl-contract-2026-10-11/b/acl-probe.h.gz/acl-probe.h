// Fixed, disposable scratch experiment. No access is granted to the LowBox SID.
std::string ownerProbeHex(const BYTE* bytes, size_t length) {
  static constexpr char digits[]="0123456789abcdef";
  std::string out; out.reserve(length*2);
  for(size_t i=0;i<length;++i){out+=digits[bytes[i]>>4];out+=digits[bytes[i]&15];}return out;
}
std::string ownerProbeSecurity(HANDLE handle) {
  PSECURITY_DESCRIPTOR sd=nullptr;PSID owner=nullptr;PACL dacl=nullptr;
  const DWORD error=GetSecurityInfo(handle,SE_FILE_OBJECT,OWNER_SECURITY_INFORMATION|DACL_SECURITY_INFORMATION,&owner,nullptr,&dacl,nullptr,&sd);
  bool valid=error==0&&sd&&IsValidSecurityDescriptor(sd);
  std::string sid="null",raw="null";SECURITY_DESCRIPTOR_CONTROL control=0;DWORD revision=0;
  bool controlOk=false;BOOL present=FALSE,defaulted=FALSE;PACL actual=nullptr;
  bool daclOk=false;
  if(valid){
    LPWSTR text=nullptr;
    if(owner&&IsValidSid(owner)&&ConvertSidToStringSidW(owner,&text)){sid="\""+privateJson(text)+"\"";LocalFree(text);}
    controlOk=GetSecurityDescriptorControl(sd,&control,&revision)!=FALSE;
    daclOk=GetSecurityDescriptorDacl(sd,&present,&actual,&defaulted)!=FALSE;
    if(daclOk&&present&&actual&&IsValidAcl(actual))raw="\""+ownerProbeHex(reinterpret_cast<const BYTE*>(actual),actual->AclSize)+"\"";
  }
  if(sd)LocalFree(sd);
  return "{\"error\":"+std::to_string(error)+",\"valid\":"+(valid?"true":"false")+",\"ownerSid\":"+sid+
    ",\"controlRead\":"+(controlOk?"true":"false")+",\"control\":"+std::to_string(control)+",\"revision\":"+std::to_string(revision)+
    ",\"daclRead\":"+(daclOk?"true":"false")+",\"daclPresent\":"+(present?"true":"false")+",\"daclDefaulted\":"+(defaulted?"true":"false")+",\"rawAclHex\":"+raw+"}";
}
napi_value ownerOnlyAclCallback(napi_env env,napi_callback_info info) {
  napi_value args[1];size_t count=1;
  if(state!=2||api.napi_get_cb_info(env,info,&count,args,nullptr,nullptr)!=napi_ok||count!=0){
    api.napi_throw_error(env,"OWNER_ACL_PROBE_ARGUMENT","Installed adapter and no arguments required");return nullptr;
  }
  static LONG invoked=0;
  if(InterlockedCompareExchange(&invoked,1,0)!=0){api.napi_throw_error(env,"OWNER_ACL_PROBE_ONCE","Fixed mutation is one-shot");return nullptr;}
  constexpr WCHAR folder[]=L"X:\\scratch\\private-v4-owner-acl-probe";
  const auto before=coordinateContext();WalkHandles held;
  HANDLE target=INVALID_HANDLE_VALUE,writeHandle=INVALID_HANDLE_VALUE;
  bool bound=before.expectedToken;std::string opens="[";
  const WCHAR* paths[]={L"X:\\scratch",folder};
  for(unsigned i=0;i<2&&bound;++i){
    HANDLE h=CreateFileW(paths[i],READ_CONTROL|FILE_READ_ATTRIBUTES,FILE_SHARE_READ|FILE_SHARE_WRITE,nullptr,OPEN_EXISTING,FILE_FLAG_BACKUP_SEMANTICS|FILE_FLAG_OPEN_REPARSE_POINT,nullptr);
    DWORD error=h==INVALID_HANDLE_VALUE?GetLastError():0;WCHAR canonical[kPathChars]={};
    bool match=false;
    if(h!=INVALID_HANDLE_VALUE){held.handles[held.count++]=h;std::wstring expected=L"\\\\?\\";expected+=paths[i];match=plainObject(h,true)&&canonicalPrivateDos(h,canonical)&&expected==canonical;if(i)target=h;}
    if(i)opens+=",";
    opens+="{\"path\":\""+privateJson(paths[i])+"\",\"access\":131200,\"share\":3,\"error\":"+std::to_string(error)+",\"opened\":"+(h!=INVALID_HANDLE_VALUE?"true":"false")+",\"matched\":"+(match?"true":"false")+"}";
    bound=bound&&match;
  }
  opens+="]";
  const std::string fileBefore=bound?coordinateFile(target):"null";
  const std::string securityBefore=bound?ownerProbeSecurity(target):"null";
  DWORD writeOpenError=0;bool writeMatched=false;std::string writeIdentity="null";
  if(bound){
    writeHandle=CreateFileW(folder,WRITE_DAC|READ_CONTROL|FILE_READ_ATTRIBUTES,FILE_SHARE_READ|FILE_SHARE_WRITE,nullptr,OPEN_EXISTING,FILE_FLAG_BACKUP_SEMANTICS|FILE_FLAG_OPEN_REPARSE_POINT,nullptr);
    writeOpenError=writeHandle==INVALID_HANDLE_VALUE?GetLastError():0;
    if(writeHandle!=INVALID_HANDLE_VALUE){
      FILE_ID_INFO first={},second={};WCHAR canonical[kPathChars]={};
      writeMatched=plainObject(writeHandle,true)&&canonicalPrivateDos(writeHandle,canonical)&&std::wstring(L"\\\\?\\")+folder==canonical&&
        GetFileInformationByHandleEx(target,FileIdInfo,&first,sizeof(first))&&GetFileInformationByHandleEx(writeHandle,FileIdInfo,&second,sizeof(second))&&
        first.VolumeSerialNumber==second.VolumeSerialNumber&&memcmp(&first.FileId,&second.FileId,sizeof(first.FileId))==0;
      writeIdentity=coordinateFile(writeHandle);
    }
  }
  HANDLE token=nullptr;BYTE userBuffer[512]={};DWORD tokenSize=0,aclPrepareError=0;
  alignas(ACL) BYTE aclBuffer[1024]={};auto* acl=reinterpret_cast<PACL>(aclBuffer);
  bool prepared=false;
  if(writeMatched){
    if(!OpenProcessToken(GetCurrentProcess(),TOKEN_QUERY,&token))aclPrepareError=GetLastError();
    else if(!GetTokenInformation(token,TokenUser,userBuffer,sizeof(userBuffer),&tokenSize))aclPrepareError=GetLastError();
    else if(!InitializeAcl(acl,sizeof(aclBuffer),ACL_REVISION))aclPrepareError=GetLastError();
    else if(!AddAccessAllowedAceEx(acl,ACL_REVISION,OBJECT_INHERIT_ACE|CONTAINER_INHERIT_ACE,FILE_ALL_ACCESS,reinterpret_cast<TOKEN_USER*>(userBuffer)->User.Sid))aclPrepareError=GetLastError();
    else prepared=true;
  }
  if(token)CloseHandle(token);
  const bool setAttempted=bound&&writeMatched&&prepared;
  DWORD setError=ERROR_INVALID_HANDLE;
  if(setAttempted)setError=SetSecurityInfo(writeHandle,SE_FILE_OBJECT,DACL_SECURITY_INFORMATION|PROTECTED_DACL_SECURITY_INFORMATION,nullptr,nullptr,acl,nullptr);
  const std::string securityAfter=bound?ownerProbeSecurity(target):"null";
  const std::string fileAfter=bound?coordinateFile(target):"null";
  bool writeClosed=true,targetClosed=true;DWORD writeCloseError=0,targetCloseError=0;
  if(writeHandle!=INVALID_HANDLE_VALUE){writeClosed=CloseHandle(writeHandle)!=FALSE;if(!writeClosed)writeCloseError=GetLastError();writeHandle=INVALID_HANDLE_VALUE;}
  if(target!=INVALID_HANDLE_VALUE){targetClosed=CloseHandle(target)!=FALSE;if(!targetClosed)targetCloseError=GetLastError();held.handles[--held.count]=INVALID_HANDLE_VALUE;target=INVALID_HANDLE_VALUE;}
  const bool operationsAttempted=setAttempted&&setError==0&&writeClosed&&targetClosed;
  std::string operations="[";unsigned opCount=0;
  auto append=[&](const char* name,bool ok,DWORD error,const std::string& extra){if(opCount++)operations+=",";operations+="{\"name\":\""+std::string(name)+"\",\"ok\":"+(ok?"true":"false")+",\"error\":"+std::to_string(error)+extra+"}";};
  if(operationsAttempted){
    const struct {const char* name;const WCHAR* path;DWORD access;DWORD creation;bool directory;bool read;bool write;} specs[]={
      {"reopen-directory",folder,FILE_LIST_DIRECTORY|READ_CONTROL|FILE_READ_ATTRIBUTES,OPEN_EXISTING,true,false,false},
      {"read-existing",L"X:\\scratch\\private-v4-owner-acl-probe\\existing.txt",GENERIC_READ,OPEN_EXISTING,false,true,false},
      {"write-existing",L"X:\\scratch\\private-v4-owner-acl-probe\\existing.txt",FILE_WRITE_DATA,OPEN_EXISTING,false,false,true},
      {"create-file",L"X:\\scratch\\private-v4-owner-acl-probe\\created.txt",GENERIC_WRITE,CREATE_NEW,false,false,true}};
    for(const auto& spec:specs){
      HANDLE h=CreateFileW(spec.path,spec.access,FILE_SHARE_READ|FILE_SHARE_WRITE,nullptr,spec.creation,FILE_FLAG_OPEN_REPARSE_POINT|(spec.directory?FILE_FLAG_BACKUP_SEMANTICS:0),nullptr);
      DWORD error=h==INVALID_HANDLE_VALUE?GetLastError():0;bool opened=h!=INVALID_HANDLE_VALUE;DWORD ioError=0,bytes=0;bool ioOk=false,closed=false;DWORD closeError=0;
      std::string identity="null",security="null";
      if(opened){identity=coordinateFile(h);if(spec.directory)security=ownerProbeSecurity(h);BYTE payload[64]={};if(spec.read){ioOk=ReadFile(h,payload,sizeof(payload),&bytes,nullptr)!=FALSE;if(!ioOk)ioError=GetLastError();}
        if(spec.write){const char text[]="probe";ioOk=WriteFile(h,text,5,&bytes,nullptr)!=FALSE;if(!ioOk)ioError=GetLastError();}
        closed=CloseHandle(h)!=FALSE;if(!closed)closeError=GetLastError();}
      append(spec.name,opened,error,",\"access\":"+std::to_string(spec.access)+",\"creation\":"+std::to_string(spec.creation)+",\"ioAttempted\":"+(opened&&(spec.read||spec.write)?"true":"false")+",\"ioOk\":"+(ioOk?"true":"false")+",\"ioError\":"+std::to_string(ioError)+",\"bytes\":"+std::to_string(bytes)+",\"closed\":"+(closed?"true":"false")+",\"closeError\":"+std::to_string(closeError)+",\"identity\":"+identity+",\"security\":"+security);
    }
    BOOL made=CreateDirectoryW(L"X:\\scratch\\private-v4-owner-acl-probe\\created-directory",nullptr);DWORD makeError=made?0:GetLastError();append("create-directory",made!=FALSE,makeError,"");
    BOOL removed=DeleteFileW(L"X:\\scratch\\private-v4-owner-acl-probe\\existing.txt");DWORD deleteError=removed?0:GetLastError();append("delete-existing",removed!=FALSE,deleteError,"");
  }
  operations+="]";const auto after=coordinateContext();
  std::string value="{\"schema\":\"chainlesschain.private-owner-acl-probe/v1\",\"status\":\"NOT_ADMITTED\",\"admissionEligible\":false,\"compatibilityConfirmed\":false,\"mappingChanged\":false,\"scope\":\"fixed-actor-created-scratch-only\",\"contextBefore\":"+before.json+",\"contextAfter\":"+after.json+
    ",\"contextObservedStable\":"+(before.expectedToken&&after.expectedToken&&before.json==after.json?"true":"false")+",\"opens\":"+opens+",\"bound\":"+(bound?"true":"false")+",\"fileBefore\":"+fileBefore+",\"fileAfter\":"+fileAfter+
    ",\"securityBefore\":"+securityBefore+",\"securityAfter\":"+securityAfter+",\"writeOpenError\":"+std::to_string(writeOpenError)+",\"writeOpened\":"+(writeMatched?"true":"false")+",\"writeIdentity\":"+writeIdentity+",\"aclPrepared\":"+(prepared?"true":"false")+",\"aclPrepareError\":"+std::to_string(aclPrepareError)+",\"setAttempted\":"+(setAttempted?"true":"false")+",\"setError\":"+std::to_string(setError)+
    ",\"writeHandleClosed\":"+(writeClosed?"true":"false")+",\"writeCloseError\":"+std::to_string(writeCloseError)+",\"targetHandleClosed\":"+(targetClosed?"true":"false")+",\"targetCloseError\":"+std::to_string(targetCloseError)+",\"operationsAttempted\":"+(operationsAttempted?"true":"false")+",\"operations\":"+operations+"}";
  napi_value result;if(api.napi_create_string_utf8(env,value.c_str(),NAPI_AUTO_LENGTH,&result)!=napi_ok)return nullptr;return result;
}
