import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import http from "node:http";
import { fileURLToPath } from "node:url";
import { spawn, execFile } from "node:child_process";
import { createRequire } from "node:module";
import { it, expect } from "vitest";
const bin = fileURLToPath(
  new URL("../../bin/chainlesschain.js", import.meta.url),
);
const { testLlm } = createRequire(import.meta.url)(
  "../../../vscode-extension/src/llm-config.js",
);
function run(args, env, cwd, input = "") {
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, [bin, ...args], {
      cwd,
      env,
      windowsHide: true,
      stdio: ["pipe", "pipe", "pipe"],
    });
    let stdout = "",
      stderr = "";
    const timer = setTimeout(() => {
      child.kill();
      reject(new Error("CLI test timeout"));
    }, 60_000);
    child.stdout.on("data", (b) => {
      stdout += b;
    });
    child.stderr.on("data", (b) => {
      stderr += b;
    });
    child.once("error", (e) => {
      clearTimeout(timer);
      reject(e);
    });
    child.once("close", (code) => {
      clearTimeout(timer);
      resolve({ code, stdout, stderr });
    });
    child.stdin.end(input);
  });
}
it.each(["openai", "volcengine"])(
  "saves %s via real CLI stdin and verifies CLI and IDE probes without exposing credentials",
  async (provider) => {
    const root = fs.mkdtempSync(path.join(os.tmpdir(), "cc-llm-connection-"));
    const requests = [];
    let finalAnswer = true;
    let reportUsage = true;
    const server = http.createServer((req, res) => {
      let body = "";
      req.on("data", (b) => {
        body += b;
      });
      req.on("end", () => {
        requests.push({
          path: req.url,
          auth: req.headers.authorization,
          body: JSON.parse(body),
        });
        res.setHeader("Content-Type", "application/json");
        const truncated = JSON.parse(body).max_tokens < 34 || !finalAnswer;
        res.end(
          JSON.stringify({
            ...(reportUsage
              ? {
                  usage: {
                    prompt_tokens: 12,
                    completion_tokens: 35,
                    prompt_tokens_details: { cached_tokens: 2 },
                  },
                }
              : {}),
            choices: [
              {
                finish_reason: truncated ? "length" : "stop",
                message: {
                  content: truncated ? "" : "Hello",
                  reasoning_content: "test-only private reasoning",
                },
              },
            ],
          }),
        );
      });
    });
    try {
      await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
      const workspace = path.join(root, "workspace");
      fs.mkdirSync(workspace);
      const env = {
        ...process.env,
        CHAINLESSCHAIN_HOME: path.join(root, "state"),
        CHAINLESSCHAIN_SECURITY_ANCHOR_HOME: path.join(root, "anchor"),
        CHAINLESSCHAIN_EVOLUTION_DEPLOYMENT_DESCRIPTOR: "",
        CHAINLESSCHAIN_EVOLUTION_DEPLOYMENT_TRUST_ROOT: "",
        NO_COLOR: "1",
      };
      const draft = {
        provider,
        model:
          provider === "volcengine"
            ? "deepseek-v4-flash-ga-260731"
            : "relay/custom-model",
        baseUrl: `http://127.0.0.1:${server.address().port}/proxy/v1`,
        apiKey: "test-only-relay-key",
        visionModel: "relay/vision-model",
      };
      const saved = await run(
        ["llm", "configure", "--storage", "file"],
        env,
        workspace,
        JSON.stringify(draft),
      );
      expect(saved.code, saved.stderr).toBe(0);
      expect(saved.stdout + saved.stderr).not.toContain(draft.apiKey);
      const tested = await run(["llm", "test"], env, workspace);
      expect(tested.code, tested.stderr).toBe(0);
      const ideResult = await testLlm({
        command: bin,
        deps: {
          execFile: (command, args, options, callback) =>
            execFile(
              command,
              args,
              {
                ...options,
                cwd: workspace,
                env: { ...options.env, ...env },
              },
              callback,
            ),
        },
      });
      expect(ideResult.ok, ideResult.detail).toBe(true);
      expect(ideResult.detail).toContain("Connected");
      expect(ideResult.detail).not.toContain(draft.apiKey);
      expect(ideResult.detail).not.toContain("private reasoning");
      expect(requests).toHaveLength(2);
      for (const request of requests)
        expect(request).toEqual({
          path: "/proxy/v1/chat/completions",
          auth: `Bearer ${draft.apiKey}`,
          body: {
            model: draft.model,
            messages: [{ role: "user", content: "Say hi in one word." }],
            max_tokens: 1024,
          },
        });
      const structured = await run(["llm", "test", "--json"], env, workspace);
      expect(structured.code, structured.stderr).toBe(0);
      const receipt = JSON.parse(structured.stdout);
      expect(receipt).toMatchObject({
        schema: "chainlesschain.llm-connection-probe/v1",
        ok: true,
        provider,
        model: draft.model,
        reply: "Hello",
        billingVerified: false,
        costBasis: "token-estimate",
        usage: {
          input_tokens: 10,
          output_tokens: 35,
          cache_read_input_tokens: 2,
          cache_creation_input_tokens: 0,
        },
      });
      if (provider === "volcengine")
        expect(receipt.totalCostUsd).toBeGreaterThan(0);
      else expect(receipt.totalCostUsd).toBeNull();
      expect(structured.stdout + structured.stderr).not.toContain(draft.apiKey);
      expect(structured.stdout + structured.stderr).not.toContain(
        "private reasoning",
      );
      finalAnswer = false;
      const exhausted = await run(["llm", "test", "--json"], env, workspace);
      expect(exhausted.code).toBe(1);
      expect(JSON.parse(exhausted.stdout)).toMatchObject({
        ok: false,
        reply: null,
        usage: receipt.usage,
      });
      expect(JSON.parse(exhausted.stdout).error).toContain("exhausted");
      finalAnswer = true;
      reportUsage = false;
      const unknown = await run(["llm", "test", "--json"], env, workspace);
      expect(unknown.code).toBe(0);
      expect(JSON.parse(unknown.stdout)).toMatchObject({
        ok: true,
        usage: null,
        totalCostUsd: null,
      });
      const file = path.join(root, "state", "config.json");
      const original = fs.readFileSync(file, "utf8");
      const failed = await run(
        ["llm", "configure", "--storage", "file"],
        env,
        workspace,
        JSON.stringify({
          ...draft,
          baseUrl: "https://unrelated.example/v1",
          apiKey: "",
        }),
      );
      expect(failed.code).not.toBe(0);
      expect(fs.readFileSync(file, "utf8")).toBe(original);
      const updated = {
        ...draft,
        model: `${draft.model}-updated`,
        visionModel: "",
        apiKey: "",
      };
      const preserved = await run(
        ["llm", "configure", "--storage", "file"],
        env,
        workspace,
        JSON.stringify(updated),
      );
      expect(preserved.code, preserved.stderr).toBe(0);
      const reopened = await run(["config", "list", "--json"], env, workspace);
      expect(reopened.code, reopened.stderr).toBe(0);
      expect(JSON.parse(reopened.stdout).llm).toMatchObject({
        provider,
        model: updated.model,
        baseUrl: draft.baseUrl,
        visionModel: null,
        apiKey: "[REDACTED]",
      });
      expect(reopened.stdout + reopened.stderr).not.toContain(draft.apiKey);
      expect(JSON.parse(fs.readFileSync(file, "utf8")).llm.apiKey).toBe(
        draft.apiKey,
      );
      const newEndpoint = {
        ...updated,
        baseUrl: draft.baseUrl.replace("/proxy/v1", "/another/v1"),
        apiKey: "test-only-new-endpoint-key",
      };
      const replaced = await run(
        ["llm", "configure", "--storage", "file"],
        env,
        workspace,
        JSON.stringify(newEndpoint),
      );
      expect(replaced.code, replaced.stderr).toBe(0);
      const newTest = await run(["llm", "test"], env, workspace);
      expect(newTest.code, newTest.stderr).toBe(0);
      expect(requests.at(-1)).toMatchObject({
        path: "/another/v1/chat/completions",
        auth: `Bearer ${newEndpoint.apiKey}`,
        body: { model: updated.model },
      });
    } finally {
      await new Promise((resolve) => server.close(resolve));
      fs.rmSync(root, { recursive: true, force: true });
    }
  },
  180_000,
);
