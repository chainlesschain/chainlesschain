import { describe, it, expect } from "vitest";
import fs from "node:fs";
import { evalDigest } from "../../src/lib/eval/evidence.js";
import { outcomeDigest } from "../../src/lib/eval/outcomes.js";
import { verifyAgentTerminal } from "../../src/lib/eval/stream-terminal.js";
import { llmProbeReceipt } from "../../src/lib/llm-connection-probe.js";
import { validateVerify01Collection } from "../../src/lib/eval/verify01-contracts.js";
import {
  inspectIdeProtocol,
  importVerify01HostCapture,
} from "../../src/lib/eval/verify01-host-evidence.js";

const directory = new URL(
  "../../../../docs/research/cli/verify01-plan-2026-10-04/",
  import.meta.url,
);
const read = (name) =>
  JSON.parse(fs.readFileSync(new URL(name, directory), "utf8"));
function fixture(entry = "vscode") {
  const bundle = {
    plan: read("plan.json"),
    catalog: read("tasks.json"),
    bindings: read("comparison-bindings.json"),
    expectedPlanDigest: fs
      .readFileSync(new URL("plan.sha256", directory), "utf8")
      .trim(),
  };
  const sample = bundle.plan.samples.find(
    (row) => row.kind === "task" && row.stratum === `win32-${entry}-volcengine`,
  );
  const task = bundle.catalog.tasks.find((row) => row.id === sample.taskId);
  const comparison = bundle.bindings.comparisons[sample.stratum];
  const bytes = Buffer.from("// test-only evaluator; must never be executed");
  const review = {
    planDigest: bundle.expectedPlanDigest,
    catalogDigest: outcomeDigest(bundle.catalog),
    projectCommit: bundle.catalog.projectCommit,
    tasks: bundle.catalog.tasks.map((task) => ({
      taskId: task.id,
      setup: { path: `review/${task.id}-setup.mjs`, digest: evalDigest(bytes) },
      check: { path: `review/${task.id}-check.mjs`, digest: evalDigest(bytes) },
      allowedChangedPaths: [...task.expectedFiles],
    })),
  };
  const preparation = {
    review,
    expectedReviewDigest: outcomeDigest(review),
    projectCommit: review.projectCommit,
    readReviewedFile: () => bytes,
  };
  const origin = Date.parse(bundle.plan.window.start) + 10000;
  const at = (ms) => new Date(origin + ms).toISOString();
  const raw = [
    [
      "output",
      {
        type: "system",
        subtype: "init",
        session_id: "capture-test",
        model: comparison.model,
        provider: comparison.provider,
        permission_mode: "acceptEdits",
        input_receipts: { version: 1 },
      },
    ],
    [
      "input",
      { type: "user", text: task.prompt, client_message_id: "test-input" },
    ],
    [
      "output",
      {
        type: "system",
        subtype: "input_accepted",
        session_id: "capture-test",
        client_message_id: "test-input",
        receipt: {
          sessionId: "capture-test",
          clientMessageId: "test-input",
          duplicate: false,
          eventHash: "d".repeat(64),
          inputDigest: evalDigest(
            Buffer.from(
              JSON.stringify({
                text: task.prompt,
                images: [],
                llm: null,
                worklogSessionId: null,
              }),
            ),
          ).slice(7),
        },
      },
    ],
    [
      "output",
      {
        type: "result",
        subtype: "success",
        is_error: false,
        session_id: "capture-test",
        result: "actual terminal fixture",
        usage: {
          input_tokens: 10,
          output_tokens: 2,
          cache_read_input_tokens: 0,
          cache_creation_input_tokens: 0,
        },
        total_cost_usd: 0.1,
      },
    ],
    ["exit", { code: 0, signal: null, stdoutDrained: true }],
  ].map(([direction, event], index) => ({
    schema: "chainlesschain.ide-protocol-record/v1",
    generation: "test-only-generation",
    sequence: index + 1,
    at: at(index * 100),
    direction,
    event,
  }));
  const ui = [
    "submit",
    "background-tab",
    "return-tab",
    "final-result",
    "reload",
    "restored-result",
  ].map((action, index) => ({
    action,
    sampleId: sample.id,
    sessionId: "capture-test",
    at: at(index === 0 ? 50 : index * 100),
    ...(["final-result", "restored-result"].includes(action)
      ? { resultDigest: evalDigest(Buffer.from(raw[3].event.result)) }
      : {}),
  }));
  const target = bundle.bindings.matrix.find(
    (row) => row.id === `win32-${entry}`,
  );
  const artifacts = new Map();
  const pin = (name, value) => {
    const bytes = Buffer.from(JSON.stringify(value));
    artifacts.set(name, bytes);
    return { path: name, digest: evalDigest(bytes) };
  };
  const check = {
    taskId: task.id,
    reviewDigest: preparation.expectedReviewDigest,
    pass: true,
    detail: "test-only acceptance",
    changedFiles: [...task.expectedFiles],
    unrelatedChanges: [],
    process: {
      sourceDigest: evalDigest(bytes),
      exitCode: 0,
      signal: null,
      error: null,
      stdout: JSON.stringify({ pass: true, detail: "test-only acceptance" }),
    },
  };
  const manifest = {
    schema: "chainlesschain.verify01-host-capture/v1",
    sampleId: sample.id,
    planDigest: bundle.expectedPlanDigest,
    reviewDigest: preparation.expectedReviewDigest,
    projectCommit: review.projectCommit,
    sourceCommit: "c".repeat(40),
    entry,
    platform: target.platform,
    arch: target.arch,
    node: target.node,
    host: target.host,
    os: target.os,
    observedAt: at(700),
    elapsedMs: 700,
    retries: 0,
    manualRepairs: 0,
    runId: "test-only-import",
    protocol: pin("protocol.json", raw),
    ui: pin("ui.json", ui),
    check: pin("check.json", check),
    diff: pin(
      "diff.json",
      task.expectedFiles.map((file) => ({
        path: file,
        before: null,
        after: {
          type: "file",
          mode: 0o644,
          dependency: false,
          digest: evalDigest(Buffer.from("test-only artifact")),
          bytes: Buffer.byteLength("test-only artifact"),
          bytesBase64: Buffer.from("test-only artifact").toString("base64"),
        },
      })),
    ),
  };
  const importCapture = () =>
    importVerify01HostCapture(bundle, preparation, {
      manifest,
      expectedManifestDigest: outcomeDigest(manifest),
      readArtifact: (file) => artifacts.get(file),
      sourceCommit: manifest.sourceCommit,
      now: Date.parse(bundle.plan.window.end) + 1000,
    });
  return {
    bundle,
    preparation,
    manifest,
    raw,
    ui,
    check,
    comparison,
    task,
    artifacts,
    pin,
    importCapture,
  };
}

function completedCliFirstRunFixture() {
  const f = fixture();
  const sample = f.bundle.plan.samples.find(
    (row) => row.kind === "first-run" && row.stratum === "win32-cli-volcengine",
  );
  const task = f.bundle.catalog.tasks.find((row) => row.id === sample.taskId);
  const comparison = f.bundle.bindings.comparisons[sample.stratum];
  const target = f.bundle.bindings.matrix.find((row) => row.id === "win32-cli");
  const startedAt = f.raw[0].at;
  Object.assign(f.manifest, {
    sampleId: sample.id,
    entry: "cli",
    host: target.host,
    firstRun: {
      cleanEnvironment: true,
      stages: Object.fromEntries(
        ["install", "configure", "authenticate", "tool", "artifact"].map(
          (stage) => [
            stage,
            {
              passed: true,
              receipt: f.pin(`${stage}.json`, { testOnly: true, stage }),
            },
          ],
        ),
      ),
    },
  });
  delete f.manifest.protocol;
  delete f.manifest.ui;
  const authentication = llmProbeReceipt(comparison, {
    ok: true,
    usage: {
      input_tokens: 10,
      output_tokens: 35,
      cache_read_input_tokens: 2,
      cache_creation_input_tokens: 0,
    },
  });
  f.manifest.firstRun.stages.authenticate.receipt = f.pin(
    "authenticate.json",
    authentication,
  );
  const invocation = {
    taskId: task.id,
    prompt: task.prompt,
    provider: comparison.provider,
    model: comparison.model,
    permissionMode: "acceptEdits",
    projectCommit: f.bundle.catalog.projectCommit,
    sourceCommit: f.manifest.sourceCommit,
    startedAt,
  };
  f.manifest.invocation = f.pin("invocation.json", invocation);
  const raw = [
    {
      type: "system",
      subtype: "init",
      model: comparison.model,
      provider: comparison.provider,
      permission_mode: "acceptEdits",
      session_id: "cli-first-run",
    },
    { ...f.raw[3].event, session_id: "cli-first-run" },
  ]
    .map(JSON.stringify)
    .join("\n");
  const streamBytes = Buffer.from(raw);
  f.artifacts.set("stream.jsonl", streamBytes);
  f.manifest.stream = {
    path: "stream.jsonl",
    digest: evalDigest(streamBytes),
  };
  f.manifest.exit = f.pin("exit.json", {
    code: 0,
    signal: null,
    finishedAt: f.raw[4].at,
  });
  f.check.taskId = task.id;
  f.check.changedFiles = [...task.expectedFiles];
  f.manifest.check = f.pin("check.json", f.check);
  f.manifest.diff = f.pin(
    "diff.json",
    task.expectedFiles.map((file) => ({
      path: file,
      before: null,
      after: {
        type: "file",
        mode: 0o644,
        dependency: false,
        digest: evalDigest(Buffer.from("test-only artifact")),
        bytes: Buffer.byteLength("test-only artifact"),
        bytesBase64: Buffer.from("test-only artifact").toString("base64"),
      },
    })),
  );
  return { ...f, invocation, authentication };
}

describe("existing actual-host evidence adapter (all records here are test fixtures)", () => {
  it.each(["vscode", "jetbrains"])(
    "imports %s records into the existing fixed-denominator report",
    (entry) => {
      const f = fixture(entry);
      const result = f.importCapture();
      expect(result.report.task).toMatchObject({
        planned: 36,
        observed: 1,
        missing: 35,
        succeeded: 1,
      });
      expect(result.report.firstRun).toMatchObject({ missing: 9 });
      expect(result.report.status).toBe("INSUFFICIENT_EVIDENCE");
      expect(result).toMatchObject({
        identityVerified: false,
        installationVerified: false,
        billingVerified: false,
      });
    },
  );
  it("keeps absent actual usage and cost unknown", () => {
    const f = fixture();
    delete f.raw[3].event.usage;
    delete f.raw[3].event.total_cost_usd;
    f.manifest.protocol = f.pin("protocol.json", f.raw);
    const result = f.importCapture();
    expect(result.history.runs[0].results[0]).toMatchObject({
      totalCostUsd: null,
      usage: null,
    });
    expect(result.report.task.succeeded).toBe(0);
  });
  function appendOutput(f, ...events) {
    f.raw.splice(
      -1,
      0,
      ...events.map((event) => ({
        ...f.raw[3],
        direction: "output",
        event,
      })),
    );
    for (const [index, record] of f.raw.entries()) {
      record.sequence = index + 1;
      record.at = new Date(Date.parse(f.raw[0].at) + index * 100).toISOString();
    }
  }
  const lifecycleEnd = () => ({
    type: "system",
    subtype: "end",
    session_id: "capture-test",
    turns: 1,
  });
  it("accepts the actual persistent stream's one-turn lifecycle end without altering capture", () => {
    const f = fixture();
    Object.assign(f.raw[3].event, { turn: 1, trace_id: "trace-test", seq: 4 });
    appendOutput(f, { ...lifecycleEnd(), trace_id: "trace-test", seq: 5 });
    const before = JSON.stringify(f.raw);
    expect(
      inspectIdeProtocol(f.raw, {
        prompt: f.task.prompt,
        comparison: f.comparison,
      }),
    ).toMatchObject({ executionSucceeded: true, terminalFailure: false });
    expect(JSON.stringify(f.raw)).toBe(before);
    expect(
      verifyAgentTerminal(
        f.raw
          .filter((r) => r.direction === "output")
          .map((r) => JSON.stringify(r.event))
          .join("\n"),
      ).terminalVerified,
    ).toBe(false);
  });
  it("keeps an explicit failure followed by lifecycle end as failure", () => {
    const f = fixture();
    Object.assign(f.raw[3].event, {
      turn: 1,
      subtype: "error_max_turns",
      is_error: true,
    });
    appendOutput(f, lifecycleEnd());
    expect(
      inspectIdeProtocol(f.raw, {
        prompt: f.task.prompt,
        comparison: f.comparison,
      }),
    ).toMatchObject({
      executionSucceeded: false,
      terminalFailure: true,
      executionEvidence: { terminalVerified: true },
    });
  });
  it.each([
    ["missing session", { ...lifecycleEnd(), session_id: undefined }],
    ["wrong turn count", { ...lifecycleEnd(), turns: 2 }],
    ["string turn count", { ...lifecycleEnd(), turns: "1" }],
    ["payload on end", { ...lifecycleEnd(), error: "late error" }],
    ["different trace", { ...lifecycleEnd(), trace_id: "foreign-trace" }],
    ["stale output sequence", { ...lifecycleEnd(), seq: 4 }],
    ["tool after result", { type: "tool_use", tool: "write_file" }],
    ["error after result", { type: "error", message: "late failure" }],
  ])("does not accept an ambiguous lifecycle trailer: %s", (_label, end) => {
    const f = fixture();
    Object.assign(f.raw[3].event, { turn: 1, trace_id: "trace-test", seq: 4 });
    appendOutput(f, end);
    expect(
      inspectIdeProtocol(f.raw, {
        prompt: f.task.prompt,
        comparison: f.comparison,
      }),
    ).toMatchObject({
      executionSucceeded: false,
      executionEvidence: { terminalVerified: false },
    });
  });
  it("rejects foreign-session lifecycle end and duplicate end/result", () => {
    const foreign = fixture();
    foreign.raw[3].event.turn = 1;
    appendOutput(foreign, { ...lifecycleEnd(), session_id: "foreign" });
    expect(() =>
      inspectIdeProtocol(foreign.raw, {
        prompt: foreign.task.prompt,
        comparison: foreign.comparison,
      }),
    ).toThrow(/foreign session/);
    const duplicate = fixture();
    duplicate.raw[3].event.turn = 1;
    appendOutput(duplicate, lifecycleEnd(), lifecycleEnd());
    expect(
      inspectIdeProtocol(duplicate.raw, {
        prompt: duplicate.task.prompt,
        comparison: duplicate.comparison,
      }).executionSucceeded,
    ).toBe(false);
    const secondResult = fixture();
    appendOutput(secondResult, { ...secondResult.raw[3].event });
    expect(() =>
      inspectIdeProtocol(secondResult.raw, {
        prompt: secondResult.task.prompt,
        comparison: secondResult.comparison,
      }),
    ).toThrow(/terminal is missing or ambiguous/);
  });
  it("does not accept a lifecycle end before the result or error hidden before a valid end", () => {
    for (const event of [
      lifecycleEnd(),
      { type: "error", message: "earlier failure" },
    ]) {
      const f = fixture();
      f.raw[3].event.turn = 1;
      f.raw.splice(3, 0, { ...f.raw[3], event });
      appendOutput(f, lifecycleEnd());
      expect(
        inspectIdeProtocol(f.raw, {
          prompt: f.task.prompt,
          comparison: f.comparison,
        }).executionSucceeded,
      ).toBe(false);
    }
    const f = fixture();
    f.raw.splice(3, 0, { ...f.raw[3], event: lifecycleEnd() });
    for (const [index, record] of f.raw.entries()) {
      record.sequence = index + 1;
      record.at = new Date(Date.parse(f.raw[0].at) + index * 100).toISOString();
    }
    expect(
      inspectIdeProtocol(f.raw, {
        prompt: f.task.prompt,
        comparison: f.comparison,
      }).executionSucceeded,
    ).toBe(false);
  });
  it("still requires a clean drained exit with a valid lifecycle end", () => {
    const f = fixture();
    f.raw[3].event.turn = 1;
    appendOutput(f, lifecycleEnd());
    f.raw.at(-1).event.code = 1;
    expect(
      inspectIdeProtocol(f.raw, {
        prompt: f.task.prompt,
        comparison: f.comparison,
      }).executionSucceeded,
    ).toBe(false);
    f.raw.at(-1).event.stdoutDrained = false;
    expect(() =>
      inspectIdeProtocol(f.raw, {
        prompt: f.task.prompt,
        comparison: f.comparison,
      }),
    ).toThrow(/drained process exit/);
  });
  it("retains a verified explicit failure rather than counting it as success", () => {
    const f = fixture();
    Object.assign(f.raw[3].event, {
      subtype: "error_max_turns",
      is_error: true,
    });
    f.manifest.protocol = f.pin("protocol.json", f.raw);
    const result = f.importCapture();
    expect(result.history.runs[0].results[0]).toMatchObject({
      executionSucceeded: false,
      pass: false,
      executionEvidence: { terminalVerified: true },
    });
    expect(result.report.task).toMatchObject({ observed: 1, succeeded: 0 });
  });
  it("retains an actual error-only persistence envelope and its interrupted UI journey", () => {
    const f = fixture();
    Object.assign(f.raw[3].event, {
      subtype: "error_persistence",
      is_error: true,
      code: "SESSION_WRITE_FAILED",
      error: "Session user turn was not durably persisted",
    });
    delete f.raw[3].event.result;
    delete f.raw[3].event.usage;
    delete f.raw[3].event.total_cost_usd;
    f.raw[4].event.code = 1;
    f.manifest.protocol = f.pin("protocol.json", f.raw);
    f.check.pass = false;
    f.check.changedFiles = [];
    f.check.process.stdout = JSON.stringify({
      pass: false,
      detail: "required artifact was not produced",
    });
    f.manifest.check = f.pin("check.json", f.check);
    f.manifest.diff = f.pin("diff.json", []);
    // The error itself prevented a restored result. Keep the actual actions,
    // rather than manufacturing reload/restoration records to count a failure.
    const actions = f.ui.slice(0, 4);
    actions[3].resultDigest = evalDigest(Buffer.from(f.raw[3].event.error));
    f.manifest.ui = f.pin("ui.json", actions);
    const result = f.importCapture();
    expect(result.history.runs[0].results[0]).toMatchObject({
      executionSucceeded: false,
      artifactCheckPassed: false,
      pass: false,
      executionEvidence: { terminalVerified: true, exitCode: 1 },
    });
    expect(result.report.task).toMatchObject({ observed: 1, succeeded: 0 });
    expect(result.report.task.totalCost).toBeNull();
    actions[3].resultDigest = evalDigest(Buffer.from("an unrelated UI error"));
    f.manifest.ui = f.pin("ui.json", actions);
    expect(f.importCapture).toThrow(/visible\/restored result/);
  });
  it("still requires all six UI steps for a successful terminal", () => {
    const f = fixture();
    f.manifest.ui = f.pin("ui.json", f.ui.slice(0, 4));
    expect(f.importCapture).toThrow(/journey is incomplete/);
  });
  it("accepts a UI submission that triggers cold initialization before the first protocol record", () => {
    const f = fixture();
    f.ui[0].at = new Date(Date.parse(f.raw[0].at) - 50).toISOString();
    f.manifest.elapsedMs += 50;
    f.manifest.ui = f.pin("ui.json", f.ui);
    expect(f.importCapture().report.task.observed).toBe(1);
  });
  it.each([
    [
      "sequence gap",
      (f) => {
        f.raw[2].sequence += 1;
      },
    ],
    [
      "stale generation",
      (f) => {
        f.raw[3].generation = "previous-child";
      },
    ],
    [
      "foreign session",
      (f) => {
        f.raw[3].event.session_id = "other-tab";
      },
    ],
    [
      "wrong model",
      (f) => {
        f.raw[0].event.model = "fallback-model";
      },
    ],
    [
      "wrong permission mode",
      (f) => {
        f.raw[0].event.permission_mode = "bypassPermissions";
      },
    ],
    [
      "wrong receipt",
      (f) => {
        f.raw[2].event.client_message_id = "old-input";
      },
    ],
    [
      "duplicate receipt",
      (f) => {
        f.raw[2].event.receipt.duplicate = true;
      },
    ],
    [
      "no negotiated receipt",
      (f) => {
        f.raw[0].event.input_receipts.version = 0;
      },
    ],
    [
      "undrained exit",
      (f) => {
        f.raw[4].event.stdoutDrained = false;
      },
    ],
    [
      "wrong frozen prompt",
      (f) => {
        f.raw[1].event.text = "a different task";
      },
    ],
    [
      "per-turn model override",
      (f) => {
        f.raw[1].event.llm = { provider: "ollama", model: "substitute" };
      },
    ],
    [
      "wrong receipt input digest",
      (f) => {
        f.raw[2].event.receipt.inputDigest = "e".repeat(64);
      },
    ],
    [
      "missing durable event hash",
      (f) => {
        delete f.raw[2].event.receipt.eventHash;
      },
    ],
  ])("rejects %s", (_name, mutate) => {
    const f = fixture();
    mutate(f);
    expect(() =>
      inspectIdeProtocol(f.raw, {
        prompt: f.task.prompt,
        comparison: f.comparison,
      }),
    ).toThrow();
  });
  it.each([
    [
      "CLI claiming IDE",
      (f) => {
        f.manifest.entry = "cli";
      },
    ],
    [
      "missing captured run identity",
      (f) => {
        delete f.manifest.runId;
      },
    ],
    [
      "wrong native runtime",
      (f) => {
        f.manifest.node = "v22.22.2";
      },
    ],
    [
      "missing host journey",
      (f) => {
        f.ui.pop();
        f.manifest.ui = f.pin("ui.json", f.ui);
      },
    ],
    [
      "stale restored text",
      (f) => {
        f.ui[5].resultDigest = evalDigest(Buffer.from("stale"));
        f.manifest.ui = f.pin("ui.json", f.ui);
      },
    ],
    [
      "future UI action",
      (f) => {
        f.ui[5].at = "2030-01-01T00:00:00Z";
        f.manifest.ui = f.pin("ui.json", f.ui);
      },
    ],
    [
      "unpinned checker",
      (f) => {
        f.check.process.sourceDigest = "sha256:" + "a".repeat(64);
        f.manifest.check = f.pin("check.json", f.check);
      },
    ],
    [
      "unreviewed edit",
      (f) => {
        f.check.changedFiles.push("package.json");
        f.manifest.check = f.pin("check.json", f.check);
      },
    ],
    [
      "falsified check verdict",
      (f) => {
        f.check.process.stdout = JSON.stringify({
          pass: false,
          detail: "failure",
        });
        f.manifest.check = f.pin("check.json", f.check);
      },
    ],
    [
      "artifact changed after pinning",
      (f) => {
        f.artifacts.set("protocol.json", Buffer.from("[]"));
      },
    ],
    [
      "missing full diff",
      (f) => {
        delete f.manifest.diff;
      },
    ],
    [
      "incomplete changed-file body",
      (f) => {
        f.manifest.diff = f.pin("diff.json", [
          {
            path: f.task.expectedFiles[0],
            before: null,
            after: {
              type: "file",
              mode: 0o644,
              dependency: false,
              digest: evalDigest(Buffer.from("other")),
              bytes: 5,
              bytesBase64: Buffer.from("actual").toString("base64"),
            },
          },
        ]);
      },
    ],
  ])("rejects %s", (_name, mutate) => {
    const f = fixture();
    mutate(f);
    expect(f.importCapture).toThrow();
  });
  it("imports a first-install early failure with all five stage receipts and no invented Eval run", () => {
    const f = fixture();
    const sample = f.bundle.plan.samples.find(
      (row) =>
        row.kind === "first-run" && row.stratum === "win32-vscode-volcengine",
    );
    Object.assign(f.manifest, {
      sampleId: sample.id,
      failureCause: "install",
      cost: null,
      firstRun: {
        cleanEnvironment: true,
        stages: Object.fromEntries(
          ["install", "configure", "authenticate", "tool", "artifact"].map(
            (stage) => [
              stage,
              {
                passed: false,
                receipt: f.pin(`${stage}.json`, {
                  error:
                    stage === "install"
                      ? "not available"
                      : "prerequisite failed",
                }),
              },
            ],
          ),
        ),
      },
    });
    delete f.manifest.protocol;
    delete f.manifest.ui;
    delete f.manifest.check;
    delete f.manifest.diff;
    const result = f.importCapture();
    expect(result.history.runs).toEqual([]);
    expect(result.observations[0]).toMatchObject({
      runId: null,
      cost: null,
      failureCause: "install",
    });
    expect(result.report.firstRun).toMatchObject({
      observed: 1,
      missing: 8,
      succeeded: 0,
    });
    f.manifest.invocation = f.pin("invocation.json", { taskId: sample.taskId });
    expect(f.importCapture).toThrow(/early stop/);
    delete f.manifest.invocation;
    delete f.manifest.firstRun.stages.configure.receipt;
    expect(f.importCapture).toThrow();
  });
  it("binds a completed CLI first-install to its own invocation, stdout, exit and full diff", () => {
    const f = completedCliFirstRunFixture();
    const { invocation } = f;
    const result = f.importCapture();
    expect(result.report.firstRun).toMatchObject({
      observed: 1,
      missing: 8,
      succeeded: 1,
    });
    expect(result.report.task.observed).toBe(0);
    expect(result.installationVerified).toBe(false);
    expect(result.history.runs[0].results[0].totalCostUsd).toBe(0.1);
    expect(result.observations[0].cost).toBe(
      0.1 + f.authentication.totalCostUsd,
    );
    expect(result.observations[0].firstRun.costAccounting).toMatchObject({
      toolCostUsd: 0.1,
      authentication: {
        usage: f.authentication.usage,
        totalCostUsd: f.authentication.totalCostUsd,
      },
    });
    invocation.prompt = "different first-install task";
    f.manifest.invocation = f.pin("invocation.json", invocation);
    expect(f.importCapture).toThrow(/invocation/);
  });

  it.each(["legacy", "missing-auth-usage", "missing-tool-cost"])(
    "keeps the whole first-run cost unknown with %s",
    (kind) => {
      const f = completedCliFirstRunFixture();
      if (kind === "legacy")
        f.manifest.firstRun.stages.authenticate.receipt = f.pin(
          "authenticate.json",
          { connected: true },
        );
      if (kind === "missing-auth-usage")
        f.manifest.firstRun.stages.authenticate.receipt = f.pin(
          "authenticate.json",
          { ...f.authentication, usage: null, totalCostUsd: null },
        );
      if (kind === "missing-tool-cost") {
        const events = f.artifacts
          .get("stream.jsonl")
          .toString("utf8")
          .split("\n")
          .map(JSON.parse);
        delete events.at(-1).total_cost_usd;
        const bytes = Buffer.from(events.map(JSON.stringify).join("\n"));
        f.artifacts.set("stream.jsonl", bytes);
        f.manifest.stream.digest = evalDigest(bytes);
      }
      const result = f.importCapture();
      expect(result.observations[0].cost).toBeNull();
      expect(result.report.firstRun).toMatchObject({
        observed: 1,
        succeeded: 0,
        totalCost: null,
      });
      if (kind !== "missing-tool-cost")
        expect(result.history.runs[0].results[0].totalCostUsd).toBe(0.1);
    },
  );

  it.each([
    [
      "wrong provider",
      (receipt) => {
        receipt.provider = "openai";
      },
    ],
    [
      "wrong model",
      (receipt) => {
        receipt.model = "other";
      },
    ],
    [
      "invented free call",
      (receipt) => {
        receipt.totalCostUsd = 0;
      },
    ],
    [
      "invalid tokens",
      (receipt) => {
        receipt.usage.input_tokens = -1;
      },
    ],
    [
      "failed prerequisite",
      (receipt) => {
        receipt.ok = false;
      },
    ],
    [
      "billing claim",
      (receipt) => {
        receipt.billingVerified = true;
      },
    ],
  ])("rejects authentication %s", (_name, mutate) => {
    const f = completedCliFirstRunFixture();
    mutate(f.authentication);
    f.manifest.firstRun.stages.authenticate.receipt = f.pin(
      "authenticate.json",
      f.authentication,
    );
    expect(f.importCapture).toThrow(/authentication/);
  });

  it.each(["omitted-auth", "double-counted", "wrong-receipt"])(
    "rejects %s journey cost at collection",
    (kind) => {
      const f = completedCliFirstRunFixture();
      const result = f.importCapture();
      const observation = result.observations[0];
      if (kind === "omitted-auth") observation.cost = 0.1;
      if (kind === "double-counted")
        observation.cost += f.authentication.totalCostUsd;
      if (kind === "wrong-receipt")
        observation.firstRun.costAccounting.authenticationReceipt = `sha256:${"f".repeat(64)}`;
      expect(() =>
        validateVerify01Collection(f.bundle, f.preparation, {
          sampleIds: [f.manifest.sampleId],
          history: result.history,
          observations: result.observations,
          sourceCommit: f.manifest.sourceCommit,
          now: Date.parse(f.bundle.plan.window.end) + 1000,
        }),
      ).toThrow(/journey cost/);
    },
  );

  it("accounts for a billed authentication failure without inventing a task run", () => {
    const f = completedCliFirstRunFixture();
    f.authentication.ok = false;
    for (const stage of ["authenticate", "tool", "artifact"])
      f.manifest.firstRun.stages[stage].passed = false;
    f.manifest.firstRun.stages.authenticate.receipt = f.pin(
      "authenticate.json",
      f.authentication,
    );
    f.manifest.cost = null;
    f.manifest.failureCause = "model-protocol";
    for (const field of ["stream", "exit", "invocation", "check", "diff"])
      delete f.manifest[field];
    const result = f.importCapture();
    expect(result.history.runs).toEqual([]);
    expect(result.observations[0]).toMatchObject({
      runId: null,
      cost: null,
    });
    expect(
      result.observations[0].firstRun.costAccounting.toolCostUsd,
    ).toBeNull();
    expect(
      result.observations[0].firstRun.costAccounting.authentication
        .totalCostUsd,
    ).toBe(f.authentication.totalCostUsd);
    expect(result.report.firstRun.succeeded).toBe(0);
  });

  it("does not treat a failed tool stage as an unbilled skipped call", () => {
    const f = completedCliFirstRunFixture();
    for (const stage of ["tool", "artifact"])
      f.manifest.firstRun.stages[stage].passed = false;
    f.manifest.cost = null;
    f.manifest.failureCause = "model-protocol";
    for (const field of ["stream", "exit", "invocation", "check", "diff"])
      delete f.manifest[field];
    const result = f.importCapture();
    expect(result.observations[0].cost).toBeNull();
    expect(result.observations[0].firstRun.costAccounting).toMatchObject({
      toolCostUsd: null,
      totalCostUsd: null,
      authentication: { totalCostUsd: f.authentication.totalCostUsd },
    });
    f.manifest.cost = f.authentication.totalCostUsd;
    expect(f.importCapture).toThrow(/early-stop cost/);
  });
});
