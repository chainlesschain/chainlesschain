import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { agentLoop, runAgentHeadless } from "../helpers/test-model-egress.js";
import { webFetch } from "../../src/lib/web-fetch.js";
import broker from "../../src/lib/process-execution-broker/index.js";
import { TaskProgressTracker } from "../../src/lib/task-progress-tracker.js";
import { IterationBudget } from "../../src/lib/iteration-budget.js";
import { messagesToContextItems } from "../../src/lib/context-memory-kernel/message-adapter.js";
import {
  mockToolCallMessage,
  mockTextMessage,
} from "../../src/harness/mock-llm-provider.js";

vi.mock("../../src/lib/web-fetch.js", () => ({ webFetch: vi.fn() }));
vi.mock("../../src/lib/project-detector.js", () => ({
  findProjectRoot: vi.fn(() => null),
  loadProjectConfig: vi.fn(() => null),
  isInsideProject: vi.fn(() => false),
}));

const url = "https://github.com/owner/repo/actions/runs/123/job/456";
const command = "gh run view 123 --job 456 --log --repo owner/repo";
const tool = (name, args, id) => ({
  message: mockToolCallMessage(name, args, `call-${id}`),
});
const done = () => ({ message: mockTextMessage("Finished the local change") });

function mockGhInspections(
  render = (count) =>
    `Observation ${count}: failed unit check; local checkout unavailable`,
) {
  let executions = 0;
  const inspect = () => render(++executions);
  const originalExec = broker.execSync;
  const originalSpawn = broker.spawnSync;
  vi.spyOn(broker, "execSync").mockImplementation(function (command, ...args) {
    return command.includes("gh ")
      ? inspect()
      : originalExec.call(this, command, ...args);
  });
  vi.spyOn(broker, "spawnSync").mockImplementation(
    function (file, args, options) {
      return args.some((value) => value.includes("gh "))
        ? { status: 0, stdout: inspect(), stderr: "" }
        : originalSpawn.call(this, file, args, options);
    },
  );
  return () => executions;
}

async function drain(iterator, events = []) {
  for await (const event of iterator) events.push(event);
  return events;
}

describe("remote read recovery in the agent runtime", () => {
  let cwd;
  let base;
  beforeEach(() => {
    cwd = mkdtempSync(join(tmpdir(), "cc-remote-loop-"));
    webFetch.mockReset().mockResolvedValue({
      error: "web_fetch failed: HTTP 403",
      statusCode: 403,
    });
    base = {
      cwd,
      contextMemorySkipPlanning: true,
      autoMicroCompact: false,
      approvalGate: {
        decide: async () => ({
          decision: "allow",
          via: "test-policy",
          policy: "autopilot",
        }),
      },
      _autoCompactor: {
        shouldAutoCompact: (messages) => messages.length > 4,
        compress: async (messages) => ({
          messages: [messages[0]],
          stats: {
            originalMessages: messages.length,
            compressedMessages: 1,
            saved: 1,
          },
        }),
      },
    };
  });
  afterEach(() => {
    vi.restoreAllMocks();
    rmSync(cwd, { recursive: true, force: true });
  });

  it.each([
    [false, false],
    [true, false],
    [false, true],
    [true, true],
  ])(
    "protects the exact task and finite-budget guidance in the canonical planner (host policy: %s, hook suffix: %s)",
    async (withHostPolicy, withHookSuffix) => {
      const task =
        "Add regression tests for request-price boundaries and validate them";
      const policy = "Host policy: preserve the requested deliverable";
      const messages = [
        ...(withHostPolicy ? [{ role: "system", content: policy }] : []),
        { role: "user", content: task },
      ];
      const chatFn = vi.fn(async (context) => {
        expect(context.findLast((message) => message.role === "user")).toEqual({
          role: "user",
          content: task,
        });
        if (withHookSuffix)
          expect(context.at(-1).content).toBe(
            "Goal progress: deliver the requested tests",
          );
        else expect(context.at(-1)).toEqual({ role: "user", content: task });
        expect(
          context.filter((message) =>
            message.content?.startsWith("Execution budget:"),
          ),
        ).toHaveLength(1);
        expect(JSON.stringify(context)).toContain(
          "this request plus 0 further model requests",
        );
        if (withHostPolicy)
          expect(context[0]).toEqual({ role: "system", content: policy });
        return done();
      });
      const events = await drain(
        agentLoop(messages, {
          ...base,
          contextMemorySkipPlanning: false,
          contextMemoryEnv: {
            CHAINLESSCHAIN_CONTEXT_MEMORY_CLI_STAGE: "canonical_default",
          },
          contextMemoryFilePath: join(cwd, "planner-memory.jsonl"),
          contextMemoryModelWindowTokens: 32768,
          iterationBudget: IterationBudget.forRun({ maxTurns: 1 }),
          ...(withHookSuffix
            ? {
                prepareCall: async () => ({
                  systemSuffix: "Goal progress: deliver the requested tests",
                }),
              }
            : {}),
          chatFn,
        }),
      );
      const plan = events.find(
        (event) => event.type === "context.plan.created",
      )?.plan;
      expect(plan).toBeTruthy();
      const taskItem = plan.selected.find((item) =>
        JSON.parse(item.content).messages?.some(
          (message) => message.content === task,
        ),
      );
      expect(taskItem).toMatchObject({
        kind: "task-state",
        binding: { requiredForRecovery: true },
      });
      const policies = plan.selected.filter(
        (item) => item.kind === "system-policy",
      );
      expect(policies).toHaveLength(
        1 + Number(withHostPolicy) + Number(withHookSuffix),
      );
      expect(policies.every((item) => item.trust === "host")).toBe(true);
      expect(chatFn).toHaveBeenCalledTimes(1);
      expect(
        messages.some((message) =>
          message.content?.startsWith("Execution budget:"),
        ),
      ).toBe(false);
    },
  );

  it.each([
    [false, false],
    [true, false],
    [false, true],
    [true, true],
  ])(
    "rejects a canonical context that cannot fit the protected task before dispatch (host policy: %s, hook suffix: %s)",
    async (withHostPolicy, withHookSuffix) => {
      const chatFn = vi.fn(async () => done());
      await expect(
        drain(
          agentLoop(
            [
              ...(withHostPolicy
                ? [{ role: "system", content: "Host policy" }]
                : []),
              {
                role: "user",
                content: "requested regression detail ".repeat(1024),
              },
            ],
            {
              ...base,
              contextMemorySkipPlanning: false,
              contextMemoryEnv: {
                CHAINLESSCHAIN_CONTEXT_MEMORY_CLI_STAGE: "canonical_default",
              },
              contextMemoryFilePath: join(cwd, "planner-memory.jsonl"),
              contextMemoryModelWindowTokens: 1024,
              maxOutputTokens: 256,
              iterationBudget: IterationBudget.forRun({ maxTurns: 1 }),
              ...(withHookSuffix
                ? {
                    prepareCall: async () => ({
                      systemSuffix:
                        "Goal progress: deliver the requested tests",
                    }),
                  }
                : {}),
              chatFn,
            },
          ),
        ),
      ).rejects.toMatchObject({ code: "context_over_budget" });
      expect(chatFn).not.toHaveBeenCalled();
    },
  );

  it.each(["zero", "infinity"])(
    "omits finite-budget guidance for an unlimited budget (%s)",
    async (mode) => {
      const chatFn = vi.fn(async (messages) => {
        expect(JSON.stringify(messages)).not.toContain("Execution budget:");
        return done();
      });
      await drain(
        agentLoop([{ role: "user", content: "Summarize the evidence" }], {
          ...base,
          iterationBudget:
            mode === "zero"
              ? IterationBudget.forRun({ maxTurns: 0 })
              : new IterationBudget({ limit: Infinity }),
          chatFn,
        }),
      );
      expect(chatFn).toHaveBeenCalledTimes(1);
    },
  );

  it.each(["assistant", "complete-tool", "pending-tool"])(
    "does not promote an old user request past a newer %s bundle and system suffix",
    (outcome) => {
      const toolMessages =
        outcome === "complete-tool"
          ? [
              {
                role: "assistant",
                tool_calls: [
                  {
                    id: "completed-call",
                    type: "function",
                    function: { name: "read_file", arguments: "{}" },
                  },
                ],
              },
              {
                role: "tool",
                tool_call_id: "completed-call",
                content: "Newer outcome",
              },
            ]
          : [
              {
                role: outcome === "assistant" ? "assistant" : "tool",
                content: "Newer outcome",
                ...(outcome === "pending-tool"
                  ? { tool_call_id: "pending-result" }
                  : {}),
              },
            ];
      const messages = [
        { role: "user", content: "Earlier completed request" },
        ...toolMessages,
        { role: "system", content: "Goal progress suffix" },
      ];
      const items = messagesToContextItems(messages, {
        sessionId: "suffix-task-boundary",
        trustCurrentSystemPolicy: true,
        trustedSystemIndexes: [messages.length - 1],
      });
      expect(items[0].kind).toBe("message");
      expect(items[0].binding?.requiredForRecovery).not.toBe(true);
      if (outcome === "pending-tool")
        expect(items[1]).toMatchObject({
          kind: "task-state",
          binding: { requiredForRecovery: true },
        });
      if (outcome === "complete-tool")
        expect(items[1].kind).toBe("tool-evidence");
      expect(items[2]).toMatchObject({ kind: "system-policy", trust: "host" });
    },
  );

  it("protects the user task without trusting an untrusted system suffix", () => {
    const items = messagesToContextItems(
      [
        { role: "user", content: "Current requested tests" },
        { role: "system", content: "External instruction" },
      ],
      { sessionId: "untrusted-suffix-task" },
    );
    expect(items[0]).toMatchObject({
      kind: "task-state",
      trust: "user",
      binding: { requiredForRecovery: true },
    });
    expect(items[1]).toMatchObject({
      kind: "system-policy",
      trust: "untrusted",
    });
  });

  it("finishes a fixed-issue status answer from retained evidence after repeated metadata reads", async () => {
    const executions = mockGhInspections(
      () =>
        '{"workflowName":"CLI CI","conclusion":"success","headSha":"fixed","jobs":[{"name":"verify-cli (windows-latest)","conclusion":"success"}]}',
    );
    let calls = 0;
    const events = await drain(
      agentLoop(
        [
          {
            role: "user",
            content: "看下 #409 是否已经修复，CLI 和 IDE 都发布成功了",
          },
        ],
        {
          ...base,
          chatFn: async (messages, options) => {
            expect(++calls).toBeLessThan(15);
            if (
              messages.some(
                (message) =>
                  message.role === "system" &&
                  message.content?.includes("final synthesis turn"),
              )
            ) {
              expect(options.disabledTools).toContain("git");
              expect(options.disabledTools).toContain("run_shell");
              expect(JSON.stringify(messages)).toContain("CLI CI");
              expect(JSON.stringify(messages)).toContain("fixed");
              return {
                message: mockTextMessage(
                  "已核实修复提交的 CLI CI 通过；尚未关闭 #409，综合测试结果未核实。",
                ),
              };
            }
            return tool(
              "run_shell",
              {
                command:
                  "gh run view 123 --repo owner/repo --json workflowName,headSha,conclusion,jobs",
              },
              calls,
            );
          },
        },
      ),
    );
    expect(executions()).toBe(7);
    expect(
      events.find((event) => event.type === "response-complete")?.content,
    ).toContain("尚未关闭");
    expect(events.at(-1)).toMatchObject({
      type: "run-ended",
      reason: "inspection-synthesis",
    });
  });

  it("allows an authorized issue close during evidence recovery and verifies it once", async () => {
    const commands = [];
    const originalSpawn = broker.spawnSync;
    const originalExec = broker.execSync;
    const run = (command) => {
      commands.push(command);
      return command.includes("issue close")
        ? "Closed issue #409"
        : command.includes("issue view")
          ? '{"state":"CLOSED"}'
          : '{"workflowName":"CLI CI","conclusion":"success"}';
    };
    vi.spyOn(broker, "execSync").mockImplementation(function (
      command,
      ...args
    ) {
      return command.startsWith("gh ")
        ? run(command)
        : originalExec.call(this, command, ...args);
    });
    vi.spyOn(broker, "spawnSync").mockImplementation(
      function (file, args, options) {
        const command = args.find((arg) => arg.startsWith("gh "));
        return command
          ? { status: 0, stdout: run(command), stderr: "" }
          : originalSpawn.call(this, file, args, options);
      },
    );
    let calls = 0;
    const events = await drain(
      agentLoop([{ role: "user", content: "确认修复后关闭 issue #409" }], {
        ...base,
        chatFn: async (messages, options) => {
          ++calls;
          if (calls <= 4)
            return tool(
              "run_shell",
              { command: "gh run view 123 --json workflowName,conclusion" },
              calls,
            );
          if (calls === 5) {
            expect(JSON.stringify(messages)).toContain(
              "Evidence inspection recovery",
            );
            expect(options.disabledTools || []).not.toContain("run_shell");
            return tool(
              "run_shell",
              { command: "gh issue close 409 --repo owner/repo" },
              calls,
            );
          }
          if (calls === 6)
            return tool(
              "run_shell",
              { command: "gh issue view 409 --repo owner/repo --json state" },
              calls,
            );
          expect(calls).toBe(7);
          return { message: mockTextMessage("Issue #409 已关闭。") };
        },
      }),
    );
    expect(
      commands.filter((command) => command.includes("issue close")),
    ).toHaveLength(1);
    expect(
      commands.filter((command) => command.includes("issue view")),
    ).toHaveLength(1);
    expect(
      events.find((event) => event.type === "response-complete")?.content,
    ).toContain("已关闭");
  });

  it("does not execute a provider's extra tool call after the final evidence synthesis request", async () => {
    const executions = mockGhInspections(
      () => '{"jobs":[{"conclusion":"success"}]}',
    );
    let calls = 0;
    const events = [];
    await expect(
      drain(
        agentLoop(
          [{ role: "user", content: "Verify whether the issue is fixed" }],
          {
            ...base,
            chatFn: async () => {
              expect(++calls).toBeLessThan(15);
              return tool(
                "run_shell",
                { command: "gh run view 123 --json jobs" },
                calls,
              );
            },
          },
        ),
        events,
      ),
    ).rejects.toMatchObject({ code: "CC_AGENT_INSPECTION_STALLED" });
    expect(executions()).toBe(7);
    expect(events.some((event) => event.type === "response-complete")).toBe(
      false,
    );
  });

  it("recovers a mixed issue/PR/CI investigation through compaction, edits and runs a real verification", async () => {
    writeFileSync(
      join(cwd, "retry-policy.cjs"),
      "module.exports = (primary, retry) => retry;\n",
    );
    const executions = mockGhInspections((count) =>
      count === 1
        ? "Error: spawn denied\nPASS deliberate spawn failure test\nUnit tests PASSED\nFAIL retry-policy.test.js > preserves primary result\nAssertionError: expected false, received true\nIntegration tests FAILED"
        : `Observation ${count}: PR merged; diagnostic retry passed`,
    );
    const tracker = new TaskProgressTracker();
    const inspections = [
      "gh issue view 390 --repo owner/repo --json number,title,state,body",
      "gh api repos/owner/repo/issues/390/comments",
      "gh pr view 389 --repo owner/repo --json number,title,state,mergedAt",
      "gh run view 123 --repo owner/repo --json jobs",
      "gh run download 123 --repo owner/repo -D artifacts_123",
      "gh api repos/owner/repo/issues/390/timeline",
    ];
    let calls = 0;
    const events = await drain(
      agentLoop(
        [
          {
            role: "user",
            content:
              "Fix the primary test failure reported in https://github.com/owner/repo/issues/390",
          },
        ],
        {
          ...base,
          taskProgressTracker: tracker,
          chatFn: async (messages, options) => {
            expect(++calls).toBeLessThanOrEqual(28);
            if (calls === 1)
              return tool(
                "run_shell",
                {
                  command:
                    "gh run view 123 --job 456 --log-failed --repo owner/repo",
                },
                calls,
              );
            if (calls === 2)
              return tool("read_file", { path: "retry-policy.cjs" }, calls);
            if (calls <= 24)
              return tool(
                "run_shell",
                { command: inspections[(calls - 3) % inspections.length] },
                calls,
              );
            if (calls <= 26) {
              expect(tracker.intervention.recovery).toBe(true);
              expect(options.disabledTools).toContain("list_dir");
              expect(options.disabledTools).not.toContain("edit_file");
              expect(options.disabledTools).not.toContain("run_shell");
              const context = JSON.stringify(messages);
              expect(context).toContain("FAIL retry-policy.test.js");
              expect(context).toContain("Unit tests PASSED");
              expect(context).toContain("Integration tests FAILED");
              if (calls === 25)
                return tool(
                  "run_shell",
                  {
                    command: "gh issue view 390 --repo owner/repo --json body",
                  },
                  calls,
                );
              return tool(
                "edit_file",
                {
                  path: "retry-policy.cjs",
                  old_string: "=> retry;",
                  new_string: "=> primary;",
                },
                calls,
              );
            }
            if (calls === 27) {
              expect(tracker.intervention).toBeNull();
              return tool(
                "run_shell",
                {
                  command:
                    "node -e \"const assert = require('node:assert/strict'); const verdict = require('./retry-policy.cjs'); assert.equal(verdict(false, true), false); assert.equal(verdict(true, false), true); console.log('regression verified');\"",
                },
                calls,
              );
            }
            return done();
          },
        },
      ),
    );
    expect(executions()).toBe(24);
    expect(
      events.filter((event) => event.type === "compaction").length,
    ).toBeGreaterThan(3);
    const verification = events
      .filter(
        (event) => event.type === "tool-result" && event.tool === "run_shell",
      )
      .at(-1);
    expect(verification.result.error).toBeFalsy();
    expect(verification.result.stdout).toContain("regression verified");
    expect(readFileSync(join(cwd, "retry-policy.cjs"), "utf8")).toContain(
      "=> primary;",
    );
    expect(events.at(-1)).toMatchObject({
      type: "run-ended",
      reason: "complete",
    });
  });

  it.each([false, true])(
    "bounds changing PR API/web inspections with one final synthesis (ignores exit=%s)",
    async (ignoresExit) => {
      const executions = mockGhInspections();
      webFetch.mockImplementation(async (url) => ({
        content: `Evidence from ${url}`,
      }));
      let calls = 0;
      const events = [];
      const run = drain(
        agentLoop(
          [
            {
              role: "user",
              content: "处理下这个pr https://github.com/owner/repo/pull/343",
            },
          ],
          {
            ...base,
            chatFn: async (messages, options) => {
              expect(++calls).toBeLessThanOrEqual(37);
              if (calls === 37) {
                expect(options.disabledTools).toContain("run_shell");
                expect(JSON.stringify(messages)).toContain(
                  "final synthesis turn",
                );
                expect(JSON.stringify(messages)).toContain(
                  "local checkout unavailable",
                );
                return ignoresExit
                  ? tool(
                      "run_shell",
                      {
                        command:
                          "gh api repos/owner/repo/compare/main...branch",
                      },
                      calls,
                    )
                  : {
                      message: mockTextMessage(
                        "The unit check failed; no local checkout is available. No PR was closed or merged.",
                      ),
                    };
              }
              if (calls % 3 === 1)
                return tool(
                  "web_fetch",
                  {
                    url: `https://github.com/owner/repo/pull/343/checks?view=${calls}`,
                  },
                  calls,
                );
              return tool(
                "run_shell",
                {
                  command:
                    calls % 3 === 2
                      ? "gh pr view 343 --repo owner/repo --json state,statusCheckRollup"
                      : "gh api repos/owner/repo/compare/main...branch",
                },
                calls,
              );
            },
          },
        ),
        events,
      );
      if (ignoresExit)
        await expect(run).rejects.toMatchObject({
          code: "CC_AGENT_PR_INVESTIGATION_STALLED",
        });
      else {
        await run;
        expect(events.at(-1)).toMatchObject({
          type: "run-ended",
          reason: "pr-investigation-stalled",
        });
        expect(
          events.find((event) => event.type === "response-complete").content,
        ).toContain("without completing");
      }
      expect(calls).toBe(37);
      expect(executions()).toBe(24);
      expect(webFetch).toHaveBeenCalledTimes(8);
      expect(
        events.filter(
          (event) => event.result?.code === "CC_TOOL_RECOVERY_PAUSED",
        ),
      ).toHaveLength(4);
      expect(events.some((event) => event.type === "compaction")).toBe(true);
    },
  );

  it("enforces paused reads in a parallel batch and still allows a justified edit", async () => {
    const tracker = new TaskProgressTracker();
    for (let i = 0; i < 24; i++)
      tracker.record("search_files", { matches: [] });
    writeFileSync(join(cwd, "fix.js"), "export const fixed = false;");
    let calls = 0;
    const events = await drain(
      agentLoop([{ role: "user", content: "Fix PR 343 in fix.js" }], {
        ...base,
        taskProgressTracker: tracker,
        chatFn: async (_messages, options) => {
          expect(++calls).toBeLessThanOrEqual(3);
          if (calls === 1)
            return {
              message: {
                role: "assistant",
                tool_calls: [1, 2].map(
                  (id) =>
                    mockToolCallMessage(
                      "read_file",
                      { path: "fix.js" },
                      `read-${id}`,
                    ).tool_calls[0],
                ),
              },
            };
          if (calls === 2)
            return tool(
              "write_file",
              { path: "fix.js", content: "export const fixed = true;" },
              calls,
            );
          expect(options.disabledTools || []).not.toContain("read_file");
          return done();
        },
      }),
    );
    expect(
      events.filter(
        (event) => event.result?.code === "CC_TOOL_RECOVERY_PAUSED",
      ),
    ).toHaveLength(2);
    expect(
      events.some(
        (event) =>
          event.type === "tool-executing" && event.tool === "read_file",
      ),
    ).toBe(false);
    expect(readFileSync(join(cwd, "fix.js"), "utf8")).toContain("fixed = true");
  });

  it.each(["json", "stream-json"])(
    "preserves paused-read IDs and fresh dispatch guidance through compaction (%s)",
    async (outputFormat) => {
      const tracker = new TaskProgressTracker();
      for (let i = 0; i < 24; i++)
        tracker.record("search_files", { matches: [] });
      writeFileSync(join(cwd, "fix.js"), "export const fixed = false;");
      const out = [];
      let calls = 0;
      let compactions = 0;
      const chatFn = async (messages) => {
        calls++;
        const guidance = messages.filter(
          (message) =>
            message.role === "system" &&
            message.content?.startsWith("Execution budget:"),
        );
        expect(guidance).toHaveLength(1);
        expect(guidance[0].content).toContain(
          `this request plus ${4 - calls} further model requests`,
        );
        expect(guidance[0].content).not.toContain("Returning work summary");
        if (calls < 4)
          expect(
            messages.some(
              (message) =>
                message.role === "system" &&
                message.content?.includes(
                  "actual test changes and focused validation remain required",
                ),
            ),
          ).toBe(true);
        if (calls === 1)
          return tool(
            "read_file",
            { path: "fix.js", offset: 1, limit: 40 },
            "read-ok",
          );
        if (calls === 2)
          return {
            message: {
              role: "assistant",
              tool_calls: ["paused-1", "paused-2"].map(
                (id) =>
                  mockToolCallMessage("read_file", { path: "fix.js" }, id)
                    .tool_calls[0],
              ),
            },
          };
        if (calls === 3) {
          expect(readFileSync(join(cwd, "fix.js"), "utf8")).toContain(
            "fixed = false",
          );
          return tool(
            "write_file",
            { path: "fix.js", content: "export const fixed = true;" },
            "write-ok",
          );
        }
        return done();
      };
      const outcome = await runAgentHeadless(
        {
          prompt: "Add the requested regression tests and validate the change",
          cwd,
          outputFormat,
          ephemeral: true,
          maxTurns: 4,
        },
        {
          bootstrap: async () => ({ db: null }),
          getApprovalGate: async () => base.approvalGate,
          writeOut: (text) => out.push(text),
          writeErr: () => {},
          agentLoop: (messages, options) =>
            agentLoop(messages, {
              ...options,
              ...base,
              taskProgressTracker: tracker,
              chatFn,
              onCompaction: () => {
                compactions++;
              },
            }),
        },
      );
      expect(outcome.exitCode).toBe(0);
      expect(calls).toBe(4);
      expect(compactions).toBeGreaterThan(0);
      expect(readFileSync(join(cwd, "fix.js"), "utf8")).toContain(
        "fixed = true",
      );
      if (outputFormat === "stream-json") {
        const events = out.join("").trim().split("\n").map(JSON.parse);
        expect(
          events
            .filter((event) => event.type === "tool_use")
            .map((event) => event.id),
        ).toEqual(["call-read-ok", "call-write-ok"]);
        const results = events.filter((event) => event.type === "tool_result");
        expect(results.map((event) => event.id)).toEqual([
          "call-read-ok",
          "paused-1",
          "paused-2",
          "call-write-ok",
        ]);
        expect(results[0].is_error).toBe(false);
        expect(results[3].is_error).toBe(false);
        for (const paused of results.slice(1, 3))
          expect(paused).toMatchObject({
            execution_started: false,
            is_error: true,
            result: { code: "CC_TOOL_RECOVERY_PAUSED" },
          });
      } else {
        const result = JSON.parse(out.join(""));
        expect(result.tool_calls.map((call) => call.id)).toEqual([
          "call-read-ok",
          "call-write-ok",
        ]);
        expect(result.tool_calls.every((call) => call.is_error === false)).toBe(
          true,
        );
      }
    },
  );

  it("does not cut off explicitly requested status monitoring", async () => {
    const executions = mockGhInspections();
    let calls = 0;
    const events = await drain(
      agentLoop(
        [{ role: "user", content: "Monitor PR 343 until checks finish" }],
        {
          ...base,
          chatFn: async () =>
            ++calls <= 40
              ? tool(
                  "run_shell",
                  { command: "gh pr checks 343 --repo owner/repo" },
                  calls,
                )
              : {
                  message: mockTextMessage(
                    "Checks finished with a failed unit check.",
                  ),
                },
        },
      ),
    );
    expect(executions()).toBe(40);
    expect(events.at(-1)).toMatchObject({
      type: "run-ended",
      reason: "complete",
    });
  });

  it("keeps recovery through web/file/status switching and command failures until a real change", async () => {
    for (let i = 0; i < 8; i++)
      writeFileSync(join(cwd, `part-${i}.js`), `export const part = ${i};`);
    webFetch.mockResolvedValue({ content: "Sign in to view detailed logs" });
    let inspections = 0;
    const inspect = (command) => {
      if (command.includes("--log")) {
        const error = new Error("Logs unavailable for cancelled job");
        error.status = 1;
        error.stderr = "Logs unavailable for cancelled job";
        throw error;
      }
      return `Run ${++inspections}: matrix jobs cancelled`;
    };
    const originalExec = broker.execSync;
    const originalSpawn = broker.spawnSync;
    vi.spyOn(broker, "execSync").mockImplementation(function (value, ...args) {
      if (value.includes("gh run view")) return inspect(value);
      return originalExec.call(this, value, ...args);
    });
    vi.spyOn(broker, "spawnSync").mockImplementation(
      function (file, args, options) {
        const command = args.find((value) => value.includes("gh run view"));
        if (!command) return originalSpawn.call(this, file, args, options);
        try {
          return { status: 0, stdout: inspect(command), stderr: "" };
        } catch (error) {
          return { status: 1, stdout: "", stderr: error.stderr };
        }
      },
    );
    let calls = 0;
    const events = await drain(
      agentLoop(
        [{ role: "user", content: "Fix the CI failure in result.js" }],
        {
          ...base,
          chatFn: async (messages, options) => {
            expect(++calls).toBeLessThanOrEqual(30);
            if (calls <= 24) {
              const index = Math.floor((calls - 1) / 3);
              if (calls % 3 === 1)
                return tool("read_file", { path: `part-${index}.js` }, calls);
              if (calls % 3 === 2)
                return tool("web_fetch", { url: `${url}${index}` }, calls);
              return tool(
                "run_shell",
                {
                  command: "gh run view 123 --repo owner/repo",
                },
                calls,
              );
            }
            if (calls <= 28) {
              expect(JSON.stringify(messages)).toContain(
                "matrix jobs cancelled",
              );
              if (calls >= 27)
                expect(JSON.stringify(messages)).toContain(
                  "Logs unavailable for cancelled job",
                );
              expect(options.disabledTools).toEqual(
                expect.arrayContaining([
                  "list_dir",
                  "web_fetch",
                  "web_search",
                  "todo_write",
                  "spawn_sub_agent",
                  "tool_search",
                ]),
              );
              for (const name of [
                "read_file",
                "search_files",
                "write_file",
                "edit_file",
                "run_shell",
              ])
                expect(options.disabledTools).not.toContain(name);
              expect(
                messages.some(
                  (message) =>
                    message.role === "system" &&
                    message.content.includes("Recovery remains active"),
                ),
              ).toBe(true);
              if (calls === 25)
                return tool(
                  "read_file",
                  { path: "part-0.js", offset: 1, limit: 1 },
                  calls,
                );
              if (calls === 26) return tool("run_shell", { command }, calls);
              if (calls === 27)
                return tool(
                  "run_shell",
                  {
                    command: "gh run view 123 --repo owner/repo --json jobs",
                  },
                  calls,
                );
              return tool(
                "write_file",
                {
                  path: "result.js",
                  content: "export const fixed = true;",
                },
                calls,
              );
            }
            expect(options.disabledTools || []).not.toContain("read_file");
            expect(options.disabledTools || []).not.toContain("web_fetch");
            if (calls === 29)
              return tool("read_file", { path: "result.js" }, calls);
            return done();
          },
        },
      ),
    );
    expect(inspections).toBe(9);
    expect(events.some((event) => event.type === "compaction")).toBe(true);
    expect(
      events.filter(
        (event) =>
          event.type === "iteration-warning" &&
          event.message.startsWith("Task progress:"),
      ),
    ).toHaveLength(2);
    expect(
      events.find(
        (event) =>
          event.type === "tool-result" &&
          event.tool === "run_shell" &&
          event.result.error,
      ),
    ).toBeTruthy();
    expect(
      events
        .filter(
          (event) => event.type === "tool-result" && event.tool === "read_file",
        )
        .at(-1).result.content,
    ).toContain("fixed = true");
    expect(readFileSync(join(cwd, "result.js"), "utf8")).toBe(
      "export const fixed = true;",
    );
  });

  it("stops failed downloads despite planning and repeated history compaction", async () => {
    let calls = 0;
    const events = [];
    await expect(
      drain(
        agentLoop([{ role: "user", content: "Fix the CI failure" }], {
          ...base,
          chatFn: async () => {
            expect(++calls).toBeLessThan(15);
            return calls % 2
              ? tool("web_fetch", { url }, calls)
              : tool(
                  "todo_write",
                  {
                    todos: [
                      { content: "Inspect failures", status: "in_progress" },
                    ],
                  },
                  calls,
                );
          },
        }),
        events,
      ),
    ).rejects.toMatchObject({ code: "CC_AGENT_REPEATED_REMOTE_READ" });
    expect(calls).toBe(11);
    expect(webFetch).toHaveBeenCalledTimes(6);
    expect(events.some((event) => event.type === "compaction")).toBe(true);
    expect(
      events.some(
        (event) =>
          event.type === "iteration-warning" &&
          event.message.includes("Repeated web/log"),
      ),
    ).toBe(true);
  });

  it("retains the original failure evidence and resumes a real local change", async () => {
    webFetch.mockResolvedValueOnce({
      content: "FAIL src/fix.js: expected normalized path",
    });
    let calls = 0;
    await drain(
      agentLoop([{ role: "user", content: "Fix the CI failure" }], {
        ...base,
        chatFn: async (messages, options) => {
          calls++;
          if (calls <= 4) return tool("web_fetch", { url }, calls);
          if (calls === 5) {
            expect(options.disabledTools).toContain("web_fetch");
            expect(options.disabledTools).not.toContain("read_file");
            expect(JSON.stringify(messages)).toContain(
              "expected normalized path",
            );
            expect(
              messages.some(
                (message) =>
                  message.role === "system" &&
                  message.content.includes("Remote-read loop recovery"),
              ),
            ).toBe(true);
            expect(
              messages
                .filter((message) => message.role === "system")
                .some((message) =>
                  message.content.includes("expected normalized path"),
                ),
            ).toBe(false);
            return tool(
              "write_file",
              { path: "fix.js", content: "export const fixed = true;" },
              calls,
            );
          }
          expect(calls).toBe(6);
          expect(options.disabledTools || []).not.toContain("web_fetch");
          return done();
        },
      }),
    );
    expect(readFileSync(join(cwd, "fix.js"), "utf8")).toBe(
      "export const fixed = true;",
    );
    expect(webFetch).toHaveBeenCalledTimes(4);
  });

  it("detects actual run_shell stdout results without skipping any command execution", async () => {
    let executions = 0;
    const originalExec = broker.execSync;
    const originalSpawn = broker.spawnSync;
    vi.spyOn(broker, "execSync").mockImplementation(function (value, ...args) {
      if (value.includes("gh run view")) {
        executions++;
        return "FAIL macOS path assertion";
      }
      return originalExec.call(this, value, ...args);
    });
    vi.spyOn(broker, "spawnSync").mockImplementation(
      function (file, args, options) {
        if (args.some((value) => value.includes("gh run view"))) {
          executions++;
          return { status: 0, stdout: "FAIL macOS path assertion", stderr: "" };
        }
        return originalSpawn.call(this, file, args, options);
      },
    );
    let calls = 0;
    const results = [];
    await expect(
      drain(
        agentLoop([{ role: "user", content: "Fix the CI failure" }], {
          ...base,
          chatFn: async () => {
            expect(++calls).toBeLessThan(11);
            return tool(
              "run_shell",
              {
                command:
                  calls % 2
                    ? command
                    : command.replace("--log", "--log-failed"),
              },
              calls,
            );
          },
        }),
        results,
      ),
    ).rejects.toMatchObject({ code: "CC_AGENT_REPEATED_REMOTE_READ" });
    expect(calls).toBe(10);
    expect(executions).toBe(7);
    expect(
      results
        .filter((event) => event.type === "tool-result")
        .every(
          (event) =>
            event.result.stdout === "FAIL macOS path assertion" ||
            event.result.code === "CC_TOOL_RECOVERY_PAUSED",
        ),
    ).toBe(true);
  });

  it("offers recovery after a batch of repeated fetches and restores the tool next turn", async () => {
    let calls = 0;
    await drain(
      agentLoop([{ role: "user", content: "Investigate CI" }], {
        ...base,
        chatFn: async (_messages, options) => {
          calls++;
          if (calls === 1)
            return {
              message: {
                role: "assistant",
                tool_calls: Array.from(
                  { length: 3 },
                  (_, i) =>
                    mockToolCallMessage("web_fetch", { url }, `fetch-${i}`)
                      .tool_calls[0],
                ),
              },
            };
          if (calls === 2) {
            expect(options.disabledTools).toContain("web_fetch");
            return tool(
              "todo_write",
              {
                todos: [
                  {
                    content: "Review retained findings",
                    status: "in_progress",
                  },
                ],
              },
              calls,
            );
          }
          expect(calls).toBe(3);
          expect(options.disabledTools || []).not.toContain("web_fetch");
          return {
            message: mockTextMessage(
              "The log endpoint requires authentication; the task remains blocked.",
            ),
          };
        },
      }),
    );
    expect(webFetch).toHaveBeenCalledTimes(3);
  });

  it.each([true, false])(
    "bounds repeated four-PR batches across compaction and preserves every tool result (parallel=%s)",
    async (parallelReadOnlyTools) => {
      const numbers = [340, 339, 332, 331];
      webFetch.mockImplementation(async (url) => ({
        content: `PR ${url.split("/").at(-1)}: already inspected evidence`,
        snapshotId: url,
        offset: 0,
        hasMore: false,
      }));
      let calls = 0;
      const events = [];
      const messages = [
        {
          role: "user",
          content: "Review PRs; close only already-handled changes",
        },
      ];
      await expect(
        drain(
          agentLoop(messages, {
            ...base,
            parallelReadOnlyTools,
            chatFn: async (context, options) => {
              expect(++calls).toBeLessThan(11);
              if (calls > 1) {
                const retained = context.find((message) =>
                  message.content?.includes("[Remote read results retained"),
                );
                for (const number of numbers)
                  expect(retained.content).toContain(`PR ${number}`);
              }
              if (calls === 5) {
                expect(options.disabledTools).toContain("web_fetch");
                expect(JSON.stringify(context)).toContain(
                  "Compare the specific PR diff/commits",
                );
              }
              return {
                message: {
                  role: "assistant",
                  content: "Let me check each PR again",
                  tool_calls: numbers.map(
                    (number) =>
                      mockToolCallMessage(
                        "web_fetch",
                        {
                          url: `https://github.com/owner/repo/pull/${number}`,
                          maxChars: calls % 2 ? 5000 : 8000,
                        },
                        `pr-${calls}-${number}`,
                      ).tool_calls[0],
                  ),
                },
              };
            },
          }),
          events,
        ),
      ).rejects.toMatchObject({ code: "CC_AGENT_REPEATED_REMOTE_READ" });
      expect(calls).toBe(10);
      expect(webFetch).toHaveBeenCalledTimes(28);
      const results = events.filter((event) => event.type === "tool-result");
      expect(results).toHaveLength(40);
      expect(new Set(results.map((event) => event.tool_use_id)).size).toBe(40);
      expect(
        messages
          .filter((message) => message.role === "tool")
          .map((message) => message.tool_call_id),
      ).toEqual(results.slice(-4).map((event) => event.tool_use_id));
      expect(events.some((event) => event.type === "response-complete")).toBe(
        false,
      );
    },
  );

  it("carries authorized PR triage into a concrete API comparison after a missing local origin", async () => {
    const originalExec = broker.execSync;
    const originalSpawn = broker.spawnSync;
    const comparison = "gh api repos/owner/repo/compare/main...feature";
    vi.spyOn(broker, "execSync").mockImplementation(function (value, ...args) {
      if (value === comparison) return '{"status":"behind","ahead_by":0}';
      return originalExec.call(this, value, ...args);
    });
    vi.spyOn(broker, "spawnSync").mockImplementation(
      function (file, args, options) {
        if (args.includes(comparison))
          return {
            status: 0,
            stdout: '{"status":"behind","ahead_by":0}',
            stderr: "",
          };
        return originalSpawn.call(this, file, args, options);
      },
    );
    webFetch.mockResolvedValue({ content: "PR 340 head=feature base=main" });
    let calls = 0;
    const events = await drain(
      agentLoop(
        [
          {
            role: "user",
            content: "Determine whether PR 340 is already included",
          },
        ],
        {
          ...base,
          chatFn: async (context) => {
            calls++;
            if (calls === 1)
              return tool(
                "web_fetch",
                { url: "https://github.com/owner/repo/pull/340" },
                calls,
              );
            if (calls === 2)
              return tool("git", { command: "fetch origin main", cwd }, calls);
            if (calls === 3) {
              expect(JSON.stringify(context)).toContain(
                "does not select the local git repository",
              );
              expect(
                context.some(
                  (message) =>
                    message.role === "system" &&
                    message.content?.includes("compare/<base>...<head>"),
                ),
              ).toBe(true);
              return tool("run_shell", { command: comparison }, calls);
            }
            expect(calls).toBe(4);
            expect(JSON.stringify(context)).toContain("ahead_by");
            return {
              message: mockTextMessage(
                "PR 340 has no commits ahead of main according to the comparison.",
              ),
            };
          },
        },
      ),
    );
    expect(
      events.find((event) => event.type === "response-complete")?.content,
    ).toContain("no commits ahead");
    expect(webFetch).toHaveBeenCalledTimes(1);
  });

  it("keeps an explicit PR-close request through compaction and executes closure instead of re-reviewing", async () => {
    const originalExec = broker.execSync;
    const originalSpawn = broker.spawnSync;
    const close = "gh pr close 331 --repo owner/repo";
    const state =
      "gh pr view 331 --repo owner/repo --json number,state,closedAt";
    const executed = [];
    const resultFor = (value) => {
      executed.push(value);
      if (value === close) return "✓ Closed pull request owner/repo#331";
      if (value === state)
        return '{"number":331,"state":"CLOSED","closedAt":"2026-09-10T00:00:00Z"}';
      return null;
    };
    vi.spyOn(broker, "execSync").mockImplementation(function (value, ...args) {
      const result = resultFor(value);
      return result ?? originalExec.call(this, value, ...args);
    });
    vi.spyOn(broker, "spawnSync").mockImplementation(
      function (file, args, options) {
        const value = args.find((arg) => arg === close || arg === state);
        const result = value && resultFor(value);
        return result == null
          ? originalSpawn.call(this, file, args, options)
          : { status: 0, stdout: result, stderr: "" };
      },
    );
    let calls = 0;
    const events = await drain(
      agentLoop(
        [
          {
            role: "user",
            content: "请关闭这些 PR，候选列表是 #331；不要再评审是否应该关闭。",
          },
        ],
        {
          ...base,
          chatFn: async (context) => {
            calls++;
            expect(
              context.some(
                (message) =>
                  message.role === "system" &&
                  message.content?.includes("User-authorized PR closure"),
              ),
            ).toBe(true);
            if (calls === 1)
              return tool("run_shell", { command: close }, calls);
            if (calls === 2) {
              // The test compactor removes old tool context; the directive is
              // injected again from the original user authorization.
              expect(JSON.stringify(context)).toContain(
                "do not keep gathering diffs",
              );
              return tool("run_shell", { command: state }, calls);
            }
            expect(calls).toBe(3);
            expect(JSON.stringify(context)).toContain("CLOSED");
            return { message: mockTextMessage("PR #331 is closed.") };
          },
        },
      ),
    );
    expect(executed).toEqual([close, state]);
    expect(
      events.find((event) => event.type === "response-complete")?.content,
    ).toContain("closed");
  });

  it("blocks PR comparison loops until an explicitly requested close is attempted", async () => {
    const originalExec = broker.execSync;
    const originalSpawn = broker.spawnSync;
    const compare = "gh api repos/owner/repo/compare/main...feature";
    const close = "gh pr close 331 --repo owner/repo";
    const state =
      "gh pr view 331 --repo owner/repo --json number,state,closedAt";
    const executed = [];
    const resultFor = (value) => {
      executed.push(value);
      if (value === compare) return '{"ahead_by":1}';
      if (value === close) return "✓ Closed pull request owner/repo#331";
      if (value === state) return '{"number":331,"state":"CLOSED"}';
      return null;
    };
    vi.spyOn(broker, "execSync").mockImplementation(function (value, ...args) {
      const result = resultFor(value);
      return result ?? originalExec.call(this, value, ...args);
    });
    vi.spyOn(broker, "spawnSync").mockImplementation(
      function (file, args, options) {
        const value = args.find((arg) => [compare, close, state].includes(arg));
        const result = value && resultFor(value);
        return result == null
          ? originalSpawn.call(this, file, args, options)
          : { status: 0, stdout: result, stderr: "" };
      },
    );
    let calls = 0;
    const events = await drain(
      agentLoop([{ role: "user", content: "关闭 PR #331，不要再评审。" }], {
        ...base,
        chatFn: async (context) => {
          calls++;
          if (calls <= 3) return tool("run_shell", { command: compare }, calls);
          if (calls === 4) {
            expect(JSON.stringify(context)).toContain(
              "CC_PR_CLOSE_ACTION_REQUIRED",
            );
            return tool("run_shell", { command: close }, calls);
          }
          if (calls === 5) return tool("run_shell", { command: state }, calls);
          return { message: mockTextMessage("PR #331 is closed.") };
        },
      }),
    );
    expect(executed.filter((command) => command === compare)).toHaveLength(2);
    expect(executed).toContain(close);
    expect(executed).toContain(state);
    expect(
      events.find((event) => event.type === "response-complete")?.content,
    ).toContain("closed");
  });

  it("bounds repeated policy rejections even when each attempt uses a different commit", async () => {
    let calls = 0;
    const events = [];
    await expect(
      drain(
        agentLoop([{ role: "user", content: "Inspect PR commits" }], {
          ...base,
          chatFn: async (context, options) => {
            expect(++calls).toBeLessThan(10);
            if (calls === 4) {
              expect(options.disabledTools).toContain("run_shell");
              expect(JSON.stringify(context)).toContain(
                "Tool-policy loop recovery",
              );
            }
            return tool(
              "run_shell",
              { command: `git branch -r --contains commit-${calls} 2>&1` },
              calls,
            );
          },
        }),
        events,
      ),
    ).rejects.toMatchObject({ code: "CC_AGENT_REPEATED_REMOTE_READ" });
    expect(calls).toBe(9);
    expect(events.filter((event) => event.type === "tool-result")).toHaveLength(
      9,
    );
    expect(events.some((event) => event.type === "response-complete")).toBe(
      false,
    );
  });
});
