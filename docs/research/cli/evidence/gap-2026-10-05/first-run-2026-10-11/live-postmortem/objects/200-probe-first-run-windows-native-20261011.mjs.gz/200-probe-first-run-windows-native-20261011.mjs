import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
const rows=[];let current=path.resolve(os.tmpdir());
while(true){let native=null,error=null;try{native=fs.realpathSync.native(current);}catch(e){error={code:e.code,syscall:e.syscall,path:e.path,message:e.message};}rows.push({path:current,native,error});const parent=path.dirname(current);if(parent===current)break;current=parent;}
const report={capturedAt:new Date().toISOString(),platform:process.platform,node:process.version,executable:process.execPath,username:os.userInfo().username,temp:os.tmpdir(),rows};
const label=process.argv[2]??'sandbox';if(!/^[a-z-]+$/.test(label))throw Error('invalid label');
fs.writeFileSync(`.work/first-run-windows-native-${label}-20261011.json`,JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(report));
