import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
const root=process.cwd();
const files=[
 '__tests__/integration/remote-read-loop.test.js',
 '__tests__/unit/task-progress-tracker.test.js',
 '__tests__/unit/agent-core-autocompact.test.js',
 '__tests__/unit/iteration-budget.test.js',
 '__tests__/unit/agent-core.test.js',
 '__tests__/unit/headless-runner.test.js',
 '__tests__/unit/headless-stream.test.js',
 '__tests__/unit/provider-model-profile.test.js',
 '__tests__/unit/session-history-origins.test.js',
];
const label=process.argv[2]??'final';
if(!/^[a-z-]+$/.test(label))throw new Error('invalid reporter label');
const prefix=`.work/first-run-optimization-${label}-${process.platform}-20261011`;
const output=path.resolve(root,prefix+'.json');
if(fs.existsSync(output)) throw new Error('refusing to overwrite final reporter');
const args=[path.resolve(root,'node_modules/vitest/vitest.mjs'),'run',...files,'--reporter=json',`--outputFile=${output}`];
const startedAt=new Date().toISOString();
const r=spawnSync(process.execPath,args,{cwd:path.resolve(root,'packages/cli'),encoding:'utf8',timeout:240000,maxBuffer:32*1024*1024,windowsHide:true});
const metadata={startedAt,finishedAt:new Date().toISOString(),platform:process.platform,node:process.version,nodeExecutable:process.execPath,args,exitCode:r.status,signal:r.signal,error:r.error?.message??null,stdout:r.stdout,stderr:r.stderr};
fs.writeFileSync(prefix+'-process.json',JSON.stringify(metadata,null,2)+'\n',{flag:'wx'});
const report=fs.existsSync(output)?JSON.parse(fs.readFileSync(output,'utf8')):null;
console.log(JSON.stringify({prefix,...metadata,stdout:undefined,stderr:undefined,pass:report?.numPassedTests,fail:report?.numFailedTests,pending:report?.numPendingTests,failures:report?.testResults.flatMap(s=>s.assertionResults.filter(t=>t.status==='failed').map(t=>({name:t.fullName,errors:t.failureMessages})))}));
process.exitCode=r.status??1;
