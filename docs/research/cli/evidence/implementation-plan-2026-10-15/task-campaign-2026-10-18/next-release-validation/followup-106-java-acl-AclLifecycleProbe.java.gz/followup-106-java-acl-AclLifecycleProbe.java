package com.chainlesschain.ide;
import java.io.*;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
public class AclLifecycleProbe {
 static String javaBin=Path.of(System.getProperty("java.home"),"bin","java.exe").toString();
 static List<String> child(String mode){ return List.of(javaBin,"-cp",System.getProperty("java.class.path"),AclLifecycleProbe.class.getName(),mode); }
 static Object run(List<String> command,long seconds)throws Exception {Method m=WindowsOwnerOnlyAcl.class.getDeclaredMethod("runProcess",List.class,long.class);m.setAccessible(true);return m.invoke(null,command,seconds);}
 public static void main(String[] args)throws Exception {
  if(args.length>0){
   if(args[0].equals("stdin")){while(System.in.read()!=-1){} System.out.print("EOF");return;}
   if(args[0].equals("hold")){Thread.sleep(7000);System.out.print("LATE");return;}
   if(args[0].equals("fork")){new ProcessBuilder(child("hold")).inheritIO().start();return;}
  }
  boolean timedOut=false;long start=System.nanoTime();
  try{run(child("stdin"),1);}catch(InvocationTargetException e){timedOut=e.getCause() instanceof IOException && e.getCause().getMessage().contains("timed out");}
  long noEofMs=(System.nanoTime()-start)/1000000;
  Process control=new ProcessBuilder(child("stdin")).start();control.getOutputStream().close();boolean controlExit=control.waitFor(5,TimeUnit.SECONDS)&&control.exitValue()==0;
  start=System.nanoTime();WindowsOwnerOnlyAcl.Result result=(WindowsOwnerOnlyAcl.Result)run(child("fork"),3);long drainMs=(System.nanoTime()-start)/1000000;
  boolean alive=Thread.getAllStackTraces().keySet().stream().anyMatch(t->t.isAlive()&&t.getName().equals("chainlesschain-ide-acl-output"));
  System.out.println("{\"stdinDependentChildTimedOut\":"+timedOut+",\"stdinTimeoutElapsedMs\":"+noEofMs+",\"sameChildWithClosedStdinExited\":"+controlExit+",\"descendantPipeResultExit\":"+result.exitCode+",\"descendantPipeElapsedMs\":"+drainMs+",\"outputReaderAliveAtReturn\":"+alive+",\"capturedLateOutput\":"+result.output.contains("LATE")+",\"syntheticLifecycleOnly\":true,\"nativeAclRootCauseProven\":false}");
  Thread.sleep(2500);
 }
}
