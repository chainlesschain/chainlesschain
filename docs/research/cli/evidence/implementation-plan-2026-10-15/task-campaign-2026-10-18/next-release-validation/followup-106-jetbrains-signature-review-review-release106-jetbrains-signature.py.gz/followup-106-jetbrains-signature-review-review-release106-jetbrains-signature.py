import hashlib
import io
import json
from pathlib import Path
import struct
import subprocess
import zipfile

ROOT = Path(r'C:\code\chainlesschain\.work')
INPUT = ROOT / 'public106-jetbrains-official-20261018'
OUT = ROOT / 'release106-jetbrains-signature-review'
OUT.mkdir(exist_ok=True)
PIN = 'd8e450f45e303485d81eb5546026d058a5bd6822'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(name, data):
    (OUT / name).write_bytes(data)
    return {'path': name, 'bytes': len(data), 'sha256': sha(data)}

sources = []
for path in ['lib/src/main/proto/SigningBlock.proto', 'lib/src/main/kotlin/org/jetbrains/zip/signer/metadata/ZipMetadata.kt']:
    endpoint = 'repos/JetBrains/marketplace-zip-signer/contents/' + path + '?ref=' + PIN
    data = subprocess.check_output(['gh', 'api', endpoint, '-H', 'Accept: application/vnd.github.raw+json'])
    record = save(path.rsplit('/', 1)[1], data)
    record.update({'repository': 'JetBrains/marketplace-zip-signer', 'commit': PIN, 'sourcePath': path,
                   'url': 'https://github.com/JetBrains/marketplace-zip-signer/blob/' + PIN + '/' + path})
    sources.append(record)

def layout(data):
    offset = data.rfind(b'PK\x05\x06')
    values = struct.unpack_from('<4s4H2IH', data, offset)
    signature, disk, cd_disk, disk_count, total_count, cd_size, cd_offset, comment = values
    assert disk == cd_disk == 0 and disk_count == total_count == 4
    assert comment == 0 and offset + 22 == len(data)
    assert cd_offset + cd_size == offset
    return {'bytes': len(data), 'sha256': sha(data), 'eocdOffset': offset,
            'centralDirectoryOffset': cd_offset, 'centralDirectorySize': cd_size,
            'entryCount': total_count, 'commentBytes': comment, 'trailingBytes': 0}

official = (INPUT / 'official-plugin.zip').read_bytes()
public = (INPUT / 'public-plugin.zip').read_bytes()
old, new = layout(official), layout(public)
start, end = old['centralDirectoryOffset'], new['centralDirectoryOffset']
block = public[start:end]
assert len(block) == 5660
assert public[:start] == official[:start]
assert public[end:new['eocdOffset']] == official[start:old['eocdOffset']]
old_eocd, new_eocd = official[old['eocdOffset']:], public[new['eocdOffset']:]
assert old_eocd[:16] == new_eocd[:16] and old_eocd[20:] == new_eocd[20:]
assert struct.unpack_from('<I', new_eocd, 16)[0] - struct.unpack_from('<I', old_eocd, 16)[0] == len(block)
restored = bytearray(public[:start] + public[end:])
struct.pack_into('<I', restored, old['eocdOffset'] + 16, start)
assert restored == official
assert block[-16:] == b'@PK Sig Block 42'
assert struct.unpack_from('<Q', block, 0)[0] == struct.unpack_from('<Q', block, len(block)-24)[0] == len(block)-8

def varint(data, offset):
    value, shift = 0, 0
    while True:
        assert offset < len(data) and shift < 70
        byte = data[offset]
        offset += 1
        value |= (byte & 127) << shift
        if not byte & 128:
            return value, offset
        shift += 7

def parse(data, allowed):
    offset, fields = 0, []
    while offset < len(data):
        start = offset
        key, offset = varint(data, offset)
        field, wire = key >> 3, key & 7
        assert field in allowed and wire == allowed[field], (field, wire)
        if wire == 0:
            value, offset = varint(data, offset)
        elif wire == 2:
            length, offset = varint(data, offset)
            value = data[offset:offset+length]
            assert len(value) == length
            offset += length
        else:
            raise AssertionError(wire)
        fields.append((field, value, start, offset))
    assert offset == len(data)
    return fields

protobuf = block[8:-24]
metadata = parse(protobuf, {1: 0, 2: 2})
assert [f[0] for f in metadata] == [1, 2] and metadata[0][1] == 1
content = parse(metadata[1][1], {1: 2, 2: 2})
digests, signers = [], []
for field, raw, lo, hi in content:
    if field == 1:
        fields = parse(raw, {1: 0, 2: 2})
        assert len({f[0] for f in fields}) == len(fields)
        values = {f[0]: f[1] for f in fields}
        algorithm = values.get(1, 0)
        assert algorithm in [0, 1, 2] and 2 in values
        digests.append({'algorithmId': algorithm, 'algorithm': {0:'SHA256',1:'SHA512',2:'SHA384'}[algorithm],
                        'digestBytes': save('content-digest-%d.bin' % len(digests), values[2]), 'encodedMessageBytes': len(raw)})
    else:
        signer = {'encodedMessageBytes': len(raw), 'certificates': [], 'signatures': []}
        for subfield, value, slo, shi in parse(raw, {1:2, 2:2}):
            if subfield == 1:
                signer['certificates'].append(save('signer-%d-certificate-%d.der' % (len(signers), len(signer['certificates'])), value))
            else:
                fields = parse(value, {1:0, 2:2})
                assert len({f[0] for f in fields}) == len(fields)
                values = {f[0]:f[1] for f in fields}
                algorithm = values.get(1, 0)
                assert algorithm in [0,2,3,4] and 2 in values
                signer['signatures'].append({'algorithmId': algorithm, 'algorithm': {0:'RSA_WITH_SHA256',2:'RSA_WITH_SHA512',3:'DSA_WITH_SHA256',4:'ECDSA_WITH_SHA384'}[algorithm],
                    'signature': save('signer-%d-signature-%d.bin' % (len(signers), len(signer['signatures'])), values[2])})
        signers.append(signer)

entry_proofs = []
with zipfile.ZipFile(io.BytesIO(official)) as a, zipfile.ZipFile(io.BytesIO(public)) as b:
    assert a.namelist() == b.namelist()
    for left, right in zip(a.infolist(), b.infolist()):
        for attribute in ['filename', 'date_time', 'compress_type', 'comment', 'extra', 'create_system', 'create_version', 'extract_version', 'flag_bits', 'volume', 'internal_attr', 'external_attr', 'header_offset', 'CRC', 'compress_size', 'file_size']:
            assert getattr(left, attribute) == getattr(right, attribute), (left.filename, attribute)
        ldata, rdata = a.read(left), b.read(right)
        assert ldata == rdata
        entry_proofs.append({'name': left.filename, 'uncompressedBytes': len(ldata), 'sha256': sha(ldata), 'identical': True})

comparator_raw = (INPUT / 'comparison.json').read_bytes()
comparator = json.loads(comparator_raw)
assert comparator['status'] == 'ZIP_BYTES_DIFFER_REVIEW_REQUIRED'
assert comparator['officialPluginDigest'] == 'sha256:' + sha(official)
assert comparator['publicPluginDigest'] == 'sha256:' + sha(public)
report = {
    'schema': 'chainlesschain.jetbrains-signing-container-review/v1',
    'status': 'SAME_SOURCE_PLUGIN_PAYLOAD_CONTAINER_DIFFERENCES_FULLY_EXPLAINED',
    'scope': 'Independent binary/container review of the preserved official and public ZIP files; upstream comparator provenance is retained.',
    'sourceCommit': comparator['sourceCommit'], 'officialRunId': comparator['officialRunId'],
    'officialArtifactId': comparator['officialArtifactId'],
    'inputComparator': {'path': str(INPUT / 'comparison.json'), 'sha256': sha(comparator_raw), 'statusUnchanged': comparator['status']},
    'official': old, 'public': new,
    'binaryProof': {
        'identicalPrefix': {'offset': 0, 'bytes': start, 'sha256': sha(official[:start])},
        'insertedBlock': dict(save('signature-block.bin', block), officialOffset=start, publicStart=start, publicEndExclusive=end),
        'identicalCentralDirectory': {'bytes': old['centralDirectorySize'], 'sha256': sha(official[start:old['eocdOffset']])},
        'eocd': {'bytes': 22, 'officialHex': old_eocd.hex(), 'publicHex': new_eocd.hex(), 'onlyChangedFieldOffset':16,
                 'onlyChangedFieldBytes':4, 'field':'centralDirectoryOffset', 'offsetIncrease':len(block),
                 'actualDifferingByteOffsetsWithinEocd':[i for i in range(22) if old_eocd[i] != new_eocd[i]]},
        'reconstruction': {'operation':'Delete public [1529640,1535300); write little-endian uint32 1529640 at restored EOCD + 16.',
                           'bytes':len(restored), 'sha256':sha(restored), 'byteForByteEqualToOfficial':True},
        'unexplainedBytes': 0, 'originalZipBytesEqual':False},
    'signatureBlockFormat': {'implementationSources':sources, 'name':'JetBrains Marketplace ZIP signing block',
        'headerBytes':8, 'protobufBytes':len(protobuf), 'footerBytes':24,
        'headerAndFooterLittleEndianUint64':len(block)-8, 'footerMagicAscii':'@PK Sig Block 42',
        'footerMagicBytes':16, 'signatureSchemeVersion':1, 'protobufUnknownFields':0,
        'protobufFullyConsumed':True, 'digests':digests, 'signers':signers},
    'entries':entry_proofs,
    'signatureVerification': {'cryptographicSignatureVerified':False, 'certificateChainTrustVerified':False,
        'reason':'No existing marketplace-zip-signer verifier found in local Gradle module cache. Official pinned source was read to identify and fully parse the format. No verifier installation or PKI work was required for byte reconstruction.'},
    'conclusions': {'sameSourcePluginPayloadEstablished':True, 'allContainerDifferencesExplained':True,
        'originalArchiveIdentityClaimed':False, 'signatureTrustClaimed':False,
        'pluginOrModelExecuted':False, 'taskAcceptanceChanged':False, 'releaseAcceptanceChanged':False},
}
save('review.json', (json.dumps(report, indent=2)+'\n').encode('utf-8'))
print(json.dumps({'output':str(OUT), 'status':report['status'], 'protobufBytes':len(protobuf), 'digests':digests,
                  'signers':signers, 'reviewSha256':sha((OUT/'review.json').read_bytes())}, indent=2))
