# JetBrains 0.4.168 public ZIP container review

**Conclusion: same-source plugin payload established; every container difference explained.**

This independent review uses the preserved files from `../public106-jetbrains-official-20261018/`. The original comparator remains `ZIP_BYTES_DIFFER_REVIEW_REQUIRED`; this review does not rewrite it or change release/task acceptance. Official provenance remains attached to source `dca47fd91a209642b6536afd5bc9e99ec74c7d06`, run `39131605961`, artifact `12139490322`.

## Original files and the inserted block

| Object | Bytes | SHA256 |
| --- | ---: | --- |
| Official ZIP | 1530054 | `6230036a2709f12eed326433d4ebdcf2622f47bd570230f70535868ff04fc84c` |
| Public ZIP | 1535714 | `5f7e9b60f37745e2febfcf934a5960e77413fb7836804af0a02429804a2f1b29` |
| Inserted signing block | 5660 | `018d3d17da2be98f655dc98ee434743849efc53bd3034c69043a75940727233d` |

## Complete byte accounting

- Bytes `[0,1529640)` are identical, including all local headers, compressed entry data and the two complete JAR payloads.
- The public ZIP inserts exactly 5660 bytes at `[1529640,1535300)`.
- The original 392-byte central directory is unchanged, shifted from 1529640 to 1535300.
- The 22-byte EOCD is shifted from 1530032 to 1535692. Its only changed field is the four-byte little-endian central directory offset at EOCD + 16, increased by 5660. There are no archive comments or trailing bytes.
- Delete the inserted block and restore that offset to 1529640: the result equals the entire official ZIP **byte for byte**, with its original SHA256. This is an exact binary reconstruction, beyond comparing extracted files.
- All four entries have identical names, order, metadata and uncompressed bytes. Raw JARs are hashed without unpacking or normalizing them. No signature entry or other data was excluded.

## Signing format identification

The block matches JetBrains' official `marketplace-zip-signer` source pinned at commit `d8e450f45e303485d81eb5546026d058a5bd6822`. Saved `ZipMetadata.kt` specifies the framing and `SigningBlock.proto` specifies all parsed fields. Source URLs and raw hashes are in `review.json`.

The 5660-byte block consists of an 8-byte header, 5628-byte protobuf, and 24-byte footer. Header and footer lengths both equal 5652 (total size minus eight); the last 16 bytes are `@PK Sig Block 42`. The protobuf is fully consumed with no unknown fields, scheme version 1, one SHA512 digest record, and one signer containing three DER certificate byte strings and a 512-byte RSA_WITH_SHA512 signature.

All nested message sizes are accounted for: the metadata contains 2 version bytes plus 3 content-framing bytes plus 5623 content bytes. Content consists of a 269-byte framed digest message and a 5354-byte framed signer message. The 5351-byte signer body contains framed certificates of 1691, 1632 and 1508 bytes plus a 520-byte framed signature message. Certificate and signature bytes are preserved separately with hashes.

## Boundaries

This establishes that the public archive contains the original official plugin payload and that its complete binary delta is a correctly framed and parsed JetBrains signing block plus the required ZIP offset update. The original ZIP files remain different.

Cryptographic signature validity and certificate-chain trust are **not verified**. No existing marketplace ZIP verifier was found in the local Gradle module cache; no verifier was installed. Format recognition does not establish signer identity or trust. Plugin code and models were not executed. Product/evaluation sources, acceptance, documentation drafts and the original comparator were not modified.

`review.json` contains the independent assertions and full digests. `evidence-digests.json` inventories saved review artifacts. The reproducible script is `../review-release106-jetbrains-signature.py`.
