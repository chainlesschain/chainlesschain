import concurrent.futures
import datetime
import json
import pathlib
import subprocess
import sys

WORK = pathlib.Path(__file__).parent
OUT = WORK / 'release-priority-cancellation'
OUT.mkdir(exist_ok=True)
REPO = 'chainlesschain/chainlesschain'
CURRENT = 'dca47fd91a209642b6536afd5bc9e99ec74c7d06'
OLD = '4317bf01a48a7ec612e12000936a81851c6febf3'
MAIN = 'ea49733d5d3ac76de17552f83faf2f8a764b6b7e'
PROTECTED = {
    'PDH Data Hub Tests (ubuntu-latest)', 'PDH Data Hub Tests (windows-latest)',
    'Quality Gate', 'Run All Tests (ubuntu-latest)',
    'Run All Tests (windows-latest)', 'Lint & Format Check',
}
KEEP = {
    '.github/workflows/cli-ci.yml', '.github/workflows/cli-strict-sandbox.yml',
    '.github/workflows/ide-extensions.yml', '.github/workflows/ide-arm64-validation.yml',
    '.github/workflows/test.yml', '.github/workflows/test-automation-full.yml',
    '.github/workflows/code-quality.yml',
}
# Every request is bound to a reviewed run ID, workflow, source and event.
TARGETS = [
    ('39114428700', 'pr-tests.yml', CURRENT, 'pull_request', 'duplicate optional PR suite'),
    ('39114428670', 'verify01-host-diagnostics.yml', CURRENT, 'pull_request', 'keyless auxiliary diagnostics; not the 36+9 campaign or publication gate'),
    ('39114426079', 'context-memory-kernel.yml', CURRENT, 'push', 'duplicate feature-push child CI; published child sources unchanged'),
    ('39114428617', 'cli-team-fairness-soak.yml', CURRENT, 'pull_request', 'auxiliary fairness soak'),
    ('39114428687', 'evolution-ledger-reliability.yml', CURRENT, 'pull_request', 'auxiliary evolution soak'),
    ('39114428675', 'cli-reliability-soak.yml', CURRENT, 'pull_request', 'auxiliary reliability soak'),
    ('39114428643', 'ide-roadmap-live-provider.yml', CURRENT, 'pull_request', 'PR loopback-only auxiliary trajectory; real-provider jobs require dispatch/schedule'),
    ('39114428692', 'cli-scheduler-soak.yml', CURRENT, 'pull_request', 'auxiliary scheduler soak'),
    ('39111986467', 'evolution-ledger-reliability.yml', OLD, 'pull_request', 'superseded release candidate auxiliary run'),
    ('39106713026', 'cli-ci.yml', MAIN, 'push', 'old merged-main CI; cannot qualify the current exact release source'),
]

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def read(path):
    return json.loads(subprocess.check_output(
        ['gh', 'api', 'repos/' + REPO + '/' + path], timeout=45))

def job_rows(run_id):
    result = []
    page = 1
    while True:
        data = read('actions/runs/' + run_id + '/jobs?filter=latest&per_page=100&page=' + str(page))
        result.extend(data['jobs'])
        if len(result) >= data['total_count']:
            assert len(result) == data['total_count']
            return result
        page += 1

def inspect(target):
    run_id, workflow, source, event, reason = target
    run = read('actions/runs/' + run_id)
    assert str(run['id']) == run_id
    assert run['path'] == '.github/workflows/' + workflow
    assert run['head_sha'] == source and run['event'] == event
    assert run['head_branch'] == ('main' if source == MAIN else 'feature/task-quality-followup-20261018')
    assert [pr['number'] for pr in run['pull_requests']] == ([] if source == MAIN else [462])
    assert source != CURRENT or run['path'] not in KEEP
    assert not run['head_branch'].startswith(('v-npm-', 'ide-vscode-', 'ide-jetbrains-'))
    jobs = job_rows(run_id)
    assert not PROTECTED.intersection(job['name'] for job in jobs)
    return {'runId': run_id, 'workflow': run['path'], 'sourceCommit': source,
            'reason': reason, 'before': run, 'jobsBefore': jobs}

protection = read('branches/main/protection/required_status_checks')
assert set(protection['contexts']) == PROTECTED, 'Protection changed; review before proceeding'
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    records = list(pool.map(inspect, TARGETS))
plan = {'schema': 'chainlesschain.release-priority-run-cleanup/v1', 'preparedAt': now(),
        'repository': REPO, 'releaseSourceCommit': CURRENT,
        'authorization': 'User explicitly requested cancellation of runners unrelated to this release.',
        'preserveCurrentSourceWorkflows': sorted(KEEP), 'protectedContexts': sorted(PROTECTED),
        'publisherAndNativeCampaignRunsTargeted': False,
        'taskGenerationDispatched': 0, 'modelCalls': 0, 'records': records}
execute = '--execute' in sys.argv
if execute:
    path = OUT / 'execution.json'
    with path.open('x', encoding='utf-8') as handle:
        handle.write(json.dumps(plan, indent=2) + '\n')
else:
    path = OUT / 'plan.json'
    path.write_text(json.dumps(plan, indent=2) + '\n', encoding='utf-8')
for record in records:
    if execute and record['before']['status'] != 'completed':
        # Re-read immediately before the sole cancellation request.
        current = read('actions/runs/' + record['runId'])
        assert current['head_sha'] == record['sourceCommit'] and current['path'] == record['workflow']
        if current['status'] != 'completed':
            record['cancelIntentAt'] = now()
            record['cancelStatus'] = 'PREPARED_BEFORE_SINGLE_REQUEST'
            path.write_text(json.dumps(plan, indent=2) + '\n', encoding='utf-8')
            try:
                reply = subprocess.run(['gh', 'run', 'cancel', record['runId'], '--repo', REPO],
                    capture_output=True, text=True, encoding='utf-8', timeout=55)
            except BaseException as error:
                record['cancelStatus'] = 'OUTCOME_UNCERTAIN_RESOLVE_READ_ONLY'
                record['localErrorType'] = type(error).__name__
                path.write_text(json.dumps(plan, indent=2) + '\n', encoding='utf-8')
                raise
            record['cancelStatus'] = 'REQUEST_ACCEPTED' if reply.returncode == 0 else 'REQUEST_FAILED_REVIEW_RESPONSE'
            record['clientExitCode'] = reply.returncode
            record['clientOutput'] = reply.stdout + reply.stderr
            record['respondedAt'] = now()
            path.write_text(json.dumps(plan, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'runId': record['runId'], 'workflow': record['workflow'],
        'statusBefore': record['before']['status'], 'reason': record['reason'],
        'action': record.get('cancelStatus', 'ALREADY_COMPLETED' if record['before']['status'] == 'completed' else 'PREVIEW_ONLY')}), flush=True)
