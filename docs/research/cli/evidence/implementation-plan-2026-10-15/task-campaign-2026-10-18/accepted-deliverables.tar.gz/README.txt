Accepted native CLI / IDE deliverables

Apply each sample/files subtree separately to frozen project b2aa3aba082873570e85dce39b00754e5504ff37.
Do not apply all samples to a current checkout. Independent candidates can share destination paths.
Receipts are from Linux offline Docker acceptance, not native Windows/macOS test execution.
Read manifest.json for historical versus latest-package provenance and end-to-end verdicts.
No new model requests or test execution were used to build this archive.
