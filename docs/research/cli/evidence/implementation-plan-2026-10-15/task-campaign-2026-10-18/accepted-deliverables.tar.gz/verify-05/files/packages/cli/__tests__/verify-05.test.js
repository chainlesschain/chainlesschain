/**
 * Regression tests: install/admission separation in AgentRouter.
 *
 * Scope: an installed but not-yet-attested external CLI backend must still be
 * refused for execution, while a usable API backend alongside it is preserved
 * and dispatchable. dispatch() is driven with an authenticated model ingress so
 * the pre-backend ingress guard is satisfied and the backend-level admission
 * decision is what is under test.
 *
 * Deterministic: the real cowork-adapter chat and evolution-ingress capture are
 * replaced by lightweight stubs so no network or subprocess is exercised. The
 * installed CLI's real pool is spied on to prove it is never dispatched.
 */

import { describe, it, expect, vi } from "vitest";

vi.mock("../src/lib/evolution/agent-evolution-ingress.js", () => ({
  captureAgentEvolutionIngress: vi.fn((ingress) => (ingress == null ? null : ingress)),
}));

vi.mock("../src/lib/cowork-adapter.js", () => ({
  createChatFn: vi.fn(() => async () => "simulated api output"),
}));

import {
  AgentRouter,
  AGENT_ROUTER_ERROR,
  BACKEND_TYPE,
} from "../src/lib/agent-router.js";

const AUTHED_INGRESS = { authenticated: true };

describe("AgentRouter install/admission separation (verify-05)", () => {
  it("refuses an installed-but-unattested CLI-only router without dispatching its pool", async () => {
    const router = new AgentRouter({
      backends: [{ type: BACKEND_TYPE.CLAUDE, installed: true }],
    });
    const pool = router._backends[0]._pool;
    const poolDispatch = vi.spyOn(pool, "dispatch");

    await expect(
      router.dispatch([{ id: "t1", description: "implement fix" }], {
        cwd: "/tmp",
        evolutionIngress: AUTHED_INGRESS,
      }),
    ).rejects.toMatchObject({
      code: AGENT_ROUTER_ERROR.EXTERNAL_MODEL_INGRESS_UNATTESTED,
    });
    expect(poolDispatch).not.toHaveBeenCalled();
  });

  it("preserves a usable API backend when an installed CLI backend is present", async () => {
    const router = new AgentRouter({
      backends: [
        { type: BACKEND_TYPE.CLAUDE, installed: true },
        { type: BACKEND_TYPE.OPENAI, apiKey: "k" },
      ],
      strategy: "round-robin",
    });
    const cliPool = router._backends.find(
      (b) => b.isCLI && b.type === BACKEND_TYPE.CLAUDE,
    )._pool;
    const cliPoolDispatch = vi.spyOn(cliPool, "dispatch");

    const results = await router.dispatch(
      [{ id: "t1", description: "implement fix" }],
      { cwd: "/tmp", evolutionIngress: AUTHED_INGRESS },
    );

    expect(results).toHaveLength(1);
    expect(results[0].taskId).toBe("t1");
    // The unattested CLI backend was filtered out before any execution.
    expect(cliPoolDispatch).not.toHaveBeenCalled();
  });

  it("installed CLI backends cannot serve as the sole fallback under primary strategy", async () => {
    const router = new AgentRouter({
      backends: [{ type: BACKEND_TYPE.CODEX, installed: true }],
      strategy: "primary",
    });
    const pool = router._backends[0]._pool;
    const poolDispatch = vi.spyOn(pool, "dispatch");

    await expect(
      router.dispatch([{ id: "t1", description: "implement fix" }], {
        cwd: "/tmp",
        evolutionIngress: AUTHED_INGRESS,
      }),
    ).rejects.toMatchObject({
      code: AGENT_ROUTER_ERROR.EXTERNAL_MODEL_INGRESS_UNATTESTED,
    });
    expect(poolDispatch).not.toHaveBeenCalled();
  });

  it("preflight passes when an API backend remains alongside an installed CLI", () => {
    const router = new AgentRouter({
      backends: [
        { type: BACKEND_TYPE.CLAUDE, installed: true },
        { type: BACKEND_TYPE.OPENAI, apiKey: "k" },
      ],
    });
    expect(() => router.assertDispatchAvailable()).not.toThrow();
  });

  it("preflight rejects an installed CLI-only router as unattested", () => {
    const router = new AgentRouter({
      backends: [{ type: BACKEND_TYPE.CLAUDE, installed: true }],
    });
    expect(() => router.assertDispatchAvailable()).toThrow(/blocked/);
  });

  it("summary separates installed from admitted for CLI while API stays dispatchable", () => {
    const router = new AgentRouter({
      backends: [
        { type: BACKEND_TYPE.CLAUDE, installed: true },
        { type: BACKEND_TYPE.OPENAI, apiKey: "k" },
      ],
    });
    const [cli, api] = router.summary();
    expect(cli).toMatchObject({
      kind: "cli",
      installed: true,
      governanceAdmitted: false,
      dispatchable: false,
      runnable: false,
      executionMode: "blocked",
      blockedReason: AGENT_ROUTER_ERROR.EXTERNAL_MODEL_INGRESS_UNATTESTED,
    });
    expect(api).toMatchObject({
      kind: "api",
      dispatchable: true,
      runnable: false,
      executionMode: "text-only",
    });
  });
});
