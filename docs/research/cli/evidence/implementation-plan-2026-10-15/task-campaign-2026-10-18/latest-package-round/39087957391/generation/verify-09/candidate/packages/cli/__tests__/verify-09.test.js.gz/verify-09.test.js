import { describe, expect, it } from "vitest";
import {
  createSessionHistoryOrigins,
  HISTORY_PREFIX_SCHEMA,
} from "../../src/lib/session-history-origins.js";
import {
  HISTORY_SUMMARY_SCHEMA,
  projectCheckpointSummary,
} from "../../src/lib/checkpoint-summary-projection.js";
import { encodePersistedMessage } from "../../src/lib/session-message-provenance.js";

// Independent regression coverage for "historical source tampering rejection":
// origin mapping must refuse any event whose session/source identity does not
// match the recorded context, while a correct identity stays readable.

const SESSION_HEAD = "a".repeat(64);
const OTHER_HEAD = "b".repeat(64);

const MESSAGES = [
  { role: "user", content: "first" },
  { role: "assistant", content: "answer" },
  { role: "user", content: "cut" },
  { role: "assistant", content: "answer" },
];

function rewindEvent(messages, retainedMessageCount) {
  return {
    prevHash: SESSION_HEAD,
    data: {
      action: "restore-conversation",
      messages: messages.slice(0, retainedMessageCount),
      historyPrefix: {
        schema: HISTORY_PREFIX_SCHEMA,
        sourceHead: SESSION_HEAD,
        sourceMessageCount: messages.length,
        retainedMessageCount,
      },
    },
  };
}

function summaryEvent(messages, action, start, end = messages.length) {
  return {
    prevHash: SESSION_HEAD,
    data: {
      action,
      turnId: "selected",
      historySummary: {
        schema: HISTORY_SUMMARY_SCHEMA,
        sourceHead: SESSION_HEAD,
        sourceMessageCount: messages.length,
        start,
        end,
      },
      messages: projectCheckpointSummary({
        messages,
        action,
        start,
        end,
        turnId: "selected",
      }).map(({ message }) => encodePersistedMessage(message)),
    },
  };
}

describe("historical source tampering rejection", () => {
  it("reads a valid rewind source: the correct session identity yields the cutoff", () => {
    const origins = createSessionHistoryOrigins();
    origins.snapshot(MESSAGES);
    expect(origins.rewind(rewindEvent(MESSAGES, 2), 4)).toBe(2);
  });

  it("rejects a rewind whose historyPrefix sourceHead was tampered", () => {
    const origins = createSessionHistoryOrigins();
    origins.snapshot(MESSAGES);
    const forged = rewindEvent(MESSAGES, 2);
    forged.data.historyPrefix.sourceHead = OTHER_HEAD;
    expect(origins.rewind(forged, 4)).toBeNull();
  });

  it("rejects a rewind whose sourceMessageCount was tampered", () => {
    const origins = createSessionHistoryOrigins();
    origins.snapshot(MESSAGES);
    const forged = rewindEvent(MESSAGES, 2);
    forged.data.historyPrefix.sourceMessageCount -= 1;
    expect(origins.rewind(forged, 4)).toBeNull();
  });

  it("rejects a rewind whose prevHash no longer matches the recorded source", () => {
    const origins = createSessionHistoryOrigins();
    origins.snapshot(MESSAGES);
    const crossSession = rewindEvent(MESSAGES, 2);
    crossSession.prevHash = OTHER_HEAD;
    expect(origins.rewind(crossSession, 4)).toBeNull();
  });

  it("reads a valid summary certificate: the correct source is accepted", () => {
    const origins = createSessionHistoryOrigins();
    origins.snapshot(MESSAGES);
    expect(
      origins.summarize(summaryEvent(MESSAGES, "summary-from", 0)),
    ).toBe(true);
  });

  it("rejects a summary certificate whose sourceHead was tampered", () => {
    const origins = createSessionHistoryOrigins();
    origins.snapshot(MESSAGES);
    const forged = summaryEvent(MESSAGES, "summary-from", 0);
    forged.data.historySummary.sourceHead = OTHER_HEAD;
    expect(origins.summarize(forged)).toBe(false);
  });
});
