import {
  mkdtempSync,
  readdirSync,
  readFileSync,
  rmSync,
  writeFileSync,
} from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { loadBackgroundAgentListIndex } from "../src/lib/background-agent-list-index.js";

// Pagination index invalidation regression: after writes and deletes the
// reloaded index must match the authoritative full list of the same snapshot,
// including the final (tail) page. No pagination API exists on the module; the
// caller slices the returned `entries` into pages, so we drive pagination in
// the test and require every page to reconstruct the full snapshot exactly.

const STATE_FILE = /^bg-[A-Za-z0-9-]+\.json$/u;

let directory;

function writeState(id, state = {}) {
  writeFileSync(
    join(directory, `${id}.json`),
    JSON.stringify({ id, startedAt: 1, status: "completed", ...state }),
    "utf8",
  );
}

function deleteState(id) {
  rmSync(join(directory, `${id}.json`), { force: true });
}

function reader() {
  return vi.fn((id) =>
    JSON.parse(readFileSync(join(directory, `${id}.json`), "utf8")),
  );
}

// Authoritative list for the current snapshot, matching the inventory the
// module builds from the directory (sorted by state-file name, .job excluded).
function currentIds() {
  return readdirSync(directory, { withFileTypes: true })
    .map((entry) => entry.name)
    .filter((name) => STATE_FILE.test(name) && !name.includes(".job."))
    .map((name) => STATE_FILE.exec(name)[1])
    .sort();
}

function loadIds() {
  return loadBackgroundAgentListIndex({ directory, readState: reader() }).entries.map(
    (entry) => entry.id,
  );
}

function paginate(ids, pageSize) {
  const pages = [];
  for (let index = 0; index < ids.length; index += pageSize) {
    pages.push(ids.slice(index, index + pageSize));
  }
  return pages;
}

function expectPaginationMatchesFullList(ids, pageSize = 3) {
  const pages = paginate(ids, pageSize);
  expect(pages.flat()).toEqual(ids);
  expect(pages.flat()).toHaveLength(ids.length);
  if (ids.length > 0) {
    // The tail page must be present and carry the final element of the list.
    expect(pages[pages.length - 1].length).toBeGreaterThan(0);
    expect(pages[pages.length - 1]).toContain(ids[ids.length - 1]);
  }
}

beforeEach(() => {
  directory = mkdtempSync(join(tmpdir(), "cc-verify10-pagination-"));
});

afterEach(() => {
  rmSync(directory, { recursive: true, force: true });
});

describe("background agent list index pagination invalidation regression", () => {
  it("rebuilds the index so pagination matches the snapshot after writes", () => {
    writeState("bg-a");
    writeState("bg-b");
    expect(loadIds()).toEqual(["bg-a", "bg-b"]);

    writeState("bg-c", { startedAt: 2 });
    writeState("bg-d");
    const ids = loadIds();
    expect(ids).toEqual(currentIds());
    expect(ids).toContain("bg-c");
    expect(ids).toContain("bg-d");
    expectPaginationMatchesFullList(ids);
  });

  it("drops deleted states so pagination matches the snapshot", () => {
    writeState("bg-a");
    writeState("bg-b");
    writeState("bg-c");
    loadIds();

    deleteState("bg-b");
    const ids = loadIds();
    expect(ids).toEqual(currentIds());
    expect(ids).toEqual(["bg-a", "bg-c"]);
    expectPaginationMatchesFullList(ids);
  });

  it("stays consistent with the snapshot when writes and deletes occur together", () => {
    writeState("bg-a");
    writeState("bg-b");
    writeState("bg-c");
    writeState("bg-d");
    loadIds();

    deleteState("bg-a");
    deleteState("bg-c");
    writeState("bg-e");
    writeState("bg-f");

    const ids = loadIds();
    expect(ids).toEqual(currentIds());
    expect(ids).toEqual(["bg-b", "bg-d", "bg-e", "bg-f"]);
    expectPaginationMatchesFullList(ids);
  });

  it("keeps pagination stable across loads when the snapshot is unchanged", () => {
    for (const id of ["bg-a", "bg-b", "bg-c", "bg-d", "bg-e"]) {
      writeState(id);
    }
    const first = loadIds();
    const second = loadIds();
    expect(first).toEqual(currentIds());
    expect(second).toEqual(first);
    expectPaginationMatchesFullList(second);
  });

  it("includes the complete tail page after sequential writes", () => {
    for (const id of [
      "bg-a",
      "bg-b",
      "bg-c",
      "bg-d",
      "bg-e",
      "bg-f",
      "bg-g",
      "bg-h",
    ]) {
      writeState(id);
    }
    loadIds();

    writeState("bg-i");
    writeState("bg-j");
    const ids = loadIds();
    expect(ids).toEqual(currentIds());
    expect(ids.length).toBe(10);
    // pageSize 3 -> pages of 3/3/3/1; the tail page must carry the last id.
    expectPaginationMatchesFullList(ids);
    const pages = paginate(ids, 3);
    expect(pages[pages.length - 1]).toEqual(["bg-j"]);
  });

  it("replaces the cached index after a mutation so later loads reuse it consistently", () => {
    writeState("bg-a");
    writeState("bg-b");
    const rebuilt = loadBackgroundAgentListIndex({
      directory,
      readState: reader(),
    });
    expect(rebuilt.source).toBe("rebuilt");
    expect(rebuilt.entries.map((entry) => entry.id)).toEqual(["bg-a", "bg-b"]);

    writeState("bg-c");
    deleteState("bg-a");
    const afterMutation = loadBackgroundAgentListIndex({
      directory,
      readState: reader(),
    });
    expect(afterMutation.source).toBe("rebuilt");
    expect(afterMutation.entries.map((entry) => entry.id)).toEqual(
      currentIds(),
    );
    expect(afterMutation.entries.map((entry) => entry.id)).toEqual([
      "bg-b",
      "bg-c",
    ]);

    const stable = loadBackgroundAgentListIndex({
      directory,
      readState: reader(),
    });
    expect(stable.source).toBe("index");
    expect(stable.entries).toEqual(afterMutation.entries);
    expect(stable.entries.map((entry) => entry.id)).toEqual(currentIds());
    expectPaginationMatchesFullList(stable.entries.map((entry) => entry.id));
  });
});
