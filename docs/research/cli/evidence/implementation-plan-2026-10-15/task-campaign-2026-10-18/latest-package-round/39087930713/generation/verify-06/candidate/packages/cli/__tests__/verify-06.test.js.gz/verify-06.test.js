/**
 * verify-06 — 付费分解前预检 (paid-decomposition preflight) regression.
 *
 * Independent behavioral controls for the paid-decomposition ingress gate that
 * Orchestrator.addTask() runs before any Run creation, notification or LLM
 * decomposition:
 *
 *   this._router.assertDispatchAvailable?.()
 *
 * A backend rejected by the preflight (opaque external CLI) must terminate the
 * addTask call BEFORE decomposition begins and BEFORE any notification fires,
 * so no paid model work is ever paid for on a rejected route.
 *
 * These tests exercise the Orchestrator directly (the same object the
 * `cc orchestrate` command drives via `orch.addTask`) and spy only on real
 * internal methods/events — no existing suite is imported and no source text
 * is asserted.
 */
import { describe, it, expect, vi } from "vitest";
import { Orchestrator, TASK_STATUS } from "../src/lib/orchestrator.js";

describe("paid-decomposition preflight (verify-06)", () => {
  it("rejects a CLI-only backend before decomposition or notifications fire", async () => {
    const notifyStart = vi.fn();
    const orch = new Orchestrator({
      agents: { backends: [{ type: "claude" }] },
      notifier: { isConfigured: true, notifyStart },
    });

    const decompose = vi.spyOn(orch, "_decompose");
    const decomposed = vi.fn();
    orch.on("task:decomposed", decomposed);

    await expect(orch.addTask("fix the bug")).rejects.toMatchObject({
      code: "AGENT_ROUTER_EXTERNAL_MODEL_INGRESS_UNATTESTED",
    });

    // Rejected backend must terminate BEFORE decomposition starts and before
    // any notification is sent: both spies remain at zero.
    expect(decompose).not.toHaveBeenCalled();
    expect(decomposed).not.toHaveBeenCalled();
    expect(notifyStart).not.toHaveBeenCalled();
  });

  it("does not add a task record or emit task:added on the rejected route", async () => {
    const orch = new Orchestrator({
      agents: { backends: [{ type: "codex" }] },
      notifier: { isConfigured: true, notifyStart: vi.fn() },
    });

    const added = vi.fn();
    orch.on("task:added", added);

    await expect(orch.addTask("fix the bug")).rejects.toMatchObject({
      code: "AGENT_ROUTER_EXTERNAL_MODEL_INGRESS_UNATTESTED",
    });

    expect(added).not.toHaveBeenCalled();
    expect(orch._tasks.size).toBe(0);
  });

  it("does not reach dispatch or CI on the rejected route", async () => {
    const orch = new Orchestrator({
      agents: { backends: [{ type: "claude" }, { type: "codex" }] },
      notifier: { isConfigured: false },
    });

    const dispatch = vi.spyOn(orch, "_dispatch");
    const ci = vi.spyOn(orch, "_runCI");

    await expect(orch.addTask("fix the bug")).rejects.toMatchObject({
      code: "AGENT_ROUTER_EXTERNAL_MODEL_INGRESS_UNATTESTED",
    });

    expect(dispatch).not.toHaveBeenCalled();
    expect(ci).not.toHaveBeenCalled();
  });

  it("preflight passes a dispatchable (non-CLI) backend and decomposition proceeds", async () => {
    // A backend that is NOT an opaque external CLI (e.g. an API/text-only
    // backend) is admitted by the preflight and is allowed to decompose.
    const orch = new Orchestrator({
      agents: { backends: [{ type: "gemini" }] },
      notifier: { isConfigured: false },
    });

    // Stub the LLM decomposition and dispatch so the test stays hermetic; we
    // only assert that the preflight gate lets execution reach decomposition.
    const subtasks = [{ id: "sub-1", description: "fix" }];
    orch._decompose = vi.fn(async () => subtasks);
    orch._dispatch = vi.fn(async () => []);
    const decomposed = vi.fn();
    orch.on("task:decomposed", decomposed);

    await expect(
      orch.addTask("fix the bug", { runCI: false }),
    ).resolves.toMatchObject({ status: TASK_STATUS.DISPATCHED });

    expect(orch._decompose).toHaveBeenCalled();
    expect(decomposed).toHaveBeenCalled();
  });

  it("admits a mixed CLI+API set through the preflight (rejects only CLI-only sets)", async () => {
    const orch = new Orchestrator({
      agents: { backends: [{ type: "claude" }, { type: "gemini" }] },
      notifier: { isConfigured: false },
    });

    orch._decompose = vi.fn(async () => [{ id: "sub-1", description: "fix" }]);
    orch._dispatch = vi.fn(async () => []);

    await expect(
      orch.addTask("fix the bug", { runCI: false }),
    ).resolves.toBeDefined();

    expect(orch._decompose).toHaveBeenCalled();
  });

  it("still rejects when the backend set is empty (no dispatchable backend)", async () => {
    const orch = new Orchestrator({
      agents: { backends: [] },
      notifier: { isConfigured: false },
    });

    const decompose = vi.spyOn(orch, "_decompose");
    const notifyStart = vi.fn();
    orch.notifier = { isConfigured: true, notifyStart };

    await expect(orch.addTask("fix the bug")).rejects.toMatchObject({
      code: "AGENT_ROUTER_NO_BACKENDS",
    });

    expect(decompose).not.toHaveBeenCalled();
    expect(notifyStart).not.toHaveBeenCalled();
  });
});
