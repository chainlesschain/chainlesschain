/**
 * Regression coverage: paid-decomposition preflight ("付费分解前预检").
 *
 * The orchestrator's addTask() runs a router preflight before Run creation,
 * notifications and paid decomposition:
 *
 *     this._router.assertDispatchAvailable?.();
 *
 * When every configured backend is rejected (only opaque external CLIs) OR no
 * backend is configured at all, addTask must terminate with the router error
 * BEFORE decomposing the task and BEFORE sending any notification. These are
 * independent behavioral controls against the live Orchestrator; no source
 * text is asserted and no other suite is imported.
 */

import { describe, it, expect, vi } from "vitest";
import { Orchestrator } from "../src/lib/orchestrator.js";

/**
 * Build an Orchestrator whose notifier spies every channel. isConfigured=true
 * so the start notification WOULD fire if the preflight were skipped.
 */
function buildOrchestrator({ backends }) {
  const notifier = {
    isConfigured: true,
    notifyStart: vi.fn(() => Promise.resolve({ ok: true })),
    notifySuccess: vi.fn(() => Promise.resolve({ ok: true })),
    notifyFailure: vi.fn(() => Promise.resolve({ ok: true })),
  };
  const orch = new Orchestrator({
    agents: { backends },
    notifier,
    // If decomposition is ever reached it should throw on purpose so a
    // rejected backend can never silently fall through to the LLM.
    evolutionCompositionFactory: vi.fn(() => {
      throw new Error("should never create evolution composition");
    }),
  });
  return { orch, notifier };
}

/** Assert the preflight terminated the run without side effects. */
async function assertTerminatesBeforeWork(orch, notifier) {
  const decompose = vi.spyOn(orch, "_decompose");
  const composition = orch._evolutionCompositionFactory;
  const before = orch._tasks.size;

  await expect(orch.addTask("paid decompose me")).rejects.toBeDefined();

  expect(decompose).not.toHaveBeenCalled();
  expect(composition).not.toHaveBeenCalled();
  expect(notifier.notifyStart).not.toHaveBeenCalled();
  expect(notifier.notifySuccess).not.toHaveBeenCalled();
  expect(notifier.notifyFailure).not.toHaveBeenCalled();
  // No task record was admitted before the preflight.
  expect(orch._tasks.size).toBe(before);
  expect(orch.status().tasks).toHaveLength(before);
}

describe("paid-decomposition preflight (rejected backend)", () => {
  it("no backends configured → AGENT_ROUTER_NO_BACKENDS before decompose/notify", async () => {
    const { orch, notifier } = buildOrchestrator({ backends: [] });
    await assertTerminatesBeforeWork(orch, notifier);
    await expect(orch.addTask("again")).rejects.toMatchObject({
      code: "AGENT_ROUTER_NO_BACKENDS",
    });
  });

  it("only opaque external CLI backends → EXTERNAL_MODEL_INGRESS_UNATTESTED before decompose/notify", async () => {
    const { orch, notifier } = buildOrchestrator({
      backends: [{ type: "claude" }, { type: "codex" }],
    });
    await assertTerminatesBeforeWork(orch, notifier);
    await expect(orch.addTask("again")).rejects.toMatchObject({
      code: "AGENT_ROUTER_EXTERNAL_MODEL_INGRESS_UNATTESTED",
    });
  });

  it("a non-CLI (API) backend passes the preflight and proceeds to decompose", async () => {
    // Positive control: the preflight must only reject when EVERY backend is
    // opaque/no backend exists; an API backend must not be blocked here.
    const { orch, notifier } = buildOrchestrator({
      backends: [{ type: "openai" }],
    });
    const decompose = vi.spyOn(orch, "_decompose");
    decompose.mockRejectedValue(new Error("fake-llm-down"));

    await expect(orch.addTask("paid decompose me")).rejects.toMatchObject({
      message: "fake-llm-down",
    });
    // The preflight passed and the run reached decomposition (did not throw
    // the no-backend/CLI-only error) with exactly one admitted task.
    expect(decompose).toHaveBeenCalledTimes(1);
    expect(orch.status().tasks).toHaveLength(1);
    // The start notification is sent once decomposition begins.
    expect(notifier.notifyStart).toHaveBeenCalledTimes(1);
  });
});
