import { describe, it, expect, vi } from "vitest";
import {
  checkImageEnvelope,
  writeImageBatch,
  MAX_IMAGE_BYTES,
} from "../src/chat/image-attachments.js";

// 1x1 transparent PNG that decodes and passes the pixel/decoded budget.
const PNG_BASE64 =
  "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==";
const smallImage = { data: `data:image/png;base64,${PNG_BASE64}` };

// Build a data URL whose *decoded* size is roughly `sizeBytes`, using 'A'
// filler. checkImageEnvelope only inspects length/structure, not base64
// validity, so this lets us target exact byte-budget boundaries.
function imageOfSize(sizeBytes) {
  // decoded = ((len - comma - 1) * 3) / 4 - padding, prefix is 22 chars.
  const dataLen = Math.ceil((sizeBytes * 4) / 3);
  const padding = (4 - (dataLen % 4)) % 4;
  return { data: `data:image/png;base64,${"A".repeat(dataLen)}` + "=".repeat(padding) };
}

describe("fast multi-image add budget (verify-33)", () => {
  it("accepts a batch of several small images within the per-image and turn limits", () => {
    expect(() => checkImageEnvelope([smallImage, smallImage, smallImage])).not.toThrow();
  });

  it("rejects a single image that exceeds the 20 MiB per-image limit and names it", () => {
    const oversized = imageOfSize(MAX_IMAGE_BYTES + 1);
    expect(() => checkImageEnvelope([smallImage, oversized])).toThrow(/Image 2: .*20 MiB/);
  });

  it("rejects the offending item when consecutive additions push the running total past 20 MiB", () => {
    // Two ~11 MiB images each pass the per-image check but total ~23 MiB.
    const big = imageOfSize(11 * 1024 * 1024);
    expect(() => checkImageEnvelope([big, big])).toThrow(/Image 2: total attachments exceed 20 MiB/);
  });

  it("keeps an already-accepted attachment usable while only the later offender is rejected", () => {
    // The first small image is valid on its own and stays valid.
    expect(() => checkImageEnvelope([smallImage])).not.toThrow();
    const oversized = imageOfSize(MAX_IMAGE_BYTES + 1);
    // In the combined batch only the second (offending) item is rejected.
    expect(() => checkImageEnvelope([smallImage, oversized])).toThrow(/Image 2: .*20 MiB/);
    // The successful attachment remains individually usable afterwards.
    expect(() => checkImageEnvelope([smallImage])).not.toThrow();
  });

  it("rejects more than 4 images per message up front", () => {
    expect(() => checkImageEnvelope(Array.from({ length: 5 }, () => smallImage))).toThrow(
      "at most 4",
    );
  });

  it("writes and preserves every accepted attachment as a file", async () => {
    const opened = [];
    const written = [];
    const io = {
      open: vi.fn(async (file) => {
        opened.push(file);
        return {
          writeFile: async (data) => written.push(data.toString("base64")),
          close: vi.fn(async () => {}),
        };
      }),
      unlink: vi.fn(async () => {}),
    };
    const files = await writeImageBatch([smallImage, smallImage], { io, directory: "/tmp" });
    expect(files).toHaveLength(2);
    expect(opened).toEqual(files);
    // Both attachments were written with their exact bytes and neither was removed.
    expect(written).toEqual([PNG_BASE64, PNG_BASE64]);
    expect(io.unlink).not.toHaveBeenCalled();
  });
});
