/**
 * Fork history attribution regression coverage.
 *
 * Covers the branch-history digest/capability contract exposed by
 * src/lib/session-branch-history.js: each fork must be attributed to a valid
 * retained ancestor (its own verified message content) while remaining
 * independent — a fork must not inherit or absorb content written after the
 * branch point, and the capability must not validate a forged/foreign body.
 */
import { describe, it, expect } from "vitest";
import {
  branchContextDigest,
  branchMessageDigest,
  withSessionBranchHistory,
  resolveSessionBranchHistory,
  createBranchHistoryImport,
  BRANCH_HISTORY_SCHEMA,
  BRANCH_HISTORY_SYSTEM_ORIGINS_SCHEMA,
} from "../src/lib/session-branch-history.js";

const ancestor = [
  { role: "user", content: "branch base question" },
  { role: "assistant", content: "branch base answer" },
];

/** A plan pinned to a given fork's retained ancestor body. */
const planFor = (messages, extra = {}) => ({
  parentSessionId: "fork-root",
  contextDigest: branchContextDigest(messages),
  ...extra,
});

describe("fork history attribution", () => {
  it("digests a retained ancestor context deterministically for the same fork", () => {
    expect(branchContextDigest(ancestor)).toBe(branchContextDigest(ancestor));
    // Content written after the branch point must not collapse into the
    // branch-point digest — the retained ancestor stays a distinct anchor.
    expect(
      branchContextDigest([...ancestor, { role: "user", content: "later" }]),
    ).not.toBe(branchContextDigest(ancestor));
  });

  it("attributes each branch to its own message body, not a sibling's", () => {
    expect(branchContextDigest(ancestor)).not.toBe(
      branchContextDigest([{ role: "user", content: "independent base" }]),
    );
    // Two different fork ancestors never share a digest (independent正文).
    expect(branchMessageDigest(ancestor[0])).not.toBe(
      branchMessageDigest(ancestor[1]),
    );
  });

  it("rejects a capability whose body does not match the fork being resolved", () => {
    const plan = planFor(ancestor);
    let capability;
    withSessionBranchHistory(plan, (history) => {
      capability = history;
    });
    expect(capability).toBeTruthy();
    // The same capability validated against a body that contains sibling-tail
    // content written after the branch point must be refused.
    expect(() =>
      resolveSessionBranchHistory(
        capability,
        "fork-root",
        [...ancestor, { role: "user", content: "sibling tail" }],
      ),
    ).toThrow("expired or does not match");
    // And it must never be attributed to a different parent session.
    expect(() =>
      resolveSessionBranchHistory(capability, "other-parent", ancestor),
    ).toThrow("expired or does not match");
    // A null capability never resolves to a plan.
    expect(resolveSessionBranchHistory(null, "fork-root", ancestor)).toBeNull();
  });

  it("returns the pinned plan only for the matching fork, never a foreign one", () => {
    const plan = planFor(ancestor, { branchSessionId: "fork-child" });
    const resolved = withSessionBranchHistory(plan, (history) =>
      resolveSessionBranchHistory(history, "fork-root", ancestor),
    );
    expect(resolved).toBe(plan);
    expect(resolved).toMatchObject({ parentSessionId: "fork-root" });
  });

  it("keeps branch-history capability consumers synchronous and scoped", () => {
    expect(() =>
      withSessionBranchHistory(planFor(ancestor), async () => {}),
    ).toThrow("synchronous");
    const resolved = withSessionBranchHistory(planFor(ancestor), (history) =>
      resolveSessionBranchHistory(history, "fork-root", ancestor),
    );
    expect(resolved).toMatchObject({ parentSessionId: "fork-root" });
    // The capability is scoped to the synchronous lock: resolving it outside
    // the lock must be refused as expired.
    expect(() => resolveSessionBranchHistory(null, "fork-root", ancestor)).toBe(
      null,
    );
  });

  it("declares the v2 origins schema for durable attribution while v1 remains the base", () => {
    const importer = createBranchHistoryImport();
    expect(typeof importer.accept).toBe("function");
    expect(typeof importer.finish).toBe("function");
    expect(BRANCH_HISTORY_SYSTEM_ORIGINS_SCHEMA).toBe(
      "chainlesschain.session-branch-history/v2",
    );
    expect(BRANCH_HISTORY_SCHEMA).toBe(
      "chainlesschain.session-branch-history/v1",
    );
  });
});
