/**
 * Fork history attribution (verify-08). Independent regression coverage: each
 * fork of a parent restores valid ancestry attributed to its own namespace and
 * keeps an independent body — nothing after the branch point leaks between
 * forks or from the parent. Black-box coverage only: we drive the real store +
 * transcript-history projection and assert on observed behavior, never on
 * source text or an existing suite.
 */
import { afterAll, describe, expect, it, vi } from "vitest";
import { mkdtempSync, rmSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";

const root = mkdtempSync(join(tmpdir(), "verify08-fork-"));
vi.mock("../src/lib/paths.js", () => ({
  getHomeDir: () => join(root, "home"),
  getClaudeProjectStorageDir: () => null,
  getStatePath: () => join(root, "home", "state"),
  getMachineSecurityAnchorDir: () => join(root, "security"),
}));
const store = await import("../src/harness/jsonl-session-store.js");
const { readSessionTranscriptHistory, createSessionTranscriptBranchProjection } =
  await import("../src/lib/session-transcript-history.js");

afterAll(() => rmSync(root, { recursive: true, force: true }));

function start(id, count = 2) {
  store.startSession(id, { provider: "test", model: "test" });
  for (let i = 0; i < count; i++) {
    store.appendUserMessage(id, `q-${i}`);
    store.appendAssistantMessage(id, `a-${i}`);
  }
}
function texts(page) {
  return page.messages.map((m) => m.text);
}
function historyBranch(parentSessionId, branchSessionId, retainedMessageCount) {
  const messages = store
    .readVerifiedMessages(parentSessionId)
    .slice(0, retainedMessageCount);
  const head = store.findLatestEvent(parentSessionId, null).hash;
  return store.withSessionAuthorityTransaction(
    parentSessionId,
    head,
    (transaction) =>
      transaction.readProjection(() =>
        createSessionTranscriptBranchProjection(
          parentSessionId,
          messages,
          (history) =>
            store.createBranchSession({
              parentSessionId,
              branchSessionId,
              parentTurnId: "selected",
              messages,
              history,
            }),
        ),
      ),
  );
}

describe("verify-08 fork history attribution", () => {
  it("attributes the same shared ancestry to each fork in its own namespace", () => {
    const parent = "verify08-fork-parent";
    const b1 = "verify08-fork-b1";
    const b2 = "verify08-fork-b2";
    start(parent, 2);
    const original = readSessionTranscriptHistory(parent);
    historyBranch(parent, b1, 3);
    historyBranch(parent, b2, 3);
    const page1 = readSessionTranscriptHistory(b1);
    const page2 = readSessionTranscriptHistory(b2);
    expect(texts(page1)).toEqual(texts(original));
    expect(texts(page2)).toEqual(texts(original));
    expect(texts(page1)).toEqual(texts(page2));
    expect(page1.messages[0].id).toMatch(new RegExp(`^${b1}:`));
    expect(page2.messages[0].id).toMatch(new RegExp(`^${b2}:`));
    expect(page1.messages[0].id).not.toBe(page2.messages[0].id);
    expect(page1.coverage.kind).toBe("from-origin");
    expect(page2.coverage.kind).toBe("from-origin");
  });

  it("does not leak parent content appended after the branch into a fork", () => {
    const parent = "verify08-fork-leak-parent";
    const child = "verify08-fork-leak-child";
    start(parent, 1);
    historyBranch(parent, child, 2);
    store.appendUserMessage(parent, "post-branch-parent");
    store.appendAssistantMessage(parent, "post-branch-answer");
    expect(texts(readSessionTranscriptHistory(child))).toEqual(["q-0", "a-0"]);
    expect(texts(readSessionTranscriptHistory(parent))).toEqual([
      "q-0",
      "a-0",
      "post-branch-parent",
      "post-branch-answer",
    ]);
  });

  it("keeps sibling fork bodies independent", () => {
    const parent = "verify08-fork-sibling-parent";
    const b1 = "verify08-fork-sib-b1";
    const b2 = "verify08-fork-sib-b2";
    start(parent, 1);
    historyBranch(parent, b1, 2);
    historyBranch(parent, b2, 2);
    store.appendUserMessage(b1, "b1 only");
    store.appendAssistantMessage(b1, "b1 answer");
    expect(texts(readSessionTranscriptHistory(b1))).toEqual([
      "q-0",
      "a-0",
      "b1 only",
      "b1 answer",
    ]);
    expect(texts(readSessionTranscriptHistory(b2))).toEqual(["q-0", "a-0"]);
  });

  it("keeps a fork's own ancestry attributed to it after later appends", () => {
    const parent = "verify08-fork-grow-parent";
    const child = "verify08-fork-grow-child";
    start(parent, 2);
    historyBranch(parent, child, 3);
    const before = readSessionTranscriptHistory(child);
    store.appendUserMessage(child, "branch turn");
    store.appendAssistantMessage(child, "branch answer");
    const after = readSessionTranscriptHistory(child);
    expect(after.messages.map((m) => m.id)).toEqual([
      ...before.messages.map((m) => m.id),
      ...after.messages.slice(before.messages.length).map((m) => m.id),
    ]);
    expect(texts(after)).toEqual([
      "q-0",
      "a-0",
      "q-1",
      "branch turn",
      "branch answer",
    ]);
    expect(after.messages.every((m) => m.id.startsWith(`${child}:`))).toBe(true);
  });

  it("rejects reading one fork with a history cursor minted in its sibling", () => {
    const parent = "verify08-fork-cursor-parent";
    const b1 = "verify08-fork-cursor-b1";
    const b2 = "verify08-fork-cursor-b2";
    start(parent, 2);
    historyBranch(parent, b1, 3);
    historyBranch(parent, b2, 3);
    const cursor = readSessionTranscriptHistory(b1, { limit: 1 }).nextCursor;
    expect(() => readSessionTranscriptHistory(b2, { cursor })).toThrow();
  });

  it("preserves ancestry through a nested fork with its own attribution", () => {
    const parent = "verify08-fork-nested-parent";
    const child = "verify08-fork-nested-child";
    const grand = "verify08-fork-nested-grand";
    start(parent, 1);
    historyBranch(parent, child, 2);
    historyBranch(child, grand, 2);
    store.appendUserMessage(grand, "grand turn");
    const page = readSessionTranscriptHistory(grand);
    expect(texts(page)).toEqual(["q-0", "a-0", "grand turn"]);
    expect(page.messages.every((m) => m.id.startsWith(`${grand}:`))).toBe(true);
  });
});
