import { describe, expect, it } from "vitest";
import {
  BackgroundInteractionJournal,
  classifyLateBackgroundInteractionSettlement,
} from "../src/lib/background-interaction-journal.js";

const baseBinding = {
  backgroundAgentId: "bg-journal-verify-11",
  sessionId: "session-a",
  turnId: "turn-1",
  toolUseId: "tool-1",
  sequence: 1,
};

describe("verify-11: durable journal problem ownership", () => {
  it("does not leak a resolved answer across sessions that reuse the same request id", () => {
    const sessionA = new BackgroundInteractionJournal({
      backgroundAgentId: "bg-journal-verify-11",
      sessionId: "session-a",
    });
    const sessionB = new BackgroundInteractionJournal({
      backgroundAgentId: "bg-journal-verify-11",
      sessionId: "session-b",
    });
    const sharedRequestId = "request-same-name";
    sessionA.recordPending({
      requestId: sharedRequestId,
      binding: { ...baseBinding, sessionId: "session-a" },
      payload: { kind: "question", question: "Deploy?" },
    });
    sessionB.recordPending({
      requestId: sharedRequestId,
      binding: { ...baseBinding, sessionId: "session-b" },
      payload: { kind: "question", question: "Deploy?" },
    });

    expect(
      sessionA.settle(sharedRequestId, { ...baseBinding, sessionId: "session-a" }, {
        status: "resolved",
        answer: "yes",
      }).applied,
    ).toBe(true);

    // Session A is terminal with its own answer.
    expect(sessionA.get(sharedRequestId)).toMatchObject({
      status: "resolved",
      settlement: { status: "resolved", answer: "yes", error: null },
    });
    // Session B remains pending and independent; it has not absorbed A's value.
    expect(sessionB.get(sharedRequestId)).toMatchObject({ status: "pending" });
    expect(
      sessionB.settle(sharedRequestId, { ...baseBinding, sessionId: "session-b" }, {
        status: "resolved",
        answer: "no",
      }).applied,
    ).toBe(true);
    expect(sessionB.get(sharedRequestId)).toMatchObject({
      status: "resolved",
      settlement: { status: "resolved", answer: "no", error: null },
    });
  });

  it("cannot settle a request through another session's journal", () => {
    const sessionA = new BackgroundInteractionJournal({
      backgroundAgentId: "bg-journal-verify-11",
      sessionId: "session-a",
    });
    sessionA.recordPending({
      requestId: "request-owned-a",
      binding: { ...baseBinding, sessionId: "session-a" },
      payload: { question: "Deploy?" },
    });
    const sessionB = new BackgroundInteractionJournal({
      backgroundAgentId: "bg-journal-verify-11",
      sessionId: "session-b",
    });
    expect(sessionB.get("request-owned-a")).toBeNull();
    expect(() =>
      sessionB.settle(
        "request-owned-a",
        { ...baseBinding, sessionId: "session-a" },
        { status: "resolved", answer: "yes" },
      ),
    ).toThrow(/Unknown background interaction request/);
  });

  it("a completed record is not re-settled into a new terminal outcome", () => {
    const journal = new BackgroundInteractionJournal({
      backgroundAgentId: "bg-journal-verify-11",
      sessionId: "session-a",
    });
    journal.recordPending({
      requestId: "request-complete",
      binding: { ...baseBinding, sessionId: "session-a" },
      payload: { question: "Deploy?" },
    });
    journal.settle("request-complete", { ...baseBinding, sessionId: "session-a" }, {
      status: "resolved",
      answer: "yes",
    });
    // Exact replay is idempotent: applied:false, no rebuild of authority.
    expect(
      journal.settle("request-complete", { ...baseBinding, sessionId: "session-a" }, {
        status: "resolved",
        answer: "yes",
      }),
    ).toEqual({ applied: false, record: expect.objectContaining({ status: "resolved" }) });
    // A different terminal outcome must be rejected, not silently replace it.
    expect(() =>
      journal.settle("request-complete", { ...baseBinding, sessionId: "session-a" }, {
        status: "cancelled",
        error: { code: "INTERACTION_CANCELLED", message: "timeout" },
      }),
    ).toThrow(/already settled/);
    expect(journal.get("request-complete")).toMatchObject({
      status: "resolved",
      settlement: { answer: "yes" },
    });
  });

  it("a late settlement of a completed record is acknowledged only as a duplicate, never delivered", () => {
    const journal = new BackgroundInteractionJournal({
      backgroundAgentId: "bg-journal-verify-11",
      sessionId: "session-a",
    });
    journal.recordPending({
      requestId: "request-late-complete",
      binding: { ...baseBinding, sessionId: "session-a" },
      payload: { question: "Deploy?" },
    });
    journal.settle("request-late-complete", { ...baseBinding, sessionId: "session-a" }, {
      status: "resolved",
      answer: "yes",
    });

    // Late exact replay: accepted but duplicate, and never re-delivered/executed.
    expect(
      classifyLateBackgroundInteractionSettlement(
        journal,
        "request-late-complete",
        { ...baseBinding, sessionId: "session-a" },
        { status: "resolved", answer: "yes" },
      ),
    ).toEqual({ accepted: true, duplicate: true, delivered: false });
  });

  it("a still-pending record rejects late settlement instead of granting execution", () => {
    const journal = new BackgroundInteractionJournal({
      backgroundAgentId: "bg-journal-verify-11",
      sessionId: "session-a",
    });
    journal.recordPending({
      requestId: "request-pending-late",
      binding: { ...baseBinding, sessionId: "session-a" },
      payload: { question: "Deploy?" },
    });
    expect(
      classifyLateBackgroundInteractionSettlement(
        journal,
        "request-pending-late",
        { ...baseBinding, sessionId: "session-a" },
        { status: "resolved", answer: "yes" },
      ),
    ).toMatchObject({ accepted: false, reason: "interaction_no_live_child" });
    expect(journal.get("request-pending-late").status).toBe("pending");
  });

  it("a completed record's answer survives a snapshot round-trip in its own session only", () => {
    const journal = new BackgroundInteractionJournal({
      backgroundAgentId: "bg-journal-verify-11",
      sessionId: "session-a",
    });
    journal.recordPending({
      requestId: "request-roundtrip",
      binding: { ...baseBinding, sessionId: "session-a" },
      payload: { question: "Deploy?" },
    });
    journal.settle("request-roundtrip", { ...baseBinding, sessionId: "session-a" }, {
      status: "resolved",
      answer: "yes",
    });
    const reloaded = BackgroundInteractionJournal.fromJSON(journal.toJSON(), {
      expectedSessionId: "session-a",
    });
    expect(reloaded.get("request-roundtrip")).toMatchObject({
      status: "resolved",
      settlement: { answer: "yes" },
    });
    // A different-session journal snapshot for the same background agent stays empty.
    const otherSession = new BackgroundInteractionJournal({
      backgroundAgentId: "bg-journal-verify-11",
      sessionId: "session-b",
    });
    expect(otherSession.get("request-roundtrip")).toBeNull();
  });
});
