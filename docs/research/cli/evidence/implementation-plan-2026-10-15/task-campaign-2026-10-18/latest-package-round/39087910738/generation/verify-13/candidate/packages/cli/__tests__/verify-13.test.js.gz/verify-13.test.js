import { afterAll, describe, expect, it, vi } from "vitest";
import fs from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import {
  MAX_INPUT_IMAGE_BYTES,
  readBoundedImage,
} from "../src/lib/image-file-boundary.js";

// Minimal self-contained 1x1 PNG admitted by inspectImageHeader.
const PNG_BYTES = Buffer.concat([
  Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), // PNG signature
  Buffer.from([0, 0, 0, 13]), // IHDR length == 13
  Buffer.from("IHDR"),
  Buffer.from([0, 0, 0, 1, 0, 0, 0, 1]), // width = 1, height = 1
  Buffer.from([8, 6, 0, 0, 0, 0, 0, 0, 0]), // bit-depth/color padding
]);

const root = fs.mkdtempSync(join(tmpdir(), "cc-verify-13-"));
afterAll(() => fs.rmSync(root, { recursive: true, force: true }));

function writeFile(name, data = PNG_BYTES, size) {
  const target = join(root, name);
  fs.writeFileSync(target, data);
  if (size) fs.truncateSync(target, size);
  return target;
}

/** io object that delegates to real fs but records readSync/closeSync calls. */
function spyIo() {
  return {
    openSync: (file, flags) => fs.openSync(file, flags),
    fstatSync: fs.fstatSync,
    readSync: vi.fn((...args) => fs.readSync(...args)),
    closeSync: vi.fn((...args) => fs.closeSync(...args)),
  };
}

describe("readBoundedImage same-handle read boundary", () => {
  it("rejects an oversized regular file before any read and closes the handle", () => {
    const target = writeFile("oversized.png", PNG_BYTES, 1024); // real handle
    const io = spyIo();
    io.fstatSync = () => ({
      size: MAX_INPUT_IMAGE_BYTES + 1,
      mtimeMs: 1,
      ctimeMs: 1,
      isFile: () => true,
    });
    expect(() =>
      readBoundedImage(target, "image/png", MAX_INPUT_IMAGE_BYTES, io),
    ).toThrow(/1 byte to 20 MiB/);
    expect(io.readSync).not.toHaveBeenCalled();
    expect(io.closeSync).toHaveBeenCalledOnce();
  });

  it("rejects a file whose size exceeds the remaining byte budget before reading", () => {
    const target = writeFile("over-budget.png"); // small real file
    const io = spyIo();
    expect(() =>
      readBoundedImage(target, "image/png", PNG_BYTES.length - 1, io),
    ).toThrow(/Total image attachments exceed 20 MiB per message/);
    expect(io.readSync).not.toHaveBeenCalled();
    expect(io.closeSync).toHaveBeenCalledOnce();
  });

  it("rejects a non-regular handle, reads nothing, and closes it", () => {
    const io = spyIo();
    io.fstatSync = () => ({
      size: PNG_BYTES.length,
      mtimeMs: 1,
      ctimeMs: 1,
      isFile: () => false,
    });
    expect(() =>
      readBoundedImage("pipe.png", "image/png", MAX_INPUT_IMAGE_BYTES, io),
    ).toThrow(/regular file/);
    expect(io.readSync).not.toHaveBeenCalled();
    expect(io.closeSync).toHaveBeenCalledOnce();
  });

  it("rejects a media-type mismatch against the pinned handle and closes it", () => {
    const target = writeFile("mismatch.png");
    const io = spyIo();
    expect(() =>
      readBoundedImage(target, "image/jpeg", MAX_INPUT_IMAGE_BYTES, io),
    ).toThrow(/extension does not match/);
    expect(io.closeSync).toHaveBeenCalledOnce();
  });

  it("returns the bytes of a normal small image and closes the handle", () => {
    const target = writeFile("ok.png");
    const io = spyIo();
    const result = readBoundedImage(
      target,
      "image/png",
      MAX_INPUT_IMAGE_BYTES,
      io,
    );
    expect(result).toEqual(PNG_BYTES);
    expect(io.closeSync).toHaveBeenCalledOnce();
    expect(io.readSync).toHaveBeenCalled();
  });

  it("detects the file changing while read on the same handle and closes it", () => {
    const target = writeFile("mutating.png");
    let changed = false;
    const io = spyIo();
    io.readSync = vi.fn((...args) => {
      const count = fs.readSync(...args);
      if (!changed) {
        changed = true;
        fs.appendFileSync(target, Buffer.alloc(64));
      }
      return count;
    });
    expect(() =>
      readBoundedImage(target, "image/png", MAX_INPUT_IMAGE_BYTES, io),
    ).toThrow(/changed while being read/);
    expect(io.closeSync).toHaveBeenCalledOnce();
  });
});
