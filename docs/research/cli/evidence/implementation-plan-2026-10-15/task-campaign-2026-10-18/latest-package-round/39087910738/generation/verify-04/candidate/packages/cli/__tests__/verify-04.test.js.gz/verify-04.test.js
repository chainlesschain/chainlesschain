import { describe, it, expect } from "vitest";
import { mergeUsagePricingBucket } from "../src/lib/usage-pricing-context.js";
import { estimateCost, priceRollup } from "../src/lib/llm-pricing.js";

// The long-context pricing threshold: a request whose full prompt (input +
// cache read + cache creation) exceeds this value is billed under the long
// context tier. gpt-6-sol is a documented OpenAI model with pricing {in:2,out:10}.
// mergeUsagePricingBucket(entry, usage) mutates entry.pricingBuckets by
// classifying each request into the bucket that matches its own per-request
// prompt tokens (cache + long context included), service tier and region.
describe("request-level cache and tiered usage buckets", () => {
  const sol = (usage) => ({
    provider: "openai",
    model: "gpt-6-sol",
    usage,
  });

  it("prices equal total tokens per request contract by cache/long split", () => {
    // Both requests carry the SAME total token count (273000), but one stays
    // short (prompt 272000, all billed input) while the other crosses the long
    // threshold only because 73000 tokens come from the cache read bucket.
    const short = sol({
      inputTokens: 272000,
      outputTokens: 1000,
      cacheReadTokens: 0,
    });
    const longCached = sol({
      inputTokens: 200000,
      outputTokens: 0,
      cacheReadTokens: 73000,
    });
    expect(
      short.usage.inputTokens +
        short.usage.outputTokens +
        (short.usage.cacheReadTokens || 0),
    ).toBe(273000);
    expect(
      longCached.usage.inputTokens +
        longCached.usage.outputTokens +
        (longCached.usage.cacheReadTokens || 0),
    ).toBe(273000);

    const entry = { provider: "openai", model: "gpt-6-sol", pricingBuckets: [] };
    mergeUsagePricingBucket(entry, short.usage);
    mergeUsagePricingBucket(entry, longCached.usage);

    // Equal totals but different per-request prompt composition must be kept in
    // distinct tiers rather than merged into one blended bucket.
    expect(entry.pricingBuckets).toHaveLength(2);
    const byPrompt = [...entry.pricingBuckets]
      .map((b) => b.requestInputTokens)
      .sort((a, b) => a - b);
    expect(byPrompt).toEqual([272000, 273000]);

    // Rolling the two buckets up equals the sum of each request's own contract.
    const expected =
      estimateCost(short.usage).totalCost +
      estimateCost(longCached.usage).totalCost;
    expect(priceRollup({ byModel: [entry] }).cost.totalCost).toBeCloseTo(
      expected,
      9,
    );

    // Each bucket preserves its own token ledger (cache read stays its own field).
    const cached = entry.pricingBuckets.find(
      (b) => b.requestInputTokens === 273000,
    );
    expect(cached).toMatchObject({
      cacheReadTokens: 73000,
      inputTokens: 200000,
      outputTokens: 0,
      totalTokens: 273000,
      calls: 1,
      serviceTier: "standard",
      regionalProcessing: false,
    });
  });

  it("accumulates same-tier requests into a single bucket with correct sums", () => {
    const entry = { provider: "openai", model: "gpt-6-sol", pricingBuckets: [] };
    mergeUsagePricingBucket(
      entry,
      sol({ inputTokens: 1000, outputTokens: 50 }).usage,
    );
    mergeUsagePricingBucket(
      entry,
      sol({ inputTokens: 2000, outputTokens: 100 }).usage,
    );
    expect(entry.pricingBuckets).toHaveLength(1);
    expect(entry.pricingBuckets[0]).toMatchObject({
      inputTokens: 3000,
      outputTokens: 150,
      cacheReadTokens: 0,
      cacheCreationTokens: 0,
      totalTokens: 3150,
      calls: 2,
      requestInputTokens: 1000,
      serviceTier: "standard",
      regionalProcessing: false,
    });
  });

  it("splits service tier and regional processing into separate buckets", () => {
    const entry = { provider: "openai", model: "gpt-6-sol", pricingBuckets: [] };
    mergeUsagePricingBucket(
      entry,
      sol({ inputTokens: 1000, service_tier: "fast", regional_processing: true })
        .usage,
    );
    mergeUsagePricingBucket(
      entry,
      sol({ inputTokens: 1000, service_tier: "flex", regional_processing: true })
        .usage,
    );
    expect(entry.pricingBuckets).toHaveLength(2);
    const fast = entry.pricingBuckets.find((b) => b.serviceTier === "fast");
    const flex = entry.pricingBuckets.find((b) => b.serviceTier === "flex");
    expect(fast).toMatchObject({ calls: 1, serviceTier: "fast", regionalProcessing: true });
    expect(flex).toMatchObject({ calls: 1, serviceTier: "flex", regionalProcessing: true });
  });

  it("honors an explicit requestInputTokens for the long-context decision", () => {
    const entry = { provider: "openai", model: "gpt-6-sol", pricingBuckets: [] };
    // inputTokens alone would look long, but the explicit per-request prompt
    // keeps it in the short tier.
    mergeUsagePricingBucket(
      entry,
      sol({ inputTokens: 300000, outputTokens: 10, requestInputTokens: 200000 })
        .usage,
    );
    expect(entry.pricingBuckets).toHaveLength(1);
    expect(entry.pricingBuckets[0]).toMatchObject({
      requestInputTokens: 200000,
      inputTokens: 300000,
      totalTokens: 300010,
    });
  });

  it("skips non-OpenAI providers entirely", () => {
    const entry = { provider: "anthropic", model: "claude-opus-5-5", usage: {} };
    mergeUsagePricingBucket(entry, {
      inputTokens: 300000,
      outputTokens: 1000,
    });
    expect(entry.pricingBuckets).toBeUndefined();
  });

  it("skips documented OpenAI models without pricing terms", () => {
    // gpt-4o is documented but carries no pricing entry, so it cannot be priced.
    const entry = { provider: "openai", model: "gpt-4o", pricingBuckets: [] };
    mergeUsagePricingBucket(entry, { inputTokens: 1000, outputTokens: 10 });
    expect(entry.pricingBuckets).toHaveLength(0);
  });
});
