import { describe, expect, it } from "vitest";
import { mergeUsagePricingBucket } from "../../src/lib/usage-pricing-context.js";
import { priceRollup, estimateCost } from "../../src/lib/llm-pricing.js";

const MODEL = "gpt-6-sol";
const PROVIDER = "openai";

function build(requests) {
  const entry = { provider: PROVIDER, model: MODEL };
  for (const usage of requests) mergeUsagePricingBucket(entry, usage);
  return entry;
}

function bucketTotals(entry) {
  return entry.pricingBuckets.reduce(
    (acc, b) => {
      acc.inputTokens += b.inputTokens;
      acc.cacheReadTokens += b.cacheReadTokens;
      acc.outputTokens += b.outputTokens;
      return acc;
    },
    { inputTokens: 0, cacheReadTokens: 0, outputTokens: 0 },
  );
}

function rolledCost(entry) {
  return priceRollup({ byModel: [entry] }).byModel[0].cost;
}

describe("request-level caching and long-context pricing", () => {
  it("prices the same total tokens differently by long/short request distribution", () => {
    const oneLongOneShort = build([
      { inputTokens: 200000, cacheReadTokens: 73000, outputTokens: 1000, totalTokens: 274000 },
      { inputTokens: 200000, outputTokens: 0, totalTokens: 200000 },
    ]);
    const twoShort = build([
      { inputTokens: 200000, cacheReadTokens: 36500, outputTokens: 500, totalTokens: 237000 },
      { inputTokens: 200000, cacheReadTokens: 36500, outputTokens: 500, totalTokens: 237000 },
    ]);

    // Same total token composition across both request sets.
    expect(bucketTotals(oneLongOneShort)).toEqual(bucketTotals(twoShort));
    // Different per-request long-context classification -> different buckets.
    expect(oneLongOneShort.pricingBuckets).toHaveLength(2);
    expect(twoShort.pricingBuckets).toHaveLength(1);
    // Different classification -> different per-request contract cost.
    expect(rolledCost(oneLongOneShort)).not.toBeCloseTo(
      rolledCost(twoShort),
      6,
    );
  });

  it("prices every request at its own threshold, summing per-request estimates", () => {
    const a1 = { inputTokens: 200000, cacheReadTokens: 73000, outputTokens: 1000, totalTokens: 274000 };
    const a2 = { inputTokens: 200000, outputTokens: 0, totalTokens: 200000 };
    const entry = build([a1, a2]);
    const expected =
      estimateCost({ provider: PROVIDER, model: MODEL, inputTokens: a1.inputTokens, cacheReadTokens: a1.cacheReadTokens, outputTokens: a1.outputTokens }).totalCost +
      estimateCost({ provider: PROVIDER, model: MODEL, inputTokens: a2.inputTokens, outputTokens: a2.outputTokens }).totalCost;
    expect(rolledCost(entry)).toBeCloseTo(expected, 10);
    // The long bucket alone carries the full long-context markup; the short
    // bucket carries only the short request.
    const longBucket = entry.pricingBuckets.find((b) => b.requestInputTokens > 272000);
    const shortBucket = entry.pricingBuckets.find((b) => b.requestInputTokens <= 272000);
    expect(
      estimateCost({ provider: PROVIDER, model: MODEL, inputTokens: longBucket.inputTokens, cacheReadTokens: longBucket.cacheReadTokens, outputTokens: longBucket.outputTokens }).totalCost,
    ).toBeCloseTo(
      priceRollup({ byModel: [{ ...entry, pricingBuckets: [longBucket] }] }).byModel[0].cost,
      10,
    );
    expect(
      estimateCost({ provider: PROVIDER, model: MODEL, inputTokens: shortBucket.inputTokens, outputTokens: shortBucket.outputTokens }).totalCost,
    ).toBeCloseTo(
      priceRollup({ byModel: [{ ...entry, pricingBuckets: [shortBucket] }] }).byModel[0].cost,
      10,
    );
  });

  it("keeps the cost additive when only cache is redistributed within the same short class", () => {
    const splitCache = build([
      { inputTokens: 100000, outputTokens: 0, totalTokens: 100000 },
      { inputTokens: 100000, cacheReadTokens: 20000, outputTokens: 0, totalTokens: 120000 },
    ]);
    const mergedCache = build([
      { inputTokens: 120000, outputTokens: 0, totalTokens: 120000 },
      { inputTokens: 80000, cacheReadTokens: 20000, outputTokens: 0, totalTokens: 100000 },
    ]);
    expect(splitCache.pricingBuckets).toHaveLength(1);
    expect(mergedCache.pricingBuckets).toHaveLength(1);
    expect(bucketTotals(splitCache)).toEqual(bucketTotals(mergedCache));
    expect(rolledCost(splitCache)).toBeCloseTo(rolledCost(mergedCache), 10);
  });

  it("does not re-blend a long request into a single short-class aggregate", () => {
    const entry = build([
      { inputTokens: 200000, cacheReadTokens: 73000, outputTokens: 1000, totalTokens: 274000 },
      { inputTokens: 200000, outputTokens: 0, totalTokens: 200000 },
    ]);
    const reBlendedShort = estimateCost({
      provider: PROVIDER,
      model: MODEL,
      inputTokens: 400000,
      cacheReadTokens: 73000,
      outputTokens: 1000,
      requestInputTokens: 200000,
    }).totalCost;
    // A naive single short bucket would underprice the 273k-token request.
    expect(rolledCost(entry)).not.toBeCloseTo(reBlendedShort, 6);
  });

  it("refuses to price a legacy multi-call row that lacks request buckets", () => {
    const row = {
      provider: PROVIDER,
      model: MODEL,
      inputTokens: 400000,
      cacheReadTokens: 73000,
      outputTokens: 1000,
      calls: 2,
    };
    const priced = priceRollup({ byModel: [row] }).byModel[0];
    expect(priced.matched).toBe(false);
    expect(priced.cost).toBe(0);
  });
});
