import { describe, it, expect, vi } from "vitest";
import {
  createImagePreviewGate,
  drawImagePreview,
} from "../src/chat/image-preview-gate.js";

describe("image preview gate: page switch / cancel drops late previews", () => {
  function workerHarness() {
    const workers = [];
    const gate = createImagePreviewGate({
      workerFactory: () => {
        const worker = { postMessage() {}, terminate: vi.fn() };
        workers.push(worker);
        return worker;
      },
    });
    return { gate, workers };
  }

  it("explicit cancel never delivers a late preview and closes its bitmaps", async () => {
    const { gate, workers } = workerHarness();
    const pending = gate.validate([]);
    const rejected = expect(pending).rejects.toThrow("cancelled");
    gate.cancel();
    const lateBitmap = { close: vi.fn() };
    workers[0].onmessage({
      data: { results: [{ thumbnails: [{ bitmap: lateBitmap }] }] },
    });
    await rejected;
    // The late preview was dropped: its bitmap is closed, not handed to a page.
    expect(lateBitmap.close).toHaveBeenCalledOnce();
    expect(workers[0].terminate).toHaveBeenCalledOnce();
  });

  it("page switch: the previous page's late preview is dropped; only the current page's result is delivered", async () => {
    const { gate, workers } = workerHarness();
    const oldPage = gate.validate([{ data: "old" }]);
    const oldRejected = expect(oldPage).rejects.toThrow("cancelled");
    const newPage = gate.validate([{ data: "new" }]);
    const oldBitmap = { close: vi.fn() };
    const freshResult = { thumbnails: [{ bitmap: { close: vi.fn() } }] };
    // The old decoder finishes after the page already switched.
    workers[0].onmessage({
      data: { results: [{ thumbnails: [{ bitmap: oldBitmap }] }] },
    });
    workers[1].onmessage({ data: { results: [freshResult] } });
    await oldRejected;
    // The current page sees only its own preview; the stale one is disposed.
    expect(await newPage).toEqual([freshResult]);
    expect(oldBitmap.close).toHaveBeenCalledOnce();
    expect(freshResult.thumbnails[0].bitmap.close).not.toHaveBeenCalled();
    expect(workers[1].terminate).toHaveBeenCalledOnce();
  });

  it("current page: a completed preview without cancellation is delivered intact and drawn", async () => {
    const { gate, workers } = workerHarness();
    const bitmap = { close: vi.fn() };
    const result = { repetitions: 1, thumbnails: [{ bitmap, duration: 100 }] };
    const pending = gate.validate([]);
    workers[0].onmessage({ data: { results: [result] } });
    const [delivered] = await pending;
    // The current page receives the exact decoded result for drawing.
    expect(delivered).toBe(result);
    const context = { clearRect() {}, drawImage: vi.fn() };
    const stop = drawImagePreview({ getContext: () => context }, result);
    expect(context.drawImage).toHaveBeenCalledWith(bitmap, 0, 0);
    // The retained bitmap is owned by the page, not disposed by the gate.
    expect(bitmap.close).not.toHaveBeenCalled();
    stop();
  });

  it("page switch with no late message still rejects the old promise and terminates its worker", async () => {
    const { gate, workers } = workerHarness();
    const oldPage = gate.validate([{ data: "old" }]);
    const oldRejected = expect(oldPage).rejects.toThrow("cancelled");
    gate.validate([{ data: "new" }]);
    await oldRejected;
    expect(workers[0].terminate).toHaveBeenCalledOnce();
    // A worker that never resolved cannot deliver into the new page.
    expect(workers[1].terminate).toHaveBeenCalledTimes(0);
  });

  it("a fresh validate after a cancelled one still delivers the current preview normally", async () => {
    const { gate, workers } = workerHarness();
    const cancelled = gate.validate([{ data: "old" }]);
    const oldRejected = expect(cancelled).rejects.toThrow("cancelled");
    gate.cancel();
    await oldRejected;
    const bitmap = { close: vi.fn() };
    const result = { repetitions: 1, thumbnails: [{ bitmap, duration: 100 }] };
    const current = gate.validate([]);
    workers[0].onmessage({ data: { results: [result] } });
    const [delivered] = await current;
    expect(delivered).toBe(result);
    expect(bitmap.close).not.toHaveBeenCalled();
  });
});
