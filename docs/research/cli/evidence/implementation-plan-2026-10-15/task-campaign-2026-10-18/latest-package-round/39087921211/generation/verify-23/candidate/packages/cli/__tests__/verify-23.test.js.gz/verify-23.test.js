import { describe, expect, it } from "vitest";
import {
  createEvalComparison,
  createEvalHistoryRecord,
  EVAL_CONTEXT_SCHEMA,
  EVAL_EXECUTION_PROTOCOL,
} from "../src/lib/eval/evidence.js";
import {
  buildOutcomeReport,
  outcomeDigest,
  OUTCOME_PLAN_SCHEMA,
} from "../src/lib/eval/outcomes.js";

const NOW = Date.parse("2026-09-15T12:00:00.000Z");
const SHA = "a".repeat(40);
const D = (letter) => `sha256:${letter.repeat(64)}`;
const STAGES = ["install", "configure", "authenticate", "tool", "artifact"];

function validFixture(sampleDefs) {
  const comparison = createEvalComparison({
    suite: "builtin",
    corpusDigest: D("a"),
    provider: "test",
    model: "test-model",
    context: {
      schema: EVAL_CONTEXT_SCHEMA,
      provider: "test",
      model: "test-model",
      modelRevision: "test-r1",
      environmentDigest: D("b"),
      permissionDigest: D("c"),
      inferenceDigest: D("d"),
    },
  });
  const window = {
    start: "2026-09-15T10:00:00.000Z",
    end: "2026-09-15T11:00:00.000Z",
  };
  const samples = sampleDefs.map((def, index) => ({
    id: def.id,
    kind: def.kind ?? "task",
    taskId: def.taskId ?? "fix-build",
    stratum: def.stratum ?? "windows-cli-test",
    comparisonDigest: outcomeDigest(comparison),
    timeBudgetMs: 1000,
    costBudget: 1,
  }));
  const runs = samples.map((sample, index) =>
    createEvalHistoryRecord(
      {
        total: 1,
        passed: 1,
        failed: 0,
        passRate: 1,
        unrelatedChangeRate: 0,
        results: [
          {
            id: sample.taskId,
            pass: true,
            artifactCheckPassed: true,
            executionSucceeded: true,
            agentOk: true,
            error: null,
            ms: 100,
            executionEvidence: {
              protocol: EVAL_EXECUTION_PROTOCOL,
              exitCode: 0,
              signal: null,
              terminalVerified: true,
              observedFallback: false,
            },
          },
        ],
      },
      {
        runId: `run-${index}`,
        ranAt: "2026-09-15T10:30:00.000Z",
        label: SHA,
        comparison,
      },
    ),
  );
  return {
    plan: {
      schema: OUTCOME_PLAN_SCHEMA,
      commitSha: SHA,
      currency: "USD",
      window,
      samples,
    },
    history: { runs, issues: [] },
    observations: samples.map((sample, index) => ({
      sampleId: sample.id,
      observedAt: "2026-09-15T10:30:00.000Z",
      runId: `run-${index}`,
      cost: 0.1,
      elapsedMs: 500,
      retries: 0,
      manualRepairs: 0,
      ...(sample.kind === "first-run"
        ? {
            firstRun: {
              cleanEnvironment: true,
              stages: Object.fromEntries(
                STAGES.map((stage) => [
                  stage,
                  { passed: true, receipt: `receipt:${stage}` },
                ]),
              ),
            },
          }
        : {}),
    })),
    maintenance: { window, complete: true, entries: [] },
  };
}
const report = (input) => buildOutcomeReport(input, { now: NOW });

describe("verify-23 missing samples keep a fixed planned denominator", () => {
  it("keeps all planned samples as the fixed success-rate denominator when some are missing", () => {
    const input = validFixture([{ id: "a" }, { id: "b" }, { id: "c" }]);
    input.observations = input.observations.filter(
      (observation) => observation.sampleId !== "c",
    );
    const result = report(input);
    expect(result.task).toMatchObject({
      planned: 3,
      observed: 2,
      missing: 1,
      succeeded: 2,
      successRate: 2 / 3,
    });
    expect(result.status).toBe("INSUFFICIENT_EVIDENCE");
  });

  it("keeps an observed-but-unknown cost null instead of turning it into zero", () => {
    const input = validFixture([{ id: "a" }, { id: "b" }]);
    input.observations.find((o) => o.sampleId === "b").cost = NaN;
    const result = report(input);
    expect(result.task).toMatchObject({
      planned: 2,
      observed: 2,
      totalCost: null,
      costPerSuccess: null,
    });
    expect(result.task.knownCost).toBe(0.1);
  });

  it("sums costs only when every observed sample reports a real value (negative control)", () => {
    const input = validFixture([{ id: "a" }, { id: "b" }]);
    input.observations.find((o) => o.sampleId === "b").cost = 0.4;
    const result = report(input);
    expect(result.task).toMatchObject({
      planned: 2,
      observed: 2,
      succeeded: 2,
      totalCost: 0.5,
      costPerSuccess: 0.25,
    });
    expect(result.task.knownCost).toBe(0.5);
  });

  it("applies the fixed planned denominator inside each group summary", () => {
    const input = validFixture([
      { id: "a", taskId: "fix-build" },
      { id: "b", taskId: "fix-build" },
    ]);
    input.observations = input.observations.filter(
      (o) => o.sampleId !== "b",
    );
    const group = report(input).groups[0];
    expect(group).toMatchObject({
      taskId: "fix-build",
      planned: 2,
      observed: 1,
      succeeded: 1,
      successRate: 0.5,
    });
  });

  it("keeps a missing first-run sample in the funnel planned denominator", () => {
    const input = validFixture([
      { id: "a", kind: "first-run" },
      { id: "b", kind: "first-run" },
    ]);
    input.observations = input.observations.filter(
      (o) => o.sampleId !== "b",
    );
    const result = report(input);
    expect(result.firstRun).toMatchObject({
      planned: 2,
      observed: 1,
      succeeded: 1,
    });
    for (const stage of result.firstRunFunnel) expect(stage.planned).toBe(2);
    expect(result.firstRunFunnel[0].passed).toBe(1);
  });

  it("does not promote a known-cost sum to a total while a planned sample is missing", () => {
    const input = validFixture([{ id: "a" }, { id: "b" }]);
    input.observations = input.observations.filter(
      (o) => o.sampleId !== "b",
    );
    const result = report(input);
    expect(result.task).toMatchObject({
      planned: 2,
      observed: 1,
      totalCost: null,
      costPerSuccess: null,
    });
    expect(result.task.knownCost).toBe(0.1);
  });
});
