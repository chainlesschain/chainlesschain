/**
 * Regression coverage: "安装与准入分离" (installation vs. admission).
 *
 * Verifies that a CLI backend which is installed but NOT governance-attested
 * still refuses to run, while an available API backend is preserved and remains
 * usable. These are independent behavioral controls (no reliance on source text
 * or on the existing agent-router test suite).
 */
import { describe, it, expect, vi, beforeEach } from "vitest";
import { AgentRouter, BACKEND_TYPE } from "../src/lib/agent-router.js";
import { createChatFn } from "../src/lib/cowork-adapter.js";
import { captureAgentEvolutionIngress } from "../src/lib/evolution/agent-evolution-ingress.js";

// Allow API dispatch to actually execute in tests without a branded real
// ingress or a real LLM provider.
vi.mock("../src/lib/cowork-adapter.js", () => ({
  createChatFn: vi.fn(() => async () => ({ content: "simulated completion" })),
}));
vi.mock("../src/lib/evolution/agent-evolution-ingress.js", () => ({
  captureAgentEvolutionIngress: vi.fn((v) => v),
  AGENT_EVOLUTION_INGRESS_FAILED_CODE: "CC_AGENT_EVOLUTION_INGRESS_FAILED",
}));

const UNATTESTED = "AGENT_ROUTER_EXTERNAL_MODEL_INGRESS_UNATTESTED";

// ─── Helpers (mirror the existing suite's fixture shape) ──────────

function mockPool() {
  return { dispatch: vi.fn(async () => []), on: vi.fn() };
}

/** Installed but NOT admitted CLI backend. */
function makeInstalledCliBackend(type = BACKEND_TYPE.CLAUDE) {
  const pool = mockPool();
  return { type, isCLI: true, installed: true, weight: 1, _pool: pool, timeout: 300_000 };
}

/** Available API backend. */
function makeApiBackend(type = BACKEND_TYPE.GEMINI) {
  return {
    type,
    isCLI: false,
    installed: false,
    weight: 1,
    provider: type,
    model: "test-model",
    apiKey: "test-key",
    baseUrl: "https://example.test",
    timeout: 60_000,
  };
}

/** Build a router bypassing real backend resolution (see existing suite). */
function makeRouter(backends, strategy = "round-robin") {
  const router = new AgentRouter({ backends: [], strategy, maxParallel: 3 });
  router._backends = backends;
  return router;
}

const task = { id: "t1", description: "implement feature" };
const opts = { cwd: "/tmp", evolutionIngress: { scope: "test" } };

describe("installation vs. admission separation", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("an installed but unattested CLI backend still refuses to run", async () => {
    const cli = makeInstalledCliBackend();
    const router = makeRouter([cli]);

    await expect(router.dispatch([task], opts)).rejects.toMatchObject({
      code: UNATTESTED,
    });
    expect(cli._pool.dispatch).not.toHaveBeenCalled();
  });

  it("refuses a direct internal execution attempt on the installed unattested CLI", async () => {
    const cli = makeInstalledCliBackend();
    const router = makeRouter([cli]);

    await expect(
      router._runSingleTask(task, cli, {
        cwd: "/tmp",
        evolutionIngress: opts.evolutionIngress,
      }),
    ).rejects.toMatchObject({ code: UNATTESTED });
    expect(cli._pool.dispatch).not.toHaveBeenCalled();
  });

  it("summary separates installation (installed) from admission (unattested) and keeps API dispatchable", () => {
    const router = makeRouter([makeInstalledCliBackend(), makeApiBackend()]);
    const summary = router.summary();

    expect(summary[0]).toMatchObject({
      type: BACKEND_TYPE.CLAUDE,
      installed: true,
      governanceAdmitted: false,
      runnable: false,
      dispatchable: false,
      blockedReason: UNATTESTED,
    });
    // The available API backend is preserved as usable.
    expect(summary[1]).toMatchObject({
      type: BACKEND_TYPE.GEMINI,
      kind: "api",
      dispatchable: true,
      executionMode: "text-only",
    });
  });

  it("assertDispatchAvailable passes when an API backend coexists with an unattested CLI", () => {
    const router = makeRouter([makeInstalledCliBackend(), makeApiBackend()]);
    expect(() => router.assertDispatchAvailable()).not.toThrow();
  });

  it("executes the preserved API backend while excluding the unattested CLI from dispatch", async () => {
    const cli = makeInstalledCliBackend();
    const router = makeRouter([cli, makeApiBackend(BACKEND_TYPE.GEMINI)]);

    const results = await router.dispatch([task], opts);

    // The API path ran; the CLI was never started.
    expect(cli._pool.dispatch).not.toHaveBeenCalled();
    expect(createChatFn).toHaveBeenCalledTimes(1);
    expect(captureAgentEvolutionIngress).toHaveBeenCalled();
    expect(results).toHaveLength(1);
    expect(results[0]).toMatchObject({
      taskId: task.id,
      backendType: BACKEND_TYPE.GEMINI,
      status: "simulated",
    });
  });

  it("with only CLI backends dispatch fails closed before any backend runs", async () => {
    const cliA = makeInstalledCliBackend(BACKEND_TYPE.CLAUDE);
    const cliB = makeInstalledCliBackend(BACKEND_TYPE.CODEX);
    const router = makeRouter([cliA, cliB]);

    await expect(router.dispatch([task], opts)).rejects.toMatchObject({
      code: UNATTESTED,
    });
    expect(cliA._pool.dispatch).not.toHaveBeenCalled();
    expect(cliB._pool.dispatch).not.toHaveBeenCalled();
  });
});
