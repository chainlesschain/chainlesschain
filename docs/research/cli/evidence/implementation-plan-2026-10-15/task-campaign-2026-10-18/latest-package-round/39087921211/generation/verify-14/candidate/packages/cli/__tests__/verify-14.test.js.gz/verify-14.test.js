/**
 * 图片逐项错误 — independent regression coverage for `resolveImages` /
 * `prepareVisionTurn` when a batch mixes valid image files with corrupted ones.
 *
 * Contract under test (all-or-nothing): a corrupted entry rejects the WHOLE
 * batch with `Image N: …`, where N is the 1-based position of the exact failing
 * entry, and the original cause is preserved via `{ cause }`. Valid entries are
 * never silently skipped-and-forgotten — a mix surfaces as an outright
 * rejection, so a caller can never mistake a partial attachment for a complete
 * one. Descriptors that were successfully opened are always closed; entries
 * whose `openSync` throws are never closed (nothing was pinned).
 *
 * The fs stub mirrors readBoundedImage's surface (which resolveImages wraps):
 * each path yields valid PNG_BYTES unless its name contains "corrupt", in which
 * case openSync throws a distinctive error. openSync/closeSync are recorded to
 * prove reachability and descriptor hygiene.
 */
import { describe, it, expect } from "vitest";
import fs from "node:fs";
import {
  resolveImages,
  prepareVisionTurn,
} from "../../src/lib/image-input.js";
import { PNG_BYTES } from "./helpers/image-file-fixtures.js";

// CORRUPT marker — openSync throws for any path containing this token.
const CORRUPT = "corrupt";
const EIO = "EIO: corrupt image on disk";

function mixedFs() {
  const opened = []; // every path handed to openSync (attempts)
  const validOpened = []; // paths that yielded a real descriptor
  const closed = []; // successful closeSync calls
  return {
    _opened: opened,
    _validOpened: validOpened,
    _closed: closed,
    openSync(file, flags) {
      opened.push(String(file));
      if (String(file).includes(CORRUPT)) throw new Error(EIO);
      validOpened.push(String(file));
      return PNG_BYTES; // valid header doubles as the pinned descriptor
    },
    fstatSync(fd) {
      return {
        size: fd.length,
        mtimeMs: 1,
        ctimeMs: 1,
        isFile: () => true,
      };
    },
    readSync(fd, target, offset, length, position) {
      return fd.copy(target, offset, position, position + length);
    },
    closeSync() {
      closed.push("closed");
    },
    constants: fs.constants,
  };
}

describe("resolveImages: mixed valid + corrupt batch", () => {
  it("rejects the whole batch and names the exact failing entry (valid-first)", () => {
    const io = mixedFs();
    // a.png is valid; corrupt.png fails. resolveImages must NOT silently drop
    // a.png and continue — it rejects loudly and identifies entry #2, and both
    // entries are reached (the valid one is surfaced, not skipped).
    expect(() =>
      resolveImages(["a.png", "corrupt.png"], { fs: io }),
    ).toThrow(/Image 2: EIO: corrupt image on disk/);
    expect(io._opened).toEqual(["a.png", "corrupt.png"]);
    // a.png's descriptor was opened and must be closed before the batch error.
    expect(io._closed).toHaveLength(io._validOpened.length);
  });

  it("names the first failing entry and aborts (corrupt-first)", () => {
    const io = mixedFs();
    expect(() =>
      resolveImages(["corrupt.png", "a.png"], { fs: io }),
    ).toThrow(/Image 1: EIO: corrupt image on disk/);
    // Aborts at the first corrupt entry; the later valid one is never opened.
    expect(io._opened).toEqual(["corrupt.png"]);
    // openSync threw before pinning a descriptor, so nothing is closed/leaked.
    expect(io._validOpened).toEqual([]);
    expect(io._closed).toHaveLength(0);
  });

  it("returns every item with accurate media type and base64 for an all-valid batch", () => {
    const io = mixedFs();
    const out = resolveImages(["a.png", "b.png", "c.png"], { fs: io });
    expect(out.map((x) => x.mediaType)).toEqual([
      "image/png",
      "image/png",
      "image/png",
    ]);
    for (const img of out) expect(img.data).toBe(PNG_BYTES.toString("base64"));
  });

  it("preserves the original cause and closes every successfully-opened descriptor", () => {
    const io = mixedFs();
    let error;
    try {
      resolveImages(["ok.png", "corrupt.png"], { fs: io });
    } catch (e) {
      error = e;
    }
    expect(error).toBeInstanceOf(Error);
    expect(error.message).toMatch(/Image 2:/);
    expect(error.cause).toBeInstanceOf(Error);
    expect(error.cause.message).toBe(EIO);
    expect(io._validOpened).toEqual(["ok.png"]);
    expect(io._closed).toHaveLength(io._validOpened.length);
  });

  it("stops at the first corrupt entry instead of scanning or skipping later ones", () => {
    const io = mixedFs();
    expect(() =>
      resolveImages(["ok.png", "corrupt.png", "corrupt.png"], { fs: io }),
    ).toThrow(/Image 2: EIO: corrupt image on disk/);
    // Only entries up to and including the first failure are touched.
    expect(io._opened).toEqual(["ok.png", "corrupt.png"]);
    expect(io._closed).toHaveLength(io._validOpened.length);
  });
});

describe("prepareVisionTurn: a mix never silently attaches only the valid image", () => {
  it("rejects loudly for a detected corrupt path instead of dropping it", () => {
    const io = mixedFs();
    const deps = {
      existsSync: (p) => true, // both tokens "exist" and get auto-detected
      fs: io,
    };
    expect(() =>
      prepareVisionTurn("describe ok.png and corrupt.png", {}, deps),
    ).toThrow(/Image 2: EIO: corrupt image on disk/);
    expect(io._opened).toEqual(["ok.png", "corrupt.png"]);
  });
});
