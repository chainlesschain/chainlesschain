# 冻结计划操作说明 — `task-outcome-report.mjs` 运维 Runbook

本文档是 `packages/cli/scripts/task-outcome-report.mjs`（"冻结计划"结果报告脚本）的仓库运维说明。
它以**只读**方式汇总 Eval 证据（history JSONL、observations JSON、maintenance JSON），在模型计划被指纹冻结后产出基线报告，并**绝不签发"改善 PASS"**。

> 源文件与既有测试均为只读。本 runbook 所引用的行为全部来自对源码
> `packages/cli/scripts/task-outcome-report.mjs` 与测试
> `packages/cli/__tests__/unit/task-outcome-report.test.js` 的阅读，未做任何实现修改。

## 1. 脚本定位与来源路径

- 脚本（冻结源）：`packages/cli/scripts/task-outcome-report.mjs`
- 实现库：`packages/cli/src/lib/eval/outcomes.js`（`buildOutcomeReport`、`outcomeDigest`、`validateOutcomePlan`）
  与 `packages/cli/src/lib/eval/evidence.js`（`readEvalHistory`）。
- 测试：`packages/cli/__tests__/unit/task-outcome-report.test.js`
- 本文档所在目录的相对引用路径：
  - 从 `docs/development/` 到脚本：`../../packages/cli/scripts/task-outcome-report.mjs`
  - 从 `docs/development/` 到测试：`../../packages/cli/__tests__/unit/task-outcome-report.test.js`

脚本是一份 Node ESM 可执行文件（`#!/usr/bin/env node`），可直接以
`node packages/cli/scripts/task-outcome-report.mjs ...` 运行，无需编译。

## 2. 命令行接口（自源码 `parseArgs` 验证）

脚本用 `node:util` 的 `parseArgs` 声明以下选项：

| 选项 | 类型 | 含义 |
| --- | --- | --- |
| `--plan <file>` | string | 冻结计划 JSON（必填） |
| `--history <file>` | string | Eval 历史 JSONL（可省略） |
| `--observations <file>` | string | 观测 JSON 数组（可省略） |
| `--maintenance <file>` | string | 维护 JSON（可省略） |
| `--plan-digest <sha256:...>` | string | 已冻结计划的摘要，`sha256:` + 64 位小写 hex |
| `--fingerprint` | boolean | 仅打印计划指纹到 stdout，不做报告 |
| `--help` | boolean | 打印使用说明 |

### 两种用法

**A. 指纹打印（冻结阶段）**

```bash
node packages/cli/scripts/task-outcome-report.mjs --plan plan.json --fingerprint
```

- 仅当 `--fingerprint` 被传入时，脚本输出 `outcomeDigest(plan)` 到 stdout（形如
  `sha256:<64-hex>`）。测试中该输出与库函数 `outcomeDigest(plan)` 逐字相等
  （`expect(digest).toBe(outcomeDigest(input.plan))`）。
- 这一步在收集证据**之前**冻结计划；收集证据后必须用同一指纹核对。

**B. 基线报告（收集证据后）**

```bash
node packages/cli/scripts/task-outcome-report.mjs \
  --plan plan.json \
  --plan-digest sha256:<64-hex> \
  --history history.jsonl \
  --observations observations.json \
  [--maintenance maintenance.json]
```

- 报告以缩进 JSON 写到 stdout。
- `--history` / `--observations` / `--maintenance` 均可省略：
  - 省略 history 时内部使用空 `{ runs: [], issues: [] }`；
  - 省略 observations 时使用空数组 `[]`；
  - 省略 maintenance 时使用 `null`。

### 退出码语义

| 退出码 | 含义 | 触发条件（自源码 `process.exitCode` 赋值验证） |
| --- | --- | --- |
| `0` | 基线已记录 | `report.status === "BASELINE_RECORDED"`，或 `--help` / `--fingerprint` |
| `2` | 证据不足 | `report.status === "INSUFFICIENT_EVIDENCE"` |
| `1` | 输入无效 | 任何抛错：缺 `--plan`、文件超 16 MiB、`--plan-digest` 缺失/格式错误、摘要不匹配等 |

## 3. 验收关注点：指纹、缺失样本、未知费用、禁止改善 PASS

### 3.1 指纹（fingerprint）

- `outcomeDigest(plan)` 是冻结计划的规范性摘要，`--fingerprint` 将其打印到 stdout。
- 非指纹模式下，`--plan-digest` **必须**匹配正则
  `/^sha256:[a-f0-9]{64}$/u`，否则抛错并以退出码 1 结束（错误消息：
  `--plan-digest is required; freeze it before collecting evidence`）。
- 若实际计划的摘要与 `--plan-digest` 不符，`buildOutcomeReport` 抛
  `digest mismatch`，退出码 1。因此**任何在指纹之后改动计划的行为都会在报告阶段被拒绝**。

### 3.2 缺失样本 → 退出码 2

- 计划（plan）声明了若干 `samples`；若某样本从未被观测/从未在 history 中出现，
  `buildOutcomeReport` 把它计为"未观察"而**不**把缺失当作零成本成功，整体判定
  `status = "INSUFFICIENT_EVIDENCE"`，脚本退出码 = 2。
- 测试中的直接证据：只给 `--plan` 与 `--plan-digest`、不给 history/observations 时，
  报告 `task = { planned: 1, observed: 0, succeeded: 0 }` 且 `status = 2`。
- 维护数据缺失同理：`totalHours: null`，`maintenance.per100Attempts: null`。

### 3.3 未知费用不当作零

- 当某计划样本缺失观测（或成本未知/非法）时，费用**不会**被当作 0：
  - 缺失样本用例：`totalCost: null, costPerSuccess: null`，`successRate: 0.5`。
  - 非法成本用例（`NaN`、`-1`、`Infinity`、字符串 `"0"`）：`task.totalCost: null`、
    `task.succeeded: 0`。
  - 缺失/不完整维护：`maintenance.totalHours: null`（而非 0）。
- 运维含义：**只有真实观测到的成本才会计入 `totalCost`；缺失即未知，报 null，而非误报免费。**

### 3.4 禁止改善 PASS

- 报告的 `improvementVerdict` 恒为 `"NOT_EVALUATED"`；`productionAttested` 恒为 `false`。
- 基线用例断言 `status: "BASELINE_RECORDED"` 时仍保持
  `improvementVerdict: "NOT_EVALUATED", productionAttested: false`。
- 因此本脚本**绝不签发任何"改善 PASS"**，也不做生产环境证明。任何宣称"改善通过"的输出
  均非本脚本产生。

## 4. 报告结构（自库函数返回字段）

`buildOutcomeReport` 的返回值（stdout JSON 顶层）包含：

- `status`：`"BASELINE_RECORDED"` 或 `"INSUFFICIENT_EVIDENCE"`。
- `improvementVerdict`：恒为 `"NOT_EVALUATED"`。
- `productionAttested`：恒为 `false`。
- `task`：`{ planned, observed, succeeded, successRate, totalCost, costPerSuccess, retries, manualRepairs }`。
- `maintenance`：`{ totalHours, per100Attempts, constructionHours }`（证据不足时相关值为 null）。
- `firstRun`、`firstRunFunnel`：首跑旅程各阶段通过情况。
- `rows`：逐样本明细，含 `reasons`（如 `"budget_exceeded"`）。
- `groups`：按任务分组统计。
- `issues`：一致性/时序问题列表（如 `inconsistent_first_run_stages`、
  `observation_outside_window`）。

## 5. 输入文件约定（自源码 `readJson` / `readEvalHistory`）

- `--plan`、`--observations`、`--maintenance` 均经 `readJson`：
  - 文件必须存在且 **≤ 16 MiB**（超出即抛 `missing input or input exceeds 16 MiB`，退出码 1）。
  - 必须为合法 UTF-8 JSON（`JSON.parse` 失败即抛错退出码 1）。
- `--history` 经 `readEvalHistory`：逐行 JSONL；解析失败会被记录为 history issue
  （如 `invalid_history_record`），并使整体 `status` 退化为 `INSUFFICIENT_EVIDENCE`（退出码 2）。

## 6. 实际验证记录（无法在本次离线/无 shell 环境中执行，列为预期）

> 本次执行为受限环境，未运行测试或命令；以下为**应执行**的验证，非已通过证明。
> 独立评测将在无网络的 Linux Docker 中运行基线/候选/行为覆盖测试，其通过与否本环境无法断言。

1. **指纹一致性**：`--fingerprint` 输出应与 `outcomeDigest(plan)` 相等
   （对应测试断言）。证据不足阶段改动计划后 `--plan-digest` 应产生 `digest mismatch` → 退出码 1。
2. **缺失样本退出 2**：仅给 `--plan` + 正确 `--plan-digest`，不给 history/observations，
   应得 `status = "INSUFFICIENT_EVIDENCE"`、`observed: 0`、退出码 2。
3. **未知费用为 null**：缺失/非法成本下 `task.totalCost` 与 `costPerSuccess` 为 `null`，不被当作 0。
4. **无改善 PASS**：任何输入下 `improvementVerdict === "NOT_EVALUATED"`。
5. **输入无效退出 1**：缺 `--plan`、文件超 16 MiB、`--plan-digest` 非 `sha256:<64-hex>`、计划被篡改，均退出码 1。
6. **完整证据退出 0**：给定匹配的 plan/history/observations/maintenance 且基线可记录，
   `status = "BASELINE_RECORDED"`、退出码 0。

## 7. 已知限制与诚实说明

- 本 runbook 未执行任何命令或测试；文中所有行为均**读源码与既有测试得到**，未被本环境实跑证明。
- 未对源码或测试做任何修改；未新增或降低任何断言。
- 若独立评测发现反例（某断言描述的行为与实测不符），应先核对冻结源码与最新测试，
  再决定是否需要最小修复；本文不虚构已存在的缺陷。
