import { afterEach, describe, expect, it, vi } from "vitest";
import fs from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { DraftStore } from "../src/chat/draft-store.js";

const roots = [];
afterEach(async () => {
  for (const root of roots.splice(0))
    await fs.rm(root, { recursive: true, force: true });
  vi.restoreAllMocks();
});
async function storage() {
  const root = await fs.mkdtemp(path.join(tmpdir(), "cc-verify25-"));
  roots.push(root);
  return root;
}
const image = {
  data: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==",
};

describe("atomic draft writes preserve the previous record on failure", () => {
  it("successful atomic write commits the new manifest and leaves no temporary file", async () => {
    const root = await storage();
    const key = randomUUID();
    const store = new DraftStore(root);
    await store.save(key, { text: "first" });
    await store.save(key, { text: "second" });
    expect((await store.view(key)).composer.text).toBe("second");
    expect(await fs.readdir(path.join(root, key))).toEqual(["draft.json"]);
  });

  it("keeps the previous draft recoverable when the atomic rename fails", async () => {
    const root = await storage();
    const key = randomUUID();
    const store = new DraftStore(root);
    await store.save(key, { text: "original" });
    const before = await fs.readFile(path.join(root, key, "draft.json"));

    const rename = fs.rename.bind(fs);
    const spy = vi.spyOn(fs, "rename").mockImplementation(async () => {
      throw new Error("disk full");
    });
    try {
      await expect(
        store.save(key, { text: "overwrite" }),
      ).rejects.toThrow("disk full");
    } finally {
      spy.mockRestore();
    }

    // The on-disk manifest is byte-for-byte the old one, so the draft is
    // recovered, and the abandoned temporary manifest was removed.
    expect(await fs.readFile(path.join(root, key, "draft.json"))).toEqual(
      before,
    );
    expect((await store.view(key)).composer.text).toBe("original");
    expect(await fs.readdir(path.join(root, key))).toEqual(["draft.json"]);
  });

  it("a failed send does not clear the saved composer or commit the pending input", async () => {
    const root = await storage();
    const key = randomUUID();
    const store = new DraftStore(root);
    await store.save(key, { text: "keep me", images: [image] });

    const rename = fs.rename.bind(fs);
    const spy = vi.spyOn(fs, "rename").mockImplementation(async () => {
      throw new Error("disk full");
    });
    try {
      await expect(
        store.prepare(key, "session-1", "input-1", {
          text: "submitted",
          images: [image],
        }),
      ).rejects.toThrow("disk full");
    } finally {
      spy.mockRestore();
    }

    // Send did not prematurely clear the composer: the previous draft is
    // still intact and viewable.
    const restored = await store.view(key);
    expect(restored.composer.text).toBe("keep me");
    expect(restored.composer.images).toHaveLength(1);
    expect(restored.pending).toEqual([]);
  });

  it("a successful send commits the input and clears the composer only after the write", async () => {
    const root = await storage();
    const key = randomUUID();
    const store = new DraftStore(root);
    await store.save(key, { text: "old", images: [image] });

    const prepared = await store.prepare(key, "session-1", "input-1", {
      text: "submitted",
      images: [image],
    });
    expect(prepared.id).toBe("input-1");

    const restored = await store.view(key);
    expect(restored.composer.text).toBe("");
    expect(restored.pending.map((p) => p.text)).toEqual(["submitted"]);
  });
});
