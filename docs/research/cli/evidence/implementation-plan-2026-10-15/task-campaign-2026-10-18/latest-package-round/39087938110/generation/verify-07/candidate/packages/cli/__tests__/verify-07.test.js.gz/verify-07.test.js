import { afterAll, describe, expect, it, vi } from "vitest";
import { mkdtempSync, rmSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";

const root = mkdtempSync(join(tmpdir(), "cc-verify07-"));
vi.mock("../src/lib/paths.js", () => ({
  getHomeDir: () => join(root, "home"),
  getClaudeProjectStorageDir: () => null,
  getStatePath: () => join(root, "home", "state"),
  getMachineSecurityAnchorDir: () => join(root, "security"),
}));

import { createSessionTranscriptHistoryProjection } from "../src/lib/session-transcript-history.js";

afterAll(() => rmSync(root, { recursive: true, force: true }));

const SESSION = "verify07-boundary";

function event(index, role, content) {
  return {
    type: role === "user" ? "user_message" : "assistant_message",
    hash: (index + 1).toString(16).padStart(64, "0"),
    data: { role, content },
  };
}
function events(pairs) {
  const evs = [];
  for (let i = 0; i < pairs; i++) {
    evs.push(event(i * 2, "user", `question-${i}`));
    evs.push(event(i * 2 + 1, "assistant", `answer-${i}`));
  }
  return evs;
}
function read(evs, options) {
  const projection = createSessionTranscriptHistoryProjection(SESSION, options);
  evs.forEach((entry) => projection.accept(entry));
  return projection.finish({
    headHash: evs.at(-1).hash,
    eventCount: evs.length,
  });
}
function texts(rows) {
  return rows.map((row) => row.text);
}
function syncCursor(page, offset) {
  return Buffer.from(
    JSON.stringify({
      v: 1,
      view: "history-sync",
      sessionId: SESSION,
      generation: page.generation,
      revision: page.revision,
      eventCount: page.eventCount,
      offset,
    }),
  ).toString("base64url");
}
function rewrite(base64, patch) {
  return Buffer.from(
    JSON.stringify({
      ...JSON.parse(Buffer.from(base64, "base64url").toString("utf8")),
      ...patch,
    }),
  ).toString("base64url");
}

describe("persistent body paging boundary", () => {
  it("walks head-to-tail cursors without omitting or duplicating the body", () => {
    // 16 display rows, ordinals 0..15. The `before` cursor pages newest-first,
    // so page 0 holds the newest rows and the tail page retains ordinal 0.
    const evs = events(8);
    const pages = [];
    let cursor = null;
    let guard = 0;
    do {
      const page = read(evs, { limit: 3, cursor });
      pages.push(page);
      cursor = page.nextCursor;
      expect(guard++).toBeLessThan(20);
    } while (cursor);
    const ordinals = pages.flatMap((p) => p.messages.map((row) => row.ordinal));
    // Every body row appears exactly once, oldest first at the tail.
    expect(ordinals).toEqual(Array.from({ length: 16 }, (_, i) => i));
    const headPage = pages[0];
    const tailPage = pages.at(-1);
    // Newest body is on the first page; the final (oldest) body is the tail.
    expect(headPage.messages[0].ordinal).toBe(13);
    expect(texts(tailPage.messages)[0]).toBe("question-0");
    expect(tailPage.nextCursor).toBeNull();
    // No boundary row is emitted more than once across pages.
    const ids = pages.flatMap((p) => p.messages.map((row) => row.id));
    expect(new Set(ids).size).toBe(ids.length);
  });

  it("segments the body boundary without repeating the shared boundary row", () => {
    // ordinals 0..7. Page 1 is the newest 4 rows; the `before: 4` cursor
    // resumes at the immediately older segment without re-emitting row 4.
    const evs = events(4);
    const first = read(evs, { limit: 4 });
    const second = read(evs, { limit: 4, cursor: first.nextCursor });
    expect(texts(first.messages)).toEqual([
      "question-2",
      "answer-2",
      "question-3",
      "answer-3",
    ]);
    expect(texts(second.messages)).toEqual([
      "question-0",
      "answer-0",
      "question-1",
      "answer-1",
    ]);
    const ids = [...first.messages, ...second.messages].map((row) => row.id);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it("syncs across a boundary after a cursor without duplicating or dropping the final body", () => {
    const evs = events(5); // ordinals 0..9
    const head = read(evs, { limit: 4 });
    const second = read(evs, { limit: 3, after: syncCursor(head, 4) });
    expect(texts(second.messages)).toEqual([
      "question-2",
      "answer-2",
      "question-3",
    ]);
    expect(second.from).toBe(4);
    expect(second.hasMore).toBe(true);
    const tail = read(evs, { limit: 4, after: second.nextCursor });
    expect(texts(tail.messages)).toEqual([
      "answer-3",
      "question-4",
      "answer-4",
    ]);
    expect(tail.hasMore).toBe(false);
    const ords = [...second.messages, ...tail.messages].map((row) => row.ordinal);
    expect(ords).toEqual([4, 5, 6, 7, 8, 9]);
  });

  it("rejects a stale cursor when the persisted body no longer matches", () => {
    const evs = events(4);
    const page = read(evs, { limit: 2 });
    expect(() =>
      read(evs, {
        cursor: rewrite(page.nextCursor, { revision: "f".repeat(64) }),
      }),
    ).toThrow(/history changed/);
    expect(() =>
      read(evs, {
        cursor: rewrite(page.nextCursor, { eventCount: 99 }),
      }),
    ).toThrow(/history changed/);
  });

  it("rejects malformed or foreign cursors as invalid", () => {
    const evs = events(4);
    expect(() => read(evs, { cursor: "!!!not-base64url!!!" })).toThrow(
      /invalid transcript history cursor/,
    );
    const page = read(evs, { limit: 2 });
    expect(() =>
      read(evs, {
        cursor: rewrite(page.nextCursor, { sessionId: "other" }),
      }),
    ).toThrow(/invalid transcript history cursor/);
  });

  it("ends the tail cursor with no hasMore while keeping the final row", () => {
    const evs = events(3); // ordinals 0..5
    let cursor = null;
    let last = null;
    let guard = 0;
    do {
      last = read(evs, { limit: 2, cursor });
      cursor = last.nextCursor;
      expect(guard++).toBeLessThan(10);
    } while (cursor);
    expect(texts(last.messages)[0]).toBe("question-0");
    expect(last.nextCursor).toBeNull();
    expect(last.totalMessages).toBe(6);
  });
});
