import "./helpers/test-model-egress.js";
/**
 * Regression coverage — 取消审批迟到回调 (cancel approval late callback).
 *
 * Invariants under test (headless-stream interactive-approvals round-trip):
 *   A. After an approval request is cancelled/settled, a late acceptance (a
 *      verdict that re-echoes the original request's id + binding) can NOT
 *      authorize a NEW, different request.
 *   B. A normal acceptance binds ONLY the original request: an approve verdict
 *      resolves exactly the pending request whose id/binding it echoes, and a
 *      verdict whose binding does not match the advertised request fails closed
 *      (deny) instead of green-lighting the call.
 *
 * These are behavioral controls on the frozen runtime. They are written as
 * independent regression tests and do not import the existing approvals suite.
 */
import { describe, it, expect, beforeEach, afterEach } from "vitest";
import { PassThrough } from "node:stream";
import {
  runAgentHeadlessStream,
  parseInputEvent,
} from "../src/runtime/headless-stream.js";
import { approvalBindingDigest } from "../src/lib/agent-authority.js";

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** Fake loop: a tool hits confirm twice, sequentially, and reports both verdicts. */
function doubleConfirmingLoop(context) {
  return async function* (_messages, opts) {
    const first = await opts.permissionConfirm(context);
    const second = await opts.permissionConfirm(context);
    yield {
      type: "response-complete",
      content: first && second ? "both executed" : "denied",
    };
    yield { type: "run-ended", reason: "complete" };
  };
}

/** Fake loop: a tool hits confirm once. */
function singleConfirmingLoop(context) {
  return async function* (_messages, opts) {
    const ok = await opts.permissionConfirm(context);
    yield {
      type: "response-complete",
      content: ok ? "executed" : "skipped (denied)",
    };
    yield { type: "run-ended", reason: "complete" };
  };
}

function harness({ agentLoop, inputGen, options = {} }) {
  const lines = [];
  const deps = {
    bootstrap: async () => ({ db: null }),
    getApprovalGate: async () => null,
    writeOut: (s) => lines.push(s),
    writeErr: () => {},
    agentLoop,
    input: inputGen(),
  };
  return {
    run: () =>
      runAgentHeadlessStream(
        { expandFileRefs: false, interactiveApprovals: true, ...options },
        deps,
      ),
    events: () =>
      lines
        .join("")
        .trimEnd()
        .split("\n")
        .filter((l) => l)
        .map((l) => JSON.parse(l)),
  };
}

const CTX = {
  tool: "run_shell",
  command: "npm run test:unit",
  riskLevel: "medium",
  reason: "settings rule asks",
};

const originalTimeout = process.env.CC_APPROVAL_TIMEOUT_MS;
beforeEach(() => {
  // Keep deliberately-unanswered approvals fail-closed quickly instead of
  // hanging the run for the default 120s.
  process.env.CC_APPROVAL_TIMEOUT_MS = "300";
});
afterEach(() => {
  if (originalTimeout === undefined) delete process.env.CC_APPROVAL_TIMEOUT_MS;
  else process.env.CC_APPROVAL_TIMEOUT_MS = originalTimeout;
});

describe("cancel approval late callback — late acceptance cannot authorize a new request", () => {
  it("approve resolves the original request true; a second pending request is NOT authorized by a stale re-echoed verdict and fails closed", async () => {
    // A: first confirm → appr-1, second confirm → appr-2. We approve appr-1
    // with its own verdict, then replay that SAME late verdict (id + binding)
    // while appr-2 is pending. The late acceptance must not authorize appr-2:
    // appr-2 stays pending and fails closed on timeout.
    const h = harness({
      agentLoop: doubleConfirmingLoop(CTX),
      inputGen: async function* () {
        yield JSON.stringify({ type: "user", text: "do the RISKY thing" }) +
          "\n";
        await sleep(80); // let confirm1 reach → appr-1 pending
        // read appr-1's advertised binding from the emitted request
        const req1 = h
          .events()
          .find((e) => e.type === "approval_request" && e.id === "appr-1");
        yield JSON.stringify({
          type: "approval",
          id: "appr-1",
          approve: true,
          binding: req1.binding,
        }) + "\n";
        await sleep(80); // confirm2 reaches → appr-2 pending
        // replay the ORIGINAL request's late verdict (id + binding of appr-1)
        yield JSON.stringify({
          type: "approval",
          id: "appr-1",
          approve: true,
          binding: req1.binding,
        }) + "\n";
        // never send a verdict for appr-2 → it must fail closed, not be
        // authorized by the stale appr-1 acceptance.
      },
    });
    await h.run();

    const resolved = h
      .events()
      .filter((e) => e.type === "approval_resolved");
    expect(resolved).toHaveLength(2);
    // original request was accepted (bound its own request)
    expect(resolved.find((e) => e.id === "appr-1")).toMatchObject({
      approved: true,
      via: "user-approve",
    });
    // the new request was NOT authorized by the late acceptance → fail closed
    expect(resolved.find((e) => e.id === "appr-2")).toMatchObject({
      approved: false,
    });
    expect(h.events().find((e) => e.type === "result").result).toBe("denied");
  }, 8000);

  it("normal acceptance binds only the original request: two approvals resolve by their own distinct ids", async () => {
    // B: accept each request with its own verdict. Each resolution is emitted
    // for exactly its own id — the first accept never resolves the second.
    const h = harness({
      agentLoop: doubleConfirmingLoop(CTX),
      inputGen: async function* () {
        yield JSON.stringify({ type: "user", text: "do the RISKY thing" }) +
          "\n";
        await sleep(80);
        const req1 = h
          .events()
          .find((e) => e.type === "approval_request" && e.id === "appr-1");
        yield JSON.stringify({
          type: "approval",
          id: "appr-1",
          approve: true,
          binding: req1.binding,
        }) + "\n";
        await sleep(80);
        const req2 = h
          .events()
          .find((e) => e.type === "approval_request" && e.id === "appr-2");
        yield JSON.stringify({
          type: "approval",
          id: "appr-2",
          approve: true,
          binding: req2.binding,
        }) + "\n";
      },
    });
    await h.run();

    const resolved = h
      .events()
      .filter((e) => e.type === "approval_resolved");
    expect(resolved.map((e) => e.id)).toEqual(["appr-1", "appr-2"]);
    expect(resolved.every((e) => e.approved === true)).toBe(true);
    expect(h.events().find((e) => e.type === "result").result).toBe(
      "both executed",
    );
  }, 8000);

  it("an approve whose binding does not match the advertised request fails closed (cannot authorize)", async () => {
    // Negative control: a verdict echoing a DIFFERENT call's binding cannot
    // green-light this request — it is rejected as binding-mismatch.
    const foreignBinding = approvalBindingDigest({
      toolCallId: "appr-1",
      args: { command: "rm -rf /tmp/other" },
      policyDigest: "medium",
    });
    const h = harness({
      agentLoop: singleConfirmingLoop(CTX),
      inputGen: async function* () {
        yield JSON.stringify({ type: "user", text: "do the RISKY thing" }) +
          "\n";
        await sleep(80);
        yield JSON.stringify({
          type: "approval",
          id: "appr-1",
          approve: true,
          binding: foreignBinding,
        }) + "\n";
      },
    });
    await h.run();

    const resolved = h
      .events()
      .find((e) => e.type === "approval_resolved");
    expect(resolved).toMatchObject({
      id: "appr-1",
      approved: false,
      via: "binding-mismatch",
    });
    expect(h.events().find((e) => e.type === "result").result).toBe(
      "skipped (denied)",
    );
  }, 8000);

  it("a verdict for a non-pending / cancelled id is a no-op and authorizes nothing", async () => {
    // Negative control: a late verdict for an id that is not pending (already
    // settled, or never issued) neither emits a resolution nor authorizes a
    // pending request. The real pending request still resolves via its own
    // verdict.
    const h = harness({
      agentLoop: singleConfirmingLoop(CTX),
      inputGen: async function* () {
        yield JSON.stringify({ type: "user", text: "do the RISKY thing" }) +
          "\n";
        await sleep(80);
        const req = h
          .events()
          .find((e) => e.type === "approval_request" && e.id === "appr-1");
        // stray verdict for an id that was never pending
        yield JSON.stringify({
          type: "approval",
          id: "appr-99",
          approve: true,
          binding: req.binding,
        }) + "\n";
        await sleep(40);
        // the real request is still pending and unresolved
        const before = h
          .events()
          .filter((e) => e.type === "approval_resolved");
        expect(before).toHaveLength(0);
        // now accept the real request with its own verdict
        yield JSON.stringify({
          type: "approval",
          id: "appr-1",
          approve: true,
          binding: req.binding,
        }) + "\n";
      },
    });
    await h.run();

    const resolved = h
      .events()
      .filter((e) => e.type === "approval_resolved");
    expect(resolved).toHaveLength(1);
    expect(resolved[0]).toMatchObject({ id: "appr-1", approved: true });
    expect(h.events().find((e) => e.type === "result").result).toBe("executed");
  }, 8000);

  it("parseInputEvent rejects a verdict with no id (cannot be routed to any request)", () => {
    expect(parseInputEvent('{"type":"approval","approve":true}')).toBe(null);
  });
});
