"use strict";

require("./observe.cjs");
const fs = require("node:fs");
const { createHash } = require("node:crypto");
const { performance } = require("node:perf_hooks");
const output = process.env.CC_GUI_DIAGNOSTIC_PHASE_PATH;
if (!output) throw new Error("Missing phase diagnostic output");
const started = performance.now();
const digest = (file) => createHash("sha256").update(fs.readFileSync(file)).digest("hex");
const report = {
  schema: "chainlesschain.product-electron-phase-diagnostic/v1",
  hostNode: process.version,
  startedAt: new Date().toISOString(),
  productGuiAcceptance: false,
  complete: false,
  runnerSha256: digest("desktop-app-vue/scripts/project-goal-native-journey.mjs"),
  permanentMemoryArtifactSha256: digest("desktop-app-vue/dist/main/llm/permanent-memory-manager.js"),
  events: [],
};
fs.writeFileSync(output, JSON.stringify(report, null, 2) + "\n", { flag: "wx" });
const save = () => fs.writeFileSync(output, JSON.stringify(report, null, 2) + "\n");
const event = (stage, details = {}) => {
  report.events.push({ stage, elapsedMs: Math.round(performance.now() - started), ...details });
  save();
};
const safeError = (error) => ({
  name: error?.name || "Error",
  timeout30000: /Timeout 30000ms/u.test(String(error?.message)),
  timeout180000: /Timeout 180000ms/u.test(String(error?.message)),
});
const { _electron } = require("@playwright/test");
report.playwright = require("@playwright/test/package.json").version;
const launch = _electron.launch;
_electron.launch = async function (...args) {
  event("launch-requested", { timeoutMs: args[0]?.timeout });
  let app;
  try {
    app = await launch.apply(this, args);
    event("launch-resolved");
  } catch (error) {
    event("launch-rejected", safeError(error));
    throw error;
  }
  for (const name of ["evaluate", "firstWindow", "close"]) {
    const original = app[name];
    let count = 0;
    app[name] = async function (...parameters) {
      const invocation = ++count;
      event(`${name}-requested`, { invocation });
      try {
        const value = await original.apply(this, parameters);
        event(`${name}-resolved`, { invocation });
        return value;
      } catch (error) {
        event(`${name}-rejected`, { invocation, ...safeError(error) });
        throw error;
      }
    };
  }
  return app;
};
process.on("exit", (code) => {
  report.complete = true;
  report.exitCode = code;
  report.finishedAt = new Date().toISOString();
  event("phase-observer-exit");
});
