"use strict";

const fs = require("node:fs");
const path = require("node:path");
const cp = require("node:child_process");
const { performance } = require("node:perf_hooks");
const output = process.env.CC_GUI_DIAGNOSTIC_PATH;
const executable = process.env.CC_GUI_DIAGNOSTIC_ELECTRON;
if (!output || !executable) throw new Error("Missing owned diagnostic paths");
const started = performance.now();
const report = {
  schema: "chainlesschain.product-electron-launch-diagnostic/v1",
  startedAt: new Date().toISOString(),
  hostNode: process.version,
  productGuiAcceptance: false,
  launchTimeoutUnchanged: true,
  complete: false,
  events: [],
};
const event = (stage, details = {}) => {
  report.events.push({ stage, elapsedMs: Math.round(performance.now() - started), ...details });
};
const save = () => fs.writeFileSync(output, JSON.stringify(report, null, 2) + "\n");
fs.writeFileSync(output, JSON.stringify(report, null, 2) + "\n", { flag: "wx" });
const normalized = (value) => String(value).replaceAll("\\", "/").toLowerCase();
const expected = normalized(path.resolve(executable));
const owned = [];
const originalSpawn = cp.spawn;
cp.spawn = function (command, args, options) {
  const child = originalSpawn.apply(this, arguments);
  const ownedCommand = [command, ...(Array.isArray(args) ? args : [])]
    .some((value) => normalized(value).includes(expected));
  if (!ownedCommand) return child;
  owned.push(child);
  event("electron-launcher-created", { pid: child.pid ?? null });
  save();
  let pending = "";
  child.stderr?.on("data", (bytes) => {
    const lines = (pending + bytes.toString("utf8")).split(/\r?\n/u);
    pending = lines.pop().slice(-2048);
    for (const line of lines) {
      if (/^Debugger listening on ws:\/\//u.test(line)) event("node-debugger-announced");
      if (/^DevTools listening on ws:\/\//u.test(line)) event("cdp-announced");
      if (/Waiting for the debugger to disconnect/u.test(line)) event("debugger-disconnect-wait");
    }
    save();
  });
  child.on("exit", (code, signal) => { event("electron-launcher-exit", { code, signal }); save(); });
  child.on("close", (code, signal) => { event("electron-launcher-close", { code, signal }); save(); });
  child.on("error", (error) => { event("electron-launcher-error", { name: error.name, code: error.code ?? null }); save(); });
  return child;
};
process.on("uncaughtExceptionMonitor", (error, origin) => {
  report.fatal = {
    name: error?.name || "Error",
    timeout30000: /Timeout 30000ms exceeded/u.test(String(error?.message)),
    origin,
  };
  event("uncaught-exception-monitor");
  save();
  for (const child of owned) {
    if (!child.pid || child.exitCode !== null || child.signalCode !== null) continue;
    const stopped = cp.spawnSync("taskkill.exe", ["/PID", String(child.pid), "/T", "/F"], {
      windowsHide: true, stdio: "ignore", timeout: 5000,
    });
    event("owned-electron-tree-stop", { pid: child.pid, status: stopped.status, code: stopped.error?.code ?? null });
  }
  save();
});
process.on("exit", (code) => {
  report.complete = true;
  report.exitCode = code;
  report.finishedAt = new Date().toISOString();
  event("observer-exit");
  save();
});
