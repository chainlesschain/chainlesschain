import fs from "node:fs";
import path from "node:path";
import assert from "node:assert/strict";
import { spawnSync, execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
const root = process.cwd();
const site = process.argv[2];
const settings = {
  docs: ["docs-site", "docs/.vitepress/dist", "chainlesschain/cli-ide-update-2026-10-29-131.html", 600],
  design: ["docs-site-design", "docs/.vitepress/dist", "release-runtime-update-2026-10-29-131.html", 250],
  www: ["docs-website-v2", "dist", "index.html", 18],
};
assert.ok(Object.hasOwn(settings, site));
const [directory, distPath, required, minimum] = settings[site];
const source = execFileSync("git", ["rev-parse", "HEAD"], { encoding: "utf8" }).trim();
assert.ok(source === "14e8bce45cf2de15187c0d7b0fb53730c07d1b05");
assert.equal(execFileSync("git", ["status", "--porcelain"], { encoding: "utf8" }).trim(), "");
const startedAt = new Date().toISOString();
const args = site === "www" ? ["node_modules/astro/astro.js", "build"] : ["C:/nvm4w/nodejs/node_modules/npm/bin/npm-cli.js", "run", "build"];
const result = spawnSync(process.execPath, args, { cwd: path.join(root, directory), encoding: "utf8", maxBuffer: 32 * 1024 * 1024, timeout: 20 * 60 * 1000, windowsHide: true });
fs.writeFileSync(`.work/sites131-final-20261029/build-${site}.log`, (result.stdout || "") + "\n" + (result.stderr || ""));
const receipt = { executable: process.execPath, node: process.version, site, directory, source, args, startedAt, endedAt: new Date().toISOString(), exitCode: result.status, signal: result.signal, error: result.error?.message || null };
try {
  assert.equal(result.status, 0, `${site} build failed`);
  const after = execFileSync("git", ["rev-parse", "HEAD"], { encoding: "utf8" }).trim();
  assert.equal(source, after);
  assert.equal(execFileSync("git", ["status", "--porcelain"], { encoding: "utf8" }).trim(), "");
  const dist = path.join(root, directory, distPath);
  const files = [];
  const walk = (directory) => {
    for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
      const file = path.join(directory, entry.name);
      if (entry.isDirectory()) walk(file);
      else {
        assert.ok(entry.isFile() && !entry.isSymbolicLink(), file);
        const bytes = fs.readFileSync(file);
        files.push({ path: path.relative(dist, file).replaceAll("\\", "/"), bytes: bytes.length, sha256: createHash("sha256").update(bytes).digest("hex") });
      }
    }
  };
  walk(dist);
  files.sort((a, b) => a.path.localeCompare(b.path));
  const htmlPages = files.filter((file) => file.path.endsWith(".html")).length;
  assert.ok(htmlPages >= minimum);
  const html = fs.readFileSync(path.join(dist, required), "utf8");
  for (const version of ["0.166.131", "0.37.169", "0.4.186", "v5.0.3.143"]) assert.ok(html.includes(version), `${site}: ${version}`);
  if (site === "www") {
    const english = fs.readFileSync(path.join(dist, "en/index.html"), "utf8");
    for (const version of ["0.166.131", "0.37.169", "0.4.186"]) assert.ok(english.includes(version));
  }
  if (site === "docs") assert.ok(fs.statSync(path.join(dist, "changelog.html")).size >= 2000);
  receipt.htmlPages = htmlPages;
  receipt.files = files;
  receipt.sourceStable = true;
  receipt.requiredPage = required;
  receipt.buildOutputVerified = true;
} catch (error) {
  receipt.verificationError = error.message;
  process.exitCode = 1;
}
fs.writeFileSync(`.work/sites131-final-20261029/build-${site}-process.json`, JSON.stringify(receipt, null, 2) + "\n");
console.log(JSON.stringify({ site, exitCode: receipt.exitCode, htmlPages: receipt.htmlPages, files: receipt.files?.length, verificationError: receipt.verificationError }));
