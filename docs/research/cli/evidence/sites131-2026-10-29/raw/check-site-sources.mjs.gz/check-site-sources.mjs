import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {execFileSync} from 'node:child_process';
const out='.work/sites131-final-20261029';fs.mkdirSync(out,{recursive:true});
const read=p=>JSON.parse(fs.readFileSync(p));
const file='docs-website-v2/src/data/release-status.json',data=read(file),publication=read('docs/research/cli/evidence/release131-public/publication.json');
const baseline=JSON.parse(execFileSync('git',['show',`83c281f4e81aed6943ec8aef37ca9c240b970275:${file}`],{encoding:'utf8',windowsHide:true}));
for(const key of Object.keys(baseline).filter(k=>/^release\d+Channels$/.test(k)))assert.deepEqual(data[key],baseline[key],key);
for(const [field,value] of Object.entries({recommendedCliVersion:'0.166.131',npmLatestCliVersion:'0.166.131',openVsxVersion:'0.37.169',jetBrainsMarketplaceVersion:'0.4.186',contextMemoryKernelVersion:'0.1.11',jetBrainsUpdateId:1206001,cumulativeAcceptedDeliveries:34,remainingUnaccepted:11,productVersion:'v5.0.3.143'}))assert.equal(data[field],value,field);
assert.equal(data.cliReleaseCommit,publication.sourceSha);assert.equal(publication.status,'public');
const sizes='docs-website-v2/src/data/release-sizes.json',size=read(sizes),oldSizes=JSON.parse(execFileSync('git',['show',`83c281f4e81aed6943ec8aef37ca9c240b970275:${sizes}`],{encoding:'utf8',windowsHide:true}));
assert.deepEqual(size.sizes,oldSizes.sizes);assert.equal(size.fetchedAt,oldSizes.fetchedAt);
const require=createRequire(path.resolve('docs-website-v2/package.json')),compiler=require('@astrojs/compiler');
const templates=[];
function walk(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(dir,e.name)):[path.join(dir,e.name)]);}
for(const name of [...walk('docs-website-v2/src/pages').filter(n=>n.endsWith('.astro')),'docs-website-v2/src/components/SourceUpdate.astro']){const result=await compiler.transform(fs.readFileSync(name,'utf8'),{filename:name});assert.ok(!result.diagnostics.some(d=>d.severity===1),name);templates.push({file:name,diagnostics:result.diagnostics.length});}
const sectionCheck=execFileSync(process.execPath,['docs-site/scripts/check-user-doc-sections.js'],{encoding:'utf8',windowsHide:true});fs.writeFileSync(out+'/user-doc-sections.log',sectionCheck);
const config=read('docs/research/cli/verify01-package-sets/2026-10-29-review-131.json');assert.equal(config.releaseSourceCommit,publication.sourceSha);assert.equal(config.origin.jetbrains.updateId,data.jetBrainsUpdateId);
for(const name of ['docs-site/docs/.vitepress/config.js','docs-site-design/docs/.vitepress/config.js','scripts/deploy-docs-snapshot.sh','.github/workflows/docs-snapshot-build.yml'])assert.ok(fs.readFileSync(name,'utf8').includes('2026-10-29-131'),name);
const design=fs.readFileSync('docs/design/release-runtime-update-2026-10-29-131.md','utf8');
assert.ok(!design.includes('(../research/'),'Research is not mirrored into either design site');
const pinned='83c281f4e81aed6943ec8aef37ca9c240b970275';
const citations=[...design.matchAll(/https:\/\/github\.com\/chainlesschain\/chainlesschain\/blob\/([a-f0-9]{40})\/(docs\/research\/[^)\s]+)/g)];
assert.equal(citations.length,17);
for(const [,commit,file] of citations){assert.equal(commit,pinned);execFileSync('git',['cat-file','-e',`${commit}:${file}`],{windowsHide:true});}
const cliReadme=fs.readFileSync('packages/cli/README.md','utf8');
for(const url of ['https://docs.chainlesschain.com/chainlesschain/cli-ide-update-2026-10-29-131.html','https://design.chainlesschain.com/release-runtime-update-2026-10-29-131.html'])assert.ok(cliReadme.includes(url));
const result={checkedAt:new Date().toISOString(),publicSource:publication.sourceSha,reviewBaseline:pinned,phase:'source verification; build receipts bind the final commit',historicalReleaseRecordsPreserved:true,clientSizesAndFetchDatePreserved:true,publicVersionsAndCountsMatch:true,pinnedResearchLinksVerified:citations.length,npmReadmeUsesPublicGuideLinks:true,templates,userDocSections:sectionCheck.trim(),deploymentVerified:false};fs.writeFileSync(out+'/source-checks.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({templates:templates.length,publicPairing:'matched',history:'preserved',pinnedResearchLinks:citations.length,userDocs:sectionCheck.trim()}));
