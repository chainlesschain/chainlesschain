import fs from "node:fs";
import path from "node:path";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { spawnSync, execFileSync } from "node:child_process";
const source = "14e8bce45cf2de15187c0d7b0fb53730c07d1b05";
const journal = ".work/sites131-final-20261029/deploy-process.json";
assert.ok(!fs.existsSync(journal), "An existing deployment attempt must be read back, never blindly replayed");
assert.equal(execFileSync("git", ["rev-parse", "HEAD"], { encoding: "utf8" }).trim(), source);
assert.equal(execFileSync("git", ["status", "--porcelain"], { encoding: "utf8" }).trim(), "");
const roots = { docs: "docs-site/docs/.vitepress/dist", design: "docs-site-design/docs/.vitepress/dist", www: "docs-website-v2/dist" };
const builds = [];
for (const [site, root] of Object.entries(roots)) {
  const build = JSON.parse(fs.readFileSync(`.work/sites131-final-20261029/build-${site}-process.json`));
  assert.ok(build.exitCode === 0 && build.buildOutputVerified && build.source === source && build.sourceStable);
  for (const file of build.files) {
    const bytes = fs.readFileSync(path.join(root, file.path));
    assert.equal(bytes.length, file.bytes);
    assert.equal(createHash("sha256").update(bytes).digest("hex"), file.sha256);
  }
  builds.push({ site, htmlPages: build.htmlPages, files: build.files.length });
}
const args = ["-NoProfile", "-NonInteractive", "-File", "scripts/deploy-docs-snapshot.ps1"];
const intent = { source, builds, args, startedAt: new Date().toISOString(), state: "intent", boundary: "Deploys the verified local build; the exact-source cloud snapshot is tracked independently. Existing live directories are backed up by the deployment script." };
fs.writeFileSync(journal, JSON.stringify(intent, null, 2) + "\n", { flag: "wx" });
const run = spawnSync("powershell.exe", args, { encoding: "utf8", windowsHide: true, maxBuffer: 16 * 1024 * 1024, timeout: 15 * 60 * 1000 });
fs.writeFileSync(".work/sites131-final-20261029/deploy.log", (run.stdout || "") + "\n" + (run.stderr || ""), { flag: "wx" });
const stamp = /Deployment stamp: ([a-zA-Z0-9-]+)/.exec(run.stdout || "")?.[1] || null;
const receipt = { ...intent, endedAt: new Date().toISOString(), exitCode: run.status, signal: run.signal, error: run.error?.message || null, state: run.status === 0 ? "deployed_requires_public_readback" : "requires_remote_state_readback", stamp, stdout: run.stdout, stderr: run.stderr };
fs.writeFileSync(journal, JSON.stringify(receipt, null, 2) + "\n");
console.log(JSON.stringify({ state: receipt.state, exitCode: run.status, stamp, error: receipt.error, output: run.stdout?.slice(-2400), stderr: run.stderr?.slice(-2000) }));
process.exitCode = run.status ?? 1;
