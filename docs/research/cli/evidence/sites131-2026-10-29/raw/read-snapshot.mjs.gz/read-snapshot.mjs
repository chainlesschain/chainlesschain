import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
const root='.work/sites131-final-20261029';
const {source}=JSON.parse(fs.readFileSync(root+'/source.json'));
const output=JSON.parse(execFileSync('gh',['api','repos/chainlesschain/chainlesschain/actions/workflows/docs-snapshot-build.yml/runs?per_page=30'],{encoding:'utf8',windowsHide:true,timeout:30000,maxBuffer:16*1024*1024}));
const rows=output.workflow_runs.filter(r=>r.head_sha===source&&r.event==='workflow_dispatch');
const report={observedAt:new Date().toISOString(),source,rows:rows.map(r=>({id:r.id,source:r.head_sha,status:r.status,conclusion:r.conclusion,url:r.html_url}))};
if(rows.length===1){const jobs=JSON.parse(execFileSync('gh',['api',`repos/chainlesschain/chainlesschain/actions/runs/${rows[0].id}/jobs?per_page=100`],{encoding:'utf8',windowsHide:true,timeout:30000,maxBuffer:16*1024*1024}));report.jobs=jobs.jobs.map(j=>({id:j.id,name:j.name,status:j.status,conclusion:j.conclusion,steps:j.steps}));}
fs.writeFileSync(root+'/snapshot-readback-'+report.observedAt.replaceAll(/[:.]/g,'-')+'.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(report));
