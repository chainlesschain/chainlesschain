import fs from "node:fs";
import path from "node:path";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
const source = "14e8bce45cf2de15187c0d7b0fb53730c07d1b05";
const stamp = process.argv[2];
assert.ok(/^[a-zA-Z0-9-]+$/.test(stamp || "") && stamp.includes(source.slice(0, 10)));
const root = `.work/sites131-final-20261029/public-${new Date().toISOString().replaceAll(/[:.]/g, "-")}`;
fs.mkdirSync(root, { recursive: true });
const sha = (bytes) => createHash("sha256").update(bytes).digest("hex");
const pages = {
  docs: ["chainlesschain/cli-ide-update-2026-10-29-131.html", "chainlesschain/cli-agent.html", "chainlesschain/ide-plugin.html", "chainlesschain/cli-memory.html", "design/release-runtime-update-2026-10-29-131.html"],
  design: ["release-runtime-update-2026-10-29-131.html", "cli-runtime-current.html"],
  www: ["index.html", "en/index.html", "cli/index.html", "ide/index.html"],
};
const directories = { docs: "docs-site/docs/.vitepress/dist", design: "docs-site-design/docs/.vitepress/dist", www: "docs-website-v2/dist" };
async function get(site, file, target) {
  const url = `https://${site}.chainlesschain.com/${file}?deployment=${stamp}`;
  const response = await fetch(url, { headers: { "Cache-Control": "no-cache", "Accept-Encoding": "identity" }, signal: AbortSignal.timeout(30_000) });
  if (!response.ok) throw new Error(`HTTP ${response.status}: ${url}`);
  const chunks = [];
  let count = 0;
  for await (const chunk of response.body) {
    count += chunk.length;
    if (count > 16 * 1024 * 1024) throw new Error("Public readback exceeds bound");
    chunks.push(Buffer.from(chunk));
  }
  const bytes = Buffer.concat(chunks);
  if (target) fs.writeFileSync(path.join(root, `${site}-${target}`), bytes, { flag: "wx" });
  return { url, status: response.status, bytes, sha256: sha(bytes) };
}
const sites = await Promise.all(Object.keys(pages).map(async (site) => {
  const build = JSON.parse(fs.readFileSync(`.work/sites131-final-20261029/build-${site}-process.json`));
  assert.ok(build.exitCode === 0 && build.buildOutputVerified && build.source === source);
  const metadata = await get(site, "deployment-source.json", "deployment-source.json");
  const deployment = JSON.parse(metadata.bytes);
  assert.equal(deployment.sourceHeadCommit, source);
  assert.equal(deployment.sourceStatus, "clean-commit");
  assert.equal(deployment.stamp, stamp);
  assert.equal(deployment.newHtmlPages, build.htmlPages);
  assert.equal(deployment.newFiles, build.files.length);
  const manifest = await get(site, "deployment-files.sha256", "deployment-files.sha256");
  const hashes = new Map(manifest.bytes.toString("utf8").trim().split(/\r?\n/).map((line) => {
    const match = /^([a-f0-9]{64})  (?:\.\/)?(.+)$/.exec(line);
    assert.ok(match, "Malformed server manifest");
    return [match[2], match[1]];
  }));
  for (const file of build.files) assert.equal(hashes.get(file.path), file.sha256, `${site}: ${file.path}`);
  const samples = await Promise.all(pages[site].map(async (file) => {
    const response = await get(site, file, 'page-' + file.replaceAll('/', '__'));
    const local = fs.readFileSync(path.join(directories[site], file));
    assert.equal(response.sha256, sha(local), response.url);
    assert.equal(response.bytes.length, local.length, response.url);
    return { url: response.url, path: file, status: response.status, bytes: response.bytes.length, sha256: response.sha256, matchesLocalBuild: true };
  }));
  return { site, deployment, newFileHashesMatched: build.files.length, checksumManifestSha256: manifest.sha256, sampledPages: samples };
}));
const report = { schema: "chainlesschain.sites131-public-readback/v1", observedAt: new Date().toISOString(), source, stamp, sites, boundary: "Public sampled page bytes and all new server-manifest file hashes match the source-bound Windows local builds. Exact-source cloud CI is separately tracked; its artifacts were not substituted for the local build receipts. Retained older files are preserved by deployment; they are not claimed as part of the new build." };
fs.writeFileSync(path.join(root, "readback.json"), JSON.stringify(report, null, 2) + "\n", { flag: "wx" });
console.log(JSON.stringify({ file: path.join(root, "readback.json"), sites: sites.map(({ site, newFileHashesMatched, sampledPages }) => ({ site, files: newFileHashesMatched, pages: sampledPages.length })) }));
