#!/usr/bin/env node
// Operator-only continuation. No dispatch or journal writes without --submit.
import fs from "node:fs";
import path from "node:path";
import { createHash, randomBytes } from "node:crypto";
import { execFileSync, spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import {
  loadNativeRetestPlan,
  verifyNativeRetestRoundWithContext,
  readNativeRetestArchive,
} from "../../packages/cli/scripts/verify01-native-retest-round.mjs";
import { assertCurrentNativeRetestChain } from "../../packages/cli/scripts/verify01-native-retest-plan.mjs";
import { verifyInheritedLegacy127 } from "./legacy127-reserve.mjs";
import { verifyTerminalEvidence } from "../../docs/research/cli/evidence/native131-preexecution-2026-10-29/verify-evidence.mjs";

const REPOSITORY = "chainlesschain/chainlesschain";
const WORKFLOW = "verify01-native-task-campaign.yml";
const PREFIX =
  "docs/research/cli/evidence/implementation-plan-2026-10-15/task-campaign-2026-10-18";
const PLAN = `${PREFIX}/next-package-131-preflight-repair-20261029-plan.json`;
const MANIFEST =
  "docs/research/cli/verify01-package-sets/2026-10-29-review-131.json";
const RELEASE_SOURCE = "c9d0bab231850697df38f2d476c2dd974cbcb6c0";
const REVIEWED_CERTIFICATE_DIGEST = "sha256:1337173028b704ad9ce262e47ace9631c4220005e66239efbba245f36805df70";
const REVIEWED_PLAN_DIGEST = "sha256:acfae4ee045f0b15b5bb14fdf8da6a8f655e733f8f4077b7ad8226583a89286a";
const OLD_DIGEST =
  "1d5cdac56fe466db1415dd1b9fcb79832a7c933b11f0743c48c18a156129ce94";
const OLD_SHARD = "win32-vscode--verify-11";
const PRIORITY = [
  "verify-10",
  "verify-04",
  "verify-13",
  "verify-09",
  "verify-30",
  "verify-07",
  "verify-19",
  "verify-08",
  "first-run-darwin-cli",
  "first-run-darwin-jetbrains",
  "verify-11",
];
const VERSIONS = { cli: "0.166.131", vscode: "0.37.169", jetbrains: "0.4.186" };
const root = path.resolve(
  path.dirname(fileURLToPath(import.meta.url)),
  "../..",
);
const observed = new Map();
let stage = "arguments";
class Stop extends Error {}
function need(condition, code) {
  if (!condition) throw new Stop(code);
}
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const hash = (bytes) =>
  `sha256:${createHash("sha256").update(bytes).digest("hex")}`;
function command(program, args, options = {}) {
  try {
    return execFileSync(program, args, {
      cwd: root,
      windowsHide: true,
      timeout: 120000,
      maxBuffer: 64 * 1024 * 1024,
      stdio: ["ignore", "pipe", "pipe"],
      ...options,
    });
  } catch {
    throw new Stop("READ_COMMAND_FAILED");
  }
}
const git = (...args) => command("git", args).toString("utf8").trim();
const parse = (bytes) =>
  JSON.parse(bytes.toString("utf8").replace(/^\uFEFF/u, ""));
function local(relative, base = root) {
  need(
    typeof relative === "string" && /^[A-Za-z0-9_./-]+$/u.test(relative),
    "UNSAFE_LOCAL_PATH",
  );
  need(
    !relative.startsWith("/") &&
      relative
        .split("/")
        .every((part) => part && part !== "." && part !== ".."),
    "UNSAFE_LOCAL_PATH",
  );
  let file = base;
  for (const part of relative.split("/")) {
    file = path.join(file, part);
    if (fs.existsSync(file))
      need(!fs.lstatSync(file).isSymbolicLink(), "LINKED_LOCAL_INPUT");
  }
  return file;
}
function bytes(file) {
  const value = fs.readFileSync(file);
  const digest = hash(value);
  if (observed.has(file))
    need(observed.get(file) === digest, "INPUT_CHANGED_DURING_ADMISSION");
  observed.set(file, digest);
  return value;
}
const read = (file) => parse(bytes(file));
const amount = (value) => {
  need(
    typeof value === "number" && Number.isFinite(value) && value >= 0,
    "INVALID_ACCOUNTING_VALUE",
  );
  return value;
};
function integer(value) {
  need(Number.isSafeInteger(value) && value >= 0, "INVALID_REQUEST_COUNT");
  return value;
}
function unchanged() {
  for (const [file, digest] of observed)
    need(
      hash(fs.readFileSync(file)) === digest,
      "INPUT_CHANGED_DURING_ADMISSION",
    );
}
function durableNew(file, value) {
  const fd = fs.openSync(file, "wx", 0o600);
  try {
    fs.writeFileSync(fd, JSON.stringify(value, null, 2) + "\n");
    fs.fsyncSync(fd);
  } finally {
    fs.closeSync(fd);
  }
}
function archive(context, run, entry) {
  return readNativeRetestArchive(entry, {
    stem: context.stem,
    runId: run.runId,
    read: (relative) => bytes(local(relative)),
  });
}
function evidence(context, run, stageName, member) {
  const found = run.evidence.filter(
    (item) => item.stage === stageName && item.originalArtifactPath === member,
  );
  need(found.length === 1, "MISSING_OR_DUPLICATE_ARCHIVED_RECEIPT");
  return parse(archive(context, run, found[0].archived));
}
// Same NO_TRANSPORT_DISPATCH exception as the existing continuation policy.
// HTTP errors, missing usage after transport and a poisoned broker all halt.
function brokerCost(broker, getRequest) {
  need(
    broker && broker.poisoned === null && broker.formalSample === false,
    "BROKER_NOT_RECONCILED",
  );
  const started = integer(broker.physicalRequestsStarted);
  const recordedComplete = integer(broker.usageCompleteRequests);
  let cost = 0,
    complete = 0,
    undispatched = 0;
  for (let index = 1; index <= started; index++) {
    const row = getRequest(index);
    need(row.id === index, "BROKER_REQUEST_ID_MISMATCH");
    if (
      row.usage !== null &&
      typeof row.usage === "object" &&
      Number.isFinite(row.tokenOnlyEstimateCny) &&
      row.tokenOnlyEstimateCny >= 0
    ) {
      cost += amount(row.tokenOnlyEstimateCny);
      complete++;
      continue;
    }
    need(
      row.usage === null &&
        row.tokenOnlyEstimateCny === null &&
        row.errorCode === "DIAGNOSTIC_REQUEST_NOT_DISPATCHED",
      "UNKNOWN_REQUEST_USAGE",
    );
    need(row.transport?.dispatchStarted === false, "UNKNOWN_REQUEST_DISPATCH");
    for (const key of [
      "tcpConnectedMs",
      "tlsConnectedMs",
      "dispatchStartedMs",
      "requestFinishedMs",
      "responseStartedMs",
    ])
      need(
        row.transport[key] === null,
        "TRANSPORT_ACTIVITY_ON_UNDISPATCHED_RECEIPT",
      );
    need(
      row.response?.status === null &&
        row.response.storedBytes === 0 &&
        row.response.originalBytes === 0,
      "UNEXPECTED_UNDISPATCHED_RESPONSE",
    );
    const empty = hash(Buffer.alloc(0)).slice(7);
    need(
      row.response.storedSha256 === empty &&
        row.response.originalSha256 === empty,
      "UNEXPECTED_UNDISPATCHED_RESPONSE",
    );
    undispatched++;
  }
  need(
    complete === recordedComplete && complete + undispatched === started,
    "BROKER_USAGE_COUNT_MISMATCH",
  );
  if (!undispatched)
    need(
      Math.abs(cost - amount(broker.tokenOnlyEstimateCny)) < 1e-8,
      "BROKER_COST_SUM_MISMATCH",
    );
  else if (broker.knownTokenOnlyEstimateCny !== undefined)
    need(
      Math.abs(cost - amount(broker.knownTokenOnlyEstimateCny)) < 1e-8,
      "BROKER_KNOWN_COST_SUM_MISMATCH",
    );
  return { cost, started, complete, undispatched };
}
function collectedRound(planFile, ledgerFile) {
  const context = loadNativeRetestPlan(planFile, root);
  bytes(local(planFile));
  const ledger = read(ledgerFile || local(context.plan.ledgerPath));
  verifyNativeRetestRoundWithContext(context, { ledger });
  let cost = 0;
  for (const run of ledger.runs) {
    need(
      run.status === "COMPLETED" &&
        run.remoteStatus === "completed" &&
        run.generation &&
        run.acceptance &&
        run.activeJobs.length === 0,
      "PRIOR_SAMPLE_NOT_FULLY_COLLECTED",
    );
    const generation = parse(archive(context, run, run.generation.rawSummary));
    const acceptance = parse(archive(context, run, run.acceptance.rawSummary));
    for (const id of run.selectedSampleIds) {
      const sample = generation.samples.find((item) => item.sampleId === id);
      const accepted = acceptance.samples.find((item) => item.sampleId === id);
      need(
        sample &&
          accepted &&
          typeof accepted.candidateAcceptancePassed === "boolean",
        "PRIOR_ACCEPTANCE_MISSING",
      );
      const usage = brokerCost(sample.broker, (index) =>
        evidence(
          context,
          run,
          "generation",
          `${id}/broker/request-${index}.receipt.json`,
        ),
      );
      need(
        sample.brokerStatus?.physicalRequestsStarted === usage.started &&
          sample.brokerStatus?.usageCompleteRequests === usage.complete &&
          sample.brokerStatus?.poisoned === null,
        "BROKER_SUMMARIES_DIFFER",
      );
      cost += usage.cost;
    }
  }
  return { context, ledger, cost };
}
function preexecutionForPlan(plan) {
  const proofFile = "docs/research/cli/evidence/native131-preexecution-2026-10-29/terminal.json";
  const proof = read(local(proofFile));
  const result = verifyTerminalEvidence();
  need(result.certificateDigest === REVIEWED_CERTIFICATE_DIGEST && hash(bytes(local(PLAN))) === REVIEWED_PLAN_DIGEST, "REVIEWED_PREEXECUTION_IDENTITY_CHANGED");
  need(same(proof, result.certificate), "PREEXECUTION_CERTIFICATE_CHANGED");
  const descriptor = plan.operatorContinuation?.preexecutionTerminal;
  need(descriptor?.path === proofFile && descriptor.digest === hash(bytes(local(proofFile))) && descriptor.successorPlanPath === PLAN && descriptor.originalPlanPath === proof.planPath && descriptor.originalPlanDigest === proof.planDigest && descriptor.runId === proof.runId && descriptor.generationExecution === "NOT_STARTED" && descriptor.normalLedgerCompletionUnchanged === true && descriptor.oneSuccessorOnly === true, "PREEXECUTION_SUCCESSOR_BINDING_INVALID");
  for (const entry of Object.values(proof.evidence)) need(hash(bytes(local(entry.path))) === entry.digest, "PREEXECUTION_ARCHIVED_BYTES_CHANGED");
  const originalJournal = local("next-package-dispatch/" + proof.planDigest.slice(7), path.join(root, ".work"));
  const originals = { context: path.join(originalJournal, "context.json"), intent: path.join(originalJournal, proof.shardId + ".intent.json"), request: path.join(originalJournal, proof.shardId + ".request.json"), resolved: path.join(originalJournal, proof.shardId + ".resolved.json"), ledger: local(read(local(proof.evidence.plan.path)).ledgerPath) };
  for (const [key, file] of Object.entries(originals)) need(hash(bytes(file)) === proof.evidence[key].digest, "PREEXECUTION_ORIGINAL_RECORD_CHANGED");
  const pending = [local(".work/native131-easy-first-20261029/admit-repaired.mjs"), local(".work/native131-easy-first-20261029/verify-terminal-current.mjs")];
  const visited = new Set();
  while (pending.length) {
    const file = pending.pop();
    if (visited.has(file)) continue;
    visited.add(file);
    const source = bytes(file).toString("utf8");
    for (const match of source.matchAll(/(?:\bfrom\s*|\bimport\s*\(\s*|\bimport\s*)["'](\.[^"']+)["']/g)) {
      const absolute = path.resolve(path.dirname(file), match[1]);
      const relative = path.relative(root, absolute).replaceAll("\\", "/");
      need(relative && !relative.startsWith("../") && !path.isAbsolute(relative), "CODE_DEPENDENCY_OUTSIDE_REPOSITORY");
      pending.push(local(relative));
    }
  }
  for (const file of [".work/native131-easy-first-20261029/dispatch-once-repaired.py", "packages/cli/scripts/verify01-dispatch-native-retest.py"]) bytes(local(file));
  return { certificate: proof, digest: result.certificateDigest, terminal: result.terminal };
}
function refreshPreexecution(proof) {
  const current = parse(command(process.execPath, [local(".work/native131-easy-first-20261029/verify-terminal-current.mjs")]));
  need(current.verified === true && current.runId === proof.terminal.runId && current.runAttempt === 1 && current.certificateDigest === proof.digest && current.successorPlanPath === PLAN && current.generationExecution === "NOT_STARTED" && current.liabilitiesPreserved === true, "PREEXECUTION_REMOTE_CHANGED");
}
function claimPreexecutionSuccessor(proof, sourceCommit, planDigest) {
  const folder = local(".work/native131-easy-first-20261029/preexecution-successors");
  fs.mkdirSync(folder, { recursive: true });
  const file = path.join(folder, "40886343743-attempt-1-8e72ccf5b30cff3f6edb8ed8c9c326e72c3c6304.json");
  const claim = { schema: "chainlesschain.preexecution-successor-use/v1", certificateDigest: proof.digest, originalRunId: proof.terminal.runId, successorPlanPath: PLAN, successorPlanDigest: planDigest, sourceCommit, liabilitiesPreserved: true };
  if (fs.existsSync(file)) need(same(read(file), claim), "PREEXECUTION_CERTIFICATE_ALREADY_CLAIMED_BY_ANOTHER_SUCCESSOR");
  else durableNew(file, claim);
  need(same(read(file), claim), "PREEXECUTION_SUCCESSOR_CLAIM_CHANGED");
  return { path: file, digest: hash(bytes(file)) };
}
function liveInventory() {
  const pages = parse(
    command("gh", [
      "api",
      "--method",
      "GET",
      "--paginate",
      "--slurp",
      `repos/${REPOSITORY}/actions/workflows/${WORKFLOW}/runs`,
      "-f",
      "per_page=100",
    ]),
  );
  need(
    Array.isArray(pages) && pages.length > 0,
    "INVALID_NATIVE_RUN_INVENTORY",
  );
  const rows = pages.flatMap((page) => page.workflow_runs);
  need(
    rows.every(
      (run) => Number.isSafeInteger(run.id) && typeof run.status === "string",
    ),
    "INVALID_NATIVE_RUN_INVENTORY",
  );
  need(
    new Set(rows.map((run) => run.id)).size === rows.length,
    "NATIVE_RUN_PAGINATION_CHANGED",
  );
  need(
    pages.every((page) => page.total_count === rows.length),
    "NATIVE_RUN_INVENTORY_INCOMPLETE",
  );
  need(
    rows.every((run) => run.status === "completed"),
    "ACTIVE_NATIVE_WORKFLOW_EXISTS",
  );
  return { observedAt: new Date().toISOString(), rows };
}
function validateInventory(inventory, knownRuns, fundingObservedAt) {
  const observedAt = Date.parse(fundingObservedAt);
  need(Number.isFinite(observedAt), "FUNDING_OBSERVATION_TIME_MISSING");
  const byId = new Map(inventory.rows.map((run) => [String(run.id), run]));
  for (const [runId, known] of knownRuns) {
    const run = byId.get(runId);
    need(
      run && run.status === "completed" && run.run_attempt === 1,
      "KNOWN_RUN_MISSING_ACTIVE_OR_RERUN",
    );
    if (known.sourceCommit)
      need(run.head_sha === known.sourceCommit, "KNOWN_RUN_SOURCE_CHANGED");
  }
  for (const run of inventory.rows) {
    need(
      Number.isFinite(Date.parse(run.created_at)),
      "NATIVE_RUN_TIME_MISSING",
    );
    if (
      Date.parse(run.created_at) >= observedAt ||
      (Date.parse(run.updated_at) >= observedAt && run.run_attempt > 1)
    )
      need(
        knownRuns.has(String(run.id)),
        "SUBSEQUENT_NATIVE_RUN_NOT_ACCOUNTED",
      );
  }
}
function journalRows(directory, shards, expectedContext) {
  if (!fs.existsSync(directory)) return [];
  const files = fs.readdirSync(directory);
  const recognized = new Set([
    "lock",
    "context.json",
    "runs.json",
    ...shards.flatMap((shard) =>
      ["intent", "request", "resolved"].map(
        (kind) => `${shard.shardId}.${kind}.json`,
      ),
    ),
  ]);
  need(
    files.every((name) => recognized.has(name)),
    "UNRECOGNIZED_JOURNAL_FILE",
  );
  if (files.some((name) => name.endsWith(".intent.json")))
    need(
      fs.existsSync(path.join(directory, "context.json")),
      "JOURNAL_CONTEXT_MISSING",
    );
  if (fs.existsSync(path.join(directory, "context.json")))
    need(
      same(read(path.join(directory, "context.json")), expectedContext),
      "JOURNAL_CONTEXT_CHANGED",
    );
  let gap = false;
  const resolved = [];
  for (const shard of shards) {
    const base = path.join(directory, shard.shardId);
    const hasIntent = fs.existsSync(`${base}.intent.json`),
      hasRequest = fs.existsSync(`${base}.request.json`),
      hasResolved = fs.existsSync(`${base}.resolved.json`);
    need(!hasRequest || hasIntent, "ORPHAN_REQUEST");
    need(!hasResolved || (hasIntent && hasRequest), "ORPHAN_RESOLUTION");
    if (!hasIntent) {
      gap = true;
      continue;
    }
    need(
      !gap && shard.sampleIds[0] !== "verify-11",
      "OUT_OF_ORDER_OR_HELD_DISPATCH",
    );
    const intent = read(`${base}.intent.json`);
    need(
      same(intent.binding, expectedContext) && same(intent.shard, shard),
      "INTENT_BINDING_CHANGED",
    );
    need(hasResolved, "UNRESOLVED_INTENT_NEVER_REPLAY");
    read(`${base}.request.json`);
    const binding = read(`${base}.resolved.json`);
    need(
      binding.shardId === shard.shardId &&
        binding.group === shard.group &&
        binding.sourceCommit === expectedContext.sourceCommit &&
        /^[1-9][0-9]*$/u.test(binding.runId),
      "INVALID_RESOLVED_BINDING",
    );
    resolved.push(binding);
  }
  need(
    new Set(resolved.map((row) => row.runId)).size === resolved.length,
    "DUPLICATE_RESOLVED_RUN",
  );
  return resolved;
}

function main() {
  const args = process.argv.slice(2);
  need(
    args.length === 0 || same(args, ["--submit"]) || same(args, ["--help"]),
    "ONLY_EXPLICIT_SUBMIT_OR_PREVIEW_SUPPORTED",
  );
  if (args[0] === "--help") {
    console.log(
      "Default: read-only admission preview. --submit: at most one original dispatcher invocation; never retry uncertain writes. See ADMISSION.md.",
    );
    return;
  }
  const submit = args[0] === "--submit";
  stage = "public-plan-prerequisites";
  for (const file of [MANIFEST, PLAN])
    need(
      fs.existsSync(local(file)),
      "PUBLIC_MANIFEST_OR_COMMITTED_PLAN_NOT_READY",
    );
  // No funding reads, network queries or journal creation before this point.
  const common = git("rev-parse", "--path-format=absolute", "--git-common-dir");
  need(
    path.isAbsolute(common) && fs.statSync(common).isDirectory(),
    "SHARED_GIT_DIRECTORY_REQUIRED",
  );
  const sharedRoot = path.dirname(fs.realpathSync(common));
  const work = local(".work", sharedRoot);
  const operator = local("native131-easy-first-20261029", work);
  need(
    fs.realpathSync(path.dirname(fileURLToPath(import.meta.url))) ===
      fs.realpathSync(operator),
    "USE_SHARED_OPERATOR_DIRECTORY",
  );
  let lockFd, lockFile;
  try {
    if (submit) {
      lockFile = path.join(operator, "admission.lock");
      try {
        lockFd = fs.openSync(lockFile, "wx", 0o600);
      } catch {
        throw new Stop("WRAPPER_LOCK_HELD_OR_CRASHED_NO_AUTOMATIC_RECOVERY");
      }
      fs.writeFileSync(
        lockFd,
        JSON.stringify({
          pid: process.pid,
          createdAt: new Date().toISOString(),
          nonce: randomBytes(32).toString("hex"),
        }) + "\n",
      );
      fs.fsyncSync(lockFd);
      bytes(lockFile);
    }
    stage = "strict-plan";
    const sourceCommit = git("rev-parse", "HEAD");
    need(git("branch", "--show-current") === "main", "MAIN_BRANCH_REQUIRED");
    need(!git("diff", "--name-only", "HEAD"), "TRACKED_TREE_MUST_BE_CLEAN");
    const planBytes = bytes(local(PLAN)),
      manifestBytes = bytes(local(MANIFEST));
    need(
      planBytes.equals(command("git", ["show", `${sourceCommit}:${PLAN}`])) &&
        manifestBytes.equals(
          command("git", ["show", `${sourceCommit}:${MANIFEST}`]),
        ),
      "PLAN_AND_MANIFEST_MUST_BE_COMMITTED",
    );
    const context = loadNativeRetestPlan(PLAN, root);
    assertCurrentNativeRetestChain(context.plan.priorRounds ?? []);
    const plan = context.plan,
      manifest = parse(manifestBytes);
    need(
      plan.packageSetPath === MANIFEST &&
        plan.packageSetDigest === hash(manifestBytes),
      "WRONG_PUBLIC_MANIFEST",
    );
    need(
      Object.entries(VERSIONS).every(
        ([key, value]) =>
          plan.versions[key] === value && manifest.versions[key] === value,
      ) && manifest.releaseSourceCommit === RELEASE_SOURCE,
      "WRONG_RELEASE_IDENTITY",
    );
    need(
      plan.plannedNewSamples === 11 &&
        plan.reusedAcceptedSampleIds.length === 34 &&
        plan.operatorContinuation?.reviewChanges === true &&
        (plan.runtimeOptions === undefined ||
          plan.runtimeOptions.reviewChanges === true),
      "TASK_CONTRACT_CHANGED",
    );
    const shards = plan.executionShards;
    need(
      same(
        shards.map((shard) => shard.sampleIds),
        PRIORITY.map((id) => [id]),
      ),
      "PRIORITY_OR_SINGLE_SAMPLE_CONTRACT_CHANGED",
    );
    need(
      same(plan.operatorContinuation?.heldSampleIds, ["verify-11"]) &&
        plan.operatorContinuation.oneActiveNewSample === true &&
        plan.operatorContinuation.newFundingGranted === false,
      "HELD_SAMPLE_CONTRACT_CHANGED",
    );
    const dispatchContext = {
      schema: "chainlesschain.native-dispatch-journal/v1",
      repository: REPOSITORY,
      workflow: WORKFLOW,
      branch: "main",
      sourceCommit,
      planPath: PLAN,
      planDigest: hash(planBytes),
      packageSetPath: MANIFEST,
      packageSetDigest: hash(manifestBytes),
      versions: plan.versions,
      executionShards: shards,
      reviewChanges: true,
    };
    const directory = local(
      `next-package-dispatch/${hash(planBytes).slice(7)}`,
      work,
    );
    const bindings = journalRows(directory, shards, dispatchContext);
    const next = shards[bindings.length];
    need(
      next && next.sampleIds[0] !== "verify-11",
      "NO_ELIGIBLE_UNREQUESTED_SAMPLE_HELD_VERIFY11_REMAINS",
    );
    const sampleId = next.sampleIds[0];
    const attemptName = `${hash(planBytes).slice(7)}--${next.shardId}`;
    const attemptFile = local(
      `attempts/${attemptName}.admission.private.json`,
      operator,
    );
    need(
      !fs.existsSync(attemptFile),
      "WRAPPER_INVOCATION_ALREADY_RECORDED_NEVER_REPLAY",
    );
    const currentLedger = fs.existsSync(
      local("collected-ledger.json", operator),
    )
      ? local("collected-ledger.json", operator)
      : local(plan.ledgerPath);
    let current = null;
    if (fs.existsSync(currentLedger))
      current = collectedRound(PLAN, currentLedger);
    need(
      (current?.ledger.runs.length ?? 0) === bindings.length,
      "JOURNAL_AND_COLLECTION_MUST_MATCH",
    );
    for (const binding of bindings) {
      const row = current.ledger.runs.find(
        (run) => run.runId === binding.runId && run.shardId === binding.shardId,
      );
      need(
        row && row.sourceCommit === binding.sourceCommit,
        "PRIOR_RESOLUTION_NOT_COLLECTED",
      );
    }

    stage = "shared-accounting";
    const fundingFile = local(
      "verify01-funded-20261027/funding-current.private.json",
      work,
    );
    const authorityFile = local(
      "verify01-review128-20261028/continuation-authority.private.json",
      work,
    );
    const funding = read(fundingFile),
      authority = read(authorityFile);
    const v2 = read(local("accounting-preparation-v2.private.json", operator));
    need(
      authority.fundingObservationDigest === hash(bytes(fundingFile)) &&
        v2.fundingObservationDigest === hash(bytes(fundingFile)) &&
        v2.continuationAuthorityDigest === hash(bytes(authorityFile)),
      "EXISTING_FUNDING_AUTHORITY_BINDING_CHANGED",
    );
    for (const key of [
      "aggregateReserveOverride",
      "perSampleLimitsUnchanged",
      "oneActiveSample",
      "priorLiabilitiesUnchanged",
      "noAutomaticReplay",
      "formalAdmissionUnchanged",
    ])
      need(authority[key] === true, "EXISTING_CONTINUATION_AUTHORITY_REQUIRED");
    need(
      v2.legacyAggregateOverrideApplied === true &&
        v2.additional129Exempted === false &&
        v2.newFundingGranted === false,
      "V2_ACCOUNTING_SEMANTICS_REQUIRED",
    );
    const oldDirectory = local(`next-package-dispatch/${OLD_DIGEST}`, work);
    const oldContext = read(path.join(oldDirectory, "context.json"));
    need(
      oldContext.sourceCommit === "f154c77641a761d4dc11a6b48a9503a3d6bc0c40",
      "OLD_129_CONTEXT_CHANGED",
    );
    need(
      hash(bytes(path.join(oldDirectory, `${OLD_SHARD}.intent.json`))) ===
        v2.originalIntentDigest &&
        hash(bytes(path.join(oldDirectory, `${OLD_SHARD}.request.json`))) ===
          v2.originalRequestDigest,
      "OLD_129_RECEIPT_CHANGED",
    );
    need(
      !fs.existsSync(path.join(oldDirectory, `${OLD_SHARD}.resolved.json`)),
      "OLD_129_STATE_CHANGED_RECONCILE_WITHOUT_REPLAY",
    );
    const prior = read(
      local(
        "docs/research/cli/evidence/recovery-2026-10-27/remaining-127-resolved-round-summary.json",
      ),
    );
    need(
      prior.knownPhysicalRequestsForResolvedRuns ===
        prior.usageCompleteRequestsForResolvedRuns &&
        prior.sharedHistoricalBudgetReset === false,
      "PRIOR_USAGE_NOT_RECONCILED",
    );
    const previous = collectedRound(
      `${PREFIX}/next-package-128-review-20261028-plan.json`,
    );
    need(previous.ledger.runs.length === 11, "PRIOR_128_COLLECTION_CHANGED");
    const knownRuns = new Map();
    function register(run) {
      need(!knownRuns.has(String(run.runId)), "DUPLICATE_ACCOUNTED_RUN");
      knownRuns.set(String(run.runId), run);
    }
    for (const row of prior.samples) register(row);
    for (const row of previous.ledger.runs) register(row);
    for (const row of current?.ledger.runs ?? []) register(row);
    const preexecution = preexecutionForPlan(plan);
    register({runId: preexecution.terminal.runId, sourceCommit: preexecution.terminal.sourceCommit});
    let subsequentCost = current?.cost ?? 0;
    // Optional operator evidence registry, NOT a new authorization or zero-spend
    // declaration. If inventory proves no later event, an absent file means no
    // extra registered source, not an invented liability or funding grant.
    const extrasFile = local("additional-known-spend.private.json", operator);
    const extras = fs.existsSync(extrasFile)
      ? read(extrasFile)
      : { nativeRounds: [], brokerSummaries: [] };
    need(
      Array.isArray(extras.nativeRounds) &&
        Array.isArray(extras.brokerSummaries),
      "INVALID_ADDITIONAL_SPEND_REGISTRY",
    );
    const extraPlans = new Set();
    for (const item of extras.nativeRounds) {
      need(
        item.planPath !== PLAN &&
          item.planPath !== previous.ledger.planPath &&
          !extraPlans.has(item.planPath),
        "DUPLICATE_ADDITIONAL_ROUND",
      );
      extraPlans.add(item.planPath);
      const extra = collectedRound(
        item.planPath,
        item.ledgerPath ? local(item.ledgerPath, sharedRoot) : undefined,
      );
      for (const row of extra.ledger.runs) register(row);
      subsequentCost += extra.cost;
    }
    const extraDigests = new Set();
    for (const item of extras.brokerSummaries) {
      const file = local(item.path, sharedRoot),
        raw = bytes(file);
      need(
        hash(raw) === item.digest && !extraDigests.has(item.digest),
        "INVALID_OR_DUPLICATE_ADDITIONAL_BROKER",
      );
      extraDigests.add(item.digest);
      const broker = parse(raw);
      subsequentCost += brokerCost(broker, (index) =>
        read(local(`request-${index}.receipt.json`, path.dirname(file))),
      ).cost;
    }
    // Preserve the one exact legacy liability already covered by the original
    // aggregate override. Age alone never exempts another unresolved intent.
    const verifyLegacy = () =>
      verifyInheritedLegacy127({
        readBytes: (file) => bytes(local(file, sharedRoot)),
        gitBytes: (commit, file) =>
          command("git", ["show", `${commit}:${file}`]),
        exists: (file) => fs.existsSync(local(file, sharedRoot)),
        v2,
        need,
      });
    const legacy = verifyLegacy();
    // Other intents must be the held .129 request, or resolved and accounted.
    const journals = local("next-package-dispatch", work);
    for (const entry of fs.readdirSync(journals, { withFileTypes: true })) {
      need(
        entry.isDirectory() &&
          !entry.isSymbolicLink() &&
          /^[a-f0-9]{64}$/u.test(entry.name),
        "UNRECOGNIZED_SHARED_JOURNAL",
      );
      const folder = local(`next-package-dispatch/${entry.name}`, work);
      for (const file of fs
        .readdirSync(folder)
        .filter((name) => name.endsWith(".intent.json"))) {
        if (entry.name === OLD_DIGEST && file === `${OLD_SHARD}.intent.json`)
          continue;
        if (
          entry.name === legacy.directoryDigest &&
          file === `${legacy.shardId}.intent.json`
        )
          continue;
        const resolvedFile = path.join(
          folder,
          file.replace(/\.intent\.json$/u, ".resolved.json"),
        );
        need(
          fs.existsSync(resolvedFile),
          "OTHER_UNRESOLVED_DISPATCH_MUST_BE_ACCOUNTED",
        );
        const binding = read(resolvedFile);
        need(
          knownRuns.has(String(binding.runId)),
          "OTHER_DISPATCH_NOT_ACCOUNTED",
        );
      }
    }
    const reserve = amount(funding.perActiveSampleTokenEstimateReserveCny);
    need(reserve > 0, "MISSING_SINGLE_SAMPLE_RESERVE");
    const inheritedReserve = amount(
      funding.priorUnresolvedWorkflowReserveCny ?? reserve,
    );
    const delayed = amount(funding.delayedBillingContingencyCny);
    const postObservation = Math.max(
      0,
      amount(prior.tokenOnlyEstimateCnyForResolvedRuns) +
        previous.cost +
        subsequentCost -
        amount(funding.tokenEstimateAtObservationCny),
    );
    const authorizedRequired = reserve + reserve + delayed + postObservation;
    const fullRequired = inheritedReserve + authorizedRequired;
    const ceiling = Math.min(
      amount(funding.availableCny),
      amount(authority.maximumNewEstimatedSpendCny),
    );
    need(
      Number.isFinite(fullRequired) && authorizedRequired <= ceiling,
      "EXISTING_AUTHORIZED_COVERAGE_INSUFFICIENT",
    );

    stage = "live-native-inventory";
    let inventory = liveInventory();
    validateInventory(inventory, knownRuns, funding.observedAt);
    refreshPreexecution(preexecution);
    unchanged();
    const dispatcherArgs = [
      "-B",
      "packages/cli/scripts/verify01-dispatch-native-retest.py",
      "--plan",
      PLAN,
      "--review-changes",
    ];
    const safe = {
      mode: submit ? "SUBMIT_ONE" : "PREVIEW_ONLY",
      sampleId,
      priority: PRIORITY,
      heldSampleIds: ["verify-11"],
      sourceCommit,
      planDigest: hash(planBytes),
      priorCollectedSamples: bindings.length,
      nativeRunsRead: inventory.rows.length,
      activeNativeRuns: 0,
      legacyAggregateOverrideApplied: true,
      inheritedLegacy127LiabilityPreserved: true,
      additional129LiabilityReserved: true,
      fullConservativeCoveragePassed: fullRequired <= ceiling,
      authorizedFundingCoveragePassed: true,
      newFundingGranted: false,
      preexecutionTerminal: { runId: preexecution.terminal.runId, digest: preexecution.digest, generationExecution: "NOT_STARTED", liabilitiesPreserved: true },
      billingReconciled: false,
      paidReady: false,
    };
    if (!submit) {
      // Original dispatcher preview rechecks committed bindings and live main;
      // public registry readback is deliberately reserved for explicit submit.
      const preview = parse(command("python", dispatcherArgs));
      need(
        preview.sourceCommit === sourceCommit &&
          preview.planDigest === hash(planBytes) &&
          preview.reviewChanges === true &&
          preview.unresolvedIntents.length === 0,
        "DISPATCHER_PREVIEW_DIFFERS",
      );
      unchanged();
      console.log(
        JSON.stringify({
          ...safe,
          publicRegistryRecheck: "required-by-dispatcher-on-submit",
          dispatches: 0,
          journalCreated: false,
        }),
      );
      return;
    }
    // Refresh immediately before the single dispatcher invocation. No polling,
    // retries, automatic resolutions, or success inferred from HTTP status.
    inventory = liveInventory();
    validateInventory(inventory, knownRuns, funding.observedAt);
    verifyLegacy();
    refreshPreexecution(preexecution);
    need(
      same(journalRows(directory, shards, dispatchContext), bindings),
      "JOURNAL_CHANGED_BEFORE_SUBMIT",
    );
    need(
      git("rev-parse", "HEAD") === sourceCommit &&
        !git("diff", "--name-only", "HEAD"),
      "SOURCE_CHANGED_BEFORE_SUBMIT",
    );
    unchanged();
    const successorClaim = claimPreexecutionSuccessor(preexecution, sourceCommit, hash(planBytes));
    fs.mkdirSync(path.dirname(attemptFile), { recursive: true });
    durableNew(attemptFile, {
      ...safe,
      wrapperProcessId: process.pid,
      wrapperLockPath: lockFile,
      wrapperLockDigest: hash(bytes(lockFile)),
      preexecutionSuccessorClaim: successorClaim,
      recordedAt: new Date().toISOString(),
      inventoryObservedAt: inventory.observedAt,
      fundingObservedAt: funding.observedAt,
      knownRunIds: [...knownRuns.keys()],
      fundingObservationDigest: hash(bytes(fundingFile)),
      continuationAuthorityDigest: hash(bytes(authorityFile)),
      inheritedReserveCny: inheritedReserve,
      additional129ReserveCny: reserve,
      newSampleReserveCny: reserve,
      delayedContingencyCny: delayed,
      subsequentKnownEstimateCny: subsequentCost,
      postObservationEstimateCny: postObservation,
      authorizedRequiredEstimatedReserveCny: authorizedRequired,
      fullRequiredEstimatedReserveCny: fullRequired,
      inputDigests: Object.fromEntries(observed),
      dispatcherInvocationAllowedOnce: true,
    });
    stage = "single-dispatcher-invocation";
    const result = spawnSync(
      "python",
      [
        "-B",
        path.join(operator, "dispatch-once-repaired.py"),
        "--expected-sample",
        sampleId,
        "--admission-file",
        attemptFile,
        ...dispatcherArgs.slice(2),
        "--submit",
        "--max-new-dispatches",
        "1",
      ],
      {
        cwd: root,
        windowsHide: true,
        timeout: 360000,
        maxBuffer: 8 * 1024 * 1024,
        stdio: ["ignore", "pipe", "pipe"],
      },
    );
    // Never save stdout/stderr: diagnostics can contain authentication or data.
    durableNew(
      attemptFile.replace(/\.admission\.private\.json$/u, ".invocation.json"),
      {
        finishedAt: new Date().toISOString(),
        exitCode: result.status,
        signal: result.signal,
        spawnError: Boolean(result.error),
        outcome:
          result.status === 0
            ? "dispatcher-returned-success"
            : "uncertain-or-stopped",
        automaticRetryAllowed: false,
      },
    );
    unchanged();
    need(
      result.status === 0 && !result.error,
      "DISPATCHER_STOPPED_OR_UNCERTAIN_NEVER_RETRY",
    );
    console.log(
      JSON.stringify({
        ...safe,
        dispatcherInvocations: 1,
        maxNewDispatches: 1,
        outcome: "dispatcher-returned-success",
        nextAction:
          "read-only resolve if needed, then strict collection and usage reconciliation before another sample",
      }),
    );
  } finally {
    if (lockFd !== undefined) {
      fs.closeSync(lockFd);
      fs.unlinkSync(lockFile);
    }
  }
}
try {
  main();
} catch (error) {
  // Never serialize assertion actual/expected, child output, private amounts,
  // environment values or arbitrary error messages.
  console.error(
    JSON.stringify({
      status: "STOPPED",
      stage,
      reason: error instanceof Stop ? error.message : "LOCAL_VALIDATION_FAILED",
      automaticRetryAllowed: false,
    }),
  );
  process.exitCode = 1;
}
