import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import { test } from "node:test";
import { verifyPreexecutionTerminal } from "./preexecution-terminal.mjs";

const ROOT = new URL("../../", import.meta.url);
const LOCAL = ".work/native131-easy-first-20261029/";
const PREFIX =
  "docs/research/cli/evidence/implementation-plan-2026-10-15/task-campaign-2026-10-18";
const ARCHIVE = "docs/research/cli/evidence/native131-preexecution-2026-10-29/";
const PLAN = `${PREFIX}/next-package-131-easy-first-20261029-plan.json`;
const PACKAGE =
  "docs/research/cli/verify01-package-sets/2026-10-29-review-131.json";
const WORKFLOW = ".github/workflows/verify01-native-task-campaign.yml";
const PLAN_HASH =
  "0ef9a3640f8a67fb399e47e99f9bd5466f637fba0954b3fade4f9a2b2e718519";
const JOURNAL = `.work/next-package-dispatch/${PLAN_HASH}/`;
const digest = (bytes) =>
  `sha256:${createHash("sha256").update(bytes).digest("hex")}`;

// Read-only offline snapshots; each case mutates private in-memory copies.
// gitBytes is a fixture adapter, never a subprocess or remote operation.
function fixture() {
  const sources = {
    plan: PLAN,
    packageSet: PACKAGE,
    context: `${JOURNAL}context.json`,
    intent: `${JOURNAL}win32-cli--verify-10.intent.json`,
    request: `${JOURNAL}win32-cli--verify-10.request.json`,
    resolved: `${JOURNAL}win32-cli--verify-10.resolved.json`,
    ledger: `${PREFIX}/next-package-131-easy-first-20261029.json`,
    run: `${LOCAL}preflight-authority/run.json`,
    jobs: `${LOCAL}preflight-authority/jobs.json`,
    artifacts: `${LOCAL}preflight-authority/artifacts.json`,
    workflow: `${LOCAL}preflight-authority/workflow.yml`,
    log: `${LOCAL}preflight-40886343743.log.private`,
  };
  const bytes = new Map();
  const evidence = {};
  for (const [key, source] of Object.entries(sources)) {
    const raw = readFileSync(new URL(source, ROOT));
    const path = `${ARCHIVE}${key}.raw`;
    bytes.set(path, raw);
    evidence[key] = { path, bytes: raw.length, digest: digest(raw) };
  }
  const committed = new Map([
    [PLAN, bytes.get(evidence.plan.path)],
    [PACKAGE, bytes.get(evidence.packageSet.path)],
    [WORKFLOW, bytes.get(evidence.workflow.path)],
  ]);
  const certificate = {
    schema: "chainlesschain.native-preexecution-terminal/v1",
    outcome: "VALIDATION_FAILED_BEFORE_GENERATION",
    sourceCommit: "8e72ccf5b30cff3f6edb8ed8c9c326e72c3c6304",
    runId: "40886343743",
    runAttempt: 1,
    shardId: "win32-cli--verify-10",
    group: "win32-cli",
    sampleIds: ["verify-10"],
    planPath: PLAN,
    planDigest: `sha256:${PLAN_HASH}`,
    packageSetPath: PACKAGE,
    packageSetDigest:
      "sha256:120f53d500bfc9b923cc713bea8f6040c28ad92df8ba3490ce914197aa0ccd81",
    successorPlanPath: `${PREFIX}/next-package-131-preflight-repair-20261029-plan.json`,
    generationExecution: "NOT_STARTED",
    acceptanceExecution: "NOT_STARTED",
    billingAssessed: false,
    liabilitiesPreserved: true,
    evidence,
  };
  const replaceRaw = (key, raw) => {
    const entry = evidence[key];
    bytes.set(entry.path, raw);
    entry.bytes = raw.length;
    entry.digest = digest(raw);
  };
  const mutate = (key, change) => {
    const value = JSON.parse(bytes.get(evidence[key].path).toString("utf8"));
    change(value);
    replaceRaw(key, Buffer.from(JSON.stringify(value)));
  };
  const verify = () =>
    verifyPreexecutionTerminal({
      certificate,
      readBytes: (path) => bytes.get(path),
      gitBytes: (commit, path) => {
        assert.equal(commit, "8e72ccf5b30cff3f6edb8ed8c9c326e72c3c6304");
        return committed.get(path);
      },
      need: (condition, code) => {
        if (!condition) throw new Error(code);
      },
    });
  return {
    certificate,
    evidence,
    bytes,
    committed,
    mutate,
    replaceRaw,
    verify,
  };
}

test("original fixed failure proves no generation or acceptance, without assessing billing", () => {
  const f = fixture();
  const before = JSON.stringify(f.certificate);
  const result = f.verify();
  assert.equal(result.outcome, "VALIDATION_FAILED_BEFORE_GENERATION");
  assert.equal(result.generationExecution, "NOT_STARTED");
  assert.equal(result.acceptanceExecution, "NOT_STARTED");
  assert.equal(result.billingAssessed, false);
  assert.equal(result.liabilitiesPreserved, true);
  assert.equal(result.expected.jobs.total_count, 3);
  assert.equal(result.expected.artifacts.total_count, 0);
  assert.equal(JSON.stringify(f.certificate), before);
});

const negatives = [
  [
    "certificate source changed",
    (f) => {
      f.certificate.sourceCommit = "0".repeat(40);
    },
    "certificate-sourceCommit",
  ],
  [
    "remote source changed",
    (f) =>
      f.mutate("run", (x) => {
        x.head_sha = "0".repeat(40);
      }),
    "remote-run",
  ],
  [
    "certificate attempt changed",
    (f) => {
      f.certificate.runAttempt = 2;
    },
    "certificate-runAttempt",
  ],
  [
    "remote rerun invalidates certificate",
    (f) =>
      f.mutate("run", (x) => {
        x.run_attempt = 2;
      }),
    "remote-run",
  ],
  [
    "job attempt changed",
    (f) =>
      f.mutate("jobs", (x) => {
        x.jobs[2].run_attempt = 2;
      }),
    "job-identity",
  ],
  [
    "pagination count exceeds returned jobs",
    (f) =>
      f.mutate("jobs", (x) => {
        x.total_count = 4;
      }),
    "complete-jobs",
  ],
  [
    "jobs page truncated",
    (f) =>
      f.mutate("jobs", (x) => {
        x.jobs.pop();
      }),
    "complete-jobs",
  ],
  [
    "extra job replaces known skipped job",
    (f) =>
      f.mutate("jobs", (x) => {
        x.jobs[2].id = 99;
      }),
    "job-identity",
  ],
  [
    "duplicate job",
    (f) =>
      f.mutate("jobs", (x) => {
        x.jobs[2] = x.jobs[1];
      }),
    "unique-jobs",
  ],
  [
    "generation started without artifacts",
    (f) =>
      f.mutate("jobs", (x) => {
        x.jobs[2].status = "in_progress";
        x.jobs[2].conclusion = null;
      }),
    "job-identity",
  ],
  [
    "generation ran to failure",
    (f) =>
      f.mutate("jobs", (x) => {
        x.jobs[2].conclusion = "failure";
      }),
    "downstream-not-started",
  ],
  [
    "generation runner assigned",
    (f) =>
      f.mutate("jobs", (x) => {
        x.jobs[2].runner_id = 123;
      }),
    "downstream-not-started",
  ],
  [
    "acceptance runner assigned",
    (f) =>
      f.mutate("jobs", (x) => {
        x.jobs[1].runner_name = "runner";
      }),
    "downstream-not-started",
  ],
  [
    "runner null field missing",
    (f) =>
      f.mutate("jobs", (x) => {
        delete x.jobs[2].runner_group_id;
      }),
    "downstream-not-started",
  ],
  [
    "generation steps present",
    (f) =>
      f.mutate("jobs", (x) => {
        x.jobs[2].steps = [{ name: "Set up job" }];
      }),
    "downstream-not-started",
  ],
  [
    "acceptance steps present",
    (f) =>
      f.mutate("jobs", (x) => {
        x.jobs[1].steps = [{ name: "accept" }];
      }),
    "downstream-not-started",
  ],
  [
    "artifact exists",
    (f) =>
      f.mutate("artifacts", (x) => {
        x.total_count = 1;
        x.artifacts = [{ id: 1 }];
      }),
    "no-artifacts",
  ],
  [
    "artifact pagination missing item",
    (f) =>
      f.mutate("artifacts", (x) => {
        x.total_count = 1;
      }),
    "no-artifacts",
  ],
  [
    "workflow changed even with recomputed digest",
    (f) => f.replaceRaw("workflow", Buffer.from("jobs: {}")),
    "workflow-original-digest",
  ],
  [
    "source workflow differs from archive",
    (f) => f.committed.set(WORKFLOW, Buffer.from("changed")),
    "workflow-committed-bytes",
  ],
  [
    "source plan differs from archive",
    (f) => f.committed.set(PLAN, Buffer.from("{}")),
    "plan-committed-bytes",
  ],
  [
    "source manifest differs from archive",
    (f) => f.committed.set(PACKAGE, Buffer.from("{}")),
    "packageSet-committed-bytes",
  ],
  [
    "fake broker on certificate",
    (f) => {
      f.certificate.broker = { requests: 0 };
    },
    "certificate-shape",
  ],
  [
    "fake broker evidence",
    (f) => {
      f.evidence.broker = f.evidence.log;
    },
    "evidence-shape",
  ],
  [
    "fake broker in ledger",
    (f) =>
      f.mutate("ledger", (x) => {
        x.runs[0].broker = { requests: 0 };
      }),
    "ledger-original-digest",
  ],
  [
    "fake generation record",
    (f) =>
      f.mutate("ledger", (x) => {
        x.samples[0].generationObserved = true;
      }),
    "ledger-original-digest",
  ],
  [
    "fake acceptance record",
    (f) =>
      f.mutate("ledger", (x) => {
        x.counts.acceptanceRecordsCollected = 1;
      }),
    "ledger-original-digest",
  ],
  [
    "original journal edited",
    (f) =>
      f.mutate("context", (x) => {
        x.reviewChanges = false;
      }),
    "context-original-digest",
  ],
  [
    "cancelled run is not exempt",
    (f) =>
      f.mutate("run", (x) => {
        x.conclusion = "cancelled";
      }),
    "remote-run",
  ],
  [
    "different validation failure",
    (f) =>
      f.mutate("jobs", (x) => {
        x.jobs[0].steps[4].conclusion = "success";
        x.jobs[0].steps[5].conclusion = "failure";
      }),
    "validate-steps",
  ],
  [
    "failure log omitted",
    (f) => f.replaceRaw("log", Buffer.from("# fail 1\n")),
    "known-validation-failure",
  ],
  [
    "multiple failing tests",
    (f) =>
      f.replaceRaw(
        "log",
        Buffer.concat([
          f.bytes.get(f.evidence.log.path),
          Buffer.from("\nnot ok 68 - other failure\n"),
        ]),
      ),
    "single-validation-failure",
  ],
  [
    "raw bytes differ without digest update",
    (f) => f.bytes.set(f.evidence.run.path, Buffer.from("{}")),
    "run-bytes",
  ],
  [
    "archive traversal",
    (f) => {
      f.evidence.run.path = `${ARCHIVE}../run.json`;
    },
    "run-path",
  ],
  [
    "duplicate archive path",
    (f) => {
      f.evidence.jobs.path = f.evidence.run.path;
    },
    "jobs-path",
  ],
  [
    "different successor",
    (f) => {
      f.certificate.successorPlanPath = "another-plan.json";
    },
    "certificate-successorPlanPath",
  ],
];
for (const [name, change, code] of negatives) {
  test(`rejects ${name}`, () => {
    const f = fixture();
    change(f);
    assert.throws(f.verify, { message: `preexecution:${code}` });
  });
}
