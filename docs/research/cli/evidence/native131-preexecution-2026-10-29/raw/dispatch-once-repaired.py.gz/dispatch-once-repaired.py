"""Local adapter: retain the original dispatcher's main, checks and journal.

The only additions are an exact-sample guard under its own journal lock and a
fresh all-ref workflow inventory immediately before the single write request.
No retry, receipt repair, replacement intent, or production modification.
"""
import contextlib
import datetime
import hashlib
import importlib.util
import json
import os
import pathlib
import re
import stat
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[2]
OPERATOR = ROOT / '.work' / 'native131-easy-first-20261029'
PLAN = 'docs/research/cli/evidence/implementation-plan-2026-10-15/task-campaign-2026-10-18/next-package-131-preflight-repair-20261029-plan.json'
PLAN_DIGEST = 'sha256:acfae4ee045f0b15b5bb14fdf8da6a8f655e733f8f4077b7ad8226583a89286a'
CERTIFICATE = 'docs/research/cli/evidence/native131-preexecution-2026-10-29/terminal.json'
CERTIFICATE_DIGEST = 'sha256:1337173028b704ad9ce262e47ace9631c4220005e66239efbba245f36805df70'
ORIGINAL_RUN = '40886343743'
ORIGINAL_SOURCE = '8e72ccf5b30cff3f6edb8ed8c9c326e72c3c6304'
MANIFEST = 'docs/research/cli/verify01-package-sets/2026-10-29-review-131.json'
OPERATOR_PATH = '.work/native131-easy-first-20261029'
CLAIM_PATH = OPERATOR_PATH + '/preexecution-successors/' + ORIGINAL_RUN + '-attempt-1-' + ORIGINAL_SOURCE + '.json'
CODE_ROOTS = (
    OPERATOR_PATH + '/admit-repaired.mjs',
    OPERATOR_PATH + '/verify-terminal-current.mjs',
    OPERATOR_PATH + '/legacy127-reserve.mjs',
    'docs/research/cli/evidence/native131-preexecution-2026-10-29/verify-evidence.mjs',
    'docs/research/cli/evidence/native131-preexecution-2026-10-29/preexecution-terminal.mjs',
    'packages/cli/scripts/verify01-native-retest-round.mjs',
    'packages/cli/scripts/verify01-native-retest-plan.mjs',
)
FIXED_INPUTS = CODE_ROOTS + (
    OPERATOR_PATH + '/dispatch-once-repaired.py',
    'packages/cli/scripts/verify01-dispatch-native-retest.py',
    PLAN, MANIFEST, CERTIFICATE, CLAIM_PATH,
    OPERATOR_PATH + '/admission.lock',
    '.work/verify01-funded-20261027/funding-current.private.json',
    '.work/verify01-review128-20261028/continuation-authority.private.json',
    OPERATOR_PATH + '/accounting-preparation-v2.private.json',
)
RELATIVE_IMPORT = re.compile(r'''(?:\bfrom\s*|\bimport\s*\(\s*|\bimport\s*)["'](\.[^"']+)["']''')
DIGEST = re.compile(r'sha256:[a-f0-9]{64}')
ALLOWED = {'verify-10', 'verify-04', 'verify-13', 'verify-09', 'verify-30',
           'verify-07', 'verify-19', 'verify-08', 'first-run-darwin-cli',
           'first-run-darwin-jetbrains'}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha256(raw):
    return 'sha256:' + hashlib.sha256(raw).hexdigest()


def checked_path(value, root):
    """Only canonical absolute files below root, without links or junctions."""
    require(isinstance(value, (str, pathlib.Path)), 'Invalid admission input path')
    path = pathlib.Path(value)
    require(path.is_absolute() and '..' not in path.parts, 'Unsafe admission input path')
    try:
        parts = path.relative_to(root).parts
    except ValueError:
        raise RuntimeError('Admission input outside repository') from None
    current = root
    for part in parts:
        current = current / part
        info = current.lstat()
        require(not stat.S_ISLNK(info.st_mode)
                and not (getattr(info, 'st_file_attributes', 0)
                         & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0x400)),
                'Linked admission input refused')
    require(path == path.resolve() and path.is_file(), 'Admission input must be a canonical file')
    return path.resolve()


def code_dependencies(root):
    """Read source text only; include the relative-import verification closure."""
    pending = [root / relative for relative in CODE_ROOTS]
    found = set()
    while pending:
        file = checked_path(pending.pop(), root)
        if file in found:
            continue
        found.add(file)
        for relative in RELATIVE_IMPORT.findall(file.read_text(encoding='utf-8')):
            # Resolve module-relative '..' here, then validate containment/links.
            candidate = file.parent / relative
            lexical = pathlib.Path(os.path.abspath(str(candidate)))
            pending.append(lexical)
    return found


def validate_handoff(admission, admission_file, expected, admission_digest, root=ROOT):
    """Validate the live parent wrapper and its complete immutable handoff.

    Tests supply a temporary root. Production has no command-line override.
    This is defense against stale/accidental/direct adapter invocation, not a
    privilege boundary against an account that can rewrite executable code.
    """
    root = root.resolve()
    admission_file = checked_path(admission_file, root)
    require(admission_file.parent == root / OPERATOR_PATH / 'attempts'
            and sha256(admission_file.read_bytes()) == admission_digest,
            'Private admission changed or has wrong location')
    require(admission.get('sampleId') == expected and expected in ALLOWED
            and admission.get('dispatcherInvocationAllowedOnce') is True
            and admission.get('heldSampleIds') == ['verify-11']
            and admission.get('planDigest') == PLAN_DIGEST
            and isinstance(admission.get('sourceCommit'), str)
            and re.fullmatch('[a-f0-9]{40}', admission['sourceCommit']),
            'Admission identity differs')
    lock_path = checked_path(admission.get('wrapperLockPath'), root)
    require(lock_path == root / OPERATOR_PATH / 'admission.lock', 'Wrong shared admission lock')
    lock_bytes = lock_path.read_bytes()
    lock = json.loads(lock_bytes)
    require(set(lock) == {'pid', 'createdAt', 'nonce'}
            and type(lock['pid']) is int and lock['pid'] > 0
            and lock['pid'] == os.getppid()
            and admission.get('wrapperProcessId') == lock['pid']
            and isinstance(lock['nonce'], str)
            and re.fullmatch('[a-f0-9]{64}', lock['nonce'])
            and isinstance(lock['createdAt'], str)
            and sha256(lock_bytes) == admission.get('wrapperLockDigest'),
            'Live parent wrapper lock is required')
    created = datetime.datetime.fromisoformat(lock['createdAt'].replace('Z', '+00:00'))
    require(created.tzinfo is not None, 'Wrapper lock timestamp requires timezone')

    inputs = admission.get('inputDigests')
    require(isinstance(inputs, dict) and inputs, 'Complete admission input digests required')
    normalized = {}
    for file, digest in inputs.items():
        require(isinstance(digest, str) and DIGEST.fullmatch(digest), 'Invalid admission input digest')
        resolved = checked_path(file, root)
        require(resolved not in normalized, 'Duplicate admission input path')
        normalized[resolved] = digest
    required = {root / relative for relative in FIXED_INPUTS}
    require(required.issubset(normalized), 'Required admission inputs missing')
    # Check all admitted bytes before discovering dependencies or parsing them.
    for file, digest in normalized.items():
        require(sha256(file.read_bytes()) == digest, 'Admission input changed before dispatch')
    require(code_dependencies(root).issubset(normalized), 'Verification code dependency missing')
    require(normalized[root / PLAN] == PLAN_DIGEST
            and normalized[root / CERTIFICATE] == CERTIFICATE_DIGEST
            and normalized[lock_path] == admission['wrapperLockDigest'],
            'Fixed plan certificate or lock digest differs')
    certificate = json.loads((root / CERTIFICATE).read_bytes())
    require(certificate['runId'] == ORIGINAL_RUN and certificate['runAttempt'] == 1
            and certificate['sourceCommit'] == ORIGINAL_SOURCE
            and certificate['successorPlanPath'] == PLAN, 'Certificate identity differs')
    for entry in certificate['evidence'].values():
        file = checked_path(root / entry['path'], root)
        require(normalized.get(file) == entry['digest']
                and file.stat().st_size == entry['bytes'], 'Raw certificate evidence missing or changed')
    original_plan = json.loads((root / certificate['evidence']['plan']['path']).read_bytes())
    original_journal = root / '.work/next-package-dispatch' / certificate['planDigest'].split(':')[1]
    originals = {'context': original_journal / 'context.json',
                 'intent': original_journal / (certificate['shardId'] + '.intent.json'),
                 'request': original_journal / (certificate['shardId'] + '.request.json'),
                 'resolved': original_journal / (certificate['shardId'] + '.resolved.json'),
                 'ledger': root / original_plan['ledgerPath']}
    for key, file in originals.items():
        require(normalized.get(checked_path(file, root)) == certificate['evidence'][key]['digest'],
                'Original pre-execution record missing or changed')
    plan = json.loads((root / PLAN).read_bytes())
    shards = [shard for shard in plan['executionShards'] if shard['sampleIds'] == [expected]]
    require(len(shards) == 1 and admission_file.name == PLAN_DIGEST.split(':')[1]
            + '--' + shards[0]['shardId'] + '.admission.private.json', 'Admission filename differs')
    bound = admission.get('preexecutionTerminal')
    require(bound == {'runId': ORIGINAL_RUN, 'digest': CERTIFICATE_DIGEST,
                      'generationExecution': 'NOT_STARTED', 'liabilitiesPreserved': True},
            'Pre-execution admission binding differs')
    claim_entry = admission.get('preexecutionSuccessorClaim')
    require(isinstance(claim_entry, dict) and set(claim_entry) == {'path', 'digest'},
            'Successor use record required')
    claim_path = checked_path(claim_entry['path'], root)
    require(claim_path == root / CLAIM_PATH
            and normalized[claim_path] == claim_entry['digest'], 'Successor use record digest differs')
    claim = json.loads(claim_path.read_bytes())
    require(claim == {'schema': 'chainlesschain.preexecution-successor-use/v1',
                      'certificateDigest': CERTIFICATE_DIGEST, 'originalRunId': ORIGINAL_RUN,
                      'successorPlanPath': PLAN, 'successorPlanDigest': PLAN_DIGEST,
                      'sourceCommit': admission['sourceCommit'], 'liabilitiesPreserved': True},
            'Successor use record binding differs')


def main():
    require(len(sys.argv) == 11 and sys.argv[1] == '--expected-sample'
            and sys.argv[3] == '--admission-file', 'Invalid guarded invocation')
    expected = sys.argv[2]
    require(expected in ALLOWED, 'Held or unknown sample refused')
    admission_file = pathlib.Path(sys.argv[4])
    require(admission_file.is_absolute()
            and admission_file.parent.resolve() == (OPERATOR / 'attempts').resolve()
            and not admission_file.is_symlink(), 'Invalid private admission path')
    admission_bytes = admission_file.read_bytes()
    admission_digest = sha256(admission_bytes)
    admission = json.loads(admission_bytes)
    require(admission['sampleId'] == expected
            and admission['dispatcherInvocationAllowedOnce'] is True
            and admission['heldSampleIds'] == ['verify-11'], 'Admission binding differs')
    original_args = ['--plan', PLAN, '--review-changes', '--submit', '--max-new-dispatches', '1']
    require(sys.argv[5:] == original_args, 'Original dispatcher arguments differ')
    validate_handoff(admission, admission_file, expected, admission_digest)
    source = ROOT / 'packages' / 'cli' / 'scripts' / 'verify01-dispatch-native-retest.py'
    spec = importlib.util.spec_from_file_location('native_dispatch', source)
    dispatcher = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(dispatcher)
    require(dispatcher.WORK.resolve() == OPERATOR.parent.resolve(), 'Shared Git journal differs')
    execute = dispatcher.execute
    journal_lock = dispatcher.journal_lock

    def unchanged():
        validate_handoff(admission, admission_file, expected, admission_digest)

    def preexecution():
        result = subprocess.run(['node', str(OPERATOR / 'verify-terminal-current.mjs')], cwd=ROOT,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120)
        require(result.returncode == 0, 'Pre-execution terminal evidence changed')
        current = json.loads(result.stdout)
        bound = admission['preexecutionTerminal']
        require(current['verified'] is True and current['runId'] == bound['runId']
                and current['certificateDigest'] == bound['digest']
                and current['runAttempt'] == 1 and current['successorPlanPath'] == PLAN
                and current['generationExecution'] == 'NOT_STARTED'
                and current['liabilitiesPreserved'] is True, 'Pre-execution binding changed')

    def inventory():
        pages = dispatcher.gh('api', '--method', 'GET', '--paginate', '--slurp',
                              f'repos/{dispatcher.REPO}/actions/workflows/{dispatcher.WORKFLOW}/runs',
                              '-f', 'per_page=100')
        require(isinstance(pages, list) and pages, 'Workflow inventory missing')
        rows = [row for page in pages for row in page['workflow_runs']]
        require(len({row['id'] for row in rows}) == len(rows)
                and all(page['total_count'] == len(rows) for page in pages), 'Workflow pagination incomplete or changed')
        require(all(row['status'] == 'completed' for row in rows), 'Active native workflow prevents dispatch')
        known = set(admission['knownRunIds'])
        since = datetime.datetime.fromisoformat(admission['fundingObservedAt'].replace('Z', '+00:00'))
        for row in rows:
            created = datetime.datetime.fromisoformat(row['created_at'].replace('Z', '+00:00'))
            updated = datetime.datetime.fromisoformat(row['updated_at'].replace('Z', '+00:00'))
            if created >= since or updated >= since and row['run_attempt'] > 1:
                require(str(row['id']) in known, 'New native run is not accounted')
            if str(row['id']) in known:
                require(row['run_attempt'] == 1, 'Known native run was rerun')

    def guarded_execute(context, directory, **kwargs):
        require(kwargs.get('submit') is True and kwargs.get('resolve') is False
                and kwargs.get('max_new_dispatches') == 1, 'Only one explicit submit is allowed')
        require(context['sourceCommit'] == admission['sourceCommit']
                and context['planDigest'] == admission['planDigest']
                and context.get('reviewChanges') is True, 'Dispatcher context differs from admission')

        @contextlib.contextmanager
        def guarded_lock(folder):
            with journal_lock(folder):
                unchanged()
                pending = [shard for shard in context['executionShards']
                           if not (folder / (shard['shardId'] + '.resolved.json')).exists()]
                require(pending and pending[0]['sampleIds'] == [expected],
                        'First unrequested shard changed; do not create an alternate intent')
                inventory()
                preexecution()
                unchanged()
                yield

        def guarded_dispatch(args):
            selections = [arg for arg in args if arg.startswith('sample_ids=')]
            require(selections == ['sample_ids=' + expected] and expected != 'verify-11',
                    'Exact selected sample required before workflow write')
            inventory()
            preexecution()
            unchanged()
            # This is the original dispatch operation, once, without retries.
            return subprocess.run(args, cwd=dispatcher.TREE, stdout=subprocess.PIPE,
                                  stderr=subprocess.PIPE, timeout=120)

        dispatcher.journal_lock = guarded_lock
        try:
            return execute(context, directory, dispatch=guarded_dispatch, **kwargs)
        finally:
            dispatcher.journal_lock = journal_lock

    dispatcher.execute = guarded_execute
    sys.argv = [str(source), *original_args]
    dispatcher.main()


if __name__ == '__main__':
    try:
        main()
    except Exception:
        # Never emit private admission contents, amounts, HTTP text or env.
        print('Guarded dispatcher stopped; retain intent and request facts; never automatically retry', file=sys.stderr)
        sys.exit(1)
