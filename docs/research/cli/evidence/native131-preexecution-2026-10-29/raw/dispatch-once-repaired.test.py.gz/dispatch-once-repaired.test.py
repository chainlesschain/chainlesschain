"""Offline handoff tests. Only temporary fixtures are written or inspected.

Public certificate snapshots seed the fixed-byte proof. Real funding files,
dispatch journals, remote APIs and dispatcher main are never accessed.
"""
import importlib.util
import json
import os
import pathlib
import subprocess
import sys
import tempfile
import unittest


HERE = pathlib.Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('guarded_adapter', HERE / 'dispatch-once-repaired.py')
ADAPTER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(ADAPTER)


class HandoffFixture:
    def __init__(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='native131-handoff-')
        self.root = pathlib.Path(self.temporary.name).resolve()
        self.inputs = {}
        self.admission = None
        for relative in ADAPTER.FIXED_INPUTS:
            self.write(relative, b'// inert temporary fixture\n')
        # A dependency outside the explicit seed set must also be frozen.
        self.write(ADAPTER.OPERATOR_PATH + '/admit-repaired.mjs',
                   b'import "./fixture-dependency.mjs";\n')
        self.dependency = ADAPTER.OPERATOR_PATH + '/fixture-dependency.mjs'
        self.write(self.dependency, b'export const fixture = true;\n')
        for relative in [ADAPTER.PLAN, ADAPTER.CERTIFICATE]:
            self.write(relative, (ADAPTER.ROOT / relative).read_bytes())
        certificate = json.loads((self.root / ADAPTER.CERTIFICATE).read_bytes())
        for entry in certificate['evidence'].values():
            self.write(entry['path'], (ADAPTER.ROOT / entry['path']).read_bytes())
        original_plan = json.loads((self.root / certificate['evidence']['plan']['path']).read_bytes())
        journal = '.work/next-package-dispatch/' + certificate['planDigest'].split(':')[1]
        originals = {'context': journal + '/context.json',
                     'intent': journal + '/' + certificate['shardId'] + '.intent.json',
                     'request': journal + '/' + certificate['shardId'] + '.request.json',
                     'resolved': journal + '/' + certificate['shardId'] + '.resolved.json',
                     'ledger': original_plan['ledgerPath']}
        for key, relative in originals.items():
            # Original private paths are reconstructed only inside temp from
            # their already-public fixed snapshots; never read real journals.
            self.write(relative, (self.root / certificate['evidence'][key]['path']).read_bytes())
        self.lock_relative = ADAPTER.OPERATOR_PATH + '/admission.lock'
        self.lock = {'pid': os.getpid(), 'createdAt': '2026-10-29T15:00:00.000Z', 'nonce': 'a' * 64}
        self.write_json(self.lock_relative, self.lock)
        self.claim = {'schema': 'chainlesschain.preexecution-successor-use/v1',
                      'certificateDigest': ADAPTER.CERTIFICATE_DIGEST,
                      'originalRunId': ADAPTER.ORIGINAL_RUN,
                      'successorPlanPath': ADAPTER.PLAN,
                      'successorPlanDigest': ADAPTER.PLAN_DIGEST,
                      'sourceCommit': 'b' * 40, 'liabilitiesPreserved': True}
        self.write_json(ADAPTER.CLAIM_PATH, self.claim)
        self.admission_path = self.root / ADAPTER.OPERATOR_PATH / 'attempts' / (
            ADAPTER.PLAN_DIGEST.split(':')[1] + '--win32-cli--verify-10.admission.private.json')
        self.admission = {'sampleId': 'verify-10', 'dispatcherInvocationAllowedOnce': True,
                          'heldSampleIds': ['verify-11'], 'planDigest': ADAPTER.PLAN_DIGEST,
                          'sourceCommit': 'b' * 40, 'wrapperProcessId': os.getpid(),
                          'wrapperLockPath': str(self.root / self.lock_relative),
                          'wrapperLockDigest': self.inputs[str(self.root / self.lock_relative)],
                          'preexecutionSuccessorClaim': {
                              'path': str(self.root / ADAPTER.CLAIM_PATH),
                              'digest': self.inputs[str(self.root / ADAPTER.CLAIM_PATH)]},
                          'preexecutionTerminal': {'runId': ADAPTER.ORIGINAL_RUN,
                              'digest': ADAPTER.CERTIFICATE_DIGEST,
                              'generationExecution': 'NOT_STARTED', 'liabilitiesPreserved': True},
                          'inputDigests': self.inputs}

    def write(self, relative, raw):
        path = self.root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
        self.inputs[str(path)] = ADAPTER.sha256(raw)

    def write_json(self, relative, value):
        self.write(relative, (json.dumps(value) + '\n').encode())

    def save_admission(self):
        raw = (json.dumps(self.admission) + '\n').encode()
        self.admission_path.parent.mkdir(parents=True, exist_ok=True)
        self.admission_path.write_bytes(raw)
        return ADAPTER.sha256(raw)

    def invoke(self, mutation=None):
        digest = self.save_admission()
        # The Python parent owns the fixture lock; the direct Python child
        # must observe that real parent PID, exactly like Node -> adapter.
        args = [sys.executable, '-B', str(pathlib.Path(__file__).resolve()), '--child',
                str(self.root), str(self.admission_path), digest]
        if mutation:
            args.append(mutation)
        return subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                              encoding='utf-8', timeout=15)

    def cleanup(self):
        self.temporary.cleanup()


class HandoffTests(unittest.TestCase):
    def setUp(self):
        self.fixture = HandoffFixture()
        self.addCleanup(self.fixture.cleanup)

    def reject(self, fragment, mutation=None):
        result = self.fixture.invoke(mutation)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn(fragment, result.stdout)

    def test_real_parent_child_handoff(self):
        result = self.fixture.invoke()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(result.stdout.strip(), 'verified')

    def test_empty_inputs(self):
        self.fixture.admission['inputDigests'] = {}
        self.reject('Complete admission input digests required')

    def test_each_mandatory_input_is_required(self):
        for relative in ADAPTER.FIXED_INPUTS:
            with self.subTest(relative=relative):
                key = str(self.fixture.root / relative)
                digest = self.fixture.inputs.pop(key)
                self.reject('Required admission inputs missing')
                self.fixture.inputs[key] = digest

    def test_missing_import_dependency(self):
        self.fixture.inputs.pop(str(self.fixture.root / self.fixture.dependency))
        self.reject('Verification code dependency missing')

    def test_wrong_parent_pid(self):
        self.fixture.lock['pid'] = os.getpid() + 100000
        self.fixture.write_json(self.fixture.lock_relative, self.fixture.lock)
        self.fixture.admission['wrapperProcessId'] = self.fixture.lock['pid']
        self.fixture.admission['wrapperLockDigest'] = self.fixture.inputs[str(self.fixture.root / self.fixture.lock_relative)]
        self.reject('Live parent wrapper lock is required')

    def test_bad_nonce(self):
        self.fixture.lock['nonce'] = 'not-a-nonce'
        self.fixture.write_json(self.fixture.lock_relative, self.fixture.lock)
        self.fixture.admission['wrapperLockDigest'] = self.fixture.inputs[str(self.fixture.root / self.fixture.lock_relative)]
        self.reject('Live parent wrapper lock is required')

    def test_missing_claim_descriptor(self):
        self.fixture.admission.pop('preexecutionSuccessorClaim')
        self.reject('Successor use record required')

    def test_claim_source_changed_with_digest_recomputed(self):
        self.fixture.claim['sourceCommit'] = 'c' * 40
        self.fixture.write_json(ADAPTER.CLAIM_PATH, self.fixture.claim)
        self.fixture.admission['preexecutionSuccessorClaim']['digest'] = self.fixture.inputs[str(self.fixture.root / ADAPTER.CLAIM_PATH)]
        self.reject('Successor use record binding differs')

    def test_alternate_claim_filename(self):
        alternate = ADAPTER.OPERATOR_PATH + '/preexecution-successors/another.json'
        self.fixture.write_json(alternate, self.fixture.claim)
        self.fixture.admission['preexecutionSuccessorClaim'] = {
            'path': str(self.fixture.root / alternate),
            'digest': self.fixture.inputs[str(self.fixture.root / alternate)]}
        self.reject('Successor use record digest differs')

    def test_certificate_reformatted_with_digest_recomputed(self):
        certificate = json.loads((self.fixture.root / ADAPTER.CERTIFICATE).read_bytes())
        self.fixture.write_json(ADAPTER.CERTIFICATE, certificate)
        self.reject('Fixed plan certificate or lock digest differs')

    def test_plan_reformatted_with_digest_recomputed(self):
        plan = json.loads((self.fixture.root / ADAPTER.PLAN).read_bytes())
        self.fixture.write_json(ADAPTER.PLAN, plan)
        self.reject('Fixed plan certificate or lock digest differs')

    def test_raw_evidence_digest_missing(self):
        certificate = json.loads((self.fixture.root / ADAPTER.CERTIFICATE).read_bytes())
        self.fixture.inputs.pop(str(self.fixture.root / certificate['evidence']['jobs']['path']))
        self.reject('Raw certificate evidence missing or changed')

    def test_original_journal_digest_missing(self):
        certificate = json.loads((self.fixture.root / ADAPTER.CERTIFICATE).read_bytes())
        original = '.work/next-package-dispatch/' + certificate['planDigest'].split(':')[1] + '/context.json'
        self.fixture.inputs.pop(str(self.fixture.root / original))
        self.reject('Original pre-execution record missing or changed')

    def test_external_input_path(self):
        self.fixture.inputs[str(self.fixture.root.parent / 'outside')] = 'sha256:' + 'a' * 64
        self.reject('Admission input outside repository')

    def test_held_sample(self):
        self.fixture.admission['sampleId'] = 'verify-11'
        self.reject('Admission identity differs')

    def test_second_check_rejects_mutations(self):
        for target in ['lock', 'claim', 'code', 'funding', 'admission']:
            with self.subTest(target=target):
                # Each child receives its own mutation path; restore snapshots
                # afterward so subsequent cases start from valid fixture bytes.
                saved = {path: pathlib.Path(path).read_bytes() for path in self.fixture.inputs}
                try:
                    self.reject('Live parent wrapper lock is required' if target == 'lock' else 'changed', target)
                finally:
                    for path, raw in saved.items():
                        pathlib.Path(path).write_bytes(raw)


def child():
    root, admission_file, digest = pathlib.Path(sys.argv[2]), pathlib.Path(sys.argv[3]), sys.argv[4]
    admission = json.loads(admission_file.read_bytes())
    try:
        ADAPTER.validate_handoff(admission, admission_file, 'verify-10', digest, root=root)
        if len(sys.argv) > 5:
            targets = {'lock': root / ADAPTER.OPERATOR_PATH / 'admission.lock',
                       'claim': root / ADAPTER.CLAIM_PATH,
                       'code': root / ADAPTER.OPERATOR_PATH / 'dispatch-once-repaired.py',
                       'funding': root / '.work/verify01-funded-20261027/funding-current.private.json',
                       'admission': admission_file}
            file = targets[sys.argv[5]]
            file.write_bytes(file.read_bytes() + b' ')
            ADAPTER.validate_handoff(admission, admission_file, 'verify-10', digest, root=root)
        print('verified')
    except Exception as error:
        # All inputs are synthetic/public, and only fixed validation errors
        # are emitted. No real source or funds are accessed by the child.
        print(str(error))
        sys.exit(1)


if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == '--child':
        child()
    else:
        unittest.main()
