import fs from "node:fs";
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
const source = "e7ab05ceb3fb5e4dda57e233f80a16a0d5619b75";
const directory = ".work/compaction-host-followup-20261029";
const repo = "chainlesschain/chainlesschain";
const journal = ".work/release131-final-source";
fs.mkdirSync(journal, { recursive: true });
function run(args) {
  const result = spawnSync("gh", args, { encoding: "utf8", windowsHide: true, timeout: 60_000, maxBuffer: 16 * 1024 * 1024 });
  assert.equal(result.status, 0, result.stdout + result.stderr);
  return result.stdout;
}
const refs = JSON.parse(run(["api", `repos/${repo}/git/matching-refs/heads`]));
fs.writeFileSync(`${directory}/remote-refs.json`, JSON.stringify({ observedAt: new Date().toISOString(), refs }, null, 2) + "\n", { flag: "wx" });
assert.equal(refs.find(ref => ref.ref === "refs/heads/main").object.sha, source);
assert.ok(!refs.some(ref => ref.ref === "refs/heads/feature/cli130-compaction-followup"));
const list = () => JSON.parse(run(["run", "list", "--repo", repo, "--commit", source, "--limit", "50", "--json", "databaseId,workflowName,headSha,status,conclusion,event,createdAt,updatedAt,url"]));
let runs = list();
if (!runs.some(run => run.workflowName === "IDE Extensions")) {
  const marker = `${journal}/ide-validation-dispatch.json`;
  fs.writeFileSync(marker, JSON.stringify({ source, plannedAt: new Date().toISOString(), state: "dispatch_intent_recorded", publishMicrosoft: false, purpose: "Build/test validation only on final candidate source; no IDE release tags." }, null, 2) + "\n", { flag: "wx" });
  const args = ["workflow", "run", "ide-extensions.yml", "--repo", repo, "--ref", "main", "-f", "publish_vscode_marketplace=false"];
  const result = spawnSync("gh", args, { encoding: "utf8", windowsHide: true, timeout: 60_000, maxBuffer: 4 * 1024 * 1024 });
  fs.writeFileSync(marker, JSON.stringify({ source, endedAt: new Date().toISOString(), args, exitCode: result.status, signal: result.signal, stdout: result.stdout || "", stderr: result.stderr || "", error: result.error?.message || null, state: result.status === 0 ? "request_accepted" : "request_failed_or_unknown", publishMicrosoft: false }, null, 2) + "\n");
  assert.equal(result.status, 0, result.stdout + result.stderr);
  runs = list();
}
assert.ok(runs.length && runs.every(run => run.headSha === source));
const snapshot = { observedAt: new Date().toISOString(), source, runs, boundary: "Exact-source status readback, not matrix success or publication. Only the missing IDE build/test workflow was dispatched once with Microsoft publishing disabled." };
fs.writeFileSync(`${directory}/cloud-status.json`, JSON.stringify(snapshot, null, 2) + "\n", { flag: "wx" });
const release = { schema: "chainlesschain.release131-target/v1", createdAt: new Date().toISOString(), source, state: "GATES_PENDING", versions: { kernel: "0.1.11", cli: "0.166.131", openVsx: "0.37.169", jetbrains: "0.4.186" }, requiredWorkflows: ["CLI CI", "CLI Strict Sandbox", "Context Memory Kernel CI", "IDE Extensions"], runs, releaseTagCreated: false, published: false, requiredOrder: "verified child npm package -> CLI OIDC plus public readback -> IDE plus public readback -> clients", original129Intent: "REQUEST_UNRESOLVED; never replay or replace its journal", microsoft: "deferred" };
fs.writeFileSync(`${journal}/release-target.json`, JSON.stringify(release, null, 2) + "\n", { flag: "wx" });
console.log(JSON.stringify({ source, refs: refs.map(ref => ref.ref), gates: runs.filter(run => release.requiredWorkflows.includes(run.workflowName)).map(({ databaseId, workflowName, status, conclusion }) => ({ databaseId, workflowName, status, conclusion })), releaseTagCreated: false, published: false }));
