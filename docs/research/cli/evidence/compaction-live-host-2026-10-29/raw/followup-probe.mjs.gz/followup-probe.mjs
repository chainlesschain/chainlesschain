import fs from "node:fs";
import path from "node:path";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";
import { compactLiveMessagesCanonical } from "../../packages/cli/src/lib/context-memory-kernel/live-compaction.js";
import { createCompactionHostContextRefresher, refreshCompactionHostContext } from "../../packages/cli/src/runtime/compaction-host-context.js";
const phase = process.argv[2];
assert.ok(["before", "after"].includes(phase));
const directory = fs.mkdtempSync(path.resolve(`.work/compaction-host-followup-20261029/${phase}-`));
const files = ["packages/cli/src/lib/context-memory-kernel/live-compaction.js", "packages/cli/src/runtime/compaction-host-context.js", "packages/cli/src/lib/compaction-host-provenance.js"];
const hashes = () => Object.fromEntries(files.map((file) => [file, fs.existsSync(file) ? createHash("sha256").update(fs.readFileSync(file)).digest("hex") : null]));
const before = hashes();
let networkCalls = 0;
globalThis.fetch = () => { networkCalls++; throw new Error("Offline adapter probe refuses network"); };
const messages = [
  { role: "system", content: "LIVE_HOST_RULE_72146" },
  { role: "user", content: "review all sections" },
  ...Array.from({ length: 80 }, (_, index) => ({ role: index % 2 ? "user" : "assistant", content: `section ${index}: ${"text ".repeat(24)}` })),
];
let rules = messages[0].content;
const refresh = createCompactionHostContextRefresher({ messages, render: () => rules });
refreshCompactionHostContext(refresh, messages);
const base = messages[0];
const result = await compactLiveMessagesCanonical(messages, {
  env: { CHAINLESSCHAIN_CONTEXT_MEMORY_CLI_STAGE: "canonical_default" },
  persist: false,
  sessionId: "unpersisted-host-probe",
  memoryFilePath: path.join(directory, "memory.json"),
  compressor: { maxTokens: 500, compress: async () => ({ messages: [{ role: "assistant", content: "summary" }], stats: { saved: 100 } }) },
});
const preserved = result.messages[0] === base;
messages.splice(0, messages.length, ...result.messages);
rules = "UPDATED_LIVE_HOST_RULE_72146";
let error = null;
try { refreshCompactionHostContext(refresh, messages); } catch (failure) { error = { code: failure.code, message: failure.message }; }
const after = hashes();
const receipt = { phase, observedAt: new Date().toISOString(), sourceHead: execFileSync("git", ["rev-parse", "HEAD"], { encoding: "utf8" }).trim(), node: process.version, status: result.receipt.status, preservedOriginalHostBase: preserved, nextRefreshError: error, updatedContent: error ? null : messages[0].content, networkCalls, before, after, sourcesStable: JSON.stringify(before) === JSON.stringify(after), boundary: "Actual canonical non-persistent adapter and host refresher with a deterministic local summarizer; not a complete CLI or paid model journey." };
fs.writeFileSync(path.join(directory, "receipt.json"), JSON.stringify(receipt, null, 2) + "\n");
assert.equal(result.receipt.status, "committed");
assert.equal(networkCalls, 0);
assert.ok(receipt.sourcesStable);
if (phase === "before") {
  assert.equal(preserved, false);
  assert.equal(error?.code, "CC_COMPACTION_CONTEXT_REFRESH_FAILED");
} else {
  assert.equal(preserved, true);
  assert.equal(error, null);
  assert.equal(messages[0].content, rules);
}
console.log(JSON.stringify({ receipt: path.join(directory, "receipt.json"), preserved, error, passed: true }));
