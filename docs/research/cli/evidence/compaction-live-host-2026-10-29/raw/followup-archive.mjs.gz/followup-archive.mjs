import fs from "node:fs";
import path from "node:path";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { gzipSync, gunzipSync } from "node:zlib";
const work = ".work/compaction-host-followup-20261029";
const samples = ".work/structured-memory-20261029";
const directory = "docs/research/cli/evidence/compaction-live-host-2026-10-29";
const sha = bytes => createHash("sha256").update(bytes).digest("hex");
const read = file => JSON.parse(fs.readFileSync(file));
function result(label, passed, files) {
  const report = read(`${samples}/${label}.json`);
  const process = read(`${samples}/${label}-process.json`);
  assert.ok(report.success && report.numPassedTests === passed && report.numFailedTests === 0 && report.numPendingTests === 0);
  assert.equal(report.testResults.length, files);
  assert.ok(process.exitCode === 0 && process.sourcesStable);
  for (const [file, digest] of Object.entries(process.sourceAfter)) assert.equal(sha(fs.readFileSync(file)), digest, file);
  return { label, files, passed, failed: 0, skipped: 0, exitCode: process.exitCode, sourcesStable: process.sourcesStable, startedAt: process.startedAt, endedAt: process.endedAt };
}
const cli = result("unsaved-host-merged-final-cli-v2", 231, 16);
const node2212 = result("unsaved-host-node2212", 43, 3);
const changelog = result("unsaved-host-changelog", 22, 4);
const native = read(`${samples}/unsaved-host-merged-final-node-process.json`);
assert.ok(native.exitCode === 0 && native.sourcesStable);
for (const [file, digest] of Object.entries(native.sourceAfter)) {
  // Native tests ran before test-only budget diagnostics; runtime bytes match.
  assert.equal(sha(fs.readFileSync(file)), digest, file);
}
const nativeLog = fs.readFileSync(`${samples}/unsaved-host-merged-final-node.log`, "utf8");
assert.ok(nativeLog.includes("# pass 29") && nativeLog.includes("# fail 0") && nativeLog.includes("# skipped 0"));
const before = read(`${work}/before-8Gv7M8/receipt.json`);
const after = read(`${work}/after-DCPlzb/receipt.json`);
assert.equal(before.preservedOriginalHostBase, false);
assert.equal(before.nextRefreshError.code, "CC_COMPACTION_CONTEXT_REFRESH_FAILED");
assert.ok(after.preservedOriginalHostBase && after.nextRefreshError === null);
assert.ok(before.sourcesStable && after.sourcesStable && before.networkCalls === 0 && after.networkCalls === 0);
const checks = read(`${work}/checks.json`);
assert.ok(checks.runs.every(run => run.exitCode === 0));
assert.ok(checks.changelogParity && checks.newHelperIncluded && checks.packFiles === 1844);
const egress = read(`${work}/egress.json`);
assert.ok(egress.sourceReview.sourceReviewPassed && egress.sourceReview.issues.length === 0 && egress.parseErrors.length === 0);
const files = [
  ...Object.keys(checks.finalSourceSha256),
  "packages/cli/__tests__/unit/canonical-compaction-usage.test.js",
];
const finalSourceSha256 = Object.fromEntries(files.map(file => [file, sha(fs.readFileSync(file))]));
const artifacts = [];
fs.mkdirSync(`${directory}/raw`, { recursive: true });
function archive(source, label) {
  const bytes = fs.readFileSync(source);
  const compressed = gzipSync(bytes);
  const target = `${directory}/raw/${label}.gz`;
  fs.writeFileSync(target, compressed, { flag: "wx" });
  assert.equal(sha(gunzipSync(fs.readFileSync(target))), sha(bytes));
  artifacts.push({ path: target, source, bytes: compressed.length, sha256: sha(compressed), encoding: "gzip", contentBytes: bytes.length, contentSha256: sha(bytes) });
}
for (const name of fs.readdirSync(samples).filter(name => /^unsaved-.*\.(json|log)$/.test(name))) archive(`${samples}/${name}`, name);
for (const name of fs.readdirSync(work).filter(name => /\.(mjs|json|log)$/.test(name))) archive(`${work}/${name}`, `followup-${name}`);
archive(`${samples}/run.mjs`, "source-bound-test-runner.mjs");
archive(`${work}/before-8Gv7M8/receipt.json`, "adapter-before.json");
archive(`${work}/after-DCPlzb/receipt.json`, "adapter-after.json");
const review = {
  schema: "chainlesschain.compaction-live-host-review/v1",
  observedAt: new Date().toISOString(),
  sourceHeadBeforeMerge: "ebc2aef24fa00c4f55cb9d872369694e8e2cc095",
  mergedBranch: { name: "feature/cli130-compaction-followup", tip: "11e698755ca603cfd639f6857f87b5db6ae6ea9d", rootFollowup: "Headless/stream constructor marking, sub-agent host marking, repeated unsaved host journeys, bounded usage fixtures and explicit pre-provider budget-refusal assertions." },
  finalSourceSha256,
  adapterReproduction: { before: { status: before.status, basePreserved: false, nextRefreshError: before.nextRefreshError.code }, after: { status: after.status, basePreserved: true, nextRefreshError: null }, networkCalls: 0, provenance: "Both receipts name the pre-merge HEAD; actual before/after bytes are identified by their recorded file digests. The fix was not present in ebc2aef24f." },
  regression: { node2222: cli, node2212, native: { passed: 29, failed: 0, skipped: 0, exitCode: 0, sourcesStable: true, boundary: "Actual canonical adapter and killed-writer recovery; not complete CLI/IDE restart." }, changelog, overlap: "The 43 Node 22.12 cases and earlier smoke passes overlap the 231-case suite; do not add them as distinct tests." },
  preservedFailures: [
    { label: "unsaved-host-smoke", reason: "Two test expectations asked for a second compaction without enough message pairs; fixture corrected to use two real evidence-file reads per round without changing the production threshold." },
    { label: "unsaved-host-final-cli", reason: "Same single-read fixture expectations; 179 passed, 2 failed. Retained, not counted as a production fix failure." },
    { label: "unsaved-hermetic-before", reason: "Actual hermetic host base lost during canonical compaction; fixed in host constructors." },
    { label: "unsaved-subagent-before", reason: "Actual SubAgentContext base lost during canonical compaction; fixed in its constructor." },
    { label: "unsaved-host-merged-final-cli", reason: "224 passed / 7 failed. Old usage fixture retained a large repository host base that could not fit its 60% reduction target; pre-provider budget refusal correctly prevented the expected semantic call." },
    { label: "unsaved-host-usage-diagnostic", reason: "Two selected failures explicitly recorded safetyMarginTokens refusal before any provider call. Usage fixture now sets a bounded system prompt and projectMemory=false; all original accounting, cost, cancellation and rejection assertions remain." },
  ],
  invariants: ["Only privately identified host objects and private runtime nudges bypass the unsaved authority planner; copies/serialized fields do not carry identity.", "Retained host context consumes the existing input budget; oversized host policy rejects before summarizer/commit.", "Persistent-session authority/CAS validation and known/unknown usage settlement remain active.", "Three real local headless/stream/hermetic entry journeys each make three injected model callbacks and two committed canonical compactions; ordinary hosts refresh project rules/imported file Memory and hermetic hosts preserve their original policy."],
  pack: { version: "0.166.131", files: checks.packFiles, helperIncluded: true, dryRun: true, ignoreScripts: true, published: false },
  egress: { candidates: egress.networkCandidates.length, issues: 0, parseErrors: 0, paidReady: false, runtimeCoverageVerified: false },
  release: { publicCli: "0.166.130", publicKernel: "0.1.10", candidateCli: "0.166.131", candidateKernel: "0.1.11", candidateOpenVsx: "0.37.169", candidateJetbrains: "0.4.186", published: false, exactSourceGates: "Require new final-SHA matrices; ebc2aef24f runs were queued and are not gates for this merge." },
  remaining: ["New exact-source three-OS CI and OIDC child -> CLI -> IDE publication", "Real semantic model quality and billing", "Full REPL/dual-IDE, crash windows and cross-platform journeys", "Memory full latency SLO and remaining 11 deliverables", "Original verify-11 dispatch remains unresolved; no replay"],
  acceptance: { accepted: 34, total: 45, originalDispatch: "REQUEST_UNRESOLVED", paidReady: false, nativeAdmission: "NOT_ADMITTED", automaticPromotion: "HOLD", microsoft: "deferred" },
  artifacts,
};
fs.writeFileSync(`${directory}/review.json`, JSON.stringify(review, null, 2) + "\n", { flag: "wx" });
console.log(JSON.stringify({ cli: cli.passed, node2212: node2212.passed, native: 29, changelog: changelog.passed, artifacts: artifacts.length, directory }));
