import fs from "node:fs";
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
const directory = ".work/compaction-host-followup-20261029";
const remote = "https://github.com/chainlesschain/chainlesschain.git";
const actions = [];
function git(args, record = true) {
  const result = spawnSync("git", args, { encoding: "utf8", windowsHide: true, maxBuffer: 4 * 1024 * 1024 });
  assert.equal(result.status, 0, record ? result.stdout + result.stderr : "Origin identity lookup failed");
  if (record) actions.push({ args, exitCode: result.status, stdout: result.stdout || "", stderr: result.stderr || "" });
  return result.stdout.trim();
}
const origin = git(["remote", "get-url", "origin"], false);
const normalized = origin.replace(/^git@github\.com:/, "https://github.com/");
const parsed = new URL(normalized);
assert.equal(parsed.hostname.toLowerCase(), "github.com");
assert.equal(parsed.pathname.toLowerCase().replace(/\.git$/, "").replace(/\/$/, ""), "/chainlesschain/chainlesschain");
const ref = "refs/remotes/origin/feature/release130-public-docs";
const old = git(["rev-parse", ref]);
git(["merge-base", "--is-ancestor", old, "main"]);
assert.equal(git(["-c", "credential.helper=!gh auth git-credential", "ls-remote", "--heads", remote, "refs/heads/feature/release130-public-docs"]), "");
git(["-c", "credential.helper=!gh auth git-credential", "fetch", remote, "refs/heads/main:refs/remotes/origin/main"]);
git(["update-ref", "-d", ref, old]);
const status = git(["status", "--short", "--branch"]);
assert.equal(git(["rev-parse", "origin/main"]), git(["rev-parse", "main"]));
fs.writeFileSync(`${directory}/tracking-cleanup.json`, JSON.stringify({ observedAt: new Date().toISOString(), originRepositoryVerified: true, removedStaleTrackingRef: ref, oldTip: old, mergedAncestorVerified: true, remoteAbsenceVerified: true, actions, status }, null, 2) + "\n", { flag: "wx" });
console.log(JSON.stringify({ originMainSynced: true, removedStaleTrackingRef: ref, status }));
