import fs from "node:fs";
import path from "node:path";
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
const repo = "chainlesschain/chainlesschain";
const remote = "https://github.com/chainlesschain/chainlesschain.git";
const records = [];
let persistRecords = () => {};
function command(executable, args) {
  const result = spawnSync(executable, args, { encoding: "utf8", windowsHide: true, maxBuffer: 16 * 1024 * 1024, timeout: 60_000 });
  records.push({ executable, args, exitCode: result.status, stdout: result.stdout || "", stderr: result.stderr || "", error: result.error?.message || null });
  persistRecords();
  assert.equal(result.status, 0, result.stdout + result.stderr);
  return result.stdout.trim();
}
const source = command("git", ["rev-parse", "HEAD"]);
assert.equal(command("git", ["show", "-s", "--format=%s", "HEAD"]), "test(cli): verify executable memory restart journeys");
assert.equal(command("git", ["status", "--porcelain=v1"]), "");
const tag = `ci-cli131-${source.slice(0, 12)}`;
// This prefix matches none of the repository's publishing tag patterns:
// v-npm-*, cli-v*, ide-*-v*, python-agent-sdk-v*, v-packages-*, v[0-9]*.*.*,
// or v*.*.*. It names validation source only and is never retargeted.
assert.match(tag, /^ci-cli131-[a-f0-9]{12}$/);
const directory = path.resolve(".work/release131-immutable-validation", tag);
fs.mkdirSync(directory, { recursive: true });
const target = path.join(directory, "release-target.json");
const journal = fs.existsSync(target) ? JSON.parse(fs.readFileSync(target)) : { schema: "chainlesschain.release131-immutable-validation/v1", createdAt: new Date().toISOString(), source, validationTag: tag, state: "VALIDATION_INTENT", versions: { kernel: "0.1.11", cli: "0.166.131", openVsx: "0.37.169", jetbrains: "0.4.186" }, releaseTagCreated: false, published: false, microsoft: "deferred", requiredOrder: "verified child npm package -> CLI OIDC/public readback -> IDE/public readback -> clients", dispatches: [], original129Dispatch: "REQUEST_UNRESOLVED; not replayed" };
assert.equal(journal.source, source);
const save = () => fs.writeFileSync(target, JSON.stringify({ ...journal, lastUpdatedAt: new Date().toISOString(), records }, null, 2) + "\n");
persistRecords = save;
save();
const existing = spawnSync("git", ["rev-parse", "--verify", `refs/tags/${tag}`], { encoding: "utf8", windowsHide: true });
if (existing.status === 0) assert.equal(existing.stdout.trim(), source);
else command("git", ["tag", tag, source]);
const beforeRefs = command("git", ["-c", "credential.helper=!gh auth git-credential", "ls-remote", remote, "refs/heads/main", `refs/tags/${tag}`]);
const before = Object.fromEntries(beforeRefs.split(/\r?\n/).filter(Boolean).map(line => line.split(/\s+/)).map(([sha, ref]) => [ref, sha]));
if (before[`refs/tags/${tag}`]) assert.equal(before[`refs/tags/${tag}`], source);
if (before["refs/heads/main"] !== source || before[`refs/tags/${tag}`] !== source)
  command("git", ["-c", "credential.helper=!gh auth git-credential", "-c", "http.version=HTTP/1.1", "-c", "http.postBuffer=52428800", "push", "--atomic", remote, "refs/heads/main:refs/heads/main", `refs/tags/${tag}:refs/tags/${tag}`]);
const remoteRef = command("git", ["-c", "credential.helper=!gh auth git-credential", "ls-remote", remote, `refs/tags/${tag}`]);
assert.equal(remoteRef.split(/\s+/)[0], source);
journal.validationTagCreated = true;
journal.validationTagPushed = true;
journal.state = "VALIDATION_REF_FROZEN";
save();
const previousPath = ".work/release131-final-source/release-target.json";
const previous = JSON.parse(fs.readFileSync(previousPath));
assert.equal(previous.source, "e7ab05ceb3fb5e4dda57e233f80a16a0d5619b75");
if (!previous.supersededBy) {
  fs.writeFileSync(path.join(directory, "previous-release-target.json"), JSON.stringify(previous, null, 2) + "\n", { flag: "wx" });
  previous.state = "SUPERSEDED_BEFORE_PUBLICATION";
  previous.supersededAt = new Date().toISOString();
  previous.supersededBy = { source, validationTag: tag, journal: target, reason: "Include the four actual executable CLI restart E2E scenarios in the exact-source cloud gates, and isolate matrices from subsequent main pushes." };
  fs.writeFileSync(previousPath, JSON.stringify(previous, null, 2) + "\n");
}
for (const [name, workflow] of [["CLI CI", "cli-ci.yml"], ["CLI Strict Sandbox", "cli-strict-sandbox.yml"], ["Context Memory Kernel CI", "context-memory-kernel.yml"], ["IDE Extensions", "ide-extensions.yml"]]) {
  const existingDispatch = journal.dispatches.find(dispatch => dispatch.workflow === workflow);
  if (existingDispatch) {
    assert.equal(existingDispatch.state, "request_accepted", "Never replay an unknown dispatch; inspect its recorded response first.");
    continue;
  }
  const dispatch = { name, workflow, state: "intent_recorded", plannedAt: new Date().toISOString(), ref: tag, source };
  journal.dispatches.push(dispatch);
  save();
  const args = ["workflow", "run", workflow, "--repo", repo, "--ref", tag];
  if (workflow === "ide-extensions.yml") args.push("-f", "publish_vscode_marketplace=false");
  const response = spawnSync("gh", args, { encoding: "utf8", windowsHide: true, timeout: 60_000, maxBuffer: 4 * 1024 * 1024 });
  Object.assign(dispatch, { endedAt: new Date().toISOString(), exitCode: response.status, signal: response.signal, stdout: response.stdout || "", stderr: response.stderr || "", error: response.error?.message || null, state: response.status === 0 ? "request_accepted" : "request_failed_or_unknown" });
  save();
  assert.equal(response.status, 0, response.stdout + response.stderr);
}
const runs = JSON.parse(command("gh", ["run", "list", "--repo", repo, "--commit", source, "--limit", "50", "--json", "databaseId,workflowName,headSha,headBranch,event,status,conclusion,url,createdAt,updatedAt"]));
journal.runs = runs;
journal.state = "GATES_PENDING";
save();
console.log(JSON.stringify({ source, validationTag: tag, acceptedDispatches: journal.dispatches.length, gates: runs.filter(run => run.event === "workflow_dispatch" && run.headBranch === tag).map(({ databaseId, workflowName, status }) => ({ databaseId, workflowName, status })), published: false }));
