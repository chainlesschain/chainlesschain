import fs from "node:fs";
import path from "node:path";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { gzipSync, gunzipSync } from "node:zlib";
const work = ".work/cli-memory-restart-20261029";
const directory = ".work/release131-immutable-validation/ci-cli131-7a5d38d151d4";
const target = "docs/research/cli/evidence/cli-memory-executable-restart-2026-10-29";
const read = file => JSON.parse(fs.readFileSync(file));
const sha = bytes => createHash("sha256").update(bytes).digest("hex");
const status = read(`${directory}/gate-status.json`);
const journal = read(`${directory}/release-target.json`);
assert.equal(status.source, "7a5d38d151d437f94f8c223dec1fbca52a44da5b");
assert.equal(status.validationTag, journal.validationTag);
assert.equal(status.gates.length, 4);
assert.ok(status.gates.every(run => run.headSha === status.source && run.headBranch === status.validationTag && run.event === "workflow_dispatch"));
assert.ok(journal.dispatches.every(dispatch => dispatch.state === "request_accepted"));
const toolEvidence = [];
for (const label of ["full-node2222", "full-node2212"])
  for (const name of ["headless-supersede", "headless-delete", "stream-supersede", "stream-delete"]) {
    const run = read(`${work}/${label}/${name}.json`);
    const events = run.processes[1].stdout.split("\n").filter(Boolean).map(JSON.parse);
    const results = events.filter(event => event.type === "tool_result");
    assert.equal(results.length, 2);
    assert.ok(results.every(event => event.tool === "read_file" && event.is_error === false));
    assert.ok(JSON.stringify(results).includes("a-0:") && JSON.stringify(results).includes("b-0:"));
    toolEvidence.push({ label, name, successfulReadTools: 2, resultCharacters: results.map(event => JSON.stringify(event.result).length), bothFilesObserved: true, boundary: "Existing read_file bounds remain active; the test does not claim every source byte was returned." });
  }
fs.writeFileSync(`${work}/read-tool-evidence.json`, JSON.stringify({ observedAt: new Date().toISOString(), cases: toolEvidence }, null, 2) + "\n", { flag: "wx" });
const artifacts = [];
for (const [source, name] of [
  ...["release-target.json", "previous-release-target.json", "duplicate-validation-cleanup.json", "gate-status.json"].map(name => [`${directory}/${name}`, `validation-${name}`]),
  ...["freeze.mjs", "frozen-status.mjs", "push-interrupted.json", "probe-cleanup.json", "read-tool-evidence.json", "write-progress.mjs", "finalize.mjs"].map(name => [`${work}/${name}`, `post-${name}`]),
]) {
  const bytes = fs.readFileSync(source);
  const compressed = gzipSync(bytes);
  const destination = `${target}/raw/${name}.gz`;
  fs.writeFileSync(destination, compressed, { flag: "wx" });
  assert.equal(sha(gunzipSync(fs.readFileSync(destination))), sha(bytes));
  artifacts.push({ path: destination, source, bytes: compressed.length, sha256: sha(compressed), encoding: "gzip", contentBytes: bytes.length, contentSha256: sha(bytes) });
}
const receipt = { schema: "chainlesschain.cli-memory-restart-freeze/v1", observedAt: new Date().toISOString(), source: status.source, validationTag: status.validationTag, pushedToMain: true, immutableValidationRef: true, publishingTag: false, requiredGates: status.gates, duplicatePushValidationCleanup: status.cancellations, duplicateFinalStates: status.finalRuns.filter(run => status.cancellations.some(item => item.id === run.databaseId)), old131Candidate: { source: "e7ab05ceb3fb5e4dda57e233f80a16a0d5619b75", state: "SUPERSEDED_BEFORE_PUBLICATION", evidenceRetained: true }, releaseTagCreated: false, published: false, microsoft: "deferred", original129Dispatch: "REQUEST_UNRESOLVED; not replayed", artifacts };
fs.writeFileSync(`${target}/immutable-validation.json`, JSON.stringify(receipt, null, 2) + "\n", { flag: "wx" });
const reportPath = "docs/research/cli-ide-cli-memory-restart-progress-2026-10-29.md";
let report = fs.readFileSync(reportPath, "utf8");
report += `\n本批源码已随 \`${status.source}\` 提交并推送 main；验证引用 \`${status.validationTag}\` 指向该准确提交，创建后不重定向。该引用不匹配仓库任何发布标签模式。独立 .131 journal 改为绑定此 SHA，旧 e7ab 候选标记 SUPERSEDED_BEFORE_PUBLICATION 并保留原门禁 / 回执，不移用旧源码的部分通过结果。\n\n| 固定源码完整门禁 | Run ID | 回读状态 |\n| --- | --- | --- |\n`;
for (const run of status.gates) report += `| ${run.workflowName} | [${run.databaseId}](${run.url}) | ${run.status}${run.conclusion ? " / " + run.conclusion : ""} |\n`;
report += "\n四个工作流均按固定引用仅派发一次；IDE 明确 publish_vscode_marketplace=false。确认四份准确源码运行存在后，取消同 SHA / main push 自动产生的重复 CLI CI 40825988659 和 Strict 40825988560；保留固定引用的完整平台矩阵，没有删减任何用例或发行门禁。后续主线提交不会取消这组固定引用验证。初次 Git 原子推送发生连接重置，远端读回确认 main 仍为 4d4478、标签不存在，才以 HTTP/1.1 重试；两引用成功到达后才开始工作流派发。原失败与核对过程保留。\n\n[固定引用、派发及重复验证清理回执](./cli/evidence/cli-memory-executable-restart-2026-10-29/immutable-validation.json)另存独立 journal、请求响应、准确 run ID 与 read_file 实际成功结果；四项完整门禁尚未全部完成，没有发布子包、CLI、IDE 或客户端。\n";
fs.writeFileSync(reportPath, report);
const tablePath = "docs/research/cli-ide-codex-claude-gap-review-2026-10-27.md";
let table = fs.readFileSync(tablePath, "utf8");
assert.ok(!table.includes("第四十三批收尾："));
const paragraph = `第四十三批收尾：源码 \`7a5d38d151\` 已推送 main，固定验证引用 \`${status.validationTag}\` 已建立；CLI CI 40825996255、Strict 40826001600、Kernel 40826006659、IDE 40826012460 均绑定此 SHA。四项完整门禁尚未完成；同 SHA 的两项重复 main push 验证已取消，保留固定引用全矩阵。旧 e7ab .131 journal 标记发布前 superseded，不复用其门禁，不创建发行标签。见[固定验证回执](./cli/evidence/cli-memory-executable-restart-2026-10-29/immutable-validation.json)。\n\n`;
table = table.replace("第四十三批补充：", paragraph + "第四十三批补充：");
const rows = table.split("\n");
const index = rows.findIndex(row => row.startsWith("| `.131 / .169 / .186`"));
assert.ok(index >= 0);
rows[index] = "| `.131 / .169 / .186` 新源码候选 | **配对 / 本地验证完成，固定源码全矩阵进行中，尚未发布** | [第四十三批](./cli-ide-cli-memory-restart-progress-2026-10-29.md)：源码 7a5d38d151 与固定验证引用绑定四项完整工作流；真实 CLI 四条恢复旅程两版 Node 各 4/4，旧 e7ab 候选已 superseded；Kernel .11 → CLI .131 → IDE .169 / .186 仍须逐级公开核验和 OIDC 发布 |";
fs.writeFileSync(tablePath, rows.join("\n"));
console.log(JSON.stringify({ source: status.source, validationTag: status.validationTag, gates: status.gates.length, artifacts: artifacts.length, successfulReadJourneysVerified: toolEvidence.length, published: false }));
