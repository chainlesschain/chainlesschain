import fs from "node:fs";
import path from "node:path";
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
const [label] = process.argv.slice(2);
assert.match(label, /^[a-z0-9-]+$/);
const work = path.resolve(".work/cli-memory-restart-20261029");
const output = { observedAt: new Date().toISOString(), source: "e7ab05ceb3fb5e4dda57e233f80a16a0d5619b75", runs: [] };
for (const id of [40822738893, 40822738898, 40822738878, 40822931865]) {
  const meta = spawnSync("gh", ["api", `repos/chainlesschain/chainlesschain/actions/runs/${id}`], { encoding: "utf8", windowsHide: true, timeout: 30_000, maxBuffer: 8 * 1024 * 1024 });
  assert.equal(meta.status, 0, meta.stderr);
  const run = JSON.parse(meta.stdout);
  assert.equal(run.head_sha, output.source);
  const jobs = [];
  for (let page = 1;; page++) {
    const result = spawnSync("gh", ["api", `repos/chainlesschain/chainlesschain/actions/runs/${id}/jobs?per_page=100&page=${page}`], { encoding: "utf8", windowsHide: true, timeout: 30_000, maxBuffer: 16 * 1024 * 1024 });
    assert.equal(result.status, 0, result.stderr);
    const data = JSON.parse(result.stdout);
    jobs.push(...data.jobs);
    if (jobs.length >= data.total_count) break;
  }
  output.runs.push({ id, name: run.name, headSha: run.head_sha, status: run.status, conclusion: run.conclusion, attempt: run.run_attempt, url: run.html_url, jobs: jobs.map(job => ({ id: job.id, name: job.name, status: job.status, conclusion: job.conclusion, labels: job.labels, runnerName: job.runner_name, startedAt: job.started_at, completedAt: job.completed_at })) });
}
fs.writeFileSync(path.join(work, `${label}.json`), JSON.stringify(output, null, 2) + "\n", { flag: "wx" });
console.log(JSON.stringify(output.runs.map(run => ({ id: run.id, name: run.name, status: run.status, conclusion: run.conclusion, jobs: run.jobs.reduce((counts, job) => { const state = job.conclusion || job.status; counts[state] = (counts[state] || 0) + 1; return counts; }, {}), failures: run.jobs.filter(job => ["failure", "timed_out", "startup_failure"].includes(job.conclusion)) }))));
