import fs from "node:fs";
import assert from "node:assert/strict";
const evidence = JSON.parse(fs.readFileSync("docs/research/cli/evidence/cli-memory-executable-restart-2026-10-29/review.json"));
assert.ok(evidence.runs.every(run => run.passed === 4 && run.failed === 0 && run.sourcesStable));
const link = "[真实 CLI 独立进程恢复记录](./cli-ide-cli-memory-restart-progress-2026-10-29.md)";
const paragraph = `第四十三批补充：真实 CLI 可执行程序的四条压缩 / 独立进程恢复旅程在 Node 22.12、22.22 各 4/4 通过，1672 份来源前后摘要稳定。普通 headless 正常退出，流式 writer 在结算成功并等待输入时实际终止；独立 mutator 完成 supersede / delete 后，新 CLI 进程只召回当前许可记忆，并读取更新后的规则及导入文件 Memory。原压缩回执和历史事件前缀不变，三次本地协议请求各结算一次；未用强制压缩或注入运行时适配器。模型服务为隔离的本机协议夹具，不能增加真实任务 / 费用验收数。新测试纳入既有三系统 E2E 分片；新准确提交仍须自己的完整门禁，34/45 和原未知派发状态保留。见${link}。\n\n`;
const tablePath = "docs/research/cli-ide-codex-claude-gap-review-2026-10-27.md";
let table = fs.readFileSync(tablePath, "utf8");
assert.ok(!table.includes("第四十三批补充："));
table = table.replace("第四十二批收尾：", paragraph + "第四十二批收尾：");
table = table.replace("## 实施批次记录\n\n", "## 实施批次记录\n\n" + paragraph.replace("第四十三批补充：", "第四十三批更新（2026-10-29）："));
const rows = table.split("\n");
const index = rows.findIndex(row => row.startsWith("| 4.8 / 5") && row.includes("Memory 独立进程压缩与恢复"));
assert.ok(index >= 0);
rows[index] = rows[index].replace("完整 CLI / 双 IDE 进程重启、其他崩溃窗口", "其他 CLI / REPL 崩溃窗口、双 IDE 及跨平台恢复");
rows.splice(index + 1, 0, "| 4.8 / 5 | 真实 CLI 可执行程序压缩与独立重启 | **四条本机旅程通过；整体部分完成** | [第四十三批](./cli-ide-cli-memory-restart-progress-2026-10-29.md)：Node 22.12 / 22.22 各 4/4；实际 argv / bootstrap / HTTP / 工具 / canonical / JSONL，普通及流式入口 × supersede / delete；实际终止空闲流式 writer，用量与压缩不重放 | 完整三系统 E2E、真实语义模型及账单、交互 REPL / 双 IDE、未结算调用及其他崩溃窗口、完整 SLO；未发布、不增加 34/45 |");
fs.writeFileSync(tablePath, rows.join("\n"));
fs.writeFileSync("docs/research/cli-ide-cli-memory-restart-progress-2026-10-29.md", `# 真实 CLI 压缩与独立进程恢复

日期：2026-10-29。第四十三批，承接[原生适配器恢复](./cli-ide-memory-process-restart-progress-2026-10-29.md)和[非持久宿主规则修复](./cli-ide-compaction-live-host-progress-2026-10-29.md)。直接修改 main，Microsoft 渠道继续暂缓。

| 项目 | 本批完成情况 | 证据与边界 |
| --- | --- | --- |
| 实际 CLI 入口 | **四条旅程通过** | 使用 bin/chainlesschain.js，经真实 argv、配置 / DB bootstrap、HTTP Ollama 适配器、read_file、默认自动压缩、JSONL 持久化与 --resume；普通 headless、stream 各覆盖 supersede / delete。未替换运行时 chatFn、bootstrap 或压缩器。 |
| writer 生命周期 | **退出 / 终止后才恢复** | 普通 headless 自然退出 0；stream 首轮成功并结算后，确认仍在等待 stdin，再实际 kill 并等待 close。覆盖已结算空闲点，不覆盖请求进行中和任意写入窗口。 |
| 独立 Memory 更新 | **独立 mutator / reader 通过** | seed、writer、inspect、mutator、reader、inspect 为独立 Node 进程。writer / mutator / reader PID 不同；原 revision 3，supersede 后 6，delete 后 8；新 provider plan 使用当前 revision。 |
| 恢复内容与隔离 | **当前记忆和文件上下文通过** | 新进程看到 current，supersede 时另含 successor；old、其他 agent scope 和其他 provider sink 均未进入请求。项目规则及导入文件 Memory 读取新内容，不沿用旧基础上下文。 |
| 幂等与用量 | **原回执不变，无重放** | 原 compact event 的 hash 和 canonical data 逐字段相同；原全部事件 hash 是恢复后事件的前缀。每旅程恰好三次本机协议请求、三个唯一 started / settled call ID；无 unknown 用量或重复压缩。计数为夹具提供的已知用量，不是实际账单测量。 |
| 临时召回与持久历史 | **限定投影验证通过** | 独立读取的 verified durable messages 在重启前后均不含召回、文件 Memory 和项目规则标记；没有声称擦除全部历史物理副本。 |
| 两版 Node 完整套件 | **各 4/4，零失败 / 跳过，退出 0** | Windows Node 22.12 / 22.22；1672 份 CLI、Kernel、core-env、session-core 来源 / 锁文件及新测试前后摘要一致。同样四条旅程跨 Node 重跑，不计为八种独立场景。 |
| 既有门禁接入 | **测试自动发现，云端未完成** | 新 E2E 文件由现有 vitest.e2e.config.js 和三系统 CLI CI E2E 分片发现；不改平台矩阵、预算或来源审计。推送后须以新准确提交完成全部门禁，不把原 e7ab 的部分通过结果转移到新源码。 |
| 生产改动与发行 | **无新增运行时代码，尚未发布** | 本批增加测试 / 证据，保持 CLI .131 / Kernel .11 / IDE .169、.186 候选；pack 运行时代码和公开 .130 配对不变。新候选将使用独立、不可移动的验证引用等待完整门禁。 |

原探索失败保留：第一份夹具显式覆盖 systemPrompt，却预期内置 rules.md 仍被加载；移除覆盖后，8K 模型窗口因默认宿主 / 工具 / 输出预留而按 input_budget 丢弃可选 Memory。正式旅程使用现有 32K 模型目录项与两份各 200 行的真实文件制造输入压力，没有强制 planner 选择 Memory、调整预算、修改压缩触发器或使用 bare 模式。

本机服务仅实现确定性的模型协议响应，每次返回 input_tokens=10 / output_tokens=5；所有子进程使用精简环境，未继承真实 provider 凭据、Evolution 部署、NODE_OPTIONS、Vitest 模型适配器或外部 IDE 端点。真实模型语义质量、费用收益、双 IDE / 交互 REPL、三系统完整旅程及其他崩溃窗口继续验收。累计真实交付仍为 **34/45**，原 verify-11 未知请求未重放，NOT_PAID_READY / NOT_ADMITTED / HOLD 保留。

[本批证据](./cli/evidence/cli-memory-executable-restart-2026-10-29/review.json)保存每个子进程的实际 argv / PID / 退出码、原始协议请求及 stdout / stderr、前后 canonical 回执、Memory revision、用量行、完整来源摘要和两个探索失败；gzip 归档逐一核对压缩 / 解压 SHA-256。
`, { flag: "wx" });
console.log(JSON.stringify({ tablePath, uniqueJourneys: 4, passedEachNode: 4 }));
