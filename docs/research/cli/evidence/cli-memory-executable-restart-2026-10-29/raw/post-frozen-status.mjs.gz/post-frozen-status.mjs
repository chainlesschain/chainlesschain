import fs from "node:fs";
import path from "node:path";
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
const directory = path.resolve(".work/release131-immutable-validation/ci-cli131-7a5d38d151d4");
const target = path.join(directory, "release-target.json");
const journal = JSON.parse(fs.readFileSync(target));
const actions = [];
const gh = args => {
  const result = spawnSync("gh", args, { encoding: "utf8", windowsHide: true, timeout: 60_000, maxBuffer: 16 * 1024 * 1024 });
  actions.push({ args, exitCode: result.status, stdout: result.stdout || "", stderr: result.stderr || "" });
  assert.equal(result.status, 0, result.stdout + result.stderr);
  return result.stdout.trim();
};
const list = () => JSON.parse(gh(["run", "list", "--repo", "chainlesschain/chainlesschain", "--commit", journal.source, "--limit", "50", "--json", "databaseId,workflowName,headSha,headBranch,event,status,conclusion,url,createdAt,updatedAt"]));
const runs = list();
const gates = journal.dispatches.map(dispatch => {
  const run = runs.find(run => run.workflowName === dispatch.name && run.headBranch === journal.validationTag && run.event === "workflow_dispatch");
  assert.ok(run, dispatch.name);
  assert.equal(run.headSha, journal.source);
  assert.ok(run.status !== "completed" || run.conclusion === "success");
  return run;
});
assert.equal(gates.length, 4);
const cancellations = [];
for (const run of runs.filter(run => run.event === "push" && run.headBranch === "main" && ["CLI CI", "CLI Strict Sandbox"].includes(run.workflowName) && run.status !== "completed")) {
  const current = JSON.parse(gh(["api", `repos/chainlesschain/chainlesschain/actions/runs/${run.databaseId}`]));
  assert.equal(current.head_sha, journal.source);
  assert.equal(current.head_branch, "main");
  assert.equal(current.event, "push");
  if (current.status === "completed") continue;
  const item = { id: run.databaseId, name: run.workflowName, source: journal.source, purpose: "Duplicate push validation only; exact same SHA is validated by the four immutable-ref workflows.", state: "intent_recorded", observedAt: new Date().toISOString() };
  cancellations.push(item);
  fs.writeFileSync(path.join(directory, "duplicate-validation-cleanup.json"), JSON.stringify({ cancellations, actions }, null, 2) + "\n");
  gh(["run", "cancel", String(run.databaseId), "--repo", "chainlesschain/chainlesschain"]);
  item.state = "cancellation_accepted";
  fs.writeFileSync(path.join(directory, "duplicate-validation-cleanup.json"), JSON.stringify({ cancellations, actions }, null, 2) + "\n");
}
const finalRuns = list();
journal.runs = finalRuns;
journal.lastObservedAt = new Date().toISOString();
journal.allRequiredWorkflowsCompletedSuccessfully = gates.every(run => run.status === "completed" && run.conclusion === "success");
fs.writeFileSync(target, JSON.stringify(journal, null, 2) + "\n");
fs.writeFileSync(path.join(directory, "gate-status.json"), JSON.stringify({ observedAt: journal.lastObservedAt, source: journal.source, validationTag: journal.validationTag, gates, finalRuns, cancellations, actions, published: false, releaseTagCreated: false }, null, 2) + "\n", { flag: "wx" });
console.log(JSON.stringify({ source: journal.source, tag: journal.validationTag, gates: gates.map(({ databaseId, workflowName, status, conclusion }) => ({ databaseId, workflowName, status, conclusion })), duplicateCancellations: cancellations.map(({ id, name, state }) => ({ id, name, state })), published: false }));
