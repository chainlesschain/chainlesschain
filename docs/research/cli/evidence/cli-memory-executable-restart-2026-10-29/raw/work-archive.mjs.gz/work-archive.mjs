import fs from "node:fs";
import path from "node:path";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { gzipSync, gunzipSync } from "node:zlib";
const work = ".work/cli-memory-restart-20261029";
const target = "docs/research/cli/evidence/cli-memory-executable-restart-2026-10-29";
const sha = bytes => createHash("sha256").update(bytes).digest("hex");
const read = file => JSON.parse(fs.readFileSync(file));
const runs = [];
for (const label of ["full-node2222", "full-node2212"]) {
  const directory = `${work}/${label}`;
  const tests = read(`${directory}/tests.json`);
  const process = read(`${directory}/process.json`);
  assert.ok(tests.success && tests.numPassedTests === 4 && tests.numFailedTests === 0 && tests.numPendingTests === 0);
  assert.ok(process.exitCode === 0 && process.sourcesStable);
  for (const [file, digest] of Object.entries(process.sourceAfter)) assert.equal(sha(fs.readFileSync(file)), digest, file);
  const cases = [];
  for (const name of ["headless-supersede", "headless-delete", "stream-supersede", "stream-delete"]) {
    const receipt = read(`${directory}/${name}.json`);
    assert.ok(receipt.passed);
    assert.equal(receipt.requests.length, 3);
    assert.deepEqual(receipt.after.compactEvents, receipt.before.compactEvents);
    assert.equal(receipt.after.compactEvents.length, 1);
    assert.equal(receipt.after.usage.length, 3);
    assert.equal(receipt.after.unknownUsage, 0);
    assert.ok(receipt.mutation.revision > receipt.before.revision);
    assert.ok(receipt.before.durableMarkersAbsent && receipt.after.durableMarkersAbsent);
    const writer = receipt.processes[1];
    const reader = receipt.processes[4];
    assert.equal(reader.code, 0);
    if (receipt.entry === "stream") assert.ok(writer.signal !== null || writer.code !== 0);
    else assert.equal(writer.code, 0);
    cases.push({ name, writerPid: writer.pid, mutationPid: receipt.mutation.pid, readerPid: reader.pid, writerCode: writer.code, writerSignal: writer.signal, readerCode: reader.code, initialRevision: receipt.before.revision, currentRevision: receipt.after.revision, protocolRequests: 3, compactEventsBefore: 1, compactEventsAfter: 1, usageRows: 3, noDuplicateUsageCallIds: true, durableRecallAndRuleMarkersAbsent: true });
  }
  runs.push({ label, executable: process.executable, node: process.node, sourceHead: process.sourceHead, exitCode: process.exitCode, sourceFiles: Object.keys(process.sourceAfter).length, sourcesStable: process.sourcesStable, passed: 4, failed: 0, skipped: 0, cases });
}
const artifacts = [];
fs.mkdirSync(`${target}/raw`, { recursive: true });
function archive(source, label) {
  const bytes = fs.readFileSync(source);
  const compressed = gzipSync(bytes);
  const destination = `${target}/raw/${label}.gz`;
  fs.writeFileSync(destination, compressed, { flag: "wx" });
  assert.equal(sha(gunzipSync(fs.readFileSync(destination))), sha(bytes));
  artifacts.push({ path: destination, source, bytes: compressed.length, sha256: sha(compressed), encoding: "gzip", contentBytes: bytes.length, contentSha256: sha(bytes) });
}
for (const name of ["smoke", "default-host-smoke", "full-window-smoke", "full-node2222", "full-node2212"])
  for (const file of fs.readdirSync(`${work}/${name}`)) archive(`${work}/${name}/${file}`, `${name}-${file}`);
for (const file of fs.readdirSync(work).filter(file => /\.(mjs|json)$/.test(file))) archive(`${work}/${file}`, `work-${file}`);
for (const file of ["packages/cli/__tests__/fixtures/cli-memory-restart-state.mjs", "packages/cli/__tests__/e2e/compaction-memory-restart-e2e.test.js"]) archive(file, path.basename(file));
const review = {
  schema: "chainlesschain.cli-memory-executable-restart/v1",
  observedAt: new Date().toISOString(),
  sourceHeadBeforeCommit: "4d4478f4d86102dc9970a9fb01a8fec9f588a359",
  scope: "Actual bin/chainlesschain.js executable through argument parsing, ordinary bootstrap, local HTTP provider protocol, tools, automatic canonical compaction, durable JSONL, independent Memory mutation and new CLI process resume. No production transport or compactor was mocked or replaced.",
  runtimeSourceChanged: false,
  runtimeSourceSha256: read(`${work}/full-node2222/process.json`).sourceAfter,
  runs,
  uniqueJourneys: 4,
  overlap: "The same four journeys run on both Node versions; do not count eight distinct scenarios or add prior smoke counts.",
  modelProtocol: { provider: "ollama", model: "qwen2.5:7b", contextWindowTokens: 32768, loopbackOnly: true, protocolRequestsPerJourney: 3, syntheticUsagePerRequest: { input_tokens: 10, output_tokens: 5 }, paidModelRequests: 0, semanticModelRequests: 0, boundary: "Protocol replies and token counts are deterministic fixture data. Automatic compaction is real but does not prove semantic summary quality or real billing." },
  invariants: ["Default project instructions and imported file Memory are loaded; no system-prompt override and no forced compaction trigger/budget.", "Two real read_file calls create sufficient input pressure for one automatic canonical compaction.", "Headless writer exits normally; stream writer is killed after settled success while waiting for new stdin. Reader starts only after writer close and independent mutation completion.", "A new process recalls current/successor Memory and re-reads updated project rules/imported file Memory; old and forbidden scope/sink records are absent from provider messages.", "Canonical compact-event hash and data remain identical after resume; the original event-hash sequence is a prefix of the final sequence.", "Exactly three started model call IDs match three unique settled usage rows, with no unknown usage, repeated compaction or repeated provider request.", "Verified durable message projection excludes temporary recall/project instruction markers; this is not an assertion that every historical physical copy has been erased."],
  preservedExploration: [
    { label: "smoke", passed: 0, failed: 1, skipped: 3, cause: "Fixture expected built-in .chainlesschain/rules.md after an explicit system-prompt override, which intentionally replaces that built-in base. Removed override to exercise the real default host." },
    { label: "default-host-smoke", passed: 0, failed: 1, skipped: 3, cause: "8K model window dropped optional Memory with input_budget after default host/tool/output reservations; planner behavior retained. Standard 32K model plus larger actual files provides the intended admitted-Memory compaction journey." },
  ],
  ci: { integration: "Existing three-OS CLI CI e2e shards discover the new test through vitest.e2e.config.js. No workflow requirements, platform matrix, budgets or allowlists were relaxed.", previousFrozenSource: "e7ab05ceb3fb5e4dda57e233f80a16a0d5619b75", previousObserved: read(`${work}/cloud-before-new-tests.json`), next: "New exact-source candidate must include the tests; preserve a validation-only immutable ref so subsequent main work cannot cancel its matrices. Publishing remains gated by the full required matrices and child -> CLI -> IDE order." },
  remaining: ["Exact-source full Linux/Windows/macOS matrices", "Semantic model quality and actual billing", "Interactive REPL and real dual-IDE restart", "All crash windows including in-flight/unknown effects", "Full Memory latency SLO", "Eleven real deliverables and unresolved original verify-11 dispatch"],
  acceptance: { accepted: 34, total: 45, original129Dispatch: "REQUEST_UNRESOLVED", paidReady: false, nativeAdmission: "NOT_ADMITTED", automaticPromotion: "HOLD", microsoft: "deferred", published: false },
  artifacts,
};
fs.writeFileSync(`${target}/review.json`, JSON.stringify(review, null, 2) + "\n", { flag: "wx" });
console.log(JSON.stringify({ directory: target, node2222: 4, node2212: 4, uniqueJourneys: 4, artifacts: artifacts.length, runtimeSourceChanged: false }));
