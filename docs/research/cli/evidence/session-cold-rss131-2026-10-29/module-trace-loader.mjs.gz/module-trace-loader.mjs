import { appendFileSync } from "node:fs";
export async function load(url, context, nextLoad) {
  const result = await nextLoad(url, context);
  if (url.startsWith("file:")) {
    appendFileSync(process.env.CC_DIAG_MODULE_TRACE, JSON.stringify({ url, bytes: result.source?.byteLength ?? Buffer.byteLength(result.source || "") }) + "\n");
  }
  return result;
}
